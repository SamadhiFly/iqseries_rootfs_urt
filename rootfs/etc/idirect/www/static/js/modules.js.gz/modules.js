define( 'modules', window.nmsweb.__modules, function () {
    return nmsweb.__modules.map( function ( module ) {
        return module.replace( 'module/', '' );
    } );
} );