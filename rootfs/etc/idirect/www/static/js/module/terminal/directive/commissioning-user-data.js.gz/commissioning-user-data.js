define( [ 'module/terminal',
'text!module/terminal/conf/general.json',
'templates/nmsweb/module/terminal/directive/commissioning-user-data.tpl',
'module/terminal/service/terminal-streaming-buffer',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form'],
    function ( terminal, strGeneralConfig, template ) {
        'use strict';
        terminal.directive( 'commissioningUserData', [ '$rootScope', 'TerminalStreamingBuffer', 'ToolResource', 'NmswebForm', '$http', function ( $rootScope, TerminalStreamingBuffer, ToolResource, NmswebForm, $http ) {
            return {
                restrict: 'E',
                template: template,
                replace: true,
                scope: {
                    userDataConfiguration: '=?',
                    valid: '=?'
                },
                compile: function () {
                    return {
                        pre: function preLink( scope, element ) {
                            var generalConfig = $.parseJSON( strGeneralConfig ),
                                formOptions = {
                                "layout": "layouts/terminal/tools/commissioning-user-data",
                                "hook": "module/terminal/hook/commissioning-user-data"
                            };
                            if(!scope.userDataConfiguration) {
                                    scope.userDataConfiguration = {};
                            }
                            if ( !element.find( 'form' ).hasClass( 'ng-invalid' ) ) {
                                scope.valid = true;
                            }
                            scope.$watch( function () {
                                return element.find( 'form' ).hasClass( 'ng-invalid' );
                            }, function ( newVal, oldVal ) {
                                scope.valid = !newVal;
                            } );
                            formOptions.resource = new ToolResource( 'commissioning-user-data' );
                            formOptions.name = 'commissioning-user-data';
                            formOptions.viewMode = false;
                            scope.title = formOptions.name;
                            scope.form = new NmswebForm( formOptions );
                            scope.form.actions = [];
                            scope.form.model = angular.extend(scope.userDataConfiguration);
                            scope.userDataConfiguration = scope.form.model;
                        },
                        post: function () {}
                    }
                }
            };
    } ] );
} );
