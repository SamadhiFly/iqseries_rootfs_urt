define(['module/terminal',
  'text!module/terminal/conf/general.json'],
  function(terminal, strGeneralConfig) {
    'use strict';
    terminal.directive('nmswebHtml', ['$http', '$compile', function($http, $compile) {
      var generalConfig = $.parseJSON( strGeneralConfig );
      return {
        restrict: 'E',
        replace: true,
        require: '?ngModel',
        scope: {
            nmswebOptions: '=',
            model: '=ngModel'
        },
        compile: function() {
            return {
                pre: function preLink(scope, element) {
                  $http.get( '/static/' + scope.nmswebOptions.fieldDetails.template ).then( function ( result ) {
                      var htmlTemplate = result.data;
                      element.append($compile(htmlTemplate)(scope));
                  } );
                }
            };
        }
      };
    }]);
  });
