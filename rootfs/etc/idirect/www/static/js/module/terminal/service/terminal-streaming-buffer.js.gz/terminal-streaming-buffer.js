define( [ 'module/terminal',
  'text!module/terminal/conf/terminal-streaming-buffer-conf.json',
  'text!module/terminal/conf/general.json',
  'module/terminal/service/authentication-service',
  'module/core/service/nmsweb-notification'
], function ( terminal, strStreamingConfig, strGeneralConfig, AuthenticationService ) {
    'use strict';
    terminal.service( 'TerminalStreamingBuffer', [ '$interval', '$resource', '$http', '$rootScope', '$location', 'AuthenticationService', 'NMSWebNotification', function ( $interval, $resource, $http, $rootScope, $location, AuthenticationService, NMSWebNotification ) {
        var generalConfig = $.parseJSON( strGeneralConfig ),
            streamingConfig = $.parseJSON( strStreamingConfig ),
            TerminalStreamingBuffer = {
                res: {},
                buffer: {},
                currentValues: {},
                lastNewData: $.now(),
                currLocationApiUrls: [],
                initialized: false,
                defaultInterval: streamingConfig.defaultInterval,
                minimumInterval: streamingConfig.minimumInterval,
                bufferLifetime: streamingConfig.bufferLifetime,
                limitBufferStarted: false,
                inTimeout: false,
                init: function () {
                    var that = this;
                    if ( that.initialized ) {
                        return that;
                    }
                    that.loadBuffer();
                    $interval( function () {
                        that.update();
                    }, that.minimumInterval );
                    $interval( function () {
                        //Gets called every defaultInterval to update ui components if the last data is more recent than defaultInterval
                        if ( that.lastNewData > $.now() - that.defaultInterval ) {
                            $rootScope.$broadcast( 'streamingBufferGeneralUpdate', true );
                        }
                    }, that.defaultInterval );
                    that.initialized = true;
                    return that;
                },
                loadBuffer: function() {
                  var that = this;
                  if(localStorage.getItem('terminalLocalStorage')) {
                    that.buffer =  JSON.parse(localStorage.getItem('terminalLocalStorage')).data;
                  }
                },
                clearResources: function() {
                  var that = this;
                  that.res = {};
                },
                getCurrentStatus: function ( pathArray ) {
                    var that = this,
                        currentStatus;
                    if ( pathArray && pathArray.length ) {
                        angular.forEach( pathArray, function ( resourcePart, key ) {
                            if ( key === 0 ) {
                                if ( !resourcePart ) {
                                    return "";
                                }
                                currentStatus = that.res[ pathArray[ 0 ] ].lastStatus;
                                if ( !currentStatus ) {
                                    return "";
                                }
                            }
                        } );
                    }
                    return currentStatus;
                },
                getCurrentValue: function ( pathArray ) {
                    var that = this,
                        tmpValue = "";
                    if ( pathArray && pathArray.length ) {
                        angular.forEach( pathArray, function ( resourcePart, key ) {
                            if ( key === 0 ) {
                                if ( !resourcePart ) {
                                    return "";
                                }
                                tmpValue = that.currentValues[ pathArray[ 0 ] ];
                                if ( !tmpValue ) {
                                    return "";
                                }
                            } else {
                                if ( !tmpValue || typeof tmpValue[ resourcePart ] === "undefined" ) {
                                    tmpValue = "";
                                    return false;
                                }
                                tmpValue = tmpValue[ resourcePart ];
                            }
                        } );
                    }
                    return tmpValue;
                },
                CheckApiPresence: function ( pathArray ) {
                    var that = this,
                        tmpValue = "", presence = true;
                    if ( pathArray && pathArray.length ) {
                         tmpValue = that.currentValues[ pathArray[ 0 ] ];
                         if ( !tmpValue ) {
                            presence = false;
                         }
                    }
                    return presence;
                },
                limitBuffer: function () {
                    var that = this,
                        targetTimestamp = $.now() - that.bufferLifetime;

                    angular.forEach( that.buffer, function ( resource, apiurl ) {
                        var bufferKeys = Object.keys(resource),
                            currentUrl = apiurl,
                            limitMap = function(obj) {
                                if(parseInt(obj) < targetTimestamp) {
                                    delete that.buffer[ currentUrl ][ obj ];
                                }
                            };
                        bufferKeys.map(limitMap);
                    } );
                },
                localStorage: function () {
                    var that = this;
                    if ( 'localStorage' in window && window[ 'localStorage' ] !== null ) {
                        var now = $.now(),
                            dataToStore = {
                                timestamp: now,
                                data: that.buffer
                            };
                        try {
                            localStorage.setItem( 'terminalLocalStorage', JSON.stringify( dataToStore ) );
                        } catch (e) {
                            //Reduce buffer size and try to save during next iteration
                            that.reduceBufferSize(that.buffer);
                        }
                    }
                },
                removeResource: function ( apiurl ) {
                    var that = this;
                    delete that.res[ apiurl ];
                },
                registerResource: function ( apiurls, interval, bufferInterval, persistent, storeToLocalStorage ) {
                    var that = this;
                    if ( typeof apiurls === 'string' ) {
                        apiurls = [ apiurls ];
                    }
                    angular.forEach( apiurls, function ( apiurl ) {
                        if ( !apiurl ) {
                            return false;
                        }
                        if ( interval !== undefined && that.res[ apiurl ] && that.res[ apiurl ].interval && that.res[ apiurl ].interval > interval ) {
                            that.res[ apiurl ].interval = interval;
                        } else if ( !that.res[ apiurl ] ) {
                            that.res[ apiurl ] = {
                                interval: interval || that.defaultInterval,
                                bufferInterval: bufferInterval || 0,
                                storeToLocalStorage: storeToLocalStorage || false,
                                lastUpdated: false,
                                lastBuffered: false,
                                pendingUpdate: false,
                                lastStatus: false
                            };
                            that.apiCall( apiurl, that.res[ apiurl ] );
                        }
                        if (!that.buffer[ apiurl ] && !persistent) {
                            if(that.currLocationApiUrls.indexOf( apiurl ) == -1) {
                              that.currLocationApiUrls.push(apiurl);
                            }
                        }
                    } );
                    return true;
                },
                changeInterval: function ( apiurl, interval ) {
                    var that = this;
                    if ( that.res[ apiurl ] && that.res[ apiurl ].interval ) {
                        that.res[ apiurl ].interval = interval;
                    }
                },
                changeBufferInterval: function ( apiurl, interval ) {
                    var that = this;
                    if ( that.res[ apiurl ]) {
                        that.res[ apiurl ].bufferInterval = interval;
                        return true;
                    }
                    return false;
                },
                changeStoreToLocalStorage: function ( apiurl, state ) {
                    var that = this;
                    if ( that.res[ apiurl ]) {
                        that.res[ apiurl ].storeToLocalStorage = state;
                        return true;
                    }
                    return false;
                },
                update: function () {
                    var that = this;
                    angular.forEach( that.res, function ( resObject, apiurl ) {
                        if ( that.checkResourceUpdate( apiurl, resObject ) ) {
                            that.apiCall( apiurl, resObject );
                        }
                    } );
                },
                checkResourceUpdate: function ( apiurl, resObject ) {
                    var that = this,
                        lastUpdated = resObject.lastUpdated,
                        interval = resObject.interval,
                        now = $.now();
                    if ( lastUpdated < now - interval ) {
                        return true;
                    }
                    return false;
                },
                checkResourceBuffering: function ( apiurl, resObject ) {
                    var that = this,
                        lastBuffered = resObject.lastBuffered,
                        bufferInterval = resObject.bufferInterval,
                        now = $.now();
                    if (bufferInterval === 0) {
                        return false;
                    }
                    if ( lastBuffered < now - bufferInterval ) {
                        return true;
                    }
                    return false;
                },
                apiCall: function ( apiurl, resObject ) {
                    var that = this,
                        now = $.now(),
                        url = generalConfig.host + generalConfig.apiRoot + apiurl,
                        error;
                    if ( that.checkResourcePending( apiurl ) == false ) {
                        that.pendingUpdate( apiurl, true );
                        $http( {
                                url: url,
                                method: "GET"
                            } )
                            .error( function ( data, status, headers, config ) {
                                if ( status === 401 ) {
                                    $( 'body' ).addClass( 'alternative' );
                                    AuthenticationService.on401();
                                    $rootScope.authenticated = AuthenticationService.authenticated;
                                    $('#initial-overlay').spin('large');
                                    $('body .n-overlay .overlay').css('visibility', 'visible');
                                    $('#initial-overlay').css('visibility', 'visible');
                                    $rootScope.authError = true;
                                    window.location.href = "/login.html"; // Spport non WS authentication
                                    that.lastUpdated( apiurl, now );
                                    that.pendingUpdate( apiurl, false );
                                    that.clearResources();
                                } else if ( status === 500 ) {
                                    that.lastStatus( apiurl, status );
                                    that.lastUpdated( apiurl, now );
                                    that.pendingUpdate( apiurl, false );
                                    if ( data.errors ) {
                                        if ( typeof data.errors === "string" ) {
                                            error = data.errors;
                                        } else if ( Array.isArray( data.errors ) && data.errors.length ) {
                                            error = data.errors[ 0 ];
                                        }
                                        if ( error && !that.notificationExists(error)) {
                                            NMSWebNotification.add( {
                                                type: "majorwarning",
                                                isFadeable: true,
                                                title: "An error has occured",
                                                message: error
                                            }, "body" );
                                        }
                                    }
                                } else if ( status === 403 ) {
                                    $location.path('/403');
                                } else if ( status === 404 ) {
                                        //Some resources are expected to be
                                } else {
                                    if ( !that.inTimeout ) {
                                        that.inTimeout = true;
                                        $('.notification-tray').css('visibility','hidden');
                                        $('#connectionLostOverlay').spin('large');
                                        $('#connectionLostOverlay').css('visibility', 'visible');
                                        $('.connectionLost').css('visibility', 'visible');
                                    }
                                    that.pendingUpdate( apiurl, false );
                                }
                            } )
                            .then( function ( response ) {
                                $('.notification-tray').css('visibility','visible');
                                $('#connectionLostOverlay').spin('false');
                                $('#connectionLostOverlay').css('visibility', 'hidden');
                                $('.connectionLost').css('visibility', 'hidden');
                                if($('.n-warning-notification').length) {
                                        $('.n-warning-notification').remove();
                                }
                                that.inTimeout = false;
                                that.addData( apiurl, response.data, that.checkResourceBuffering( apiurl, resObject ), that.checkBufferToLocalStorage( apiurl ) );
                                that.lastUpdated( apiurl, now );
                                that.pendingUpdate( apiurl, false );
                                that.lastStatus( apiurl, response.status );
                            } );
                    }
                },
                checkBufferToLocalStorage: function ( apiurl ) {
                    var that = this;
                    if( that.res[ apiurl ] && that.res[ apiurl ].storeToLocalStorage === true) {
                      return true;
                    }
                    return false;
                },
                checkResourcePending: function ( apiurl ) {
                    var that = this;
                    if ( that.res[ apiurl ].pendingUpdate ) {
                        return true;
                    }
                    return false;
                },
                reduceBufferSize: function (object) {
                    var that = this;
                    angular.forEach(that.buffer, function(item, apiurl) {
                            var firstKey = Object.keys(that.buffer[apiurl])[0];
                            delete that.buffer[apiurl][firstKey];
                    });
                },
                addData: function ( apiurl, data, buffer, bufferToLocalStorage ) {
                    var that = this,
                        now = $.now();

                    if ( buffer === true ) {
                        if ( !that.buffer[ apiurl ] ) {
                            that.buffer[ apiurl ] = {};
                        }
                        that.buffer[ apiurl ][ now ] = data;
                        that.lastBuffered = now;
                        if( !that.limitBufferStarted ) {
                          setInterval(function() {
                            that.limitBuffer();
                          }, 60000);
                        }
                        that.limitBufferStarted = true;
                        if( bufferToLocalStorage === true ) {
                          that.localStorage();
                        }
                    }
                    if ( !that.currentValues[ apiurl ] ) { // Update on initial Data retrieval
                        that.currentValues[ apiurl ] = data;
                        $rootScope.$broadcast( 'streamingBufferGeneralUpdate', true );
                    } else {
                        that.currentValues[ apiurl ] = data;
                    }
                    $rootScope.$broadcast( 'streamingBufferUpdate', true );
                    that.lastNewData = $.now();
                },
                pendingUpdate: function ( apiurl, status ) {
                    var that = this;
                    if(!that.res[ apiurl ]) { return; }
                    that.res[ apiurl ].pendingUpdate = status;
                },
                lastUpdated: function ( apiurl, now ) {
                    var that = this;
                    if(!that.res[ apiurl ]) { return; }
                    that.res[ apiurl ].lastUpdated = now;
                },
                lastStatus: function ( apiurl, status ) {
                    var that = this;
                    if(!that.res[ apiurl ]) { return; }
                    that.res[ apiurl ].lastStatus = status;
                },
                notificationExists: function (newNotification) {
                    var exists = false;
                    angular.forEach($( "div[class^='notification']:not('.notification-tray')" ).children("ul").children("li"), function(notification){
                        if($(notification).html() == newNotification) {
                                exists = true;
                        }
                    })
                    return exists;
                }
          };
          $rootScope.$on( '$routeChangeStart', function ( event, next ) {
            angular.forEach(TerminalStreamingBuffer.currLocationApiUrls, function( apiurl ) {
                TerminalStreamingBuffer.removeResource( apiurl );
            });
            TerminalStreamingBuffer.currLocationApiUrls = [];
          });
        return TerminalStreamingBuffer.init();
  } ] );
} );
