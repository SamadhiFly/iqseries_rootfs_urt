define( [ 'module/terminal',
'text!module/terminal/conf/general.json',
'templates/nmsweb/module/terminal/directive/one-touch-commissioning.tpl',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form',
'module/terminal/service/terminal-streaming-buffer',
'module/terminal/directive/nmsweb-html',
'module/core/directive/nmsweb-tooltip' ],
    function ( terminal, strGeneralConfig, template ) {
        'use strict';
        terminal.directive( 'oneTouchCommissioning', [ '$rootScope', 'TerminalStreamingBuffer', '$http', '$interval', 'ToolResource', 'NmswebForm', function ( $rootScope, TerminalStreamingBuffer, $http, $interval, ToolResource, NmswebForm ) {
            return {
                restrict: 'E',
                template: template,
                replace: true,
                scope: {
                    valid: '=?',
                    downstreamConfiguration: '=?'
                },
                compile: function () {
                    return {
                        pre: function preLink( $scope, element ) {
                            var generalConfig = $.parseJSON( strGeneralConfig ),
                                timeouts = [],
                                intervals = [],
                                currProgress = 0,
                                currProgressName,
                                lastProgress = 0,
                                started,
                                currentStatus,
                                resInterval,
                                formOptions = {
                                    "layout": "layouts/terminal/tools/one-touch-commissioning",
                                    "hook": "module/terminal/hook/tool-one-touch-commissioning"
                                };

                            TerminalStreamingBuffer.registerResource( 'terminal/rx' );
                            $scope.smartBuc = true;
                            $scope.valid = false;
                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/odu/buc/0',
                                method: "GET"
                            } ).then( function ( result ) {
                                // Check if Smart BUC or not
                                if ( result.data.data.product_id ) {
                                    $scope.smartBuc = true;
                                } else {
                                    $scope.smartBuc = false;
                                }
                            } );
                            $http( {
                                    url: generalConfig.host + generalConfig.apiRoot + 'terminal/mode/buc_cal/0/status',
                                    method: "GET"
                            } ).then( function ( response ) {
                                if ( ( response.data ) ) {
                                    currentStatus = response.data;
                                    currProgressName = currentStatus.data[ "buc_calibration_status" ];
                                    currProgress = currentStatus.data[ "cal_completion" ];
                                    if ( currProgressName === "IN_PROGRESS" ) {
                                        angular.element( start_btn_element ).ready( function () {
                                            $scope.one_touch_start();
                                        } );
                                    } else if ( currProgressName === "CALIBRATED" ) {
                                        $scope.display_message = $rootScope.translation.language.one_touch_commissioning_successfully_completed + '!';
                                        $scope.message_color = 'green';
                                        $scope.success = true;
                                        $scope.display_status = true;
                                        $scope.valid = true;
                                        $scope.completed = true;
                                        $scope.lastTimeCompleted = true;
                                        updateProgressBar( currProgress );
                                        $scope.start_btn_text = $rootScope.translation.language.repeat;
                                        stopCurrentStreams();
                                        $scope.needsRerun = true;
                                        $scope.runCount = 0;
                                    }
                                }
                            }, function (error) {
                                if ( error.data.errors && error.data.errors[ 0 ] ) {
                                    $scope.display_message_head = $rootScope.translation.language.error + ":";
                                    $scope.display_message = error.data.errors[ 0 ];
                                } else {
                                    $scope.display_message = $rootScope.translation.language.one_touch_commissioning_failed_please_try_again;
                                }
                                $scope.message_color = 'red';
                                $scope.display_status = true;
                            } );

                            formOptions.resource = new ToolResource( 'one-touch-commissioning' );
                            formOptions.name = 'one-touch-commissioning';
                            formOptions.viewMode = false;

                            $scope.title = "";

                            $scope.form = new NmswebForm( formOptions );
                            $scope.form.actions = [];

                            if ( $scope.downstreamConfiguration ) {
                                $scope.form.model = angular.extend( $scope.form.model, $scope.downstreamConfiguration );
                                $scope.validDownstream = true;
                            }
                            $scope.downstreamConfiguration = $scope.form.model;

                            $scope.bar_width = '0%';
                            $scope.runCount = 0;
                            $scope.start = true;
                            $scope.display_status = false;
                            $scope.success = false;
                            $scope.message_color = 'info';
                            $scope.start_btn_text = $rootScope.translation.language.start;
                            $scope.stop_btn_text = $rootScope.translation.language.stop;
                            $scope.progress_color = 'blue';
                            $scope.completed = false;
                            $scope.needsRerun = false;
                            var getCurrentProgress = function ( onPageLoad, currentStatus ) {
                                if ( currentStatus ) {
                                    currProgress = currentStatus.data[ "cal_completion" ];
                                    currProgressName = currentStatus.data[ "buc_calibration_status" ];
                                    setProgressBarOk();
                                    if ( currProgress == 0 ) {
                                        started = true;
                                    }
                                    if ( lastProgress > 1 && currProgress == 100 && currProgressName == "CALIBRATED" ) {
                                        $scope.display_message = $rootScope.translation.language.one_touch_commissioning_successfully_completed + '!';
                                        $scope.message_color = 'green';
                                        $scope.success = true;
                                        $scope.display_status = true;
                                        $scope.valid = true;
                                        //$scope.start = true;
                                        $scope.completed = true;
                                        updateProgressBar( currProgress );
                                        $scope.start_btn_text = $rootScope.translation.language.repeat;
                                        started = false;
                                        lastProgress = 0;
                                        stopCurrentStreams();
                                        $scope.needsRerun = true;
                                        $scope.runCount = 0;
                                    }
                                    if ( lastProgress || currProgress != 100 ) {
                                        lastProgress = currProgress;
                                    }
                                    if ( (currProgressName == "FAILED" && started) || (currProgressName == "FAILED" && !onPageLoad) ) {
                                        setProgressBarError();
                                        stopCurrentStreams();
                                        $scope.start_btn_text = $rootScope.translation.language.repeat;
                                        $scope.start = true;
                                        $scope.display_message = $rootScope.translation.language.one_touch_commissioning_failed_please_try_again + "!";
                                        $scope.message_color = 'red';
                                        $scope.display_status = true;
                                        started = false;
                                        currProgress = 0;
                                        $scope.needsRerun = true;
                                        $scope.runCount = 0;
                                    }
                                    if ( onPageLoad && ( currProgress > 0 ) ) {
                                        $scope.start = false;
                                        $scope.start_btn_text = $rootScope.translation.language.running;
                                        updateProgressBar( currProgress );
                                    } else if ( onPageLoad && ( currProgress == 0 ) ) {
                                        stopCurrentStreams();
                                    }
                                    return currProgress;
                                }
                            };
                            var updateProgressBar = function ( progress ) {
                                $scope.bar_width = progress + '%';
                            };
                            var stopCurrentStreams = function () {
                              angular.forEach(intervals, function(interval) {
                                $interval.cancel(interval);
                              });
                              TerminalStreamingBuffer.removeResource( 'terminal/mode/buc_cal/0/status' );
                              intervals.length = 0; //clear the array
                            };
                            var currentStatus;
                            var monitorCal = function ( onPageLoad ) {
                                var onPageLoad = onPageLoad;
                                if(!$scope.completed) {
                                    $http( {
                                            url: generalConfig.host + generalConfig.apiRoot + 'terminal/mode/buc_cal/0/status',
                                            method: "GET"
                                        } )
                                    .error( function ( data ) {
                                        if ( data.errors && data.errors[ 0 ] ) {
                                            $scope.display_message_head = $rootScope.translation.language.error + ":";
                                            $scope.display_message = data.errors[ 0 ];
                                        } else {
                                            $scope.display_message = $rootScope.translation.language.one_touch_commissioning_failed_please_try_again;
                                        }
                                        $scope.start_btn_text = $rootScope.translation.language.repeat;
                                        $scope.message_color = 'red';
                                        $scope.display_status = true;
                                        $scope.start = true;
                                        setProgressBarError();
                                        stopCurrentStreams();
                                        $scope.needsRerun = true;
                                        $scope.runCount = 0;
                                    } )
                                    .then( function ( response ) {
                                        if ( ( response.data ) ) {
                                            currentStatus = response.data;
                                            if ( onPageLoad === false ) {
                                                currProgress = 0;
                                                stopCurrentStreams();
                                            }
                                            getCurrentProgress( onPageLoad, currentStatus );
                                            if ( !onPageLoad && ( onPageLoad !== undefined ) ) {
                                                stopCurrentStreams();
                                                updateProgressBar( 0 );
                                                $scope.start = true;
                                                $scope.start_btn_text = $rootScope.translation.language.start;
                                            } else if ( ( onPageLoad === undefined ) && ( currProgress >= 0 ) && ( currProgress < 100 ) ) {
                                                $scope.start = false;
                                                $scope.start_btn_text = $rootScope.translation.language.running;
                                                updateProgressBar( currProgress );
                                            } else if ( ( onPageLoad === undefined ) && ( currProgress == 100 ) ) {
                                                $scope.display_message = $rootScope.translation.language.one_touch_commissioning_successfully_completed + '!';
                                                $scope.message_color = 'green';
                                                $scope.display_status = true;
                                                $scope.success = true;
                                                $scope.valid = true;
                                                stopCurrentStreams();
                                                if(!$scope.completed) {
                                                  updateProgressBar( currProgress );
                                                }
                                                $scope.completed = true;
                                                //$scope.start = true;
                                                $scope.start_btn_text = $rootScope.translation.language.repeat;
                                                $scope.needsRerun = true;
                                                $scope.runCount = 0;
                                            }
                                        }
                                    } );
                                }
                            };
                            var setProgressBarError = function () {
                                var bar_class = document.getElementsByClassName( "progress-container" );
                                if ( angular.element( bar_class ).hasClass( 'blue' ) ) {
                                    $scope.progress_color = 'red noanimate';
                                }
                            };
                            var setProgressBarOk = function () {
                                var bar_class = document.getElementsByClassName( "progress-container" );
                                if ( angular.element( bar_class ).hasClass( 'red' ) ) {
                                    $scope.progress_color = 'blue';
                                }
                            };
                            var checkForOpenConn = function ( callback ) {
                                $http( {
                                        url: generalConfig.host + generalConfig.apiRoot + 'terminal/mode/buc_cal/0/status',
                                        method: "GET"
                                    } )
                                    .error( function ( data ) {
                                        if ( data.errors && data.errors[ 0 ] ) {
                                            $scope.display_message_head = $rootScope.translation.language.error + ":";
                                            $scope.display_message = data.errors[ 0 ];
                                        } else {
                                            $scope.display_message = $rootScope.translation.language.one_touch_commissioning_failed_please_try_again;
                                        }
                                        $scope.start_btn_text = $rootScope.translation.language.repeat;
                                        $scope.message_color = 'red';
                                        $scope.display_status = true;
                                        $scope.start = true;
                                        setProgressBarError();
                                        stopCurrentStreams();
                                        $scope.needsRerun = true;
                                        $scope.runCount = 0;
                                        if ( callback ) {
                                            callback();
                                        }
                                    } )
                                    .then( function ( data ) {
                                        if( $scope.needsRerun ) {
                                          if ( callback ) {
                                        	    callback();
                                        	}
                                        }
                                        TerminalStreamingBuffer.registerResource( 'terminal/mode/buc_cal/0/status', 500 );
                                        if ( data.data.data.buc_calibration_status == "FAILED" && !callback ) {
                                            setProgressBarError();
                                            stopCurrentStreams();
                                            $scope.display_message_head = $rootScope.translation.language.last_state + ": ";
                                            $scope.display_message = $rootScope.translation.language.one_touch_commissioning_failed_please_try_again + "!";
                                            $scope.message_color = 'red';
                                            $scope.display_status = true;
                                            $scope.start_btn_text = $rootScope.translation.language.repeat;
                                            $scope.start = true;
                                            $scope.needsRerun = true;
                                            $scope.runCount = 0;
                                        } else if ( data.data.data.buc_calibration_status == "CALIBRATED" && !callback ) {
                                            $scope.display_message_head = $rootScope.translation.language.last_state + ": ";
                                            $scope.display_message = $rootScope.translation.language.one_touch_commissioning_successfully_completed + "!";
                                            $scope.message_color = 'green';
                                            $scope.display_status = true;
                                            $scope.valid = true;
                                            $scope.lastTimeCompleted = true;
                                            $scope.start = true;
                                            $scope.start_btn_text = $rootScope.translation.language.repeat;
                                            stopCurrentStreams();
                                            $scope.needsRerun = true;
                                            $scope.runCount = 0;
                                        } else if ( data.data.data.buc_calibration_status !== "IN_PROGRESS" && data.data.data.buc_calibration_status !== "NOT_CALIBRATED" ) {
                                        	if ( callback ) {
                                        	    callback();
                                        	}
                                        	$scope.start = true;
                                        } else if ( data.data.data.buc_calibration_status === "IN_PROGRESS" || data.data.data.buc_calibration_status === "NOT_CALIBRATED" ) {
                                            $scope.start = false;
                                            $scope.start_btn_text = $rootScope.translation.language.please_wait;
                                            if ( callback ) {
                                          	    callback();
                                          	} else {
                                                intervals.push($interval( function () {
                                                    setProgressBarOk();
                                                    monitorCal( undefined, currentStatus );
                                                }, 500 ));
                                            }
                                        }
                                    } );
                            };
                            $scope.one_touch_start = function () {
                                $scope.success = false;
                                $scope.valid = false;
                                $scope.display_status = false;
                                $scope.start = false;
                                $scope.start_btn_text = $rootScope.translation.language.please_wait;
                                $scope.display_message = '';
                                $scope.message_color = 'info';
                                $scope.completed = false;
                                $scope.lastTimeCompleted = false;
                                checkForOpenConn(
                                    function () {
                                        $scope.runCount++;
                                        if($scope.runCount < 2) {
                                          $http( {
                                                  url: generalConfig.host + generalConfig.apiRoot + 'terminal/mode/buc_cal/0/run',
                                                  method: "POST",
                                                  headers: {
                                                      'Content-Type': 'application/json'
                                                  }
                                              } )
                                              .error( function ( data, status, headers, config ) {
                                                  $scope.display_message = $rootScope.translation.language.one_touch_commissioning_failed_please_try_again + '!';
                                                  $scope.message_color = 'red';
                                                  $scope.display_status = true;
                                                  $scope.start = true;
                                                  $scope.start_btn_text = $rootScope.translation.language.repeat;
                                                  $scope.stop_btn_text = $rootScope.translation.language.stop;
                                                  setProgressBarError();
                                                  stopCurrentStreams();
                                                  $scope.needsRerun = true;
                                                  $scope.runCount = 0;
                                              } )
                                              .then( function ( response ) {
                                                  intervals.push($interval( function () {
                                                    setProgressBarOk();
                                                    monitorCal();
                                                  }, 500 ));
                                                  $scope.needsRerun = false;
                                                  $scope.display_status = false;
                                                  $scope.start = false;
                                                  $scope.start_btn_text = $rootScope.translation.language.please_wait;
                                                  $scope.stop_btn_text = $rootScope.translation.language.stop;
                                              } );
                                        }
                                    }
                                );
                            };
                            $scope.one_touch_stop = function () {
                                $scope.start = false;
                                $scope.stop_btn_text = $rootScope.translation.language.stopping;
                                $scope.start_btn_text = $rootScope.translation.language.start;
                                $scope.runCount = 0;
                                $http( {
                                        url: generalConfig.host + generalConfig.apiRoot + 'terminal/mode/off',
                                        method: "POST",
                                        headers: {
                                            'Content-Type': 'application/json'
                                        }
                                    } )
                                    .error( function ( data, status, headers, config ) {
                                        getCurrentProgress();
                                    } )
                                    .then( function ( response ) {
                                        monitorCal( false );
                                        $scope.start = true;
                                        $scope.start_btn_text = $rootScope.translation.language.start;
                                        $scope.stop_btn_text = $rootScope.translation.language.stop;
                                        stopCurrentStreams();
                                    } );
                            };
                            var start_btn_element = document.getElementById( "start-comm" );
                            $scope.show_details = function () {
                                $( '#details-container' ).slideToggle( 'slow' );
                            };
                            $( '#details-container' ).bind( 'change', function () {
                                if ( $( this ).html() != "" ) {
                                    $( '.details-link' ).removeClass( 'hide' );
                                } else {
                                    $( '.details-link' ).addClass( 'hide' );
                                }
                            } );
                        },
                        post: function () {}
                    }
                }
            };
    } ] );
    } );
