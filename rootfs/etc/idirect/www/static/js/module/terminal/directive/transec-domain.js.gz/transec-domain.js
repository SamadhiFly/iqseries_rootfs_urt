define( [ 'module/terminal',
'text!module/terminal/conf/general.json',
'templates/nmsweb/module/terminal/directive/angle-calculator.tpl',
'vendor/downloadjs/download.min',
'module/terminal/service/terminal-streaming-buffer',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form',
'module/terminal/directive/nmsweb-html',
'module/core/directive/nmsweb-tooltip',
'jqueryConfirm' ],
    function ( terminal, strGeneralConfig, template, download ) {
        'use strict';
        terminal.directive( 'transecDomain', [ '$rootScope', 'TerminalStreamingBuffer', 'ToolResource', 'NmswebForm', '$http', 'NMSWebNotification', function ( $rootScope, TerminalStreamingBuffer, ToolResource, NmswebForm, $http, NMSWebNotification ) {
            return {
                restrict: 'E',
                template: template,
                replace: true,
                scope: {

                },
                compile: function () {
                    return {
                        pre: function preLink( scope, element ) {
                            var generalConfig = $.parseJSON( strGeneralConfig ),
                                formOptions = {
                                    "layout": "layouts/terminal/tools/transec-domain",
                                    "hook": "module/terminal/hook/tool-transec-domain"
                                };

                            formOptions.resource = new ToolResource( 'transec-domain' );
                            formOptions.name = 'transec-domain';
                            formOptions.viewMode = false;
                            scope.title = formOptions.name;
                            scope.form = new NmswebForm( formOptions );

                            scope.remote_data = $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/identity',
                                method: "GET"
                            } );
                            scope.certRequest = $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/transec/domain',
                                method: "GET"
                            } );
                            scope.certRequest.then( function ( certData ) {
                                $( document ).off( 'click', 'button.show-details' ).on( 'click', 'button.show-details', function () {
                                    var id = $( this ).attr( 'rel' );
                                    if ( certData.data && certData.data.data && certData.data.data[ id ] )
                                        var certInfo = JSON.stringify( certData.data.data[ id ], null, 4 );
                                    $.alert( {
                                        title: $rootScope.translation.language.domain_details,
                                        content: "<pre>" + certInfo + "</pre>"
                                    } );
                                } );
                            } );
                            $( document ).off( 'click', 'button.do-csr' ).on( 'click', 'button.do-csr', function () {
                                var buttonid = $( this ).attr( 'id' ),
                                    buttonRel = $( this ).attr( 'rel' );

                                scope.remote_data.then( function ( response ) {
                                    var t = new Date();
                                    var date = t.getFullYear() + "_" + ( t.getMonth() < 9 ? "0" : "" ) + ( t.getMonth() + 1 ) + "_" + ( t.getDate() < 10 ? "0" : "" ) + t.getDate();

                                    var filename = response.data.data.model + "_" + response.data.data.serial_number + "_" + date + ".csr";

                                    $.confirm( {
                                        title: $rootScope.translation.language.generate_csr_confirm_head,
                                        content: $rootScope.translation.language.generate_csr_confirm_content,
                                        confirmButton: $rootScope.translation.language.continue,
                                        cancelButton: $rootScope.translation.language.cancel,
                                        confirm: function () {
                                            scope.csr = $http( {
                                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/transec/domain/' + buttonRel + '/csr',
                                                method: "POST"
                                            } );
                                            angular.element( '.main' ).spin( true );

                                            scope.csr.then( function ( cert ) {
                                                angular.element( '.main' ).spin( false );
                                                if ( cert.data && cert.data.data && cert.data.data.csr ) {
                                                    var cert_request = cert.data.data.csr;
                                                    download( cert_request, filename, "text/plain" );
                                                } else {
                                                    NMSWebNotification.add( {
                                                        type: "majorwarning",
                                                        isFadeable: true,
                                                        title: $rootScope.translation.language.update_rsp_failed,
                                                        message: $rootScope.translation.language.the_change_could_not_be_saved_colon + response.errors[ 0 ]
                                                    }, "body" );
                                                }
                                            } );
                                        }
                                    } );
                                } );
                            } );

                            $( document ).off( 'click', 'button.install-rsp' ).on( 'click', 'button.install-rsp', function () {
                                var buttonRel = $( this ).attr( 'rel' );
                                var reader = new FileReader();
                                $( "#rsp_file_upload" + buttonRel + ":file" ).change( function ( e ) {
                                    if ( !e.isDefaultPrevented() ) {
                                        e.preventDefault();
                                        var fileName = $( this ).val();
                                        reader.onload = function ( data ) {
                                            var pass = $( "#rsp_file_upload" + buttonRel + ":file" ).val( null );

                                            $.confirm( {
                                                title: $rootScope.translation.language.install_rsp,
                                                content: $rootScope.translation.language.rsp_passphrase + '<p><input style=\"font-family: monospace !important;\" type="password" id="rsp_pass"> </input></p><p>Show password <input style=\"margin-bottom: 4px;\" id=\"toggle_pass\" type=\"checkbox\" ></p>',
                                                confirmButton: $rootScope.translation.language.continue,
                                                cancelButton: $rootScope.translation.language.cancel,
                                                confirm: function () {
                                                    var pass = $( "#rsp_pass" );
                                                    angular.element( '.main' ).spin( true );
                                                    $http( {
                                                            url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/transec/domain/' + buttonRel + '/rsp',
                                                            method: "POST",
                                                            data: {
                                                                "rsp": data.target.result,
                                                                "password": $( "#rsp_pass" ).val()
                                                            }
                                                        } ).error( function ( response ) {
                                                            angular.element( '.main' ).spin( false );
                                                            if(response && response.errors && response.errors.length > 0) {
                                                                NMSWebNotification.add( {
                                                                    type: "majorwarning",
                                                                    isFadeable: true,
                                                                    title: $rootScope.translation.language.update_rsp_failed,
                                                                    message: $rootScope.translation.language.the_change_could_not_be_saved_colon + response.errors[ 0 ]
                                                                }, "body" );
                                                            }
                                                        } )
                                                        .success( function ( response ) {
                                                            angular.element( '.main' ).spin( false );
                                                            NMSWebNotification.add( {
                                                                type: "success",
                                                                isFadeable: true,
                                                                title: $rootScope.translation.language.update_rsp_success,
                                                                message: $rootScope.translation.language.update_rsp_success_content
                                                            }, "body" );
                                                        } );
                                                }
                                            } );
                                            $( "#toggle_pass" ).change( function () {
                                                if ( this.checked ) {
                                                    $( "#rsp_pass" ).attr( "type", "text" );
                                                } else {
                                                    $( "#rsp_pass" ).attr( "type", "password" );
                                                }
                                            } );
                                        };
                                        if(e.target.files.length > 0) {
                                            reader.readAsText( e.target.files[ 0 ] );
                                        }
                                    }
                                } );
                                $( "#rsp_file_upload" + buttonRel ).trigger( 'click' );
                            } );

                        },
                        post: function postLink( scope, element ) {}
                    }
                }
            };
    } ] );
    } );