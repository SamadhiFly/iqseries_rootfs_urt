define( [ 'module/terminal',
'templates/nmsweb/module/terminal/directive/one-time-token.tpl',
'text!module/terminal/conf/general.json',
'module/terminal/service/terminal-streaming-buffer',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form',
'module/terminal/directive/nmsweb-html',
'module/core/directive/nmsweb-tooltip',
'module/core/service/nmsutils',
'jqueryConfirm' ],
    function ( terminal, template, strGeneralConfig ) {
        'use strict';
        terminal.directive( 'oneTimeToken', [ '$rootScope', 'TerminalStreamingBuffer', 'ToolResource', 'NmswebForm', '$http', 'NMSWebNotification', '$timeout', function ( $rootScope, TerminalStreamingBuffer, ToolResource, NmswebForm, $http, NMSWebNotification, $timeout ) {
            return {
                restrict: 'E',
                template: template,
                replace: true,
                scope: {
                    standAloneTool: '=?'
                },
                compile: function () {
                    return {
                        pre: function preLink( scope, element ) {
                            var generalConfig = $.parseJSON( strGeneralConfig ),
                                formOptions = {
                                    "layout": "layouts/terminal/tools/one-time-token",
                                    "hook": "module/terminal/hook/tool-one-time-token"
                                };
                            scope._isolate = scope;
                            scope.mode = ( typeof scope.mode !== "undefined" ) ? scope.mode : "oneTimeToken";
                            formOptions.resource = new ToolResource( 'one-time-token' );
                            formOptions.name = 'one-time-token';
                            formOptions.viewMode = false;
                            scope.title = formOptions.name;
                            scope.form = new NmswebForm( formOptions );
                            scope.form.actions = [];
                            $( document ).ready( function () {
                                $( window ).keydown( function ( event ) {
                                    if ( event.keyCode == 13 ) {
                                        event.preventDefault();
                                        return false;
                                    }
                                } );
                            } );

                            scope.uploadToken = function () {
                                $.confirm( {
                                    title: $rootScope.translation.language.one_time_token,
                                    content: $rootScope.translation.language.wantSubmitTokenConfirm,
                                    confirmButton: $rootScope.translation.language.continue,
                                    cancelButton: $rootScope.translation.language.cancel,
                                    confirmButtonClass: "btn-cancel",
                                    confirm: function () {
                                        angular.element( '.main' ).spin( true );
                                        $http( {
                                            url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/identity/passcode',
                                            method: 'POST',
                                            data: {
                                                one_time_key: scope.form.model.token
                                            },
                                            headers: {
                                                'Content-Type': 'application/json'
                                            }
                                        } ).then( function successCallback() {
                                            angular.element( '.main' ).spin( false );
                                            NMSWebNotification.add( {
                                                type: "success",
                                                isFadeable: true,
                                                title: $rootScope.translation.language.the_token_has_been_successfully_submitted,
                                                message: $rootScope.translation.language.the_token_has_been_successfully_submitted
                                            }, "body" );
                                        }, function errorCallback( response ) {
                                            angular.element( '.main' ).spin( false );
                                            if ( typeof response.data.errors !== 'undefined' && response.data.errors.length > 0 ) {
                                                NMSWebNotification.add( {
                                                    type: "error",
                                                    isFadeable: true,
                                                    title: $rootScope.translation.language.the_token_could_not_be_submitted,
                                                    message: $rootScope.translation.language.the_token_could_not_be_submitted + ': ' + response.data.errors[ 0 ]
                                                }, "body" );
                                            }
                                        } );
                                    },
                                    cancel: function () {
                                        return false;
                                    }
                                } );
                            };
                        }
                    };
                }
            };
    } ] );
    } );
