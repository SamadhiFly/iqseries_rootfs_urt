define(['module/terminal', 'text!module/terminal/conf/general.json'], function(terminal, strGeneralConfig) {
  'use strict';
  terminal.service('AuthenticationService', ['$http', function($http) {
    var generalConfig = $.parseJSON(strGeneralConfig);

    return {
      authenticated: false,
      isAdmin: false,
      on401: function() {
        var that = this;
        that.authenticated = false;
      },
      checkBeAuth: function() {
        var that = this,
            httpPromise;

        httpPromise = $http({
           url: generalConfig.host + generalConfig.apiRoot + 'terminal/status/session',
           method: "GET"
        });

        httpPromise.then(function(response) {
          if(response.data.data.whoami === 'admin') {
            that.isAdmin = true;
            that.authenticated = true;
          } else if(response.data.data.whoami !== '') {
            that.isAdmin = false;
            that.authenticated = true;
          } else {
            that.isAdmin = false;
            that.authenticated = false;
          }
        });
        return httpPromise;
      },
      login: function(user, password) {
        var that = this,
            httpPromise;

        httpPromise = $http({
           url: generalConfig.host + generalConfig.apiRoot + 'auth/login',
           method: "POST",
           //data: { "username" : user , "password" : password }
           data: "username="+user+"&password="+password,
           headers: {
                   'Content-Type': 'application/json'
           }
        });

        httpPromise.then(function(response) {
            if(response.data.success === '1' && response.data.msg_code === '100') {
              that.authenticated = true;
              that.checkBeAuth();
            } else {
              that.authenticated = false;
            }
        });

        return httpPromise;
      },
      logout: function () {
        var that = this,
            httpPromise;

        httpPromise = $http({
           url: generalConfig.host + generalConfig.apiRoot + 'auth/logout',
           method: "POST",
           headers: {
                   'Content-Type': 'application/json'
           }
        });

        httpPromise.then(function(response) {
            if(response.data.success === '1' && response.data.msg_code === '101') {
              that.authenticated = false;
            } else {
              that.authenticated = true;
            }
        });

        return httpPromise;

      }
    };
  }]);
});
