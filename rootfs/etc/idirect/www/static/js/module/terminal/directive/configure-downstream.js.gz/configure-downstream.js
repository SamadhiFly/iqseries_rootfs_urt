define( [ 'module/terminal',
  'text!module/terminal/conf/general.json',
  'templates/nmsweb/module/terminal/directive/configure-downstream.tpl',
  'module/terminal/service/terminal-streaming-buffer',
  'module/terminal/factory/tool-resource',
  'module/core/directive/form',
  'module/core/factory/form',
  'module/core/directive/nmsweb-input'
], function ( terminal, strGeneralConfig, template ) {
    'use strict';
    terminal.directive( 'configureDownstream', [ '$rootScope', 'TerminalStreamingBuffer', '$http', '$interval', 'ToolResource', 'NmswebForm', function ( $rootScope, TerminalStreamingBuffer, $http, $interval, ToolResource, NmswebForm ) {
        return {
            restrict: 'E',
            template: template,
            replace: true,
            scope: {
                valid: '=?',
                downstreamConfiguration: '=',
                wizard: '=?'
            },
            compile: function () {
                return {
                    pre: function preLink( scope, element, attrs, ngModel ) {
                        var formOptions = {
                                "layout": "layouts/terminal/tools/antenna-pointing",
                                "hook": "module/terminal/hook/tool-antenna-pointing"
                            },
                            generalConfig = $.parseJSON( strGeneralConfig );
                        scope.openamip = false;
                        TerminalStreamingBuffer.registerResource( 'terminal/rx' );
                        //TerminalStreamingBuffer.registerResource( 'terminal/odu/buc/0' );
                        formOptions.resource = new ToolResource( 'antenna-pointing' );
                        formOptions.name = 'antenna-pointing';
                        formOptions.viewMode = false;
                        scope.title = "";
                        var httpPromise = $http( {
                            url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/identity',
                            method: "GET"
                        } );
                        httpPromise.then( function successCallback( response ) {
                            scope.formReady = true;
                            if ( response.data && response.data.data && response.data.data.openamip && response.data.data.openamip.mode == 'disabled' ) {
                                scope.openamip = false;
                                scope.form.openAmip = false;
                            } else {
                                scope.form.openAmip = true;
                                scope.openamip = true;
                            }
                            scope.form.wizard = scope.wizard;
                        }, function errorCallback() {
                            scope.formReady = true;
                            scope.openamip = false;
                            scope.form.openAmip = false;
                            scope.form.wizard = scope.wizard;
                        } );
                        if ( !element.find( 'form' ).hasClass( 'ng-invalid' ) ) {
                            scope.valid = true;
                        }
                        scope.$watch( function () {
                            return element.find( 'form' ).hasClass( 'ng-invalid' );
                        }, function ( newVal, oldVal ) {
                            scope.valid = !newVal;
                        } );
                        scope.form = new NmswebForm( formOptions );
                        scope.form.actions = [];

                        if ( scope.downstreamConfiguration ) {
                            scope.form.model = angular.extend( scope.form.model, scope.downstreamConfiguration );
                        }
                        scope.downstreamConfiguration = scope.form.model;
                        scope.downstreamConfiguration.openamip = scope.openamip;

                    },
                    post: function () {}
                }
            }
        };
    } ] );
} );
