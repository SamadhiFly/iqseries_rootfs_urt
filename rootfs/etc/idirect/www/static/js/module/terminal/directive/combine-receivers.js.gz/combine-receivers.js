define( [ 'module/terminal',
  'text!module/terminal/conf/general.json',
  'templates/nmsweb/module/terminal/directive/combine-receivers.tpl',
  'module/terminal/service/terminal-streaming-buffer',
  'module/terminal/factory/tool-resource',
  'module/core/directive/form',
  'module/core/factory/form',
  'module/core/directive/nmsweb-input'
], function ( terminal, strGeneralConfig, template ) {
    'use strict';
    terminal.directive( 'combineReceivers', [ '$rootScope', 'TerminalStreamingBuffer', '$http', '$interval', 'ToolResource', 'NmswebForm', function ( $rootScope, TerminalStreamingBuffer, $http, $interval, ToolResource, NmswebForm ) {
        return {
            restrict: 'E',
            template: template,
            scope: {},
            compile: function () {
                return {
                    pre: function preLink( scope, element, attrs, ngModel ) {
                        var formOptions = {
                                "layout": "layouts/terminal/tools/combine-receivers",
                                "hook": "module/terminal/hook/combine-receivers"
                            },
                            generalConfig = $.parseJSON( strGeneralConfig );

                        $http( {
                            url: generalConfig.host + generalConfig.apiRoot + 'terminal/mode/manual_downstream/',
                            method: "GET"
                        } ).then( function ( data ) {
                            var rx0data = data.data.data.receivers[ 0 ],
                                rx1data = data.data.data.receivers[ 1 ],
                                combineReceiversData = data.data.data.combine_receivers;
                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/rx/0',
                                method: "GET",
                                headers: {
                                    'Content-Type': 'application/json'
                                }
                            } ).then( function ( rx0getData ) {
                                var rx0mode = rx0getData.data.data.mode;
                                $http( {
                                    url: generalConfig.host + generalConfig.apiRoot + 'terminal/rx/1',
                                    method: "GET",
                                    headers: {
                                        'Content-Type': 'application/json'
                                    }
                                } ).then( function ( rx1getData ) {
                                    var rx1mode = rx1getData.data.data.mode;

                                    formOptions.resource = new ToolResource( 'combine-receivers' );
                                    formOptions.name = 'combine-receivers';
                                    formOptions.viewMode = false;
                                    scope.form = new NmswebForm( formOptions );
                                    scope.form.rx0data = rx0data;
                                    scope.form.rx1data = rx1data;
                                    scope.form.combineReceiversData = combineReceiversData;
                                    scope.form.rx0mode = rx0mode;
                                    scope.form.rx1mode = rx1mode;

                                    scope.formReady = true;
                                } );
                            } );
                        } );
                    },
                    post: function () {}
                }
            }
        };
    } ] );
} );
