define( [ 'module/terminal',
  'module/terminal/service/terminal-streaming-buffer',
  'vendor/highcharts-directive/highcharts-ng',
  'module/core/directive/nmsweb-popover' ],
    function ( terminal, TerminalStreamingBuffer ) {
        'use strict';
        terminal.directive( 'chart', [ '$interval', '$timeout', 'TerminalStreamingBuffer', '$rootScope', '$compile', '$window', function ( $interval, $timeout, TerminalStreamingBuffer, $rootScope, $compile, $window ) {
            return {
                restrict: 'E',
                template: "",
                replace: true,
                scope: {
                    resource: '=?',
                    field: '=?',
                    respath: '=?',
                    type: '=?',
                    unit: '=?',
                    tooltipoptions: '=?',
                    min: '=?',
                    max: '=?',
                    maxpoints: '=?',
                    buffer: '=?',
                    resolutionlive: '=?',
                    resolutionbuffer: '=?',
                    streaminginterval: '=?'
                },
                compile: function () {
                    return {
                        pre: function preLink( scope, element ) {
                            scope.template = "<div><div ng-class=\"{fieldset: 'fieldset-chart', inline:'inline-chart', popover:'popover-chart'}[type]\"><highchart config=\"chartConfig\"></highchart></div></div>";
                            if ( scope.type === 'inline' ) {
                                scope.height = 150;
                                scope.width = 300;
                            } else if ( scope.type === 'popover' ) {
                                scope.height = 200;
                                scope.width = 300;
                            } else if ( scope.type === 'fieldset' ) {
                                scope.height = 200;
                                // scope.width = 400;
                            }

                            if ( scope.resource instanceof Array ) {
                                angular.forEach( scope.resource, function ( value ) {
                                    if ( scope.buffer ) {
                                        TerminalStreamingBuffer.registerResource( value, ( scope.streaminginterval ? scope.streaminginterval : 5000 ), ( scope.streaminginterval ? scope.streaminginterval : 5000 ), true, true );
                                        TerminalStreamingBuffer.changeStoreToLocalStorage( value, true );
                                    }
                                    if ( !TerminalStreamingBuffer.changeBufferInterval( value, 30000 ) ) {
                                        return;
                                    }
                                } );
                            } else {
                                if ( scope.buffer ) {
                                    TerminalStreamingBuffer.registerResource( scope.resource, ( scope.streaminginterval ? scope.streaminginterval : 5000 ), ( scope.streaminginterval ? scope.streaminginterval : 5000 ), true, true );
                                    TerminalStreamingBuffer.changeStoreToLocalStorage( scope.resource, true );
                                } else {
                                    TerminalStreamingBuffer.registerResource( scope.resource, ( scope.streaminginterval ? scope.streaminginterval : 5000 ), 0, false, false );
                                    TerminalStreamingBuffer.changeStoreToLocalStorage( scope.resource, false );
                                }
                                if ( !TerminalStreamingBuffer.changeBufferInterval( scope.resource, 30000 ) ) {
                                    return;
                                }
                            }
                            Highcharts.setOptions( {
                                global: {
                                    useUTC: false,
                                    Date: oldDate
                                }
                            } )
                            scope.chartConfig = {
                                options: {
                                    chart: {
                                        type: 'line',
                                        animation: true,
                                        height: scope.height,
                                        width: scope.width,
                                        zoomType: 'x'
                                    },
                                    plotOptions: {
                                        series: {
                                            marker: {
                                                enabled: false
                                            },
                                            events: {
                                                legendItemClick: function () {
                                                    return false;
                                                }
                                            }
                                        },
                                        line: {
                                            marker: {
                                                enabled: false
                                            },
                                            events: {
                                                legendItemClick: function () {
                                                    return false;
                                                }
                                            }
                                        }
                                    }
                                },
                                title: {
                                    text: ''
                                },
                                series: [],
                                yAxis: {
                                    title: {
                                        text: ''
                                    }
                                },
                                xAxis: {
                                    type: "datetime"
                                },
                                plotOptions: {
                                    series: {
                                        marker: {
                                            enabled: false
                                        }
                                    },
                                    line: {
                                        marker: {
                                            enabled: false
                                        }
                                    }
                                },
                                credits: {
                                    enabled: false
                                }
                            };
                            if ( scope.min !== undefined ) {
                                scope.chartConfig.yAxis.min = scope.min;
                            }
                            if ( scope.max !== undefined ) {
                                scope.chartConfig.yAxis.max = scope.max;
                            }

                            var populateBufferData = function ( res, series ) {
                                if ( series === undefined ) {
                                    var series = 0;
                                }
                                var lastAdded = false;
                                angular.forEach( TerminalStreamingBuffer.buffer[ res ], function ( value, key ) {
                                    var currentTime = parseInt( $.now() );
                                    if ( parseInt( key ) > currentTime - 1800000 ) {
                                        if ( !lastAdded ) {
                                            lastAdded = key;
                                            scope.chartConfig.series[ series ].marker = {
                                                enabled: false
                                            };
                                            if ( scope.respath instanceof Array ) {
                                                if ( scope.respath.length === 0 && value.data[ scope.field[ series ] ] ) {
                                                    scope.chartConfig.series[ series ].data.push( [ parseInt( key ), parseInt( value.data[ scope.field[ series ] ] ) ] );
                                                } else if ( scope.respath.length === 1 && value.data[ scope.respath ] && value.data[ scope.respath[ 0 ] ] && value.data[ scope.respath[ 0 ] ][ scope.field[ series ] ] ) {
                                                    scope.chartConfig.series[ series ].data.push( [ parseInt( key ), parseInt( value.data[ scope.respath[ 0 ] ][ scope.field[ series ] ] ) ] );
                                                } else if ( scope.respath.length === 2 && value.data[ scope.respath ] && value.data[ scope.respath[ 0 ] ] && value.data[ scope.respath[ 0 ] ][ scope.respath[ 1 ] ][ scope.field[ series ] ] ) {
                                                    scope.chartConfig.series[ series ].data.push( [ parseInt( key ), parseInt( value.data[ scope.respath[ 0 ] ][ scope.respath[ 1 ] ][ scope.field[ series ] ] ) ] );
                                                }
                                            } else if ( value.data[ scope.field[ series ] ] ) {
                                                scope.chartConfig.series[ series ].data.push( [ parseInt( key ), parseInt( value.data[ scope.field[ series ] ] ) ] );
                                            }
                                        } else if ( ( key - lastAdded ) > scope.resolutionbuffer ) {
                                            lastAdded = key;
                                            scope.chartConfig.series[ series ].marker = {
                                                enabled: false
                                            };
                                            if ( scope.respath instanceof Array ) {
                                                if ( scope.respath.length === 0 && value.data[ scope.field[ series ] ] ) {
                                                    scope.chartConfig.series[ series ].data.push( [ parseInt( key ), parseInt( value.data[ scope.field[ series ] ] ) ] );
                                                } else if ( scope.respath.length === 1 && value.data[ scope.respath ] && value.data[ scope.respath[ 0 ] ] && value.data[ scope.respath[ 0 ] ][ scope.field[ series ] ] ) {
                                                    scope.chartConfig.series[ series ].data.push( [ parseInt( key ), parseInt( value.data[ scope.respath[ 0 ] ][ scope.field[ series ] ] ) ] );
                                                } else if ( scope.respath.length === 2 && value.data[ scope.respath ] && value.data[ scope.respath[ 0 ] ] && value.data[ scope.respath[ 0 ] ][ scope.respath[ 1 ] ][ scope.field[ series ] ] ) {
                                                    scope.chartConfig.series[ series ].data.push( [ parseInt( key ), parseInt( value.data[ scope.respath[ 0 ] ][ scope.respath[ 1 ] ][ scope.field[ series ] ] ) ] );
                                                }
                                            } else if ( value.data[ scope.field[ series ] ] ) {
                                                scope.chartConfig.series[ series ].data.push( [ parseInt( key ), parseInt( value.data[ scope.field[ series ] ] ) ] );
                                            }
                                        }
                                    }
                                } );
                            };

                            var populateData = function ( res, series ) {
                                if ( series === undefined ) {
                                    var series = 0;
                                }
                                $rootScope.routeListeners.push( $rootScope.$on( 'streamingBufferGeneralUpdate', function ( event ) {
                                    var currentTime, dataInput;
                                    currentTime = parseInt( $.now() );
                                    // var resource = [ res, 'data'].concat( ( scope.respath ) ? scope.respath[series] : [] ).concat( scope.field[series] );
                                    if(scope.resource && !(scope.resource instanceof Array)){
                                        res = scope.resource;
                                    }
                                    var resource = [ res, 'data' ];
                                    if ( scope.respath ) {
                                        angular.forEach( scope.respath, function ( value ) {
                                            resource = resource.concat( value );
                                        } );
                                    }
                                    resource = resource.concat( scope.field[ series ] );
                                    dataInput = TerminalStreamingBuffer.getCurrentValue( resource );
                                    if ( scope.field[ series ] === 'idsACSStatusDelay' ) {
                                        dataInput = dataInput.split( " " )[ 0 ];
                                    }
                                    if ( dataInput instanceof Array ) {
                                        dataInput = Number( dataInput[ 0 ] );
                                    } else {
                                        dataInput = Number( dataInput );
                                    }
                                    scope.chartConfig.series[ series ].marker = {
                                        enabled: false
                                    };
                                    if ( scope.chartConfig.series[ series ].data.length > scope.maxpoints ) {
                                        scope.chartConfig.series[ series ].data.shift();
                                    }
                                    if ( !isNaN( dataInput ) ) {
                                        if ( !scope.chartConfig.series[ series ].lastAdded ) {
                                            scope.chartConfig.series[ series ].data.push( [ currentTime, dataInput ] );
                                            scope.chartConfig.series[ series ].lastAdded = currentTime;
                                        } else if ( ( currentTime - scope.chartConfig.series[ series ].lastAdded ) > scope.resolutionlive ) {
                                            scope.chartConfig.series[ series ].data.push( [ currentTime, dataInput ] );
                                            scope.chartConfig.series[ series ].lastAdded = currentTime;
                                        }
                                    }
                                } ) );
                            };

                            if ( scope.resource instanceof Array ) {
                                var currentTime = parseInt( $.now() );
                                angular.forEach( scope.resource, function ( value, key ) {
                                    if ( scope.unit[ key ] == '' ) {
                                        var unit = '';
                                    } else {
                                        var unit = ' in ' + scope.unit[ key ];
                                    }
                                    scope.chartConfig.series.push( {
                                        name: $rootScope.translation.language[ scope.field[ key ] ] + unit,
                                        data: [],
                                        lastAdded: currentTime
                                    } );
                                    if ( scope.buffer ) {
                                        populateBufferData( value, key );
                                    }
                                    populateData( value, key );
                                } );
                            } else {
                                if ( scope.unit == '' ) {
                                    var unit = '';
                                } else {
                                    var unit = ' in ' + scope.unit;
                                }
                                scope.chartConfig.series.push( {
                                    name: $rootScope.translation.language[ scope.field ] + unit,
                                    data: [],
                                    lastAdded: currentTime
                                } );
                                scope.field = [ scope.field ];
                                if ( scope.buffer ) {
                                    populateBufferData( scope.resource );
                                }
                                populateData( scope.resource );
                            }
                            if ( scope.type === 'inline' || scope.type === 'fieldset' ) {
                                element.append( $compile( scope.template )( scope ) );
                            } else if ( scope.type === 'popover' ) {
                                scope.tooltip = {
                                    "title": scope.tooltipoptions.title,
                                    "placement": scope.tooltipoptions.placement,
                                    "manual": true,
                                    "closeBtn": true,
                                    "content": ""
                                };
                                scope.renderPopoverContent = function () {
                                    scope.popover.options.content = $compile( scope.template )( scope );
                                };
                                element.append( $compile( '<span class="charting-tooltip" ng-click="renderPopoverContent()" nmsweb-popover="popover" nmsweb-popover-options="tooltip"><span class="tooltip-icon"></span></span>' )( scope ) );
                            }
                        },
                        post: function postLink( scope, element ) {
                            $timeout( function () {
                                $( window ).resize();
                            } );
                        }
                    };
                }
            }
  } ] );
    } );
