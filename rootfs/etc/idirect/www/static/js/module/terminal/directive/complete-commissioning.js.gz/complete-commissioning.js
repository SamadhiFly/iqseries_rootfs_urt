define( [ 'module/terminal',
'text!module/terminal/conf/general.json',
'templates/nmsweb/module/terminal/directive/complete-commissioning.tpl',
'module/terminal/service/terminal-streaming-buffer' ],
    function ( terminal, strGeneralConfig, template ) {
        'use strict';
        terminal.directive( 'completeCommissioning', [ '$rootScope', 'TerminalStreamingBuffer', '$interval', '$location', '$route', function ( $rootScope, TerminalStreamingBuffer, $interval, $location, $route ) {
            return {
                restrict: 'E',
                template: template,
                replace: true,
                scope: {},
                compile: function () {
                    return {
                        pre: function preLink( scope, element ) {
                            var generalConfig = $.parseJSON( strGeneralConfig );
                            scope.remainingAqcuireTime = 300;
                            scope.acquiringNetwork = false;
                            scope.foundNetwork = false;
                            scope.acquireNetwork = function () {
                                TerminalStreamingBuffer.registerResource( 'terminal/status/network', 5000 );
                                scope.acquiringNetwork = true;
                                var acquireInterval = $interval( function () {
                                    var network = TerminalStreamingBuffer.getCurrentValue( [ 'terminal/status/network' ] ),
                                        min = Math.floor( scope.remainingAqcuireTime / 60 ),
                                        sec = Math.floor( scope.remainingAqcuireTime - min * 60 );
                                    scope.remainingAqcuireTime = parseInt( scope.remainingAqcuireTime ) - 1;
                                    scope.remainingAqcuireTimeHuman = ( ( min ) ? min + "min " : "" ) + sec + "sec";
                                    if ( network.data && network.data.state && ( network.data.state == "IN_NETWORK" || network.data.state == "RX_ONLY" ) ) {
                                        scope.foundNetwork = true;
                                        scope.acquiringNetwork = false;
                                        $interval.cancel( acquireInterval );
                                    } else if ( scope.remainingAqcuireTime <= 0 ) {
                                        scope.acquiringNetwork = false;
                                        $interval.cancel( acquireInterval );
                                    }
                                }, 1000 );
                            };
                            scope.reloadPath = function () {
                                $route.reload();
                            };
                            scope.changePath = function ( path ) {
                                $location.path( path );
                            }
                            scope.acquireNetwork();
                        },
                        post: function () {}
                    }
                }
            };
    } ] );
    } );
