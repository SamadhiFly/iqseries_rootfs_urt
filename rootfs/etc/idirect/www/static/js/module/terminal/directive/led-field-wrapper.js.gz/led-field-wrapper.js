define(['module/terminal', 'module/terminal/directive/led'],
    function(terminal) {
        'use strict';
        terminal.directive('ledFieldWrapper', ['$compile', function($compile) {
            return {
                restrict: 'E',
                replace: true,
                require: '?ngModel',
                template: '',
                scope: {
                    nmswebOptions: '=',
                    additionalOptions: '=',
                    model: '=ngModel'
                },
                compile: function() {
                    return {
                        pre: function preLink(scope, element) {
                            var fieldTpl = angular.element('<led size="' + scope.nmswebOptions.ledSize + '" color="model[0]"></led><' + scope.nmswebOptions.origType + ' nmsweb-options="nmswebOptions"  additional-options="additionalOptions" ng-model="model[1]"></' + scope.nmswebOptions.origType + '>');
                            element.append($compile(fieldTpl)(scope));
                        }
                    };
                }
            };
        }]);
    });