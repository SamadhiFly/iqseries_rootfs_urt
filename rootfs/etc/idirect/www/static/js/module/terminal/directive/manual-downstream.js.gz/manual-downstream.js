define( [ 'module/terminal',
'text!module/terminal/conf/general.json',
'templates/nmsweb/module/terminal/directive/manual-downstream.tpl',
'module/terminal/service/terminal-streaming-buffer',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form',
'module/core/directive/nmsweb-input',
'module/terminal/directive/multicast',
'module/terminal/directive/mpe',
'module/terminal/directive/mgmt-lan'
], function ( terminal, strGeneralConfig, template ) {
    'use strict';
    terminal.directive( 'manualDownstream', [ '$rootScope', 'TerminalStreamingBuffer', '$http', '$interval', '$timeout', 'ToolResource', 'NmswebForm', 'NMSWebNotification', function ( $rootScope, TerminalStreamingBuffer, $http, $interval, $timeout, ToolResource, NmswebForm, NMSWebNotification ) {
        return {
            restrict: 'E',
            template: template,
            replace: true,
            compile: function () {
                return {
                    pre: function preLink( scope, element, attrs, ngModel ) {
                        scope.combineReceiverEnable = false;
                        scope.activeTab = 0;
                        scope.tabStyle0 = {
                            "display": "block"
                        };
                        var generalConfig = $.parseJSON( strGeneralConfig );
                        var form = {
                            "layout": "layouts/terminal/tools/manual-downstream",
                            "hook": "module/terminal/hook/tool-manual-downstream"
                        };
                        form.resource = new ToolResource( 'manual-downstream' );
                        scope.manualDownstream_1 = new NmswebForm( form );
                        scope.manualDownstream_1.actions = [];
                        scope.manualDownstream_1.receiver = 1;

                        form.layout += "2";
                        scope.manualDownstream_2 = new NmswebForm( form );
                        scope.manualDownstream_2.actions = [];
                        scope.manualDownstream_2.receiver = 2;

                        scope.toggleCombineReceiver = function () {
                            if ( $rootScope.model != "950mp" ) {
                                scope.combineReceiverEnable = !scope.combineReceiverEnable;
                                if ( scope.combineReceiverEnable ) {
                                    $rootScope.$broadcast( 'combineReceiversOn' );
                                } else {
                                    $rootScope.$broadcast( 'combineReceiversOff' );
                                }
                            }
                        };

                        scope.toggleManualConfiguration = function ( id ) {
                            scope[ "manualConfigurationEnabled" + id ] = !scope[ "manualConfigurationEnabled" + id ];
                            scope.update( id );
                        };
                        scope.update = function ( id ) {
                            if ( $( '#' + scope[ "manualDownstream_" + id ].fields[ 'symbol_rate_' + id ].id ).data( 'kendoNumericTextBox' ) ) {
                                if ( !scope[ "manualConfigurationEnabled" + id ] ) {
                                    $( '#' + scope[ "manualDownstream_" + id ].fields[ 'symbol_rate_' + id ].id ).data( 'kendoNumericTextBox' ).enable( false );
                                    $( '#' + scope[ "manualDownstream_" + id ].fields[ 'rolloff_' + id ].id ).data( 'kendoDropDownList' ).enable( false );
                                    $( '#' + scope[ "manualDownstream_" + id ].fields[ 'rf_frequency_' + id ].id ).data( "kendoNumericTextBox" ).enable( false );
                                    $( '#' + scope[ "manualDownstream_" + id ].fields[ 'if_frequency_' + id ].id ).data( "kendoNumericTextBox" ).enable( false );
                                    $( '#' + scope[ "manualDownstream_" + id ].fields[ 'coding_' + id ].id ).data( "kendoDropDownList" ).enable( false );
                                    $( '#' + scope[ "manualDownstream_" + id ].fields[ 'modulation_' + id ].id ).data( "kendoDropDownList" ).enable( false );
                                    $( '#' + scope[ "manualDownstream_" + id ].fields[ 'encapsulation_' + id ].id ).data( "kendoDropDownList" ).enable( false );
                                } else {
                                    if ( !scope.combineReceiverEnable ) {
                                        $( '#' + scope[ "manualDownstream_" + id ].fields[ 'encapsulation_' + id ].id ).data( "kendoDropDownList" ).enable( true );
                                    }
                                    $( '#' + scope[ "manualDownstream_" + id ].fields[ 'symbol_rate_' + id ].id ).data( 'kendoNumericTextBox' ).enable( true );
                                    $( '#' + scope[ "manualDownstream_" + id ].fields[ 'rolloff_' + id ].id ).data( 'kendoDropDownList' ).enable( true );
                                    $( '#' + scope[ "manualDownstream_" + id ].fields[ 'rf_frequency_' + id ].id ).data( "kendoNumericTextBox" ).enable( true );
                                    $( '#' + scope[ "manualDownstream_" + id ].fields[ 'if_frequency_' + id ].id ).data( "kendoNumericTextBox" ).enable( true );
                                    if ( scope[ "manualDownstream_" + id ].model[ "encapsulation_" + id ] === "MPE" ) {
                                        $( '#' + scope[ "manualDownstream_" + id ].fields[ 'coding_' + id ].id ).data( "kendoDropDownList" ).enable( true );
                                        $( '#' + scope[ "manualDownstream_" + id ].fields[ 'modulation_' + id ].id ).data( "kendoDropDownList" ).enable( true );
                                    }
                                }
                            }
                        };
                        scope.changeTab = function ( name ) {
                            scope.activeTab = name;
                            scope.tabStyle0 = {
                                "display": "none"
                            };
                            scope.tabStyle1 = {
                                "display": "none"
                            };
                            scope.tabStyle2 = {
                                "display": "none"
                            };
                            scope.tabStyle3 = {
                                "display": "none"
                            };
                            scope[ "tabStyle" + name ] = {
                                "display": "block"
                            };

                        };
                        scope.saveManualDownstream = function ( receiver ) {
                            var model = scope[ "manualDownstream_" + receiver ].fields[ 'encapsulation_' + receiver ].model || {},
                                generalConfig = $.parseJSON( strGeneralConfig ),
                                apiResource,
                                apiData = {};

                            if ( !scope[ "manualConfigurationEnabled" + receiver ] ) {
                                apiResource = "terminal/mode/auto/0";
                                apiData = {
                                    beam_select: "IDIRECT",
                                    tx_init_power: -10
                                };
                                if ( receiver == 1 ) {
                                    $http( {
                                        url: generalConfig.host + generalConfig.apiRoot + apiResource,
                                        method: "POST",
                                        data: apiData,
                                        headers: {
                                            'Content-Type': 'application/json'
                                        }
                                    } ).success( function ( response ) {
                                        NMSWebNotification.add( {
                                            type: "success",
                                            isFadeable: true,
                                            title: $rootScope.translation.language[ "receiver_updated" ],
                                            message: $rootScope.translation.language[ "receiver_to_auto" ]
                                        }, "body" );
                                    } ).error( function ( response ) {
                                        NMSWebNotification.add( {
                                            type: "majorwarning",
                                            isFadeable: true,
                                            title: $rootScope.translation.language[ "receiver_" + receiver + "_mode_switch_failed" ],
                                            message: $rootScope.translation.language.the_change_could_not_be_saved_colon + response.errors[ 0 ]
                                        }, "body" );
                                    } );
                                } else {
                                    apiResource = "terminal/mode/off/1";
                                    $http( {
                                        url: generalConfig.host + generalConfig.apiRoot + apiResource,
                                        method: "POST",
                                        headers: {
                                            'Content-Type': 'application/json'
                                        }
                                    } ).success( function ( response ) {
                                        NMSWebNotification.add( {
                                            type: "success",
                                            isFadeable: true,
                                            title: $rootScope.translation.language[ "receiver_updated" ],
                                            message: $rootScope.translation.language[ "receiver_to_off" ]
                                        }, "body" );
                                    } ).error( function ( response ) {
                                        NMSWebNotification.add( {
                                            type: "majorwarning",
                                            isFadeable: true,
                                            title: $rootScope.translation.language[ "receiver_" + receiver + "_mode_switch_failed" ],
                                            message: $rootScope.translation.language.the_change_could_not_be_saved_colon + response.errors[ 0 ]
                                        }, "body" );
                                    } );
                                }
                            } else {
                                model.startValues = scope[ "manualDownstream_" + receiver ].startValues;

                                apiResource = 'terminal/mode/manual_downstream/' + ( receiver - 1 );
                                apiData = {
                                    "encapsulation": model[ 'encapsulation_' + receiver ],
                                    "if_frequency": parseFloat( model[ 'if_frequency_' + receiver ] ),
                                    "rf_frequency": parseFloat( model[ 'rf_frequency_' + receiver ] ),
                                    "symbol_rate": parseFloat( model[ 'symbol_rate_' + receiver ] ),
                                    "rolloff": parseFloat( model[ 'rolloff_' + receiver ] ),
                                    "modulation": model[ 'modulation_' + receiver ],
                                    "coding": model[ 'coding_' + receiver ].replace( '_', '/' )
                                };

                                $http( {
                                        url: generalConfig.host + generalConfig.apiRoot + apiResource,
                                        method: "POST",
                                        data: apiData,
                                        headers: {
                                            'Content-Type': 'application/json'
                                        }
                                    } )
                                    .error( function ( response ) {
                                        NMSWebNotification.add( {
                                            type: "majorwarning",
                                            isFadeable: true,
                                            title: $rootScope.translation.language[ "receiver_" + receiver + "_mode_switch_failed" ],
                                            message: $rootScope.translation.language.the_change_could_not_be_saved_colon + response.errors[ 0 ]
                                        }, "body" );
                                    } )
                                    .success( function ( response ) {
                                        // only if encapsulation or mode changed
                                        if ( apiData.encapsulation !== model.startValues[ 'encapsulation_' + receiver ] ) {
                                            $rootScope.$broadcast( 'receiverConfigSaved' );
                                            NMSWebNotification.add( {
                                                type: "success",
                                                isFadeable: true,
                                                title: $rootScope.translation.language[ "receiver_" + receiver + "_mode_change_successful" ],
                                                message: $rootScope.translation.language.encapsulation_has_been_switched_to + " " + apiData.encapsulation + ". " + $rootScope.translation.language.reboot_needed
                                            }, "body" );
                                        } else {
                                            NMSWebNotification.add( {
                                                type: "success",
                                                isFadeable: true,
                                                title: $rootScope.translation.language[ "receiver_" + receiver + "_mode_change_successful" ],
                                                message: $rootScope.translation.language.configuration_successfully_saved
                                            }, "body" );
                                        }
                                    } );
                            }
                            return false;
                        };
                        scope.saveCombineReceivers = function () {

                            var apiData = {
                                    combine_receivers: scope.combineReceiverEnable
                                },
                                generalConfig = $.parseJSON( strGeneralConfig );
                            $http( {
                                    url: generalConfig.host + generalConfig.apiRoot + "/terminal/mode/manual_downstream",
                                    method: "POST",
                                    data: apiData,
                                    headers: {
                                        'Content-Type': 'application/json'
                                    }
                                } )
                                .error( function ( response ) {
                                    NMSWebNotification.add( {
                                        type: "majorwarning",
                                        isFadeable: true,
                                        title: $rootScope.translation.language.combine_receivers_failed,
                                        message: $rootScope.translation.language.the_change_could_not_be_saved_colon + response.errors[ 0 ]
                                    }, "body" );
                                } )
                                .success( function ( response ) {
                                    reboot();
                                } );

                        };
                        scope.reboot = function () {
                            reboot();
                        };

                        function reboot() {
                            $.confirm( {
                                title: $rootScope.translation.language.wantReboot,
                                content: $rootScope.translation.language.wantRebootLong,
                                confirmButton: $rootScope.translation.language.continueReboot,
                                cancelButton: $rootScope.translation.language.cancel,
                                confirm: function () {
                                    $http( {
                                            url: generalConfig.host + generalConfig.apiRoot + 'terminal/device/reboot',
                                            method: "POST",
                                            headers: {
                                                'Content-Type': 'application/json'
                                            }
                                        } )
                                        .then( function successCallback( response ) {
                                            $rootScope.$broadcast( 'streamingBufferGeneralUpdate', true );
                                            NMSWebNotification.add( {
                                                type: "success",
                                                isFadeable: true,
                                                title: $rootScope.translation.language.reboot_successful,
                                                message: $rootScope.translation.language.reboot_message
                                            }, "body" );
                                        }, function errorCallback( response ) {
                                            NMSWebNotification.add( {
                                                type: "majorwarning",
                                                isFadeable: true,
                                                title: $rootScope.translation.language.reboot_failed,
                                                message: $rootScope.translation.language.the_device_cant_be_rebooted
                                            }, "body" );
                                        } );
                                },
                                cancel: function () {}
                            } );
                        }

                    },
                    post: function () {}
                };
            }
        };
  } ] );
} );