define( [ 'module/terminal',
'text!module/terminal/conf/general.json',
'templates/nmsweb/module/terminal/directive/mgmt-lan.tpl',
'module/terminal/service/terminal-streaming-buffer',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form',
'module/core/directive/nmsweb-input'
], function ( terminal, strGeneralConfig, template ) {
    'use strict';
    terminal.directive( 'mgmtLan', [ '$rootScope', 'TerminalStreamingBuffer', '$http', '$interval', '$timeout', 'ToolResource', 'NmswebForm', 'NMSWebNotification', function ( $rootScope, TerminalStreamingBuffer, $http, $interval, $timeout, ToolResource, NmswebForm, NMSWebNotification) {
        return {
            restrict: 'E',
            template: template,
            replace: true,
            compile: function () {
                return {
                    pre: function preLink( scope, element, attrs, ngModel ) {
                        var generalConfig = $.parseJSON( strGeneralConfig );
                        var form = {
                            "layout": "layouts/terminal/tools/mgmt_lan",
                            "hook": "module/terminal/hook/tool-mgmt-lan"
						};
                        form.resource = new ToolResource( 'mgmt-lan' );
                        scope.mgmt_lan = new NmswebForm( form );
                        scope.mgmt_lan.actions = [];
                        scope.mgmt_lan.receiver = 1;

                        scope.mgmtsave = function(){
                            var ip_regex = /^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/;
                            var apiData = {};
                            for(var config in this.mgmt_lan.model){
                                if(!config.startsWith("lan")){
                                   continue;
                                }
                                if(ip_regex.test(this.mgmt_lan.model[config])){
                                    apiData[config] = this.mgmt_lan.model[config];
                                } else {
                                    NMSWebNotification.add( {
                                        type: "majorwarning",
                                        isFadeable: true,
                                        title: $rootScope.translation.language.error,
                                        message: $rootScope.translation.language.invalid_field + ": " + $rootScope.translation.language[config]
                                    }, "body" );
                                    return false;
                                }
                            }
                            generalConfig = $.parseJSON( strGeneralConfig );
                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + "/terminal/ip/multicast_management_lan",
                                method: "POST",
                                data: apiData,
                                headers: {
                                    'Content-Type': 'application/json'
                                }
                            } )
                            .error( function ( response ) {
                                NMSWebNotification.add( {
                                    type: "majorwarning",
                                    isFadeable: true,
                                    title: $rootScope.translation.language.update_ip_config_failed,
                                    message: $rootScope.translation.language.the_change_could_not_be_saved_colon + response.errors[ 0 ]
                                }, "body" );
                            } )
                            .then( function ( response ) {
                                if ( response.status == "200" ) {
                                    NMSWebNotification.add( {
                                        type: "success",
                                        isFadeable: true,
                                        title: $rootScope.translation.language.update_ip_config,
                                        message: $rootScope.translation.language.configuration_successfully_saved
                                    }, "body" );
                                } else {
                                    NMSWebNotification.add( {
                                        type: "majorwarning",
                                        isFadeable: true,
                                        title: $rootScope.translation.language.update_ip_config_failed,
                                        message: $rootScope.translation.language.the_change_could_not_be_saved
                                    }, "body" );
                                }
                            } );
                        };

                    },
                    post: function () {
                    }
                };
            }
        };
  } ] );
} );