define( [ 'module/terminal',
'templates/nmsweb/module/terminal/directive/cross-pol.tpl',
'text!module/terminal/conf/general.json',
'module/terminal/service/terminal-streaming-buffer',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form',
'module/terminal/directive/nmsweb-html',
'module/core/directive/nmsweb-tooltip',
'module/core/service/nmsutils' ],
    function ( terminal, template, strGeneralConfig ) {
        'use strict';
        terminal.directive( 'crossPol', [ '$rootScope', 'TerminalStreamingBuffer', 'ToolResource', 'NmswebForm', '$http', 'NMSWebNotification', '$timeout', function ( $rootScope, TerminalStreamingBuffer, ToolResource, NmswebForm, $http, NMSWebNotification, $timeout ) {
            return {
                restrict: 'E',
                template: template,
                replace: true,
                scope: {
                    valid: '=?',
                    crossPolConfiguration: '=?',
                    rxId: '=?',
                    standAloneTool: '=?',
                    mode: '=?'
                },
                compile: function () {
                    return {
                        pre: function preLink( scope, element ) {
                            var generalConfig = $.parseJSON( strGeneralConfig ),
                                formOptions = {
                                    "layout": "layouts/terminal/tools/cross-polarization",
                                    "hook": "module/terminal/hook/tool-cross-polarization"
                                };
                            scope._isolate = scope;
                            scope.mode = ( typeof scope.mode !== "undefined" ) ? scope.mode : "crosspol";
                            formOptions.resource = new ToolResource( 'cross-polarization' );
                            formOptions.name = 'cross-polarization';
                            formOptions.viewMode = false;
                            scope.title = formOptions.name;
                            scope.isCircular = false;
                            if ( $rootScope.system_type === "VELOCITY" ) {
                                scope.bucs = [];
                                scope.bands = [];
                                scope.commissioned_bands = [];

                                $http( {
                                    url: generalConfig.host + generalConfig.apiRoot + "terminal/config/commission",
                                    method: 'GET',
                                } ).error( function ( error ) {
                                    NMSWebNotification.add( {
                                        type: "error",
                                        isFadeable: true,
                                        title: $rootScope.translation.language.no_band_information,
                                        message: error
                                    }, "body" );
                                } ).success( function ( bands ) {
                                    for ( var k = 0; k < bands.data.commissioned_bucs.length; k++ ) {
                                        scope.commissioned_bands.push.apply( scope.commissioned_bands, bands.data.commissioned_bucs[ k ].available_bands )
                                    }

                                    $http( {
                                        url: generalConfig.host + generalConfig.apiRoot + "terminal/odu/buc",
                                        method: 'GET',
                                    } ).error( function ( error ) {
                                        NMSWebNotification.add( {
                                            type: "error",
                                            isFadeable: true,
                                            title: $rootScope.translation.language.no_band_information,
                                            message: error
                                        }, "body" );
                                    } ).success( function ( bucs ) {

                                        for ( var i = 0; i < bucs.data.length; i++ ) {
                                            $http( {
                                                url: generalConfig.host + generalConfig.apiRoot + "terminal/odu/buc/" + i + "/bands",
                                                method: 'GET',
                                            } ).error( function ( error ) {
                                                NMSWebNotification.add( {
                                                    type: "error",
                                                    isFadeable: true,
                                                    title: $rootScope.translation.language.no_band_information,
                                                    message: error
                                                }, "body" );
                                            } ).success( function ( buc_bands ) {
                                                for ( var j = 0; j < buc_bands.data.length; j++ ) {
                                                    var band = buc_bands.data[ j ];
                                                    band.commissioned = false;
                                                    if ( scope.commissioned_bands ) {
                                                        for ( var k = 0; k < scope.commissioned_bands.length; k++ ) {
                                                            if ( scope.commissioned_bands[ k ].installer_record.start_rf_frequency == buc_bands.data[ j ].start_rf_frequency ) {
                                                                band.commissioned = true;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    scope.bands.push( band );
                                                }
                                            } );
                                        }
                                    } );
                                } );
                            }

                            var executeCrossPol = function ( bucResult ) {
                                var getSpectralInversion = function () {
                                        var spectralInversion = false;
                                        // if system_type is evolution, use odu/buc API result for spectralInversion flag
                                        if ( $rootScope.system_type === 'EVOLUTION' ) {
                                            angular.forEach( bucResult, function ( value, key ) {
                                                if ( value.id === scope.form.model.receiver || value.id === 0 ) {
                                                    spectralInversion = value.spectral_inversion;
                                                }
                                            } );
                                        } else {
                                            // if system_type is velocity, check if BUC LO frequency is greater than RF frequency --> spectralInversion
                                            if ( typeof scope.form.model.buc_lo_frequency !== 'undefined' && typeof scope.form.model.rf_uplink_frequency !== 'undefined' ) {
                                                spectralInversion = ( scope.form.model.buc_lo_frequency > scope.form.model.rf_uplink_frequency );
                                            }
                                        }
                                        return spectralInversion;
                                    },
                                    getLbandTxFrequency = function () {
                                        var spectralInversion = getSpectralInversion();
                                        if ( $rootScope.system_type === "VELOCITY" ) {
                                            var found_legacy = false;
                                            var found_multiband = false;
                                            var error = false;

                                            if ( scope.form.model.buc_lo_frequency && scope.form.model.buc_lo_frequency > 0 ) {
                                                found_legacy = true;
                                                if ( !spectralInversion || spectralInversion === false || spectralInversion === "false" && typeof scope.form.model.rf_uplink_frequency !== 'undefined'  ) {
                                                    scope.form.model.start_frequency = scope.form.model.buc_lo_frequency + 950;
                                                    scope.form.model.stop_frequency = scope.form.model.buc_lo_frequency + 1950;
                                                } else if ( spectralInversion || spectralInversion === true || spectralInversion === "true" && typeof scope.form.model.rf_uplink_frequency !== 'undefined' ) {
                                                    scope.form.model.start_frequency = scope.form.model.buc_lo_frequency - 1950;
                                                    scope.form.model.stop_frequency = scope.form.model.buc_lo_frequency - 950;
                                                }
                                            }

                                            var do_for = (scope.bands.length > 0)? true : false ;
                                            var translation = 0;

                                            for ( var i = 0; i < scope.bands.length && do_for ; i++ ) {
                                                if ( scope.bands && scope.bands[ i ].start_rf_frequency <= scope.form.model.rf_uplink_frequency && scope.bands[ i ].stop_rf_frequency >= scope.form.model.rf_uplink_frequency ) {
                                                    scope.form.model.start_frequency = scope.bands[ i ].start_rf_frequency;
                                                    scope.form.model.stop_frequency = scope.bands[ i ].stop_rf_frequency;
                                                    scope.form.model.stop_frequency = scope.bands[ i ].stop_rf_frequency;
                                                    translation = scope.bands[ i ].translation;
                                                    scope.form.model.rf_buc_rated_power = scope.bands[ i ].rf_buc_rated_power;
                                                    scope.form.model.band_status = ( scope.bands[ i ].commissioned ) ? "Commissioned" : "Not Commissioned";
                                                    found_multiband = true;
                                                    error = false;
                                                    break;
                                                } else {
                                                    scope.form.model.start_frequency = 0;
                                                    scope.form.model.stop_frequency = 0;
                                                    scope.form.model.rf_buc_rated_power = 0;
                                                    scope.form.model.band_status = "No band found";
                                                    error = true;
                                                }
                                            }

                                            if ( ! error && found_multiband || found_legacy ) {
                                                scope.form.model.buc_lo_frequency = found_multiband ? translation : scope.form.model.buc_lo_frequency ;
                                            }

                                        }
                                        if ( !spectralInversion || spectralInversion === false || spectralInversion === "false"  ) {
                                            if ( $rootScope.system_type === "VELOCITY" ) {
                                                var valid_rf_uplink = (scope.form.model.rf_uplink_frequency >= scope.form.model.start_frequency && scope.form.model.rf_uplink_frequency <= scope.form.model.stop_frequency );
                                                return ( valid_rf_uplink && (found_multiband || found_legacy) )? ( scope.form.model.rf_uplink_frequency - scope.form.model.buc_lo_frequency ).toFixed( 6 ) : 
                                                    (0).toFixed( 6 );
                                            } else if ( $rootScope.system_type === "EVOLUTION" ) {
                                                return ( scope.form.model.rf_uplink_frequency - scope.form.model.buc_lo_frequency ).toFixed( 6 );
                                            }
                                        } else {
                                            return ( scope.form.model.buc_lo_frequency - scope.form.model.rf_uplink_frequency ).toFixed( 6 );
                                        }
                                    },
                                    httpPromise = $http( {
                                        url: generalConfig.host + generalConfig.apiRoot + 'terminal/status/location/satellite',
                                        method: "GET"
                                    } );
                                httpPromise.then( function ( response ) {
                                    var polarization = false;
                                    if ( response.data.data && response.data.data[ 0 ] && response.data.data[ 0 ].polarization ) {
                                        polarization = response.data.data[ 0 ].polarization;
                                    }
                                    scope.isCircular = ( polarization === "L" || polarization === "R" );
                                    if ( scope.mode == "crosspol" && scope.isCircular ) {
                                        $timeout( function () {
                                            scope.valid = true;
                                        } );
                                    }
                                } );
                                var httpPromise = $http( {
                                    url: generalConfig.host + generalConfig.apiRoot + 'terminal/tx',
                                    method: "GET"
                                } );
                                httpPromise.then( function ( response ) {
                                    scope.form = new NmswebForm( formOptions );
                                    scope.form.tx = response.data.data;
                                    scope.form.actions = [];
                                    scope.form.stand_alone_tool = scope.standAloneTool;
                                    scope.form.mode = scope.mode;
                                    scope.form.bucResult = bucResult;

                                    if ( scope.crossPolConfiguration ) {
                                        scope.form.model = angular.extend( scope.crossPolConfiguration );
                                    }
                                    scope.form.rxId = scope.rxId;
                                    if ( !scope.crossPolConfiguration ) {
                                        scope.crossPolConfiguration = {
                                            rf_uplink_frequency: 0,
                                            adjust_lband_transmit_power: 0,
                                            modulation: "CW",
                                            symbol_rate: 0
                                        };
                                    }

                                    if ( !scope.valid ) {
                                        scope.valid = true;
                                    }
                                    var updateValidity = function () {
                                        scope.valid = ( scope.mode === "crosspol" && scope.isCircular && !scope.start ) || ( scope.hasBeenStartedBefore && !scope.start && !element.find( 'form' ).hasClass( 'ng-invalid' ) );
                                    };
                                    scope.$watch( 'start', function () {
                                        updateValidity();
                                    }, true );
                                    scope.$watch( function () {
                                        return element.find( 'form' ).hasClass( 'ng-invalid' );
                                    }, function ( newVal, oldVal ) {
                                        updateValidity();
                                    } );
                                    scope.$watch( function () {
                                        return scope.form && scope.form.$element && scope.form.$element.hasClass( "ng-invalid" );
                                    }, function ( newVal, oldVal ) {
                                        scope.allowStart = !newVal;
                                    } );
                                    scope.translation = $rootScope.translation;
                                    scope.stop = true;
                                    scope.inputError = false;
                                    scope.outOfBoundsFrequency = false;
                                    scope.cross_pol_status = $rootScope.translation.language.off;
                                    scope.power_mode_value = '';
                                    scope.symrate_read_only = true;
                                    if ( scope.tool === 'cross-pol' ) {
                                        scope.form.model.modulation = "CW";
                                    }
                                    TerminalStreamingBuffer.registerResource( 'terminal/odu/buc' );
                                    TerminalStreamingBuffer.registerResource( 'terminal/tx' );
                                    scope.$watch( 'form.model.rf_uplink_frequency', function () {
                                        scope.form.model.lband_tx_frequency = getLbandTxFrequency();
                                    } );
                                    scope.$watch( 'form.model.buc_lo_frequency', function () {
                                        scope.form.model.lband_tx_frequency = getLbandTxFrequency();
                                    } );
                                    scope.$watch( 'form.model.receiver', function () {
                                        scope.form.model.lband_tx_frequency = getLbandTxFrequency();
                                    } );
                                    if ( $rootScope.currentWizardStep === 6 ) {
                                        scope.form.model.modulation = 'CW';
                                    }
                                    scope.$watch( 'crossPolConfiguration.modulation', function () {
                                        if ( scope.crossPolConfiguration.modulation === 'CW' ) {
                                            scope.crossPolConfiguration.symbol_rate = 0;
                                            scope.symrate_read_only = true;
                                        } else {
                                            scope.symrate_read_only = false;
                                        }
                                    } );
                                    $http.get( generalConfig.host + generalConfig.apiRoot + 'terminal/tx' ).then( function ( result ) {
                                        scope.power_mode_value = result.data.data.transmitters[ 0 ].power_mode;
                                    } );
                                    scope.cross_pol_start = function () {
                                        var spectralInversion = getSpectralInversion();
                                        var inversion = !( !spectralInversion || spectralInversion === false || spectralInversion === "false" )
                                        if ( !scope.allowStart || !inversion && scope.form.model.rf_uplink_frequency < scope.form.model.buc_lo_frequency || inversion && scope.form.model.buc_lo_frequency < scope.form.model.rf_uplink_frequency ) {
                                            if ( scope.form.model.rf_uplink_frequency >= scope.form.model.buc_lo_frequency ) {
                                                scope.loRf = true;
                                            } else {
                                                scope.rfLo = true;
                                            }
                                            scope.outOfBoundsFrequency = true;

                                        } else {
                                            angular.element( '.main' ).spin( true );
                                            if(scope.$parent && scope.$parent.buttons && scope.$parent.buttons.length) {
                                                scope.$parent.buttons[0].enabled = false;
                                            }
                                            scope.outOfBoundsFrequency = false;
                                            if ( scope.form.model.modulation === 'CW' ) {
                                                if ( scope.form.model.rf_uplink_frequency != undefined ) {
                                                    scope.inputError = false;
                                                    scope.requestPending = true;

                                                    var postData = {
                                                        rf_frequency: parseFloat( scope.form.model.rf_uplink_frequency ),
                                                        power: parseFloat( scope.form.model.adjust_lband_transmit_power )
                                                    };
                                                    if ( $rootScope.system_type !== "VELOCITY" ) {
                                                        postData.if_frequency = parseFloat( scope.form.model.lband_tx_frequency );
                                                    }

                                                    $http( {
                                                        url: generalConfig.host + generalConfig.apiRoot + ( $rootScope.system_type === 'VELOCITY' ? 'terminal/mode/cw' : 'terminal/mode/cw/' + ( ( scope.rxId !== undefined ) ? scope.rxId : scope.form.model.receiver ) ),
                                                        method: 'POST',
                                                        data: postData
                                                    } ).error( function ( response ) {
                                                        scope.requestPending = false;
                                                        angular.element( '.main' ).spin( false );
                                                        var data = response,
                                                            error;
                                                        if ( data && data.errors && data.errors.length ) {
                                                            if ( typeof data.errors === "string" ) {
                                                                error = data.errors;
                                                            } else if ( Array.isArray( data.errors ) && data.errors.length ) {
                                                                error = data.errors[ 0 ];
                                                            }
                                                            if ( error ) {
                                                                NMSWebNotification.add( {
                                                                    type: "error",
                                                                    isFadeable: true,
                                                                    title: $rootScope.translation.language.an_error_has_occured,
                                                                    message: error
                                                                }, "body" );
                                                            }
                                                        }
                                                    } ).then( function ( response ) {
                                                        var cwOffChangeStep = $rootScope.$on( "wizardChangeStep", function () {
                                                            if ( scope.start ) {
                                                                scope.cross_pol_stop();
                                                            }
                                                            cwOffChangeStep();
                                                        } );
                                                        var cwOff = $rootScope.$on( '$routeChangeStart', function ( event, next ) {
                                                            if ( scope.start ) {
                                                                scope.cross_pol_stop();
                                                            }
                                                            cwOff();
                                                        } );
                                                        scope.requestPending = false;
                                                        angular.element( '.main' ).spin( false );
                                                        scope.cross_pol_status = $rootScope.translation.language.on;
                                                        if ( !scope.start ) {
                                                            NMSWebNotification.add( {
                                                                type: "success",
                                                                isFadeable: true,
                                                                title: $rootScope.translation.language.cross_pol_update_notification,
                                                                message: $rootScope.translation.language.cross_pol_update_notification
                                                            }, "body" );
                                                        }
                                                        scope.start = true;
                                                        scope.hasBeenStartedBefore = true;
                                                        scope.stop = false;
                                                    } );
                                                } else {
                                                    scope.inputError = true;
                                                }
                                            } else {
                                                if ( scope.form.model.rf_uplink_frequency != undefined && scope.form.model.symbol_rate != undefined && scope.form.model.symbol_rate != 0 ) {
                                                    scope.inputError = false;
                                                    scope.requestPending = true;
                                                    var postData = {
                                                        rf_frequency: parseFloat( scope.form.model.rf_uplink_frequency ),
                                                        power: parseFloat( scope.form.model.adjust_lband_transmit_power ),
                                                        symbol_rate: parseFloat( scope.form.model.symbol_rate ),
                                                        modulation: scope.form.model.modulation
                                                    };
                                                    if ( $rootScope.system_type !== "VELOCITY" ) {
                                                        postData.if_frequency = parseFloat( scope.form.model.lband_tx_frequency );
                                                    }
                                                    // if its velocity system, ensure that symbol rate is in range 128Ksps-7500Ksps.
                                                    if ( $rootScope.system_type == "VELOCITY" ) {
                                                        if ( scope.form.model.symbol_rate < 128 ) {
                                                            scope.form.model.symbol_rate = 128;
                                                        }
                                                        else if ( scope.form.model.symbol_rate > 7500 ) {
                                                            scope.form.model.symbol_rate = 7500;
                                                        }
                                                        postData.symbol_rate = parseFloat( scope.form.model.symbol_rate );
                                                    }
                                                    $http( {
                                                        url: generalConfig.host + generalConfig.apiRoot + ( $rootScope.system_type === 'VELOCITY' ? 'terminal/mode/pn' : 'terminal/mode/pn/' + ( ( scope.rxId !== undefined ) ? scope.rxId : scope.form.model.receiver ) ),
                                                        method: 'POST',
                                                        headers: {
                                                            'Content-Type': 'application/json'
                                                        },
                                                        data: postData
                                                    } ).error( function ( response ) {
                                                        scope.requestPending = false;
                                                        angular.element( '.main' ).spin( false );
                                                        var data = response,
                                                            error;
                                                        if ( data.errors.length ) {
                                                            if ( typeof data.errors === "string" ) {
                                                                error = data.errors;
                                                            } else if ( Array.isArray( data.errors ) && data.errors.length ) {
                                                                error = data.errors[ 0 ];
                                                            }
                                                            if ( error ) {
                                                                NMSWebNotification.add( {
                                                                    type: "error",
                                                                    isFadeable: true,
                                                                    title: $rootScope.translation.language.an_error_has_occured,
                                                                    message: error
                                                                }, "body" );
                                                            }
                                                        }
                                                    } ).then( function ( response ) {
                                                        scope.requestPending = false;
                                                        angular.element( '.main' ).spin( false );
                                                        scope.cross_pol_status = $rootScope.translation.language.on;
                                                        scope.start = true;
                                                        scope.hasBeenStartedBefore = true;
                                                        scope.stop = false;
                                                    } );
                                                } else {
                                                    scope.inputError = true;
                                                }
                                            }
                                        }
                                    };
                                    scope.cross_pol_stop = function () {
                                        angular.element( '.main' ).spin( true );
                                        scope.cross_pol_status = $rootScope.translation.language.off;
                                        scope.stop = true;
                                        scope.start = false;
                                        scope.requestPending = true;
                                        updateValidity();
                                        $http( {
                                            url: generalConfig.host + generalConfig.apiRoot + ( $rootScope.system_type === 'VELOCITY' ? 'terminal/mode/auto' : 'terminal/mode/auto/' + ( ( scope.rxId !== undefined ) ? scope.rxId : scope.form.model.receiver ) ),
                                            method: 'POST',
                                            data: {
                                                "tx_init_power": -10
                                            },
                                            headers: {
                                                'Content-Type': 'application/json'
                                            }
                                        } ).then( function successCallback( response ) {
                                            scope.requestPending = false;
                                            angular.element( '.main' ).spin( false );
                                            if(scope.$parent && scope.$parent.buttons && scope.$parent.buttons.length) {
                                                scope.$parent.buttons[0].enabled = true;
                                            }
                                        }, function errorCallback() {
                                            scope.requestPending = false;
                                            angular.element( '.main' ).spin( false );
                                            if(scope.$parent && scope.$parent.buttons && scope.$parent.buttons.length) {
                                                scope.$parent.buttons[0].enabled = true;
                                            }
                                        } );
                                    };
                                    scope.formReady = true;
                                    $timeout( function () {
                                        scope.$apply();
                                    } );
                                } );
                            };

                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/odu/buc',
                                method: "GET"
                            } ).then( function successCallback( bucResult ) {
                                var bucResultData = bucResult.data.data;
                                executeCrossPol( bucResultData );
                            }, function errorCallback() {
                                // odu/lnb
                            } );
                        }
                    }
                }
            };
    } ] );
    } );
