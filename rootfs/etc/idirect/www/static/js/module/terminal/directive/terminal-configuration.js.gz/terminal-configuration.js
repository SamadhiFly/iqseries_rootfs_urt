define( [ 'module/terminal',
  'text!module/terminal/conf/general.json',
  'module/terminal/service/terminal-streaming-buffer',
  'templates/nmsweb/module/terminal/directive/terminal-configuration.tpl',
  'module/terminal/service/translation-service',
  'module/core/directive/nmsweb-tooltip' ],
    function ( terminal, strGeneralConfig, TerminalStreamingBuffer, template ) {
        'use strict';
        terminal.directive( 'terminalConfiguration', [ '$rootScope', '$timeout', 'TerminalStreamingBuffer', '$compile', '$http', 'NMSWebNotification', function ( $rootScope, $timeout, TerminalStreamingBuffer, $compile, $http, NMSWebNotification ) {
            return {
                restrict: 'E',
                template: template,
                replace: true,
                scope: {
                    modified: '=?'
                },
                compile: function () {
                    return {
                        pre: function preLink( scope ) {
                            var generalConfig = $.parseJSON( strGeneralConfig );

                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/identity',
                                method: "GET"
                            } ).then( function ( result ) {
                                if ( result.data.data.model ) {
                                    scope.terminalModel = result.data.data.model;
                                    scope.system_type = result.data.data.system_type;
                                        angular.element( '.main' ).spin( true );
                                        scope.getConfigs = function () {
                                            $http( {
                                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/files',
                                                method: "GET"
                                            } ).error( function ( ) {
                                                scope.configFiles = {};
                                                angular.element( '.main' ).spin( false );
                                            } ).then( function ( result ) {
                                                scope.configFiles = result.data.data;
                                                angular.element( '.main' ).spin( false );
                                            } );
                                        };
                                        scope.getConfigs();
                                        scope.upload_config_tooltip = {
                                            closeBtn: true,
                                            content: "<div>Please select the required configuration files from your computer.</div>",
                                            placement: "bottom"
                                        };
                                        scope.onSuccess = function ( e ) {
                                            if ( scope.modified !== undefined ) {
                                                scope.modified = true;
                                            }
                                            scope.getConfigs();
                                            var uploadSuccessMsg = $rootScope.translation.language.upload_option_successful;
                                            if ( e.files && e.files.length > 0 && e.files[0].name.indexOf('downstream_config') !== -1 ) {
                                                uploadSuccessMsg = $rootScope.translation.language.upload_option_successful_downstream_config;
                                            }
                                            NMSWebNotification.add( {
                                                type: "success",
                                                isFadeable: true,
                                                title: $rootScope.translation.language.upload_success,
                                                message: uploadSuccessMsg
                                            }, "body" );
                                        };
                                        scope.onError = function ( ) {
                                            NMSWebNotification.add( {
                                                type: "error",
                                                isFadeable: true,
                                                title: $rootScope.translation.language.upload_failed,
                                                message: $rootScope.translation.language.configuration_file_could_not_be_uploaded
                                            }, "body" );
                                        };
                                        scope.upload_config = {
                                            async: {
                                                saveUrl: generalConfig.host + generalConfig.apiRoot + 'terminal/config/files'
                                            },
                                            multiple: false,
                                            localization: {
                                                select: $rootScope.translation.language.upload_configuration_file
                                            },
                                            showFileList: false,
                                            success: scope.onSuccess,
                                            error: scope.onError
                                        };
                                        scope.downloadFile = function ( file ) {
                                            window.location = '/api/1.0/terminal/config/files/' + file;
                                        };
                                    }
                                scope.terminalModelChecked = true;
                            } );
                        },
                        post: function postLink( ) {}
                    };
                }
            };
        } ] );
    } );
