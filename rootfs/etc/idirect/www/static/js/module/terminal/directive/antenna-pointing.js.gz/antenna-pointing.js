define( [ 'module/terminal', 'templates/nmsweb/module/terminal/directive/antenna-pointing.tpl', 'text!module/terminal/conf/general.json', 'vendor/highcharts-directive/highcharts-ng', 'module/terminal/service/terminal-streaming-buffer', 'module/core/directive/nmsweb-tooltip', 'module/core/directive/nmsweb-popover', 'module/terminal/directive/configure-downstream', 'jqueryConfirm' ], function ( terminal, template, strGeneralConfig, highchart ) {
    'use strict';
    terminal.directive( 'antennaPointing', [ '$rootScope', 'TerminalStreamingBuffer', '$http', '$interval', '$window', 'NMSWebNotification', function ( $rootScope, TerminalStreamingBuffer, $http, $interval, $window, NMSWebNotification ) {
        return {
            restrict: 'E',
            template: template,
            replace: true,
            scope: {
                valid: '=?',
                downstreamConfiguration: '=?'
            },
            compile: function () {
                return {
                    pre: function preLink( scope, element ) {
                        angular.element( '.main' ).spin( true );
                        var generalConfig = $.parseJSON( strGeneralConfig );
                        TerminalStreamingBuffer.registerResource( 'terminal/rx' );
                        scope.openamip = false;
                        scope.openamipChecked = false;
                        scope.antennaError = false;
                        scope.systemType = $rootScope.system_type;
                        $http( {
                            url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/identity',
                            method: "GET"
                        } ).then( function successCallback( result ) {
                            scope.openamipChecked = true;
                            if ( result.data && result.data.data && result.data.data.openamip && result.data.data.openamip.mode != 'disabled' ) {
                                scope.openamip = true;
                                if ( scope.$parent.config ) {
                                    scope.$parent.config.steps.commissioning_wizard_fine_antenna_pointing.buttons[ 0 ].disabledText = "commissioning_disabled_button_antenna_pointing_openamip";
                                }
                                toolAntennaPointingPromise.then( function ( result ) {
                                    if ( !scope.showDownstream ) {
                                        scope.antenna_pointing_start();
                                    }
                                } );
                            }
                        }, function errorCallback( data ) {
                            scope.openamipChecked = true;
                            if ( $rootScope.system_type !== 'EVOLUTION' ) {
                                scope.error = data.data.errors[ 0 ];
                                scope.antennaError = true;
                            }
                        } );
                        scope.checkValidDownstream = function () {
                            if ( $rootScope.system_type !== 'EVOLUTION' ) {
                                return ( scope.downstreamConfiguration && scope.downstreamConfiguration.rf_frequency && scope.downstreamConfiguration.symbol_rate && scope.downstreamConfiguration.rx_clear != "" && !scope.antennaError );
                            } else {
                                return ( scope.downstreamConfiguration && scope.downstreamConfiguration.rf_frequency && scope.downstreamConfiguration.symbol_rate && scope.downstreamConfiguration.rolloff && scope.downstreamConfiguration.rx_clear != "" );
                            }
                        };
                        if ( !scope.downstreamConfiguration || !scope.downstreamConfiguration.rx_clear ) {
                            scope.showDownstream = true;
                            scope.downstreamConfiguration = {
                                rx_clear: 0
                            };
                        } else {
                            scope.showDownstream = false;
                        }
                        if ( !scope.valid ) {
                            scope.valid = true;
                        }
                        var updateValidity = function () {
                            if ( scope.openamip ) {
                                scope.valid = ( !scope.start && scope.state == "Locked" && scope.functional && scope.modemMayTransmit );
                            } else {
                                scope.valid = ( !scope.start && scope.state == "Locked" );
                            }
                        };
                        scope.$watch( 'start', function () {
                            updateValidity();
                        } );
                        scope.$watch( 'state', function () {
                            updateValidity();
                        } );
                        scope.$watch( 'downstreamConfiguration', function () {
                            scope.validDownstream = scope.checkValidDownstream();
                        }, true );
                        scope.validDownstream = scope.checkValidDownstream();
                        scope.start = false;
                        scope.stop = true;
                        // scope.reset = false;
                        scope.antenna_pointing_status = $rootScope.translation.language.off;
                        scope.info_box_text_step_1 = true;
                        scope.voltage_max = 0;
                        scope.plotlinemax = 0;
                        scope.background_gradients = {};
                        scope.audiofeedback = false;
                        scope.pwm = false;
                        scope.webaudio = ( typeof AudioContext !== 'undefined' );
                        if ( scope.antenna_pointing_interval ) {
                            $interval.cancel( scope.antenna_pointing_interval );
                        }
                        if ( scope.webaudio ) {
                            var context = new AudioContext(); //webkit browsers only
                        }
                        scope.oscillatorControl = function ( action ) {
                            if ( action == 'start' ) {
                                scope.oscillator = context.createOscillator();
                                scope.oscillator.type = "sine"; // sine wave
                                scope.oscillator.frequency.value = 100;
                                scope.oscillator.connect( context.destination );
                                scope.oscillator.noteOn && scope.oscillator.noteOn( 0 );
                                scope.oscillator.start();
                            } else if ( action == 'stop' ) {
                                scope.oscillator.stop();
                            }
                        }
                        scope.pwmConfirm = function () {
                            if ( scope.pwm ) {
                                scope.pwm = false;
                                $.confirm( {
                                    title: $rootScope.translation.language.wantPWM,
                                    content: ( ( $rootScope.system_type === 'EVOLUTION' ) ? $rootScope.translation.language.wantPWMLong_evo : $rootScope.translation.language.wantPWMLong ),
                                    confirmButton: $rootScope.translation.language.continue,
                                    cancelButton: $rootScope.translation.language.cancel,
                                    cancelButtonClass: "btn-cancel",
                                    confirm: function () {
                                        scope.pwm = true
                                    },
                                    cancel: function () {
                                        return false;
                                    }
                                } );
                            }
                        };
                        scope.pwm_tooltip = {
                            closeBtn: true,
                            content: "<div>" + ( ( $rootScope.system_type === 'EVOLUTION' ) ? $rootScope.translation.language.pwm_tooltip_evo : $rootScope.translation.language.pwm_tooltip ) + "</div>",
                            placement: "bottom"
                        };
                        scope.noise_floor_tooltip = {
                            closeBtn: true,
                            content: "<div>" + $rootScope.translation.language.noise_floor_tooltip + "</div>",
                            placement: "bottom",
                            autoHide: true,
                            showOn: "mouseenter"
                        };
                        scope.audio_feedback_tooltip = {
                            closeBtn: true,
                            content: "<div>" + $rootScope.translation.language.audio_feedback_tooltip + "</div>",
                            placement: "bottom"
                        };
                        scope.voltage_tooltip = {
                            closeBtn: true,
                            content: "<div>" + $rootScope.translation.language.voltage_tooltip + "</div>",
                            placement: "bottom"
                        };
                        scope.$watch( 'audiofeedback', function ( newVal, oldVal ) {
                            if ( newVal != oldVal && typeof AudioContext !== 'undefined' ) {
                                if ( newVal == true && scope.start ) {
                                    scope.oscillatorControl( 'start' );
                                } else if ( newVal == false && scope.start ) {
                                    scope.oscillatorControl( 'stop' );
                                }
                            }
                        }, true );
                        var toolAntennaPointingPromise = $http( {
                            url: generalConfig.host + generalConfig.apiRoot + 'tools/antenna-pointing',
                            method: "OPTIONS"
                        } );
                        toolAntennaPointingPromise.then( function ( result ) {
                            angular.element( '.main' ).spin( false );
                            if ( result.data.field_details ) {
                                scope.ranges = result.data.field_details.ranges;
                                scope.pwmEnabled = result.data.field_details.pwmEnabled;
                                scope.splitted_ranges = {
                                    red: scope.ranges[ 0 ].range.split( "-" ),
                                    yellow: scope.ranges[ 1 ].range.split( "-" ),
                                    green: scope.ranges[ 2 ].range.split( "-" )
                                };
                                scope.color_ranges = {
                                    red: parseFloat( scope.splitted_ranges.red[ 1 ] ),
                                    yellow: parseFloat( scope.splitted_ranges.yellow[ 1 ] ),
                                    green: parseFloat( scope.splitted_ranges.green[ 1 ] )
                                };
                                scope.background_gradients = {
                                    firstStop: 0.825,
                                    secondStop: 0.825 - ( ( 0.825 / scope.color_ranges.green ) * ( scope.color_ranges.red ) ),
                                    thirdStop: 0.86 - ( ( 0.825 / scope.color_ranges.green ) * ( scope.color_ranges.yellow ) ),
                                    fourthStop: 0
                                }
                                scope.chartConfig.options.chart.backgroundColor.stops = [
                                                                        [ 0.036, '#FFF' ],
                                                                        [ 0.035, '#c8d77f' ],
                                                                        [ scope.background_gradients.thirdStop, '#fbf8e4' ],
                                                                        [ scope.background_gradients.secondStop, '#fbf8e4' ],
                                                                        [ scope.background_gradients.firstStop, '#c55754' ],
                                                                        [ scope.background_gradients.firstStop, '#FFF' ],
                                                                        [ 0.825, '#FFF' ]
                                                                ]
                                if ( result.data.field_details.type === "PWM" ) {
                                    scope.ispwm = true;
                                    scope.pwm_text = $rootScope.translation.language.voltage;
                                }
                            }
                        } );
                        $http( {
                            url: generalConfig.host + generalConfig.apiRoot + ( $rootScope.system_type === 'VELOCITY' ? 'terminal/mode/antenna_point' : 'terminal/mode/antenna_point/' + scope.downstreamConfiguration.rx_clear ),
                            method: "GET"
                        } ).then( function ( result ) {
                            scope.chartConfig.yAxis.max = result.data.data.voltage_max;
                        } );
                        Highcharts.setOptions( {
                            global: {
                                useUTC: false,
                                Date: oldDate
                            }
                        } );
                        scope.chartConfig = {
                            options: {
                                chart: {
                                    animation: false,
                                    height: 300,
                                    width: $window.innerWidth - 100,
                                    zoomType: 'x',
                                    backgroundColor: {
                                        linearGradient: [ 0, 0, 0, 300 ],
                                        stops: []
                                    }
                                }
                            },
                            title: {
                                text: ''
                            },
                            series: [ {
                                name: 'Voltage',
                                data: []
                                                        } ],
                            yAxis: {
                                title: {
                                    text: ''
                                },
                                tickInterval: 1,
                                plotLines: [ {
                                    value: 0,
                                    color: 'red',
                                    dashStyle: 'solid',
                                    width: 2,
                                    id: 'max-plot'
                                                                } ],
                                min: 0,
                                max: 0,
                                opposite: true
                            },
                            xAxis: {
                                tickInterval: null,
                                tickPixelInterval: 200,
                                type: "datetime"
                            },
                            plotOptions: {
                                series: {
                                    marker: {
                                        enabled: false
                                    }
                                },
                                column: {
                                    events: {
                                        legendItemClick: function () {
                                            return false;
                                        }
                                    }
                                }
                            },
                            credits: {
                                enabled: false
                            }
                        };
                        scope.$watch( function () {
                            return $window.innerWidth;
                        }, function ( value ) {
                            scope.chartConfig.options.chart.width = value - 100;
                        } );
                        $rootScope.$on( '$routeChangeStart', function ( event, next ) {
                            $interval.cancel( scope.antenna_pointing_interval );
                        } );
                        scope.$watch( '$parent.currentStep', function () {
                            if ( scope.$parent.currentStep !== 4 ) {
                                $interval.cancel( scope.antenna_pointing_interval );
                            }
                        } );
                        scope.antenna_pointing_restart = function () {
                            scope.chartConfig.series[ 0 ].data = [];
                            var a = new Array(),
                                milliseconds = ( $.now() ) - ( 50 * 99 );
                            for ( var i = 0; i < 100; i++ ) {
                                a[ i ] = [ milliseconds, 0 ];
                                milliseconds = milliseconds + 50;
                            }
                            scope.chartConfig.series[ 0 ].data = a;
                        };
                        scope.antenna_pointing_execute = function ( pwm, reset ) {
                            scope.start = true;
                            scope.background_gradients = {
                                firstStop: 0.77,
                                secondStop: 0.77 - ( ( 0.77 / scope.color_ranges.green ) * ( scope.color_ranges.red ) ),
                                thirdStop: 0.805 - ( ( 0.77 / scope.color_ranges.green ) * ( scope.color_ranges.yellow ) ),
                                fourthStop: 0
                            }
                            scope.chartConfig.options.chart.backgroundColor.stops = [
                                [ 0.036, '#FFF' ],
                                [ 0.035, '#c8d77f' ],
                                [ scope.background_gradients.thirdStop, '#fbf8e4' ],
                                [ scope.background_gradients.secondStop, '#fbf8e4' ],
                                [ scope.background_gradients.firstStop, '#c55754' ],
                                [ scope.background_gradients.firstStop, '#FFF' ],
                                [ 0.77, '#FFF' ]
                            ]
                            scope.antenna_pointing_restart();
                            var receiverObjs = TerminalStreamingBuffer.getCurrentValue( [ 'terminal/rx', 'data' ] ),
                                postData = {
                                    voltage_on: scope.pwm,
                                    tx_id: ( receiverObjs[ scope.downstreamConfiguration.rx_clear ].tx_id ) ? receiverObjs[ scope.downstreamConfiguration.rx_clear ].tx_id : 0,
                                    rf_frequency: parseFloat( scope.downstreamConfiguration.rf_frequency )
                                };
                            if ( !postData.symbol_rate ) {
                                postData.symbol_rate = parseFloat( scope.downstreamConfiguration.symbol_rate );
                            }
                            if ( !postData.rolloff && scope.downstreamConfiguration.rolloff != "" ) {
                                postData.rolloff = parseFloat( scope.downstreamConfiguration.rolloff ) / 100;
                            }
                            if ( !postData.modulation && scope.downstreamConfiguration.modulation != "" ) {
                                postData.modulation = scope.downstreamConfiguration.modulation;
                            }
                            var data = {};
                            if ( scope.downstreamConfiguration.spacecraft_longitude_direction ) {
                                scope.downstreamConfiguration.spacecraft_longitude = ( scope.downstreamConfiguration.spacecraft_longitude_direction === "East" ? parseFloat( scope.downstreamConfiguration.spacecraft_longitude ) : -parseFloat( scope.downstreamConfiguration.spacecraft_longitude ) );
                                data.longitude = scope.downstreamConfiguration.spacecraft_longitude;
                            } else if ( typeof scope.$parent.stepData !== 'undefined' && scope.$parent.stepData.commissioning_wizard_coarse_antenna_pointing.spacecraft_longitude_direction ) {
                                scope.downstreamConfiguration.spacecraft_longitude = ( scope.$parent.stepData.commissioning_wizard_coarse_antenna_pointing.spacecraft_longitude_direction === "East" ? parseFloat( scope.$parent.stepData.commissioning_wizard_coarse_antenna_pointing.spacecraft_longitude ) : -parseFloat( scope.$parent.stepData.commissioning_wizard_coarse_antenna_pointing.spacecraft_longitude ) );
                                data.longitude = scope.downstreamConfiguration.spacecraft_longitude;
                            }
                            if ( scope.openamip ) {
                                if ( scope.downstreamConfiguration.receive_polarization ) {
                                    data.rx_polarization = scope.downstreamConfiguration.receive_polarization;
                                }
                                if ( scope.downstreamConfiguration.transmit_polarization ) {
                                    data.tx_polarization = scope.downstreamConfiguration.transmit_polarization;
                                }
                                if ( scope.downstreamConfiguration.latitude_variance != "" ) {
                                    data.latitude_variance = parseFloat( scope.downstreamConfiguration.latitude_variance );
                                }
                                if ( scope.downstreamConfiguration.polarization_skew != "" ) {
                                    data.polarization_skew = parseFloat( scope.downstreamConfiguration.polarization_skew );
                                }
                            }
                            if ( $rootScope.system_type === 'VELOCITY' ) {
                                $http( {
                                    url: generalConfig.host + generalConfig.apiRoot + "terminal/config/location/satellite",
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json'
                                    },
                                    data: data
                                } ).success( function () {
                                    scope.executePointing( pwm, reset, postData );
                                } ).error( function ( error ) {
                                    if ( error.data && error.data.errors && error.data.errors[ 0 ] ) {
                                        NMSWebNotification.add( {
                                            type: "error",
                                            isFadeable: true,
                                            title: $rootScope.translation.language.antenna_error,
                                            message: error.errors[ 0 ]
                                        }, "body" );
                                    } else {
                                        NMSWebNotification.add( {
                                            type: "error",
                                            isFadeable: true,
                                            title: $rootScope.translation.language.antenna_error,
                                            message: $rootScope.translation.language.antenna_starting_error
                                        }, "body" );
                                    }

                                    scope.antenna_pointing_stop();
                                } );
                            } else if ( $rootScope.system_type === 'EVOLUTION' ) {
                                scope.executePointing( pwm, reset, postData );
                            }
                        }
                        scope.executePointing = function ( pwm, reset, postData ) {
                            var antennaPointingOff = $rootScope.$on( '$routeChangeStart', function ( event, next ) {
                                if ( scope.start ) {
                                    scope.antenna_pointing_stop();
                                }
                                antennaPointingOff();
                            } );
                            var antennaPointingOffChangeStep = $rootScope.$on( "wizardChangeStep", function () {
                                if ( scope.start ) {
                                    scope.antenna_pointing_stop();
                                }
                                antennaPointingOffChangeStep();
                            } );
                            scope.start = true;
                            scope.info_box_text_step_1 = true;
                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + ( $rootScope.system_type === 'VELOCITY' ? 'terminal/mode/antenna_point' : 'terminal/mode/antenna_point/' + scope.downstreamConfiguration.rx_clear ),
                                method: 'POST',
                                data: postData,
                                headers: {
                                    'Content-Type': 'application/json'
                                }
                            } ).success( function () {
                                scope.error = false;
                                if ( reset ) {
                                    //don't populate data in reset mode
                                    scope.start = false;
                                    return;
                                }
                                if ( scope.openamip ) {
                                    scope.functional = false;
                                    scope.modemMayTransmit = false;
                                }
                                scope.antenna_pointing_interval = $interval( function () {
                                    $http( {
                                        url: generalConfig.host + generalConfig.apiRoot + ( $rootScope.system_type === 'VELOCITY' ? 'terminal/mode/antenna_point' : 'terminal/mode/antenna_point/' + scope.downstreamConfiguration.rx_clear ),
                                        method: "GET"
                                    } ).then( function ( result ) {
                                        if ( scope.start ) {
                                            if ( scope.openamip ) {
                                                $http( {
                                                    url: generalConfig.host + generalConfig.apiRoot + ( $rootScope.system_type === 'VELOCITY' ? 'terminal/odu/antenna/0' : 'terminal/odu/antenna/0' ),
                                                    method: "GET"
                                                } ).then( function successCallback( result ) {
                                                    scope.functional = result.data.data.openamip.functional;
                                                    scope.modemMayTransmit = result.data.data.openamip.modem_may_transmit;
                                                    scope.func = ( scope.functional ) ? 'Functional' : 'Not Functional';
                                                    scope.transmit = ( scope.modemMayTransmit ) ? 'May Transmit' : 'May Not Transmit';
                                                }, function errorCallback( response ) {
                                                    NMSWebNotification.add( {
                                                        type: "error",
                                                        isFadeable: true,
                                                        title: $rootScope.translation.language.antenna_error,
                                                        message: response.data.errors[ 0 ]
                                                    }, "body" );
                                                    scope.antenna_pointing_stop();
                                                } );
                                            }

                                            var datainput = result.data.data.voltage_output,
                                                now = $.now();
                                            scope.state = result.data.data.state;
                                            if ( datainput > 0 ) {
                                                scope.info_box_text_step_1 = false;
                                            }
                                            if ( datainput && scope.audiofeedback && typeof AudioContext !== 'undefined' ) {
                                                scope.oscillator.frequency.value = datainput / ( 20 / 2000 ) + 100;
                                            }
                                            scope.chartConfig.series[ 0 ].data.push( [ now, datainput ] );
                                            if ( datainput > scope.chartConfig.yAxis.plotLines[ 0 ].value ) {
                                                scope.chartConfig.yAxis.plotLines[ 0 ].value = datainput;
                                            }
                                            if ( scope.chartConfig.series[ 0 ].data.length > 100 ) {
                                                scope.chartConfig.series[ 0 ].data.shift();
                                            }
                                        }
                                    } );
                                }, 1000 );
                                if ( typeof AudioContext !== 'undefined' ) {
                                    if ( scope.audiofeedback ) {
                                        scope.oscillatorControl( 'start' );
                                    }
                                }
                                scope.currentRx = scope.downstreamConfiguration.rx_clear;
                                scope.stop = false;
                                scope.antenna_pointing_status = $rootScope.translation.language.on;
                            } ).error( function ( data, status ) {
                                scope.stop = true;
                                scope.start = false;
                                scope.antenna_pointing_status = $rootScope.translation.language.on;
                                scope.error = data.errors[ 0 ];
                                TerminalStreamingBuffer.removeResource( ( $rootScope.system_type === 'VELOCITY' ? 'terminal/mode/antenna_point' : 'terminal/mode/antenna_point/' + scope.downstreamConfiguration.rx_clear ) );
                            } );
                        };
                        scope.antenna_pointing_start = function ( pwm, reset ) {
                            scope.start = true;
                            if ( $rootScope.system_type === 'EVOLUTION' || ( $rootScope.system_type === 'VELOCITY' && !scope.openamip ) ) {
                                $.confirm( {
                                    title: $rootScope.translation.language.want_start_antenna_pointing,
                                    content: $rootScope.translation.language.want_start_antenna_pointing_long,
                                    confirmButton: $rootScope.translation.language.continue,
                                    cancelButton: $rootScope.translation.language.cancel,
                                    confirm: function () {
                                        scope.antenna_pointing_execute( pwm, reset );
                                    },
                                    cancel: function () {
                                        scope.start = false;
                                    }
                                } );
                            } else {
                                scope.antenna_pointing_execute( pwm, reset );
                            }
                        };
                        scope.antenna_pointing_stop = function () {
                            TerminalStreamingBuffer.removeResource( ( $rootScope.system_type === 'VELOCITY' ? 'terminal/mode/antenna_point' : 'terminal/mode/antenna_point/' + scope.currentRx ) );
                            $interval.cancel( scope.antenna_pointing_interval );
                            scope.start = false;
                            scope.stop = true;
                            scope.antenna_pointing_status = 'off';
                            if ( scope.audiofeedback && typeof AudioContext !== 'undefined' ) {
                                scope.oscillatorControl( 'stop' );
                            }
                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + ( $rootScope.system_type === 'VELOCITY' ? 'terminal/mode/auto' : 'terminal/mode/auto/' + scope.currentRx ),
                                data: {
                                    "tx_init_power": -10
                                },
                                method: 'POST'
                            } ).then( function () {
                                TerminalStreamingBuffer.removeResource( ( $rootScope.system_type === 'VELOCITY' ? 'terminal/mode/antenna_point' : 'terminal/mode/antenna_point/' + scope.downstreamConfiguration.rx_clear ) );
                                TerminalStreamingBuffer.changeInterval( ( $rootScope.system_type === 'VELOCITY' ? 'terminal/rx' : 'terminal/rx/' + scope.downstreamConfiguration.rx_clear ), 5000 );
                            } );
                        };
                    },
                    post: function () {}
                }
            }
        };
        } ] );
} );
