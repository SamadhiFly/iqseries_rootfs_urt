define( [ 'module/terminal',
'text!module/terminal/conf/general.json',
'templates/nmsweb/module/terminal/directive/angle-calculator.tpl',
'module/terminal/service/terminal-streaming-buffer',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form',
'module/terminal/directive/nmsweb-html',
'module/core/directive/nmsweb-tooltip'],
    function ( terminal, strGeneralConfig, template ) {
        'use strict';
        terminal.directive( 'angleCalculator', [ '$rootScope', 'TerminalStreamingBuffer', 'ToolResource', 'NmswebForm', '$http', function ( $rootScope, TerminalStreamingBuffer, ToolResource, NmswebForm, $http ) {
            return {
                restrict: 'E',
                template: template,
                replace: true,
                scope: {
                    valid: '=?',
                    angleCalculatorConfiguration: '=?'
                },
                compile: function () {
                    return {
                        pre: function preLink( scope, element ) {
                            var generalConfig = $.parseJSON( strGeneralConfig ),
                                formOptions = {
                                "layout": "layouts/terminal/tools/angle-calculator",
                                "hook": "module/terminal/hook/tool-angle-calculator"
                            };
                            if(!scope.angleCalculatorConfiguration) {
                                    scope.angleCalculatorConfiguration = {};
                            }
                            var updateValidity = function() {
                                    scope.valid = !element.find('form').hasClass('ng-invalid');
                            };
                            scope.$watch(function(){return element.find('form').hasClass('ng-invalid');}, function(newVal,oldVal){
                                updateValidity();
                            });
                            formOptions.resource = new ToolResource( 'angle-calculator' );
                            formOptions.name = 'angle-calculator';
                            formOptions.viewMode = false;
                            scope.title = formOptions.name;
                            scope.form = new NmswebForm( formOptions );
                            scope.form.actions = [];
                            scope.form.model = angular.extend(scope.angleCalculatorConfiguration);

                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/location/remote',
                                method: "GET"
                            } ).then( function ( result ) {
                                if(result.data.data.latitude >= 0) {
                                    scope.form.model.remote_latitude = result.data.data.latitude;
                                    scope.form.model.remote_latitude_direction = "North";
                                } else {
                                    scope.form.model.remote_latitude = -result.data.data.latitude;
                                    scope.form.model.remote_latitude_direction = "South";
                                }
                                if(result.data.data.longitude >= 0) {
                                    scope.form.model.remote_longitude = result.data.data.longitude;
                                    scope.form.model.remote_longitude_direction = "East";
                                } else {
                                    scope.form.model.remote_longitude = -result.data.data.longitude;
                                    scope.form.model.remote_longitude_direction = "West";
                                }
                            });
                        },
                        post: function () {}
                    }
                }
            };
    } ] );
    } );
