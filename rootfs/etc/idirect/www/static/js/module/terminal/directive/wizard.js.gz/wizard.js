define( [ 'module/terminal',
  'module/terminal/service/terminal-streaming-buffer',
  'templates/nmsweb/module/terminal/directive/wizard.tpl',
  'text!module/terminal/conf/general.json',
  'core/popover' ],
    function ( terminal, TerminalStreamingBuffer, template, strGeneralConfig ) {
        'use strict';
        terminal.directive( 'wizard', [ '$timeout', 'TerminalStreamingBuffer', '$compile', '$rootScope', '$location', '$http', 'NMSWebNotification', function ( $timeout, TerminalStreamingBuffer, $compile, $rootScope, $location, $http, NMSWebNotification ) {
            return {
                restrict: 'E',
                template: template,
                replace: true,
                scope: {
                    id: '@',
                    config: '=',
                    initialStep: '=?',
                    forceProcess: '=?',
                    clearProgress: '=?'
                },
                compile: function () {
                    return {
                        pre: function preLink( scope, element ) {
                            var generalConfig = $.parseJSON( strGeneralConfig );
                            scope.currentStep = 0;
                            scope.maxStep = 0;
                            scope.stepData = {};
                            scope.wizardComplete = false;
                            if ( !$rootScope.wizards ) {
                                $rootScope.wizards = [];
                            }
                            if ( !$rootScope.wizards[ scope.id ] ) {
                                $rootScope.wizards[ scope.id ] = 0;
                                if ( scope.forceProcess ) {
                                    //Reset to intiial step if forceProcess is true and wizard has just been started
                                    scope.initialStep = $rootScope.wizards[ scope.id ];
                                }
                                scope.maxStep = scope.initialStep;
                            }
                            scope.changePath = function ( path ) {
                                $location.path( path );
                            };
                            var addDetachClass = function () {
                                var element = document.getElementsByClassName( 'footer-lang' ),
                                    footerTop = $( '.footer-lang' ).offset().top,
                                    scrollTop = document.getScroll()[ 1 ],
                                    range = $( 'footer' ).height() + parseInt( $( 'footer' ).css( 'margin-top' ).slice( 0, -2 ) ),
                                    windowHeight = $( window ).height();
                                if ( ( scrollTop + windowHeight ) < footerTop ) {
                                    $( '.wizard-buttons' ).addClass( 'detach' );
                                } else {
                                    $( '.wizard-buttons' ).removeClass( 'detach' );
                                }
                            };
                            $timeout( function () {
                                addDetachClass();
                            }, 500 );
                            document.getScroll = function () {
                                if ( window.pageYOffset != undefined ) {
                                    return [ pageXOffset, pageYOffset ];
                                } else {
                                    var sx, sy, d = document,
                                        r = d.documentElement,
                                        b = d.body;
                                    sx = r.scrollLeft || b.scrollLeft || 0;
                                    sy = r.scrollTop || b.scrollTop || 0;
                                    return [ sx, sy ];
                                }
                            };
                            document.addEventListener( "scroll", function () {
                                addDetachClass();
                            } );
                            window.addEventListener( 'resize', function () {
                                addDetachClass();
                            }, true );
                            scope.doClearProgress = function () {
                                if ( scope.clearProgress ) {
                                    scope.resetStepData();
                                    scope.updateLocalStorage();
                                    scope.maxStep = 0;
                                    scope.initialStep = 0;
                                    scope.setCurrentStep( 0 );
                                }
                            };
                            scope.resetStepData = function () {
                                angular.forEach( scope.config.steps, function ( value, key ) {
                                    scope.stepData[ key ] = {};
                                } );
                            };
                            scope.completeWizard = function () {
                                scope.wizardComplete = true;
                                scope.resetStepData();
                                scope.updateLocalStorage();
                            };
                            scope.executeButtonAction = function ( buttonIndex ) {
                                var button = scope.config.steps[ scope.config.order[ scope.currentStep ] ].buttons[ buttonIndex ];
                                if ( button.enabled !== true ) {
                                    return;
                                }
                                if ( button.type === 'step' ) {
                                    scope.setCurrentStep( button.typeValue );
                                } else if ( button.type === 'next' ) {
                                    if ( scope.config.order[ scope.currentStep ] == "commissioning_wizard_cross_polarization_test" ) {
                                        $http( {
                                            url: generalConfig.host + generalConfig.apiRoot + ( $rootScope.system_type === 'VELOCITY' ? 'terminal/mode/auto' : 'terminal/mode/auto/' + scope.stepData[ 'commissioning_wizard_configure_downstream' ].rx_clear ),
                                            method: 'POST',
                                            data: {
                                                "tx_init_power": -10
                                            },
                                            headers: {
                                                'Content-Type': 'application/json'
                                            }
                                        } );
                                    }
                                    scope.setCurrentStep( parseInt( scope.currentStep ) + 1 );
                                } else if ( button.type === 'callback' ) {
                                    if ( button.typeValue ) {
                                        angular.element( '.main' ).spin( true );
                                        require( [ button.typeValue ], function ( callback ) {
                                            angular.element( '.main' ).spin( false );
                                            callback( scope, $http, TerminalStreamingBuffer, NMSWebNotification );
                                        } );
                                    }
                                }
                            };
                            scope.updateLocalStorage = function () {
                                if ( 'localStorage' in window && window[ 'localStorage' ] !== null ) {
                                    try {
                                        localStorage.setItem( 'wizard-' + scope.id, JSON.stringify( {
                                            maxStep: scope.maxStep,
                                            stepData: scope.stepData,
                                            currentStep: scope.currentStep,
                                            wizardComplete: scope.wizardComplete,
                                            lastEdit: new Date().getTime()
                                        } ) );
                                    } catch ( e ) {}
                                }
                            };
                            scope.loadLocalStorage = function () {
                                if ( 'localStorage' in window && window[ 'localStorage' ] !== null ) {
                                    if ( localStorage.getItem( 'wizard-' + scope.id ) ) {
                                        var localStorageData = JSON.parse( localStorage.getItem( 'wizard-' + scope.id ) );
                                        if ( localStorageData.lastEdit >= new Date().getTime() - 1800000 ) {
                                            scope.maxStep = localStorageData.maxStep;
                                            scope.stepData = localStorageData.stepData;
                                            scope.wizardComplete = localStorageData.wizardComplete;
                                            if ( scope.wizardComplete ) {
                                                scope.wizardComplete = false;
                                                scope.currentStep = 0;
                                                scope.maxStep = 0;
                                                scope.updateLocalStorage();
                                                localStorageData.currentStep = 0;
                                            }
                                            scope.setCurrentStep( localStorageData.currentStep );
                                        }
                                    } else {
                                        try {
                                            localStorage.setItem( 'wizard-' + scope.id, JSON.stringify( {
                                                maxStep: scope.maxStep,
                                                stepData: scope.stepData,
                                                currentStep: scope.currentStep,
                                                wizardComplete: scope.wizardComplete
                                            } ) );
                                        } catch ( e ) {}
                                    }
                                }
                            };
                            scope.setCurrentStep = function ( stepIndex, deniedForward ) {
                                if ( scope.wizardComplete ) {
                                    //Only allow step Change with valid form and wizard in progress
                                    if ( stepIndex != 0 ) {
                                        return;
                                    } else {
                                        scope.maxStep = 0;
                                        scope.wizardComplete = false;
                                    }
                                }
                                if ( stepIndex === "NEXT" && ( !deniedForward ||  scope.maxStep >= stepIndex ) ) {
                                    scope.currentStep++;
                                } else if ( stepIndex < scope.currentStep || ( !deniedForward &&  scope.maxStep >= stepIndex - 1 ) ) {
                                    scope.currentStep = stepIndex;
                                }
                                if ( !scope.maxStep || scope.currentStep > scope.maxStep ) {
                                    scope.maxStep = scope.currentStep;
                                }
                                //Update localStorage
                                scope.updateLocalStorage();
                            };
                            scope.setPath = function ( path ) {
                                $location.path( path );
                            };
                            scope.doClearProgress();
                            scope.$watch( 'clearProgress', function () {
                                scope.doClearProgress();
                            } );
                            scope.$watch( 'buttons', function () {
                                //Remove existing button popovers
                                $timeout( function () {
                                    $( '.wizardButtonPopover' ).remove();
                                    angular.forEach( scope.buttons, function ( button, i ) {
                                        if ( !button.enabled && button.disabledText ) {
                                            element.find( '.wizard-buttons button' ).eq( i ).nmswebPopover( {
                                                "manual": false,
                                                "closeBtn": false,
                                                "forceCreate": true,
                                                "content": "<p>" + ( $rootScope.translation.language[ button.disabledText ] ) ? $rootScope.translation.language[ button.disabledText ] : button.disabledText + "</p>",
                                                "placement": "top",
                                                "cssclass": "disabled wizardButtonPopover"
                                            } );
                                        }
                                    } );
                                } );
                            }, true );
                            scope.$watch( 'currentStep', function ( newVal, oldVal ) {
                                if ( newVal === 6 ) {
                                    $rootScope.currentWizardStep = 6;
                                } else {
                                    delete $rootScope.currentWizardStep;
                                }
                                if ( scope.forceProcess && newVal - $rootScope.wizards[ scope.id ] > 1 && newVal > scope.maxStep ) {
                                    scope.setCurrentStep( $rootScope.wizards[ scope.id ] );
                                }
                                $rootScope.wizards[ scope.id ] = scope.currentStep;
                                if ( scope.config.order[ scope.currentStep ] && scope.config.steps[ scope.config.order[ scope.currentStep ] ] ) {
                                    element.spin();
                                    if ( scope.config.steps[ scope.config.order[ scope.currentStep ] ].template ) {
                                        //Close popovers
                                        $( '.wizard-content .n-popoverbody' ).addClass( 'hide' );
                                        require( [ 'text!' + scope.config.steps[ scope.config.order[ scope.currentStep ] ].template ], function ( stepTemplate ) {
                                            element.find( '.wizard-content' ).html( stepTemplate ).hide();
                                            $compile( element.find( '.wizard-content' ).contents() )( scope );
                                            $timeout( function () {
                                                scope.buttons = scope.config.steps[ scope.config.order[ scope.currentStep ] ].buttons;
                                                element.find( '.wizard-content' ).show()
                                                element.spin( false );
                                                $rootScope.$emit( "wizardChangeStep" );
                                            } );
                                        } );
                                    }
                                }
                            } );
                            scope.$watch( function () {
                                    return angular.toJson( scope.config );
                                },
                                function () {
                                    if ( scope.config.order[ scope.currentStep ] && scope.config.steps[ scope.config.order[ scope.currentStep ] ] && scope.config.steps[ scope.config.order[ scope.currentStep ] ].modified != undefined ) {
                                        if ( scope.config.steps[ scope.config.order[ scope.currentStep ] ].modified === true ) {
                                            require( [ scope.config.steps[ scope.config.order[ scope.currentStep ] ].modifiedCallback ], function ( modifiedCallback ) {
                                                modifiedCallback.modified( scope );
                                            } );
                                        }
                                    }
                                } );
                            scope.resetStepData();
                            //Load from Local storage
                            scope.loadLocalStorage();
                        },
                        post: function postLink( scope, element ) {
                            if ( scope.initialStep ) {
                                if ( scope.config.order[ scope.initialStep ] && scope.config.steps[ scope.config.order[ scope.initialStep ] ] && scope.config.steps[ scope.config.order[ scope.initialStep ] ].noDirectAccess && scope.config.steps[ scope.config.order[ parseInt( scope.initialStep ) - 1 ] ] ) {
                                    scope.initialStep = parseInt( scope.initialStep ) - 1;
                                }
                                scope.setCurrentStep( scope.initialStep );
                            }
                        }
                    }
                }
            }
    } ] );
    } );