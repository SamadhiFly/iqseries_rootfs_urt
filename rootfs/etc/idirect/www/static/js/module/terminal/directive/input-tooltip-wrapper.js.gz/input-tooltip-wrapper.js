define(['module/terminal'],
    function(terminal) {
        'use strict';
        terminal.directive('inputInfo', ['$compile', function($compile) {
            return {
                restrict: 'E',
                replace: true,
                require: '?ngModel',
                template: '',
                scope: {
                    nmswebOptions: '=',
                    additionalOptions: '=',
                    model: '=ngModel'
                },
                compile: function() {
                    return {
                        pre: function preLink(scope, element) {
                            var fieldTpl = angular.element('<' + scope.nmswebOptions.origType + ' nmsweb-options="nmswebOptions"  additional-options="additionalOptions" ng-model="model[0]"></' + scope.nmswebOptions.origType + '><div class="input-info-wrapper">'+scope.model[1]+'</div>');
                            element.append($compile(fieldTpl)(scope));
                        }
                    };
                }
            };
        }]);
    });