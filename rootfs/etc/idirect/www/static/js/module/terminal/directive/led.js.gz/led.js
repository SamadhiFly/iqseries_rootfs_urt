define( [ 'module/terminal' ],
    function ( terminal ) {
        'use strict';
        terminal.directive( 'led', [ '$interval', '$timeout', function ( $interval, $timeout ) {
            return {
                restrict: 'E',
                template: "<div class=\"n-light-wrapper\"><div class=\"n-light {{size}} {{color}}\" ng-class=\"{'off':deactivated}\"></div></div>",
                replace: true,
                scope: {
                    color: '=?',
                    size: '@?',
                    flash: '=?',
                    deactivated: '=?'
                },
                compile: function () {
                    return {
                        pre: function preLink( scope ) {
                            scope.deactivated = false;
                            scope.flashLed = function ( flash ) {
                                if ( scope.interval ) {
                                    $interval.cancel( scope.interval );
                                    $timeout.cancel( scope.timeout );
                                    scope.deactivated = false;
                                }
                                if ( typeof flash === "undefined" || flash === '' ) {
                                    return;
                                }
                                var flashsplit = flash.split( "/" ),
                                    flashon = flashsplit[ 0 ] * 1000,
                                    flashoff = flashsplit[ 1 ] * 1000,
                                    flashsum = flashon + flashoff;
                                scope.interval = $interval( function () {
                                    scope.deactivated = false;
                                    scope.timeout = $timeout( function () {
                                        scope.deactivated = true;
                                    }, flashon );
                                }, flashsum );
                            };
                            scope.flashLed( scope.flash );
                            if ( scope.size === undefined ) {
                                scope.size = "small";
                            }
                            if ( scope.color === undefined ) {
                                scope.color = "off";
                            }
                            scope.$watch( 'flash', function ( newValue, oldValue ) {
                                if ( newValue === oldValue ) {
                                    return;
                                }
                                scope.flashLed( newValue );
                            } )
                        }
                    };
                }
            };
    } ] );
    } );
