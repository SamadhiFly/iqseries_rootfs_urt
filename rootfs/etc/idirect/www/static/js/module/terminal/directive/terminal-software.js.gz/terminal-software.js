define( [ 'module/terminal',
  'text!module/terminal/conf/general.json',
  'module/terminal/service/terminal-streaming-buffer',
  'templates/nmsweb/module/terminal/directive/terminal-software.tpl',
  'module/core/service/nmsutils',
  'module/terminal/service/translation-service',
  'module/core/directive/nmsweb-tooltip' ],
    function ( terminal, strGeneralConfig, TerminalStreamingBuffer, template ) {
        'use strict';
        terminal.directive( 'terminalSoftware', [ '$rootScope', '$timeout', 'TerminalStreamingBuffer', '$compile', '$http', 'NMSWebNotification', function ( $rootScope, $timeout, TerminalStreamingBuffer, $compile, $http, NMSWebNotification ) {
            return {
                restrict: 'E',
                template: template,
                replace: true,
                scope: {
                    modified: '=?'
                },
                compile: function () {
                    return {
                        pre: function preLink( scope, element ) {
                            var generalConfig = $.parseJSON( strGeneralConfig ),
                                dataChecked = false;
                            angular.element( '.main' ).spin( true );

                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/identity',
                                method: "GET"
                            } ).then( function ( result ) {
                                if ( result.data.data.model ) {
                                    scope.terminalModel = result.data.data.model;
                                    scope.system_type = result.data.data.system_type;
                                }
                                scope.terminalModelChecked = true;
                            } );

                            // Fetch software partitions each 3s
                            TerminalStreamingBuffer.registerResource( 'terminal/config/software/partitions', 3000 );
                            scope.installingPartitionID = null;
                            $rootScope.routeListeners.push( $rootScope.$on( 'streamingBufferGeneralUpdate', function ( event ) {
                                scope.releases = TerminalStreamingBuffer.getCurrentValue( [ 'terminal/config/software/partitions', 'data' ] );
                                if ( scope.releases != "" && !dataChecked ) {
                                    dataChecked = true;
                                    angular.element( '.main' ).spin( false );
                                }
                                var isPackageInstalling = false;
                                angular.forEach( scope.releases, function ( value, key ) {
                                    var lastCharPartitionID = value.partition_id.substr( value.partition_id.length - 1 );
                                    if ( !_.isNaN( parseInt( lastCharPartitionID ) ) ) {
                                        scope.releases[ key ].partition_number = parseInt( lastCharPartitionID );
                                    }
                                    if( $rootScope.system_type === "VELOCITY" ) {
                                        // Check if a package is in state "Installing Package" (Velo) or "Installing.." (Evo) to decide if upload component should be disabled
                                        if( value.state && value.state.indexOf('Installing') !== -1 ) {
                                            isPackageInstalling = true;
                                            scope.installingPartitionID = value.partition_id;
                                            $( '.installation_status_label' ).html( value.state );
                                            $( '.upload_wrapper .k-upload-status-total' ).remove();
                                        } else if( value.state && value.state === 'Installation Success' && scope.installingPartitionID === value.partition_id) {
                                            // This package was in installing state before, installation is now successful, show notification
                                            NMSWebNotification.add( {
                                                type: "success",
                                                isFadeable: true,
                                                title: $rootScope.translation.language.installation_successful,
                                                message: $rootScope.translation.language.installation_completed_please_activate_release
                                            }, "body" );
                                            scope.installingPartitionID = null;
                                            $( '.installation_status_label' ).html( value.state );
                                            $( '.upload_wrapper .k-upload-status-total' ).remove();
                                        } else if( value.state && value.state === 'Installation Failed' && scope.installingPartitionID === value.partition_id) {
                                            // This package was in installing state before, installation failed, show notification
                                            NMSWebNotification.add( {
                                                type: "error",
                                                isFadeable: true,
                                                title: $rootScope.translation.language.installation_error,
                                                message: $rootScope.translation.language.an_error_occured_during_the_release_installation
                                            }, "body" );
                                            scope.installingPartitionID = null;
                                            $( '.installation_status_label' ).html( value.state );
                                            $( '.upload_wrapper .k-upload-status-total' ).remove();
                                        }
                                    }
                                } );
                                // If any of the packages is installing, disable upload component
                                // If all installations are successful / failed, enable upload component (only if upload is not in progress)
                                if($('#upload-release-component').data("kendoUpload") != undefined) {
                                    if(isPackageInstalling) {
                                        $('#upload-release-component').data("kendoUpload").disable();
                                    } else if(!scope.installInProgress) {
                                        $('#upload-release-component').data("kendoUpload").enable();
                                    }
                                }
                            } ) );

                            scope.uploadInProgress = false;
                            scope.installInProgress = false;

                            $rootScope.$on('changeLanguage', function(event, currentValues) {
                                if($rootScope.translation.language.release_activate_tooltip){
                                    scope.upload_release_tooltip = {
                                        closeBtn: true,
                                        content: "<div>" + $rootScope.translation.language.release_activate_tooltip + "</div>",
                                        placement: "bottom"
                                    };
                                    scope.langLoaded = true;
                                }
                            });

                            // Upload component callback functions
                            scope.onUpload = function ( e ) {
                                scope.uploadInProgress = true;
                                scope.installInProgress = true;
                                scope.progress = 0;
                                $('#upload-release-component').data('kendoUpload').disable();
                                $('.installation_status_label').html('');
                            };
                            scope.onSuccess = function ( e ) {
                                // Per the Remote WebService ICD, the POST config/software/partitions API will return true when the
                                // installation is complete, not the upload. For this reason, we need to report upload success client-side.
                                scope.uploadInProgress = false;
                                scope.installInProgress = false;
                                if ( $rootScope.system_type == "EVOLUTION" ) {
                                    clearInterval(scope.inter);
                                    $( '.upload_wrapper .k-upload-status-total' ).html( 'Done' );
                                    if ( scope.modified != undefined ) {
                                        scope.modified = true;
                                    }
                                }
                            };
                            scope.onError = function ( e ) {
                                NMSWebNotification.add( {
                                    type: "error",
                                    isFadeable: true,
                                    title: $rootScope.translation.language.installation_upload_error,
                                    message: $rootScope.translation.language.an_error_occured_during_the_release_upload
                                }, "body" );
                                scope.uploadInProgress = false;
                                scope.installInProgress = false;
                            };
                            scope.onProgress = function ( e ) {
                                // HACK: Although the showFileList property is false, the Kendo element still shows the file list.
                                // Removing the list in onUpload() leads to an operation on an undefined element, so we have to
                                // put it here.
                                $('ul.k-upload-files').remove();
                                scope.progress = e.percentComplete;
                                if( e.percentComplete >= 100 && scope.uploadInProgress ) {
                                    NMSWebNotification.add( {
                                        type: "success",
                                        isFadeable: true,
                                        title: $rootScope.translation.language.upload_successful,
                                        message: $rootScope.translation.language.upload_successful_now_install
                                    }, "body" );
                                    scope.uploadInProgress = false;
                                }
                                scope.showProgress = true;
                                if($rootScope.system_type == "EVOLUTION"){
                                    if(!scope.inter){
                                        scope.inter = setInterval(function(){
                                            if ( $( '.upload_wrapper .k-upload-status-total' ).length ) {
                                                $( '.upload_wrapper .k-upload-status-total' ).html( 'Installing...<span class="k-icon k-loading">uploading</span>' )
                                            }
                                            $http( {
                                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/software/partitions/install_status',
                                                method: "GET",
                                                headers: {
                                                    'Content-Type': 'application/json'
                                                }
                                            } ).success( function ( response ) {
                                                scope.progress = response.data.install_progress;
                                                if(scope.progress >= 100 || response.data.install_active == false){
                                                    $( '.upload_wrapper .k-upload-status-total' ).html( 'Done' );
                                                    clearInterval(scope.inter);
                                                    NMSWebNotification.add( {
                                                        type: "success",
                                                        isFadeable: true,
                                                        title: $rootScope.translation.language.installation_successful,
                                                        message: $rootScope.translation.language.installation_completed_please_activate_release
                                                    }, "body" );
                                                    scope.showProgress = false;
                                                }
                                            }).error( function(){
                                                scope.showProgress = false;
                                                clearInterval(scope.inter);
                                            });
                                        },500);
                                    }
                                }
                            };
                            // Upload component configuration, success, progress, error and upload are callback functions
                            scope.upload_release = {
                                id: "upload_release",
                                async: {
                                    saveUrl: generalConfig.host + generalConfig.apiRoot + 'terminal/config/software/partitions',
                                },
                                localization: {
                                    headerStatusUploading: "Uploading",
                                    headerStatusUploaded: "Upload Successful"
                                },
                                multiple: false,
                                showFileList: false,
                                success: scope.onSuccess,
                                progress: scope.onProgress,
                                error: scope.onError,
                                upload: scope.onUpload
                            };

                            scope.activate_release = function ( url, id ) {
                                var myUrl;
                                $http.defaults.headers.post[ "Content-Type" ] = "application/x-www-form-urlencoded";
                                if ( $rootScope.system_type === 'EVOLUTION' ) {
                                    myUrl = generalConfig.host + generalConfig.apiRoot + 'terminal/config/software/partitions/' + id + '/activate';
                                } else {
                                    myUrl = generalConfig.host + url + '/activate';
                                }
                                $http( {
                                        url: myUrl,
                                        method: "POST",
                                        headers: {
                                            'Content-Type': 'application/json'
                                        }
                                    } )
                                    .error( function ( response ) {
                                        NMSWebNotification.add( {
                                            type: "majorwarning",
                                            isFadeable: true,
                                            title: $rootScope.translation.language.release_couldnt_be_activated,
                                            message: $rootScope.translation.language.the_release_couldnt_be_activated_please_try_again
                                        }, "body" );
                                    } )
                                    .then( function ( response ) {
                                        if ( response.status == "200" ) {
                                            if ( scope.modified != undefined ) {
                                                scope.modified = true;
                                            }
                                            $rootScope.$broadcast( 'streamingBufferGeneralUpdate', true );
                                            NMSWebNotification.add( {
                                                type: "success",
                                                isFadeable: true,
                                                title: $rootScope.translation.language.release_activated,
                                                message: $rootScope.translation.language.the_release_has_been_activated
                                            }, "body" );
                                        } else {
                                            NMSWebNotification.add( {
                                                type: "majorwarning",
                                                isFadeable: true,
                                                title: $rootScope.translation.language.release_couldnt_be_activated,
                                                message: $rootScope.translation.language.the_release_couldnt_be_activated_please_try_again
                                            }, "body" );
                                        }
                                        scope.reboot( $rootScope.translation.language.wantRebootActivateLong, $rootScope.translation.language.wantRebootActivate );
                                    } );
                            };
                            scope.reboot = function ( message, header ) {
                                $.confirm( {
                                    title: header ? header : $rootScope.translation.language.wantReboot,
                                    content: message ? message : $rootScope.translation.language.wantRebootLong,
                                    confirmButton: $rootScope.translation.language.continueReboot,
                                    cancelButton: $rootScope.translation.language.cancel,
                                    confirm: function () {
                                        $http( {
                                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/device/reboot',
                                                method: "POST",
                                                headers: {
                                                    'Content-Type': 'application/json'
                                                }
                                            } )
                                            .then( function successCallback( response ) {
                                                $rootScope.$broadcast( 'streamingBufferGeneralUpdate', true );
                                                NMSWebNotification.add( {
                                                    type: "success",
                                                    isFadeable: true,
                                                    title: $rootScope.translation.language.reboot_successful,
                                                    message: $rootScope.translation.language.reboot_message
                                                }, "body" );
                                            }, function errorCallback( response ) {
                                                NMSWebNotification.add( {
                                                    type: "majorwarning",
                                                    isFadeable: true,
                                                    title: $rootScope.translation.language.reboot_failed,
                                                    message: $rootScope.translation.language.the_device_cant_be_rebooted
                                                }, "body" );
                                            } );
                                    },
                                    cancel: function () {}
                                } );
                            }
                        },
                        post: function postLink( scope, element ) {}
                    }
                }
            }
        } ] );
    } );
