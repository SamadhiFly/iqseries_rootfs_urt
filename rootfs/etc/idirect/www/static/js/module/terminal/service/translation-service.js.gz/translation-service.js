define(['module/terminal'], function(terminal) {
    'use strict';
    terminal.service('TranslationService', ['$http', '$rootScope', function($http, $rootScope) {
        var defaultLanguage = 'en_us',
            TranslationService = {
                lang: defaultLanguage,
                data: {
                    meta: {},
                    language: {}
                },
                init: function(lang) {
                    var that = this;
                    if (that.initialized) {
                        return that;
                    }

                    // set language
                    that.lang = lang || defaultLanguage;

                    // load language json
                    that.loadLanguage();

                    // set initialized
                    that.initialized = true;
                    return that;
                },
                loadLanguage: function() {
                    var that = this,
                        languageFilePath = '/static/lang/' + that.lang + '.json';
                    $http({
                            url: languageFilePath,
                            method: "GET"
                        })
                        .then(function(response) {
                            that.data.language = response.data.language;
                            that.data.meta = response.data.meta;
                            $rootScope.$broadcast('changeLanguage', true);
                        });

                },
                changeLanguage: function(lang) {
                    var that = this;

                    // set language
                    that.lang = lang;

                    // load language json
                    that.loadLanguage();
                }
            };
        return TranslationService.init();
    }]);
});
