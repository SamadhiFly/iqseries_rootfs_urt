define(['module/terminal',
  'text!module/terminal/conf/general.json'],
  function(terminal, strGeneralConfig) {
    'use strict';
    terminal.directive('inlineWizard', ['$http', '$compile', '$location', '$rootScope', function($http, $compile, $location, $rootScope) {
      var generalConfig = $.parseJSON( strGeneralConfig );
      return {
        restrict: 'E',
        template: '<div><div class="wizard-tool-buttonholder"><button ng-click="cancelAndReturn()" class="wizard-cancel-button" ng-hide="wizardNotInitialized">Cancel and return to wizard</button><button ng-click="continue()" class="wizard-button" ng-hide="wizardNotInitialized">Continue with wizard</button><button ng-click="wizardInitialize()" class="wizard-button" ng-show="wizardNotInitialized">Start Commissioning Wizard</button></div></div>',
        replace: true,
        scope: {
          type: '@?'
        },
        compile: function() {
            return {
                pre: function preLink(scope, element) {
                  var index;
                  if($rootScope.commissioningWizard === undefined) {
                    scope.wizardNotInitialized = true;
                  }
                  scope.cancelAndReturn = function() {
                    $location.path('/commissioning-wizard');
                  }
                  scope.continue = function() {
                    angular.forEach( $rootScope.commissioningWizard, function ( value, key ) {
                        if(value.name === scope.type) {
                          index = parseInt(key);
                        }
                    } );
                    $rootScope.commissioningWizard[index].status = 'done';
                    if($rootScope.commissioningWizard[index+1] !== undefined) {
                      $rootScope.commissioningWizard[index+1].status = 'active';
                    }
                    $location.path('/commissioning-wizard');
                  }
                  scope.wizardInitialize = function() {
                    $location.path('/commissioning-wizard');
                  }
                }
            };
        }
      };
    }]);
  });
