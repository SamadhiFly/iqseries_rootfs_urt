define( [ 'module/terminal',
'text!module/terminal/conf/general.json',
'templates/nmsweb/module/terminal/directive/multicast.tpl',
'module/terminal/service/terminal-streaming-buffer',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form',
'module/core/directive/nmsweb-input'
], function ( terminal, strGeneralConfig, template ) {
    'use strict';
    terminal.directive( 'multicast', [ '$rootScope', 'TerminalStreamingBuffer', '$http', '$interval', '$timeout', 'ToolResource', 'NmswebForm', 'NMSWebNotification', function ( $rootScope, TerminalStreamingBuffer, $http, $interval, $timeout, ToolResource, NmswebForm, NMSWebNotification) {
        return {
            restrict: 'E',
            template: template,
            replace: true,
            compile: function () {
                return {
                    pre: function preLink( scope, element, attrs, ngModel ) {
                        scope.enableFilteringEnable = scope.enableFilteringEnable || false;
                        var generalConfig = $.parseJSON( strGeneralConfig );
                        var form = {
                            "layout": "layouts/terminal/tools/multicast"
						};
                        form.resource = new ToolResource( 'multicast' );
                        scope.multicast = new NmswebForm( form );
                        scope.multicast.actions = [];
                        scope.multicast.receiver = 1;
                        scope.disabledFilteringEnable = false;
                        scope.upperthreshold;

                        scope.validate = function(){
                            var apiData = {
                                combine_receivers: scope.multicast.model.combineReceiverEnable,
                                interval: parseInt(scope.multicast.model.interval),
                                activity_threshold: parseInt(scope.multicast.model.activity_threshold),
                                inactivity_threshold:  parseInt(scope.multicast.model.inactivity_threshold)
                            };
                            scope.upperthreshold = scope.multicast.model.activity_threshold;
                            if(apiData.interval < 1){
                                scope.multicast.model.interval = 1;
                            } else if(apiData.interval > 30){
                                scope.multicast.model.interval = 30;
                            }
                            if(apiData.activity_threshold < 1){
                                scope.multicast.model.activity_threshold = 1;
                            } else if(apiData.activity_threshold > 100000){
                                scope.multicast.model.activity_threshold = 100000;
                            }
                            if(apiData.inactivity_threshold < 1){
                                scope.multicast.model.inactivity_threshold = 1;
                            } else if(apiData.inactivity_threshold > scope.upperthreshold){
                                scope.multicast.model.inactivity_threshold = scope.upperthreshold;
                            }
                        };
                        var apiResource = 'terminal/ip/multicast_filtering';
                        $http( {
                            url: generalConfig.host + generalConfig.apiRoot + apiResource,
                            method: "GET"
                        } ).then( function ( data ) {
                            angular.element( '.main' ).spin( false );
                            scope.enableFilteringEnable = data.data.data.filtering_enabled;
                            scope.multicast.model.filtering_enabled = data.data.data.filtering_enabled;
                            scope.multicast.model.interval = data.data.data.interval;
                            scope.multicast.model.activity_threshold = data.data.data.activity_threshold;
                            scope.upperthreshold = scope.multicast.model.activity_threshold;
                            scope.multicast.model.inactivity_threshold = data.data.data.inactivity_threshold;
                            if( scope.manualDownstream_1.model.encapsulation_1 == "MPE" && scope.manualDownstream_2.model.encapsulation_2 == "MPE"){
                                scope.disabledFilteringEnable = true;
                                scope.enableFilteringEnable = true;
                            }
                            scope.validate();
                        } );

                        scope.tooltip_interval = {
                            content:"<p>Seconds; counting interval for activity</p>",
                            placement:"right",
                            title:"Interval"
                        };
                        scope.tooltip_active_threshold = {
                            content:"<p>Number of packets per interval that an inactive receiver must be above to be able to become active</p>",
                            placement:"right",
                            title:"Activity Threshold"
                        };
                        scope.tooltip_inactive_threshold = {
                            content:"<p>Number of packets per interval that an active receiver must fall below to be declared inactive</p>",
                            placement:"right",
                            title:"Inactivity Threshold"
                        };
                        scope.saveMulticast = function(){
                            var apiData = {
                                filtering_enabled: scope.enableFilteringEnable,
                                interval: parseInt(scope.multicast.model.interval),
                                activity_threshold: parseInt(scope.multicast.model.activity_threshold),
                                inactivity_threshold:  parseInt(scope.multicast.model.inactivity_threshold)
                            };
                            if(apiData.interval < 1){
                                apiData.interval = 1;
                            } else if(apiData.interval > 30){
                                apiData.interval = 30;
                            }
                            if(apiData.activity_threshold < 1){
                                apiData.activity_threshold = 1;
                            } else if(apiData.activity_threshold > 100000){
                                apiData.activity_threshold = 100000;
                            }
                            if(apiData.inactivity_threshold < 1){
                                apiData.inactivity_threshold = 1;
                            } else if(apiData.inactivity_threshold > scope.upperthreshold){
                                apiData.inactivity_threshold = scope.upperthreshold;
                            }
                            generalConfig = $.parseJSON( strGeneralConfig );
                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + "/terminal/ip/multicast_filtering",
                                method: "POST",
                                data: apiData,
                                headers: {
                                    'Content-Type': 'application/json'
                                }
                            } )
                            .error( function ( response ) {
                                NMSWebNotification.add( {
                                    type: "majorwarning",
                                    isFadeable: true,
                                    title: $rootScope.translation.language.multicast_update_failed,
                                    message: $rootScope.translation.language.the_change_could_not_be_saved_colon + response.errors[ 0 ]
                                }, "body" );
                            } )
                            .then( function ( response ) {
                                if ( response.status == "200" ) {
                                    NMSWebNotification.add( {
                                        type: "success",
                                        isFadeable: true,
                                        title: $rootScope.translation.language.multicast_update_successfully,
                                        message: $rootScope.translation.language.configuration_successfully_saved
                                    }, "body" );
                                } else {
                                    NMSWebNotification.add( {
                                        type: "majorwarning",
                                        isFadeable: true,
                                        title: $rootScope.translation.language.multicast_update_failed,
                                        message: $rootScope.translation.language.the_change_could_not_be_saved
                                    }, "body" );
                                }
                            } );
                        }
                        scope.toggleEnableFiltering = function(){
                            if(!scope.disabledFilteringEnable){
                                scope.enableFilteringEnable = !scope.enableFilteringEnable;
                            }
                        };
                    },
                    post: function () {
                    }
                };
            }
        };
  } ] );
} );