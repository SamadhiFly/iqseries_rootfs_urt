define( [ 'module/terminal',
'text!module/terminal/conf/general.json',
'templates/nmsweb/module/terminal/directive/mpe.tpl',
'module/terminal/service/terminal-streaming-buffer',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form',
'module/core/directive/nmsweb-input'
], function ( terminal, strGeneralConfig, template ) {
    'use strict';
    terminal.directive( 'mpe', [ '$rootScope', 'TerminalStreamingBuffer', '$http', '$interval', '$timeout', 'ToolResource', 'NmswebForm', 'NMSWebNotification', function ( $rootScope, TerminalStreamingBuffer, $http, $interval, $timeout, ToolResource, NmswebForm, NMSWebNotification ) {
        return {
            restrict: 'E',
            template: template,
            replace: true,
            compile: function () {
                return {
                    pre: function preLink( scope, element, attrs, ngModel ) {
                        var generalConfig = $.parseJSON( strGeneralConfig );
                        var form = {
                            "layout": "layouts/terminal/tools/mpe",
                            "hook": "module/terminal/hook/tool-mpe"
						};
                        form.resource = new ToolResource( 'mpe' );
                        scope.mpe = new NmswebForm( form );
                        scope.mpe.actions = [];

                        scope.saveMPE = function () {
                                var generalConfig = $.parseJSON( strGeneralConfig ),
                                apiResource,
                                apiData = {};

                            apiResource = 'terminal/ip/mpe';
                            apiData = {
                                "receivers": [
                                ]
                            };
                            for(var i = 0;2 > i;i++)
                            {
                                if(this.mpe.model["overview_"+(i+1)] && this.mpe.model["overview_"+(i+1)].length){
                                    for(var j = 0;this.mpe.model["overview_"+(i+1)].length > j;j++)
                                    {
                                        if(apiData.receivers[i] === undefined){
                                            apiData.receivers[i] = {
                                                "pids": []
                                            };
                                        }
                                        apiData.receivers[i].pids.push(this.mpe.model["overview_"+(i+1)][j]["pid_number_"+(i+1)]);
                                    }
                                    apiData.receivers[i].rx_id = i;
                                }
                            }
                            $http( {
                                    url: generalConfig.host + generalConfig.apiRoot + apiResource,
                                    method: "POST",
                                    data: apiData,
                                    headers: {
                                        'Content-Type': 'application/json'
                                    }
                                } )
                                .error( function ( response ) {
                                    NMSWebNotification.add( {
                                        type: "majorwarning",
                                        isFadeable: true,
                                        title: $rootScope.translation.language.warning,
                                        message: $rootScope.translation.language.the_change_could_not_be_saved_colon + response.errors[ 0 ]
                                    }, "body" );
                                } )
                                .success( function ( response ) {
                                    NMSWebNotification.add( {
                                        type: "success",
                                        isFadeable: true,
                                        title: $rootScope.translation.language.success,
                                        message: $rootScope.translation.language.configuration_successfully_saved
                                    }, "body" );
                                } );
                            return false;
                        };
                    },
                    post: function () {
                    }
                };
            }
        };
  } ] );
} );