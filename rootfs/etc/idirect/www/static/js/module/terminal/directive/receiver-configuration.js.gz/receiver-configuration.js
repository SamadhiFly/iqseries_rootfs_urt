define( [ 'module/terminal',
  'text!module/terminal/conf/general.json',
  'templates/nmsweb/module/terminal/directive/receiver-configuration.tpl',
  'module/terminal/service/terminal-streaming-buffer',
  'module/terminal/factory/tool-resource',
  'module/core/directive/form',
  'module/core/factory/form',
  'module/core/directive/nmsweb-input'
], function ( terminal, strGeneralConfig, template ) {
    'use strict';
    terminal.directive( 'receiverConfiguration', [ '$rootScope', 'TerminalStreamingBuffer', '$http', '$interval', 'ToolResource', 'NmswebForm', function ( $rootScope, TerminalStreamingBuffer, $http, $interval, ToolResource, NmswebForm ) {
        return {
            restrict: 'E',
            template: template,
            replace: true,
            scope: {
                receiver: '='
            },
            compile: function () {
                return {
                    pre: function preLink( scope, element, attrs, ngModel ) {
                        var formOptions = {
                                "layout": "layouts/terminal/tools/receiver-configuration",
                                "hook": "module/terminal/hook/receiver-configuration"
                            },
                            generalConfig = $.parseJSON( strGeneralConfig );
                        formOptions.resource = new ToolResource( 'receiver-configuration' );
                        formOptions.name = 'receiver-configuration' + scope.receiver;
                        formOptions.viewMode = false;
                        scope.form = new NmswebForm( formOptions );
                        scope.form.receiver = scope.receiver;
                        $http( {
                            url: generalConfig.host + generalConfig.apiRoot + "terminal/rx/" + ( scope.receiver - 1 ),
                            method: "GET"
                        } ).then( function ( data ) {
                            scope.form.rx_mode = data.data.data.mode;
                            scope.formReady = true;
                        } );
                    },
                    post: function () {}
                };
            }
        };
    } ] );
} );