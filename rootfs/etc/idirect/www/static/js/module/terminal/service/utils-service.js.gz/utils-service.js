define( [ 'module/terminal',
'text!module/terminal/conf/general.json',
'module/terminal/service/terminal-streaming-buffer' ], function ( terminal, strGeneralConfig ) {
    'use strict';
    terminal.service( 'UtilsService', [ '$http', '$rootScope', 'TerminalStreamingBuffer', function ( $http, $rootScope, TerminalStreamingBuffer ) {
        var generalConfig = $.parseJSON( strGeneralConfig );
        return {
            getLocationUnit: function ( type, value ) {
                var unit = "° ";
                if( type === 'longitude' ) {
                    if ( value > 0 && value <= 180 ) {
                        unit = unit + $rootScope.translation.language.east;
                    } else if ( value > 180 && value <= 360 ) {
                        unit = unit + $rootScope.translation.language.west;
                    }
                    if ( value < 0 ) {
                        value = value * - 1;
                        unit = unit + $rootScope.translation.language.west;
                    }
                } else if ( type === 'latitude' ) {
                    if ( value > 0 && value <= 90 ) {
                        unit = unit + $rootScope.translation.language.north;
                    } else if ( value < 0 && value >= -90 ) {
                        unit = unit + $rootScope.translation.language.south;
                    }
                }
                return unit;
            },
            getLocationValue: function ( type, value ) {
                if ( value < 0 ) {
                    value = value * - 1;
                }
                if ( type === 'longitude' ) {
                    if ( value > 180 && value <= 360 ) {
                        value = 360 - value;
                    }
                }
                return value;
            }
        };
  } ] );
} );
