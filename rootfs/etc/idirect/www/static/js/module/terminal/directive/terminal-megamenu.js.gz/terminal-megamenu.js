define( [ 'module/terminal',
  'templates/nmsweb/module/terminal/directive/terminal-megamenu.tpl',
  'text!module/terminal/conf/general.json',
  'core/megamenu',
  'jquery',
  'module/terminal/service/terminal-streaming-buffer',
  'module/terminal/service/translation-service' ], function ( terminal, template, strGeneralConfig, megaMenu ) {
    'use strict';
    terminal.directive( 'terminalMegamenu', [ '$http', '$rootScope', 'TerminalStreamingBuffer', '$interval', 'TranslationService', '$timeout', 'AuthenticationService',
  function ( $http, $rootScope, TerminalStreamingBuffer, $interval, TranslationService, $timeout, AuthenticationService ) {
            return {
                restrict: 'E',
                template: template,
                priority: 1001,
                scope: {},
                compile: function () {
                    return {
                        pre: function preLink( scope, element ) {
                            var generalConfig = $.parseJSON( strGeneralConfig ),
                                httpPromise, antennaModePromise,
                                deletes = [ "commissioning_wizard", "commissioning_details" ],
                                commissioningData,
                                inCommissioning;
                            scope.adminUser = false;
                            scope.hideFields = [];
                            scope.hideFirstLevelItems = [];
                            AuthenticationService.checkBeAuth().then( function ( response ) {
                                if ( response.data.data.whoami === 'admin' ) {
                                    scope.adminUser = true;
                                }
                                if ( response.data.data.whoami ) {
                                    scope.username = response.data.data.whoami;
                                }
                            } );
                            scope.processMegamenuResponse = function ( hideFields, hideFirstLevelItems ) {
                                httpPromise = $http( {
                                    url: generalConfig.host + generalConfig.apiRoot + 'tools/terminal-megamenu',
                                    method: "OPTIONS"
                                } );
                                httpPromise.then( function ( response ) {
                                    scope.menuitems = response.data;
                                    if ( ( !$rootScope.commissioningAvailable || hideFields ) && scope.menuitems ) {
                                        var deleteKeys = [];
                                        var deleteFirstLevelItems = [];
                                        angular.forEach( scope.menuitems, function ( value, key ) {
                                            if ( value.children.length !== 0 ) {
                                                if ( hideFirstLevelItems.length !== 0 && hideFirstLevelItems.indexOf( value.title ) !== -1 ) {
                                                    if ( deleteFirstLevelItems.indexOf( key ) === -1 ) {
                                                        deleteFirstLevelItems.push( key );
                                                    }
                                                }
                                                angular.forEach( value.children, function ( childvalue, childkey ) {
                                                    if ( value.children.length !== 0 ) {
                                                        angular.forEach( childvalue.children, function ( childchildvalue ) {
                                                            if ( !$rootScope.commissioningAvailable && $.inArray( childchildvalue.title, deletes ) !== -1 ) {
                                                                if ( $.inArray( {
                                                                        "key": key,
                                                                        "childkey": childkey,
                                                                        "childchildvalue": childchildvalue
                                                                    }, deleteKeys ) === -1 ) {
                                                                    deleteKeys.push( {
                                                                        "key": key,
                                                                        "childkey": childkey,
                                                                        "childchildvalue": childchildvalue
                                                                    } );
                                                                }
                                                            } else if ( hideFields && $.inArray( childchildvalue.title, hideFields ) !== -1 ) {
                                                                if ( $.inArray( {
                                                                        "key": key,
                                                                        "childkey": childkey,
                                                                        "childchildvalue": childchildvalue
                                                                    }, deleteKeys ) === -1 ) {
                                                                    deleteKeys.push( {
                                                                        "key": key,
                                                                        "childkey": childkey,
                                                                        "childchildvalue": childchildvalue
                                                                    } );
                                                                }
                                                            }
                                                        } );
                                                    }
                                                } );
                                            }
                                        } );
                                        angular.forEach( deleteKeys, function ( deleteVal ) {
                                            var deleteKey;
                                            deleteKey = $.inArray( deleteVal.childchildvalue, scope.menuitems[ deleteVal.key ].children[ deleteVal.childkey ].children );
                                            scope.menuitems[ deleteVal.key ].children[ deleteVal.childkey ].children.splice( deleteKey, 1 );
                                        } );
                                        angular.forEach( deleteFirstLevelItems, function ( firstLevelKey ) {
                                            scope.menuitems.splice( firstLevelKey, 1 );
                                        } );
                                    }
                                    $timeout( function () {
                                        $( '#megamenuHolder' ).nmsMegaMenu( {
                                            groupColumns: 6,
                                            reactive: true,
                                            width: '100%',
                                            categoryWidth: '100px'
                                        } );
                                    } );
                                    $rootScope.$broadcast( 'changeLanguage', true );
                                } );
                            };
                            scope.hideAntennaPoint = function ( hideFields) {
                                hideFields.push( 'antenna_pointing' );
                            };
                            scope.hideAntennaPoint( scope.hideFields );
                            TerminalStreamingBuffer.registerResource( 'terminal/config/commission', 10000, 0, true );
                            $interval( function () {
                                if ( $rootScope.commissioningAvailable ) {
                                    commissioningData = TerminalStreamingBuffer.getCurrentValue( [ 'terminal/config/commission', 'data' ] );
                                    if ( commissioningData ) {
                                        if ( inCommissioning !== commissioningData.is_commissioning ) {
                                            inCommissioning = commissioningData.is_commissioning;
                                            if ( inCommissioning ) {
                                                scope.hideFields.push( 'cross_polarization_p1db' );
                                            } else {
                                                var index = scope.hideFields.indexOf( 'cross_polarization_p1db' );
                                                if ( index !== -1 ) {
                                                    scope.hideFields.splice( index, 1 );
                                                }
                                            }
                                            scope.processMegamenuResponse( scope.hideFields, scope.hideFirstLevelItems );
                                        }
                                    }
                                }
                            }, 2000 );
                            if ( $rootScope.system_type === 'VELOCITY' ) {
                                antennaModePromise = $http( {
                                    url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/identity',
                                    method: "GET"
                                } );
                                antennaModePromise.then( function ( response ) {
                                    if ( response.data.data && response.data.data.openamip && response.data.data.openamip.mode && response.data.data.openamip.mode === "tcp" ) {
                                        scope.processMegamenuResponse( scope.hideFields, scope.hideFirstLevelItems );
                                    } else {
                                        scope.hideFields.push( 'bim_configuration' );
                                        scope.processMegamenuResponse( scope.hideFields, scope.hideFirstLevelItems );
                                    }
                                } );
                            } else {
                                // Check if COTP menu item should be visible
                                $http( {
                                    url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/mobility',
                                    method: "GET"
                                } ).then( function successCallback( mobilityResult ) {
                                    var cotpAvailable = mobilityResult && mobilityResult.data && mobilityResult.data.data && mobilityResult.data.data.mobility === 'COTP';
                                    if ( !cotpAvailable ) {
                                        scope.hideFirstLevelItems.push( 'cotp' );
                                    }
                                    scope.processMegamenuResponse( scope.hideFields, scope.hideFirstLevelItems );
                                }, function errorCallback( error ) {
                                    scope.hideFirstLevelItems.push( 'cotp' );
                                    scope.processMegamenuResponse( scope.hideFields, scope.hideFirstLevelItems );
                                } );
                            }

                            $rootScope.$on( 'changeLanguage', function ( event, currentValues ) {
                                angular.forEach( scope.menuitems, function ( value, key ) {
                                    if ( value.title in TranslationService.data.language ) {
                                        scope.menuitems[ key ].title = TranslationService.data.language[ value.title ];
                                    }
                                    if ( value.children.length !== 0 ) {
                                        angular.forEach( value.children, function ( childvalue, childkey ) {
                                            if ( childvalue.title in TranslationService.data.language ) {
                                                scope.menuitems[ key ].children[ childkey ].title = TranslationService.data.language[ childvalue.title ];
                                            }
                                            if ( value.children.length !== 0 ) {
                                                angular.forEach( childvalue.children, function ( childchildvalue, childchildkey ) {
                                                    if ( childchildvalue.title in TranslationService.data.language ) {
                                                        scope.menuitems[ key ].children[ childkey ].children[ childchildkey ].title = TranslationService.data.language[ childchildvalue.title ];
                                                    }
                                                } );
                                            }
                                        } );
                                    }
                                } );
                            } );
                        }
                    };
                }
            };
  } ] );
} );
