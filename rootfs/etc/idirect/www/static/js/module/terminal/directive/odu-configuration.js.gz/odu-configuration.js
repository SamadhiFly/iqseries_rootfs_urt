define( [ 'module/terminal',
'text!module/terminal/conf/general.json',
'templates/nmsweb/module/terminal/directive/odu-configuration.tpl',
'module/terminal/service/terminal-streaming-buffer',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form',
'module/terminal/directive/nmsweb-html',
'module/terminal/directive/txrx-configuration',
'module/core/directive/nmsweb-tooltip'],
	function ( terminal, strGeneralConfig, template ) {
		'use strict';
		terminal.directive( 'oduConfiguration', [ '$rootScope', 'TerminalStreamingBuffer', 'ToolResource', 'NmswebForm', '$http', 'NMSWebNotification', function ( $rootScope, TerminalStreamingBuffer, ToolResource, NmswebForm, $http, NMSWebNotification ) {
			return {
				restrict: 'E',
				template: template,
				replace: true,
				scope: {
				},
				compile: function () {
					return {
						pre: function preLink( scope, element ) {
							var generalConfig = $.parseJSON( strGeneralConfig ),
								formOptions = {
								"hook": "module/terminal/hook/tool-odu-configuration"
							};
							scope.rx2 = false;
							 $http( {
								url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/identity',
								method: "GET"
							} ).then( function ( result ) {
								if ( result.data.data && result.data.data.model ) {
									if(result.data.data.model === "900"  || result.data.data.model === "9350"){
										scope.rx2 = true;
									}
								}
							});
							formOptions.name = 'odu-configuration';
							formOptions.viewMode = false;
							scope.title = formOptions.name;
							scope.apply = function(elem){
								var default_values;
								if(elem === "tx"){
									default_values = scope.$$childHead.form.default_values;
								} else if(elem === "rx1"){
									default_values = scope.$$childHead.$$nextSibling.form.default_values;
								} else {
									default_values = scope.$$childHead.$$nextSibling.$$nextSibling.form.default_values;
								}

								var postData = {
									"reference":parseInt(scope.config.params[elem]["reference_"+elem]),
									"translation":default_values.translation,
									"spectral_inversion":(default_values.spectral_inversion == "true"),
									"dc_voltage":parseInt(scope.config.params[elem]["dc_voltage_"+elem])
								};
								var url;
								if(elem !== "tx"){
									postData.rx_acqrange = (default_values.rx_acqrange) ? default_values.rx_acqrange : 0;
									postData.tone_enabled = (scope.config.params[elem]["tone_enabled_"+elem] == "true");
									url = "terminal/odu/lnb/"+(Number(elem.substr(2,1))-1);

									postData = {
										"data":postData
									};
								} else {
									url = "terminal/odu/buc/0";
								}
								if(scope.config.params[elem]["dc_voltage_"+elem] != "0" && scope.config.params[elem]["dc_voltage_"+elem] !== default_values.dc_voltage){
										$.confirm( {
											title: $rootScope.translation.language.dc_enabled_warning_tx,
											content: $rootScope.translation.language.dc_enabled_warning_text_tx,
											confirmButton: $rootScope.translation.language.continue,
											cancelButton: $rootScope.translation.language.cancel,
											confirm: function () {
												$http( {
													url: generalConfig.host + generalConfig.apiRoot + url,
													method: "POST",
													data: postData,
													headers: {
														'Content-Type': 'application/json'
													}
												} ).then( function ( response ) {
													if(response.data.errors && response.data.errors[ 0 ]){
														NMSWebNotification.add( {
															type: "error",
															isFadeable: true,
															title: $rootScope.translation.language.error,
															message: response.data.errors[ 0 ]
														}, "body" );
													} else {
														NMSWebNotification.add( {
															type: "success",
															isFadeable: true,
															title: $rootScope.translation.language.info,
															message: $rootScope.translation.language["odu_info_"+elem+"_successful"]
														}, "body" );
													}
												} );
											},
											cancel: function () {

											}
										} );
									} else {
										$http( {
											url: generalConfig.host + generalConfig.apiRoot + url,
											method: "POST",
											data: postData,
											headers: {
												'Content-Type': 'application/json'
											}
										} ).then( function ( response ) {
											if(response.data.errors && response.data.errors[ 0 ]){
												NMSWebNotification.add( {
													type: "error",
													isFadeable: true,
													title: $rootScope.translation.language.error,
													message: response.data.errors[ 0 ]
												}, "body" );
											} else {
												NMSWebNotification.add( {
													type: "success",
													isFadeable: true,
													title: $rootScope.translation.language.info,
													message: $rootScope.translation.language["odu_info_"+elem+"_successful"]
												}, "body" );
											}
										} );
									}
							};
							scope.config = formOptions;
							scope.config.params = {};
							scope.$watch("config.params",function(newVal,oldVal){
								if(newVal.rx1 && newVal.rx2){
									if(newVal.rx1.reference_rx1 != oldVal.rx1.reference_rx1 && newVal.rx1.reference_rx1 != newVal.rx2.reference_rx2){
										newVal.rx2.reference_rx2 = newVal.rx1.reference_rx1;
									}
									if(newVal.rx2.reference_rx2 != oldVal.rx2.reference_rx2 && newVal.rx2.reference_rx2 != newVal.rx1.reference_rx1){
										newVal.rx1.reference_rx1 = newVal.rx2.reference_rx2;
									}
									if(newVal.rx1.dc_voltage_rx1 !== "0"){
										$( '#odu-configuration-tone-enabled-rx1' ).prop( 'disabled', false ).removeClass( 'disabled' );
									} else {
										$( '#odu-configuration-tone-enabled-rx1' ).prop( 'disabled', true ).addClass( 'disabled' );
										newVal.rx1.tone_enabled_rx1 = "false";
									}
									if(newVal.rx2.dc_voltage_rx2 !== "0"){
										$( '#odu-configuration-tone-enabled-rx2' ).prop( 'disabled', false ).removeClass( 'disabled' );
									} else {
										$( '#odu-configuration-tone-enabled-rx2' ).prop( 'disabled', true ).addClass( 'disabled' );
										newVal.rx2.tone_enabled_rx2 = "false";
									}
								}
							},true);
						},
						post: function () {}
					};
				}
			};
	} ] );
	} );
