define( [ 'module/terminal',
'templates/nmsweb/module/terminal/buc-tab.tpl',
'text!module/terminal/conf/general.json',
'module/terminal/hook/callback/tool-buc-oscillator',
'module/terminal/hook/callback/tool-buc-fan',
'module/terminal/hook/callback/tool-buc-output',
'module/terminal/hook/callback/tool-buc-options',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form',
'module/terminal/directive/nmsweb-html'
], function ( terminal, template, strGeneralConfig, BucOscillator, BucFan, BucOutput, BucOptions ) {
    'use strict';
    terminal.directive( 'bucTab', [ '$rootScope', 'TerminalStreamingBuffer', '$http', 'ToolResource', 'NmswebForm', function ( $rootScope, TerminalStreamingBuffer, $http, ToolResource, NmswebForm ) {
        return {
            restrict: 'E',
            template: template,
            replace: true,
            scope: {
                buc: '=?',
                formOptions: '=?'
            },
            compile: function () {
                return {
                    pre: function preLink( scope, element ) {
                        var generalConfig = $.parseJSON( strGeneralConfig );
                        scope.formOptions.resource = new ToolResource( 'buc' );
                        scope.formOptions.name = 'buc';
                        scope.stat = [];
                        scope.formOptions.viewMode = true;
                        scope.title = scope.formOptions.name;
                        scope.formOptions.bucGet = $http( {
                            url: generalConfig.host + generalConfig.apiRoot + 'terminal/odu/buc',
                            method: "GET"
                        } );
                        scope.formOptions.bandConfiguration = $http( {
                            url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/commission',
                            method: "GET"
                        } );

                        if ( $rootScope.system_type == "VELOCITY" ) {
                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/mode/buc_cal/' + scope.buc + '/status',
                                method: "GET"
                            } ).then( function ( status ) {
                                if ( status.data && status.data.data ) {
                                    var index = status.config.url.split( "/" )[ ( status.config.url.split( "/" ).length - 2 ) ];
                                    scope.stat[ index ] = status.data.data.buc_calibration_status;
                                }
                            } );
                            scope.formOptions.bandSettings = $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/odu/buc/' + scope.buc + '/bands',
                                method: "GET"
                            } );
                        }
                        scope.formOptions.bucGet.error( function ( data, status, headers, config ) {
                            $rootScope.noBuc = true;
                        } );

                        scope.formOptions.bucGet.then( function ( data ) {
                            if ( !data.data.data || !data.data.data[ 0 ].product_id ) {
                                $rootScope.noBuc = true;
                            }
                            scope.formOptions.bucs = data.data.data.length;
                            scope.bucs = data.data.data;
                        } );
                        scope.form = new NmswebForm( scope.formOptions );
                        scope.form.id = scope.buc;

                        scope.form.model = {};
                        scope.form.fields = {};
                        if ( scope.form.viewMode ) {
                            scope.form.actions = [];
                        } else {
                            scope.form.actions = [ scope.form.actions[ 0 ] ];
                        }

                        var options = BucOptions.additionalOptions( scope.form.id );
                        for ( var i = 0; i < options.length; i++ ) {
                            scope.form.fields[ options[ i ].attr_name ] = {
                                options: options[ i ]
                            }
                        }

                        $rootScope.routeListeners.push( $rootScope.$on( 'streamingBufferGeneralUpdate', function ( event ) {
                            var model = {};
                            angular.forEach( scope.form.fields, function ( field, fieldName ) {
                                if ( field.options.active_value && field.options.active_value.length ) {
                                    TerminalStreamingBuffer.registerResource( field.options.active_value[ 0 ] );
                                }
                                var tmpValue = TerminalStreamingBuffer.getCurrentValue( field.options.active_value );
                                if ( tmpValue !== false ) {
                                    model[ fieldName ] = tmpValue;
                                }
                            } )
                            scope.form.bucGet.success( function ( data, status, headers, config ) {
                                if ( $rootScope.noBuc ) {
                                    model = {};
                                } else {

                                    var act_temp = TerminalStreamingBuffer.getCurrentValue( [ 'terminal/odu/buc/' + scope.form.id, 'data', 'temperature' ] ),
                                        fault_status = TerminalStreamingBuffer.getCurrentValue( [ 'terminal/odu/buc/' + scope.form.id, 'data', 'fault_status' ] );
                                    model[ 'temperature' ] = Math.round( 100 * act_temp ) / 100;
                                    model[ 'local_oscillator' ] = BucOscillator.bucOscillatorOut( fault_status );
                                    model[ 'fan' ] = [ BucFan.bucFanLedOut( TerminalStreamingBuffer, BucFan ),
                                                                    BucFan.bucFanOut( fault_status )
                                                                ];
                                    model[ 'output' ] = BucOutput.bucOutputOut( fault_status );
                                }
                                angular.extend( scope.form.model, model );
                            } );
                            if ( $rootScope.system_type == "VELOCITY" ) {
                                $http( {
                                    url: generalConfig.host + generalConfig.apiRoot + 'terminal/config/identity',
                                    method: "GET"
                                } ).then( function ( data ) {
                                    if ( data.data.data && data.data.data.openbmip && data.data.data.openbmip.mode ) {
                                        scope.state = data.data.data.openbmip.mode;
                                    }
                                } );
                                var commissiond_bands = [];
                                scope.form.bandConfiguration.success( function ( data ) {
                                    commissiond_bands = [];
                                    if ( data.data.commissioned_bucs ) {
                                        for ( var k = 0; k < data.data.commissioned_bucs.length; k++ ) {
                                            commissiond_bands.push.apply( commissiond_bands, data.data.commissioned_bucs[ k ].available_bands );
                                        }
                                    }
                                } );

                                scope.form.bandSettings.then( function ( data ) {
                                    if ( data.data.data && data.data.data.length ) {
                                        scope.form.band_config = data.data.data;
                                        var buc_id = data.config.url.split( "/" )[ ( data.config.url.split( "/" ).length - 2 ) ];

                                        for ( var i = 0; scope.form.band_config.length > i; i++ ) {
                                            scope.form.band_config[ i ].commissiond = scope.stat[ buc_id ];
                                            scope.form.band_config[ i ].state = scope.state;
                                            for ( var j = 0; j < commissiond_bands.length; j++ ) {
                                                if ( scope.form.band_config[ i ].start_rf_frequency == commissiond_bands[ j ].installer_record.start_rf_frequency ) {
                                                    scope.form.band_config[ i ].state = "details";
                                                    if(!scope.form.band_config[ i ].commissiond){
                                                        scope.form.band_config[ i ].commissiond = "Commissioned";
                                                    }
                                                }
                                            }
                                            if(!scope.form.band_config[ i ].commissiond){
                                                scope.form.band_config[ i ].commissiond = "Not Commissioned";
                                            }
                                        }
                                    }
                                } );
                            }
                        } ) );
                        $rootScope.$broadcast( 'streamingBufferGeneralUpdate', true );
                        var replaceLabel = function ( object ) {
                            if ( object.label && $rootScope.translation.language[ object.label_internal || object.label ] ) {
                                object.label_internal = object.label_internal || object.label;
                                object.label = $rootScope.translation.language[ object.label_internal || object.label ]
                            }
                            if ( object.contents ) {
                                angular.forEach( object.contents, function ( obj, key ) {
                                    object.contents[ key ] = replaceLabel( obj );
                                } );
                            }
                            return object;
                        }
                        $rootScope.$on( 'changeLanguage', function ( event, currentValues ) {
                            angular.forEach( scope.form.fields, function ( field, fieldname ) {
                                if ( $rootScope.translation.language[ field.options.label ] || $rootScope.translation.language[ fieldname ] ) {
                                    if ( field.options.label && field.options.label != $rootScope.translation.language[ fieldname ] ) {
                                        scope.form.fields[ fieldname ].options.label = $rootScope.translation.language[ field.options.label ];
                                    } else {
                                        scope.form.fields[ fieldname ].options.label = $rootScope.translation.language[ fieldname ];
                                    }
                                }
                                angular.forEach( scope.form.layout, function ( obj, key ) {
                                    scope.form.layout[ key ] = replaceLabel( obj );
                                } );
                            } );
                        } );
                        $rootScope.$broadcast( 'changeLanguage', true );
                        scope.form.fields[ 'fan' ].directive = "nmsweb-input";
                        scope.form.fields[ 'fan' ].options.origType = scope.form.fields[ 'fan' ].directive;
                        scope.form.fields[ 'fan' ].directive = "led-field-wrapper";
                        scope.form.fields[ 'fan' ].options.ledSize = "small";
                        return scope.form.field;

                    },
                    post: function () {}
                };
            }
        };
    } ] );
} );