define( [ 'module/terminal',
'text!module/terminal/conf/general.json',
'templates/nmsweb/module/terminal/directive/transec-receiver.tpl',
'module/terminal/service/terminal-streaming-buffer',
'module/terminal/factory/tool-resource',
'module/core/directive/form',
'module/core/factory/form',
'module/terminal/directive/nmsweb-html',
'module/core/directive/nmsweb-tooltip' ],
    function ( terminal, strGeneralConfig, template ) {
        'use strict';
        terminal.directive( 'transecReceiver', [ '$rootScope', 'TerminalStreamingBuffer', 'ToolResource', 'NmswebForm', '$http', function ( $rootScope, TerminalStreamingBuffer, ToolResource, NmswebForm, $http ) {
            return {
                restrict: 'E',
                template: template,
                replace: true,
                scope: {
                    receiver: "="
                },
                compile: function () {
                    return {
                        pre: function preLink( scope, element ) {
                            var generalConfig = $.parseJSON( strGeneralConfig ),
                                formOptions = {
                                    "layout": "layouts/terminal/tools/transec-receiver",
                                    "hook": "module/terminal/hook/tool-transec-receiver"
                                };
                            angular.element( '.main' ).spin( true );
                            scope._completed = false;
                            var domainData = $rootScope.transecData.domains,
                                domains = [];
                            for ( var i = 0; i < domainData.length; i++ ) {
                                domains.push( {
                                    "id": domainData[ i ].domain_id.toString(),
                                    "name": "Domain " + ( domainData[ i ].domain_id + 1 )
                                } );
                            }
                            formOptions.resource = new ToolResource( 'transec-receiver' );
                            formOptions.name = 'transec-receiver';
                            formOptions.viewMode = false;
                            scope.title = formOptions.name;
                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/rx/' + ( scope.receiver - 1 ),
                                method: "GET"
                            } ).then(function successCallback(data3) {
                                //check rx mode
                                scope.rxMode = data3.data.data.mode;
                                if(scope.rxMode == 'MANUAL_DOWNSTREAM') {
                                    $http( {
                                        url: generalConfig.host + generalConfig.apiRoot + 'terminal/mode/manual_downstream/' + ( scope.receiver - 1 ),
                                        method: "GET"
                                    } ).then(function successCallback(data2) {
                                        scope.form = new NmswebForm( formOptions );
                                        scope.form.rxMode = scope.rxMode;
                                        scope.form._domains = domains;
                                        scope.form.receiver = scope.receiver;
                                        scope.form.encapsulation = data2.data.data.encapsulation;
                                        scope._completed = true;
                                        scope.receiverForm = "receiverForm"+scope.receiver;
                                    } );
                                } else {
                                    scope.form = new NmswebForm( formOptions );
                                    scope.form.rxMode = scope.rxMode;
                                    scope.form._domains = domains;
                                    scope.form.receiver = scope.receiver;
                                    scope.form.encapsulation = null;
                                    scope._completed = true;
                                    scope.receiverForm = "receiverForm"+scope.receiver;
                                }
                                angular.element( '.main' ).spin( false );
                            }, function errorCallback() {
                                angular.element( '.main' ).spin( false );
                            } );
                        },
                        post: function () {}
                    }
                }
            };
    } ] );
    } );
