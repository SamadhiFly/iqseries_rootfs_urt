define( [ 'module/terminal',
  'text!module/terminal/conf/general.json',
  'templates/nmsweb/module/terminal/directive/txrx-configuration.tpl',
  'module/terminal/service/terminal-streaming-buffer',
  'module/terminal/factory/tool-resource',
  'module/core/directive/form',
  'module/core/factory/form',
  'module/core/directive/nmsweb-input'
], function ( terminal, strGeneralConfig, template ) {
    'use strict';
    terminal.directive( 'txrxConfiguration', [ '$rootScope', 'TerminalStreamingBuffer', '$http', '$interval', '$timeout', 'ToolResource', 'NmswebForm', function ( $rootScope, TerminalStreamingBuffer, $http, $interval, $timeout, ToolResource, NmswebForm ) {
        return {
            restrict: 'E',
            template: template,
            replace: true,
            scope: {
                configuration: '=',
                type: '=?'
            },
            compile: function () {
                return {
                    pre: function preLink( scope, element, attrs, ngModel ) {

                        scope.configuration.layout = "layouts/terminal/tools/"+scope.type+"-configuration";
                        scope.configuration.resource = new ToolResource(scope.type+"-configuration");
                        var generalConfig = $.parseJSON( strGeneralConfig );
                        scope.openamip = false;
                        if(scope.type === "tx"){
                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/odu/buc/0',
                                method: "GET"
                            } ).then( function ( result ) {

                                if ( result.data.data ) {
                                    scope.form.default_values = result.data.data;
                                }
                                scope.form.default_values.type = scope.type;
                            } );
                        } else {
                            $http( {
                                url: generalConfig.host + generalConfig.apiRoot + 'terminal/odu/lnb/'+(Number(scope.type.substr(2,1))-1),
                                method: "GET"
                            } ).then( function ( result ) {

                                if ( result.data.data ) {
                                    scope.form.default_values = result.data.data;
                                }
                                scope.form.default_values.type = scope.type;
                            } );
                        }
                        scope.form = new NmswebForm( scope.configuration );
                        scope.form.actions = [];
                        scope.configuration.params[scope.type] = scope.form.model;

                    },
                    post: function () {}
                };
            }
        };
    } ] );
} );
