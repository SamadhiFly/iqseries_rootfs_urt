define( [ 'angular', 'module/core', 'module/core/factory/element' ], function ( ng, core ) {
    'use strict';
    core.factory( 'Resources', [ '$injector',
        function ( $injector ) {
            return function () {
                return {
                    create: function ( name, params ) {
                        params = params || {};
                        return $injector.invoke( [ name,
                            function ( res ) {
                                //Minification fails if annotates are not part of params - it would try to load it as a Provider
                                angular.forEach( $injector.annotate( res ), function ( varname, key ) {
                                    if ( !params[ varname ] ) {
                                        params[ varname ] = params[ Object.keys( params )[ key ] ];
                                    }
                                } );
                                return $injector.invoke( res, {}, params );
                            } ] );
                    }
                };
            };
        } ] );
} );