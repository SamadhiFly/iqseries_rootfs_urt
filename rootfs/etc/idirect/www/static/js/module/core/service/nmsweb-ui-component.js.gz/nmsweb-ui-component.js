define( [ 'underscore', 'module/core' ], function ( _, core ) {
    'use strict';

    /**
     * @ngdoc service
     * @name nmsweb.service:nmswebUIComponent
     * @description Helper service for directives which are ui components. Ui component is a complex directive which contains from various directives and takes some time to render.
     * @example
     * nmswebUIComponent.ready($scope); - call when ui component is in 'ready' state, before rendering
     * nmswebUIComponent.rendered($scope, subcomponenets) - call when ui componenet is rendered and it's waiting for subcomponenets (array)
     **/
    core.service( 'nmswebUIComponent', [
        '$q',
        function ( $q ) {
            var EVENTREADY = 'nmswebWidgetReady',
                EVENTRENDERED = 'nmswebWidgetRendered';

            function nmswebUIComponent( $scope ) {
                this.id = Math.random().toString( 36 ).substring( 7 ) + _.uniqueId();
                this.$scope = $scope;
                $scope.$emit( EVENTREADY, this.id );

                return this;
            }

            function emit( $scope, id, deferred ) {
                $scope.widget = $scope.widget || {};
                $scope.widget.id = id;
                $scope.$emit( EVENTRENDERED, $scope.widget );
                deferred.resolve( $scope.widget );
            }

            nmswebUIComponent.prototype.kendoRendered = function ( subComponentsNames ) {
                var deregister,
                    id = this.id,
                    $scope = this.$scope,
                    deferred = $q.defer(),
                    index;

                subComponentsNames = subComponentsNames || [];
                subComponentsNames = _.isArray( subComponentsNames ) ? subComponentsNames : [ subComponentsNames ];
                if ( subComponentsNames.length === 0 ) {
                    emit( $scope, id, deferred );
                } else {
                    deregister = $scope.$on( 'kendoWidgetCreated', function ( event, widget ) {
                        _.find( subComponentsNames, function ( subComponentName, index ) {
                            if ( widget === $scope.$eval( subComponentName ) ) {
                                subComponentsNames.splice( index, 1 );
                                return true;
                            }
                        } );
                        if ( subComponentsNames.length === 0 ) {
                            emit( $scope, id, deferred );
                            deregister();
                        }
                    } );
                }

                return deferred.promise;
            }

            nmswebUIComponent.prototype.rendered = function ( subComponentsNames ) {
                var id = this.id,
                    deregisterEvent,
                    $scope = this.$scope,
                    deregisterWatcher = {},
                    checkupArrays = {
                        watch: [],
                        event: []
                    },
                    deferred = $q.defer();

                //Helper function for checking up if a subComponent is registered by watcher and announced by event emitter
                //It exists to fix race condition, which happens between watch and event emit 
                function checkSubcomponents( type, uiComponent ) {
                    // subComponentsNames is a list of all subcomponents of main uiComponent
                    // subComponents is a list of references created from the scope based on uiComponents' names
                    var index, subComponents = subComponentsNames.map( function ( subComponentName ) {
                        return $scope.$eval( subComponentName );
                    } );

                    //Grab index of subComponent to get its name
                    index = subComponents.indexOf( uiComponent );

                    //If uiComponent is not yet in checkup array add it to the array and deregister related watcher (if it happens for watchers)
                    if ( !~checkupArrays[ type ].indexOf( uiComponent ) ) {
                        checkupArrays[ type ].push( uiComponent );
                        if ( type === 'watch' ) {
                            deregisterWatcher[ subComponentsNames[ index ] ]();
                        }
                    }

                    if ( ~checkupArrays.watch.indexOf( uiComponent ) && ~checkupArrays.event.indexOf( uiComponent ) ) {
                        if ( ~index ) {
                            subComponentsNames.splice( index, 1 );
                        }
                    }

                    if ( subComponentsNames.length === 0 ) {
                        deregisterEvent();
                        emit( $scope, id, deferred );
                    }

                }

                subComponentsNames = subComponentsNames || [];
                subComponentsNames = _.isArray( subComponentsNames ) ? subComponentsNames : [ subComponentsNames ];
                if ( subComponentsNames.length === 0 ) {
                    emit( $scope, id, deferred );
                } else {
                    deregisterEvent = $scope.$on( EVENTRENDERED, function ( event, uiComponent ) {
                        event.stopPropagation();
                        checkSubcomponents( 'event', uiComponent );
                    } );

                    subComponentsNames.forEach( function ( subComponentName ) {
                        deregisterWatcher[ subComponentName ] = $scope.$watch( subComponentName, function ( uiComponent ) {
                            if ( undefined !== uiComponent ) {
                                checkSubcomponents( 'watch', uiComponent );
                            }
                        } );
                    } );
                }

                return deferred.promise;
            };

            return nmswebUIComponent;
    } ] );
} );