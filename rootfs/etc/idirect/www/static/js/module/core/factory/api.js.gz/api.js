define( [ 'module/core' ], function ( core ) {
    "use strict";
    //only kept for backwards compability, the API factory is moved to module/core file to resovle cross-dependency
} );