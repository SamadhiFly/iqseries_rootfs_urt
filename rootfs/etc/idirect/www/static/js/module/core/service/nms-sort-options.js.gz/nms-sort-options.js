define( [ 'module/core' ], function ( core ) {
    'use strict';
    core.service( 'NMSSortOptions', [
        function () {
            var arrayMapping = {
                weekdays: [ "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" ],
                emodcodtype: [ "QPSK-1/4", "QPSK-1/3", "QPSK-2/5", "QPSK-1/2", "QPSK-3/5", "QPSK-2/3", "QPSK-3/4", "QPSK-4/5", "QPSK-5/6", "QPSK-8/9",
                        "QPSK-9/10", "8PSK-3/5", "8PSK-2/3", "8PSK-3/4", "8PSK-5/6", "8PSK-8/9", "8PSK-9/10", "16APSK-2/3", "16APSK-3/4", "16APSK-4/5",
                        "16APSK-5/6", "16APSK-8/9", "16APSK-9/10", "32APSK-3/4", "32APSK-4/5", "32APSK-5/6", "32APSK-8/9", "32APSK-9/10" ],
                ecodingratetype: [ "1/3", "1/2", "2/3", "3/4", "4/5", "5/6", "6/7", "7/8" ],
                eerrorcorrectiontype: [ "OFF", "Reed", "LDPC  BCH", "TCM-2/3", "2D16S-100bytes  (1/3)",
                        "2D16S-100bytes  (1/2)", "2D16S-100bytes  (2/3)", "2D16S-100bytes  (3/4)", "2D16S-100bytes  (4/5)",
                        "2D16S-100bytes  (5/6)", "2D16S-100bytes  (6/7)", "2D16S-100bytes  (7/8)", "2D16S-170bytes  (1/3)",
                        "2D16S-170bytes  (1/2)", "2D16S-170bytes  (2/3)", "2D16S-170bytes  (3/4)", "2D16S-170bytes  (4/5)",
                        "2D16S-170bytes  (5/6)", "2D16S-170bytes  (6/7)", "2D16S-170bytes  (7/8)", "2D16S-438bytes  (1/3)",
                        "2D16S-438bytes  (1/2)", "2D16S-438bytes  (2/3)", "2D16S-438bytes  (3/4)", "2D16S-438bytes  (4/5)",
                        "2D16S-438bytes  (5/6)", "2D16S-438bytes  (6/7)", "2D16S-438bytes  (7/8)", "TPC-441/1024 (.431)",
                        "TPC-2028/4096 (.49)", "TPC-546/1024 (.533)", "TPC-676/1024 (.66)", "TPC-3249/4096 (.79)", "TPC-14400/16384 (.879)",
                        "Viterbi Rate 1/3", "Viterbi Rate 1/2", "Viterbi Rate 3/4", "Viterbi-3/" ]
            };

            function sortArray( data, order, keyName ) {
                return data.sort( function ( a, b ) {
                    return order.indexOf( a[ keyName ] ) - order.indexOf( b[ keyName ] );
                } );
            }

            function sortNatural( data, keyName ) {
                return data.sort( function ( a, b ) {
                    function chunkify( t ) {
                        var tz = new Array();
                        var x = 0,
                            y = -1,
                            n = 0,
                            i, j;

                        while ( i = ( j = t.charAt( x++ ) ).charCodeAt( 0 ) ) {
                            var m = ( i == 46 || ( i >= 48 && i <= 57 ) );
                            if ( m !== n ) {
                                tz[ ++y ] = "";
                                n = m;
                            }
                            tz[ y ] += j;
                        }
                        return tz;
                    }

                    var aa = chunkify( a[ keyName ].toLowerCase() );
                    var bb = chunkify( b[ keyName ].toLowerCase() );

                    for ( var x = 0; aa[ x ] && bb[ x ]; x++ ) {
                        if ( aa[ x ] !== bb[ x ] ) {
                            var c = Number( aa[ x ] ),
                                d = Number( bb[ x ] );
                            if ( c == aa[ x ] && d == bb[ x ] ) {
                                return c - d;
                            } else return ( aa[ x ] > bb[ x ] ) ? 1 : -1;
                        }
                    }
                    return aa.length - bb.length;
                } );
            }

            return {
                doSorting: function ( data, enum_type ) {
                    var keyName;
                    if ( data.length < 2 ) {
                        return data;
                    }

                    if ( 'display' in data[ 0 ] ) { // in selects
                        keyName = 'display';
                    } else if ( 'name' in data[ 0 ] ) { // in dropdowns
                        keyName = 'name';
                    } else if ( 'value' in data[ 0 ] ) { // in compositions
                        keyName = 'value';
                    } else {
                        // this should never happen
                        console.warn( 'no "display", "name" or "value" keys found while sorting options', data );
                        return data;
                    }

                    if ( enum_type in arrayMapping ) {
                        return sortArray( data, arrayMapping[ enum_type ], keyName );
                    } else {
                        return sortNatural( data, keyName );
                    }
                }
            };
    } ] );
} );