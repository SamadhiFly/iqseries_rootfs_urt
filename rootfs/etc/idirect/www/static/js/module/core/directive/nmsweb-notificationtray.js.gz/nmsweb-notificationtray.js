define( [ 'underscore', 'angular', 'module/core', 'text!templates/nmsweb/module/core/directive/nmsweb-notificationtray.tpl', 'text!templates/nmsweb/module/core/directive/nmsweb-notificationtray-success.tpl', 'text!templates/nmsweb/module/core/directive/nmsweb-notificationtray-error.tpl', 'text!templates/nmsweb/module/core/directive/nmsweb-notificationtray-warning.tpl', 'module/core/service/nmsweb-notification', 'module/core/directive/tab-strip' ],

    function ( _, ng, core, template, messagesTemplateSuccess, messagesTemplateError, messagesTemplateWarning ) {
        'use strict';
        core.directive( 'nmswebNotificationTray', [ "NMSWebNotification", "$compile", function ( NMSWebNotification, $compile ) {
            return {
                restrict: 'E',
                replace: true,
                scope: {
                    widget: '=?'
                },
                template: template,
                compile: function () {
                    // This goes through $scope.messages and creates the error, success and warning message structure
                    var createMsgStructure = function ( $scope ) {
                        $scope.successMsgs = [];
                        $scope.errorMsgs = [];
                        $scope.warningMsgs = [];

                        if ( $scope.messages.length > 0 ) {
                            $scope.show = true;
                            ng.forEach( $scope.messages, function ( value ) {
                                if ( value.type === 'success' ) {
                                    $scope.successMsgs.push( value.message );
                                } else if ( value.type === 'error' ) {
                                    if ( _.isArray( value.message ) ) {
                                        _.each( value.message, function ( ele ) {
                                            $scope.errorMsgs.push( ele );
                                        } );
                                    } else {
                                        $scope.errorMsgs.push( value.message );
                                    }
                                } else {
                                    $scope.warningMsgs.push( value.message );
                                }
                            } );
                        } else {
                            $scope.show = false;
                        }
                    };
                    return {
                        pre: function preLink( $scope, $element ) {

                            var successText, errorText, warningText;

                            $scope.messages = NMSWebNotification.getMessages();
                            $scope.opts = {};
                            $scope.opts.collapsible = true;
                            $scope.show = true;

                            $scope.$watch( 'messages', function ( newVal, oldVal ) {
                                if ( newVal !== oldVal ) {
                                    createMsgStructure( $scope, $element );
                                    if ( $scope.tabstrip ) {
                                        //Check if we have errors, if yes, then we select error tab
                                        //otherwise we select the success tab
                                        if ( $scope.errorMsgs.length > 0 ) {
                                            $scope.tabstrip.select( 1 );
                                        } else if ( $scope.successMsgs.length > 0 ) {
                                            $scope.tabstrip.select( 0 );
                                        } else {
                                            $scope.tabstrip.select( 2 );
                                        }
                                        // Text based on length of each type of messages.
                                        successText = ( $scope.successMsgs.length === 1 ) ? 'Success' : 'Successes';
                                        errorText = ( $scope.errorMsgs.length === 1 ) ? 'Error' : 'Errors';
                                        warningText = ( $scope.warningMsgs.length === 1 ) ? 'Warning' : 'Warnings';

                                        //Changing the title of the tabs dynamically based on length of each type of message
                                        $scope.tabstrip.tabGroup.find( "li:eq(0) .k-link" ).html( '<img class="notification-tray-icon" src="/static/images/notification-tray/successIcon.png"/> <b>' + $scope.successMsgs.length + '</b> ' + successText );
                                        $scope.tabstrip.tabGroup.find( "li:eq(1) .k-link" ).html( '<img class="notification-tray-icon" src="/static/images/notification-tray/errorIcon.png" /> <b>' + $scope.errorMsgs.length + '</b> ' + errorText );
                                        $scope.tabstrip.tabGroup.find( "li:eq(2) .k-link" ).html( '<img  class="notification-tray-icon" src="/static/images/notification-tray/warningIcon.png" /> <b>' + $scope.warningMsgs.length + '</b> ' + warningText );
                                    }
                                }
                            }, true );

                            //call the function for the first time, when directive is being compiled
                            createMsgStructure( $scope );

                            // Text based on length of each type of messages.
                            successText = ( $scope.successMsgs.length === 1 ) ? 'Success' : 'Successes';
                            errorText = ( $scope.errorMsgs.length === 1 ) ? 'Error' : 'Errors';
                            warningText = ( $scope.warningMsgs.length === 1 ) ? 'Warning' : 'Warnings';

                            //setting up Success tab and its content structure
                            var successObject = {};
                            successObject.text = '<img class="notification-tray-icon" src="/static/images/notification-tray/successIcon.png"/> <b>' + $scope.successMsgs.length + '</b> ' + successText;
                            successObject.encoded = false;
                            successObject.content = messagesTemplateSuccess;

                            //setting up Error tab and its content structur
                            var errorObject = {};
                            errorObject.text = '<img class="notification-tray-icon" src="/static/images/notification-tray/errorIcon.png" /> <b>' + $scope.errorMsgs.length + '</b> ' + errorText;
                            errorObject.encoded = false;
                            errorObject.content = messagesTemplateError;

                            //setting up Warning tab and its content structur
                            var warningObject = {};
                            warningObject.text = '<img  class="notification-tray-icon" src="/static/images/notification-tray/warningIcon.png" /> <b>' + $scope.warningMsgs.length + '</b> ' + warningText;
                            warningObject.encoded = false;
                            warningObject.content = messagesTemplateWarning;

                            var dom_element_success = $compile( messagesTemplateSuccess )( $scope );
                            var dom_element_error = $compile( messagesTemplateError )( $scope );
                            var dom_element_warning = $compile( messagesTemplateWarning )( $scope );

                            // Right now using a setTimeout hack, as $scope.tabstrip is not 
                            // available without this
                            setTimeout( function () {
                                // Find tabstrip element manually
                                $scope.tabstrip = $element.find( '[kendo-tab-strip]' ).scope().widget;
                                if ( $scope.tabstrip ) {
                                    var tabstrip_success = $scope.tabstrip.append( successObject );
                                    var tabstrip_error = $scope.tabstrip.append( errorObject );
                                    var tabstrip_warning = $scope.tabstrip.append( warningObject );
                                    $( tabstrip_success.contentElement( 0 ) ).html( dom_element_success );
                                    $( tabstrip_error.contentElement( 1 ) ).html( dom_element_error );
                                    $( tabstrip_warning.contentElement( 2 ) ).html( dom_element_warning );

                                    //Add CSS to Success tab
                                    $( $scope.tabstrip.contentHolder( 0 ) ).css( {
                                        backgroundColor: "#def2dd"
                                    } );
                                    $( $( $( $scope.tabstrip.contentHolder( 0 ) )[ 0 ].parentNode ).find( "ul li" )[ 0 ] ).css( {
                                        backgroundColor: "#def2dd"
                                    } );

                                    //Add CSS to Error tab's
                                    $( $scope.tabstrip.contentHolder( 1 ) ).css( {
                                        backgroundColor: "#ffebed"
                                    } );
                                    $( $( $( $scope.tabstrip.contentHolder( 1 ) )[ 0 ].parentNode ).find( "ul li" )[ 1 ] ).css( {
                                        backgroundColor: "#ffebed"
                                    } );

                                    //Add CSS to Warning tab's
                                    $( $scope.tabstrip.contentHolder( 2 ) ).css( {
                                        backgroundColor: "#ffffcb"
                                    } );
                                    $( $( $( $scope.tabstrip.contentHolder( 2 ) )[ 0 ].parentNode ).find( "ul li" )[ 2 ] ).css( {
                                        backgroundColor: "#ffffcb"
                                    } );

                                    //Check if we have errors, if yes, then we select error tab
                                    //otherwise we select the success tab
                                    if ( $scope.errorMsgs.length > 0 ) {
                                        $scope.tabstrip.select( 1 );
                                    } else if ( $scope.successMsgs.length > 0 ) {
                                        $scope.tabstrip.select( 0 );
                                    } else {
                                        $scope.tabstrip.select( 2 );
                                    }
                                }
                            }, 500 );

                            // function to close the notification tray
                            $scope.closeNotificationTray = function () {
                                $scope.show = false;
                                NMSWebNotification.add( {}, "", true );
                            };
                        }
                    };
                }
            };
    } ] );
    } );
