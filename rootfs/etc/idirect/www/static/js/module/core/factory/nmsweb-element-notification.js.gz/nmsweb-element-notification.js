define( [
    'jquery',
    'angular',
    'module/core',
    'text!templates/nmsweb/module/core/factory/nmsweb-element-notification/grid.tpl',
    'module/core/service/nmsweb-notification'
 ], function ( $, ng, core, gridTemplate ) {
    'use strict';
    core.factory( 'NmswebElementNotification', [ '$rootScope', '$compile', 'NMSWebNotification',
        function ( $rootScope, $compile, NMSWebNotification ) {
            var elementDefault = {
                chart: {
                    getChart: function () {
                        return this.component.chart;
                    },
                    startLoading: function ( message ) {
                        message = message || 'Waiting for data...';
                        this.getChart().showLoading( message );
                        this.displayChartLegend();
                        this.alignChartMessage();
                    },
                    removeNotification: function () {
                        this.getChart().hideLoading();
                        this.displayChartLegend( true );
                    },
                    clear: function () {
                        this.removeNotification();
                    },
                    displayChartLegend: function ( isShow ) {
                        var visibility = isShow ? 'visible' : 'hidden',
                            opacity = isShow ? 1 : 0;
                        this.element
                            .find( '.highcharts-legend, .highcharts-axis' ).css( 'visibility', isShow ? 'visible' : 'hidden' )
                            .find( 'rect, text' ).css( {
                                'visibility': visibility,
                                'opacity': opacity
                            } );
                        this.element
                            .find( '.highcharts-axis path' ).attr( 'stroke-width', opacity );
                    },
                    alignChartMessage: function () {
                        this.element.find( '.highcharts-loading span' ).center( this.element.find( '.highcharts-loading span' ).parent() );
                    },
                    noData: function ( message ) {
                        message = message || 'No data available';
                        this.displayChartLegend();
                        this.getChart().showLoading( message );
                    },
                    noDataCurrently: function ( message ) {
                        message = message || 'No data currently available';
                        this.displayChartLegend();
                        this.getChart().showLoading( message );
                    }
                }
            };

            function NmswebElementNotification( options ) {
                var that = this;
                var defaultErrorNotificationOptions = {
                    isFadeable: true,
                    type: 'error'
                };
                var $scope = $rootScope.$new();
                var updateMessage = function ( message ) {
                    if ( this.isApplyNeeded ) {
                        $scope.$apply( function () {
                            $scope.message = message;
                        } );
                    } else {
                        $scope.message = message;
                    }
                };
                $.extend( this, options );
                if ( this.type === 'grid' ) {
                    this.notificationMessage = $compile( gridTemplate )( $scope );
                }
                this.positionNotification = function () {
                    var $notification = this.element.find( '.nmsweb-element-' + this.type + '-notification' );
                    if ( this.element.find( '.k-grid-content' ).find( '.k-scrollbar-vertical' ).length > 0 ) {
                        $notification.addClass( 'parent-has-k-scrollbar-vertical' );
                    }
                    if ( this.element.find( '.k-pager-wrap' ).length > 0 && this.element.find( '.k-pager-wrap' ).css( 'display' ) === 'block' ) {
                        $notification.addClass( 'parent-has-k-pager-wrap' );
                    } else {
                        $notification.removeClass( 'parent-has-k-pager-wrap' );
                    }
                };
                this.element.find( '.k-grid-toolbar' ).on( 'click', 'span, button', function () {
                    that.positionNotification();
                } );
                this.startLoading = function ( message ) {
                    message = message || 'Waiting for data';
                    updateMessage.call( this, message );
                    this.element.find( '.nmsweb-element-' + this.type + '-notification' ).remove();
                    this.element.append( this.notificationMessage );
                    this.positionNotification();
                };
                this.waitingForUserInput = function ( message ) {
                    message = message || 'Waiting for user input';
                    updateMessage.call( this, message );
                    this.element.find( '.nmsweb-element-' + this.type + '-notification' ).remove();
                    this.element.append( this.notificationMessage );
                    this.positionNotification();
                };
                this.removeNotification = this.clear = function () {
                    if( this.element.find( '.nmsweb-element-' + this.type + '-notification' ).length > 0 ) {
                        this.element.find( '.nmsweb-element-' + this.type + '-notification' ).remove();
                    } else {
                        this.element.find( '.n-progress-notifications-container' ).remove();
                    }
                };
                this.noData = function ( message ) {
                    message = message || 'No data available';
                    updateMessage.call( this, message );
                    this.element.find( '.nmsweb-element-' + this.type + '-notification' ).remove();
                    this.element.append( this.notificationMessage );
                    this.positionNotification();
                };
                this.noDataCurrently = function ( message ) {
                    message = message || 'No data currently available';
                    updateMessage.call( this, message );
                    this.element.find( '.nmsweb-element-' + this.type + '-notification' ).remove();
                    this.element.append( this.notificationMessage );
                    this.positionNotification();
                };
                this.error = function ( opts ) {
                    if ( typeof opts === 'string' || opts === null ) {
                        opts = {
                            message: opts === null ? '' : opts,
                            title: 'Error'
                        };
                    }
                    // opts.selector = this.element;
                    defaultErrorNotificationOptions.type = 'error';
                    $.extend( true, defaultErrorNotificationOptions, opts );
                    NMSWebNotification.add( defaultErrorNotificationOptions, this.element );
                };
                if ( elementDefault[ this.type ] ) {
                    $.extend( this, elementDefault[ this.type ] );
                }
            }
            return NmswebElementNotification;
    } ] );
} );
