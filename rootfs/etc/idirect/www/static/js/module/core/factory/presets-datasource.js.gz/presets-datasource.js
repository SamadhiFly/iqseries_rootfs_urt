define( [ 'angular', 'kendo', 'module/core',
    'module/core/service/nmsweb-notification',
    'module/core/service/nmsutils',
    'module/core/factory/presets',
     ],
    function ( ng, kendo, core ) {
        'use strict';
        /**
         * @ngdoc factory
         * @name core.factory:PresetsDatasource
         * @description Provided data source that will be used by Presets components.
         */
        core.factory( 'PresetsDatasource', [ 'NMSUtils', 'NMSWebNotification', 'Presets',
        function ( NMSUtils, NMSWebNotification, Presets ) {
                return {
                    /**
                 * @ngdoc method
                 * @name init
                 * @methodOf core.factory:PresetsDatasource
                 * @description Returns instance of datasource with expanded possibilities
                 * @param {Object} options - option parameters.


                    var dataSource = PresetsDatasource.init( opts );

                    After calling dataSource.read() request will be triggered toward Presets Web Service
                 */
                    init: function ( options ) {
                        var dataSource,
                            presets = new Presets(),
                            defaults = {
                                schema: {
                                    model: {
                                        id: "id",
                                        fields: {
                                            url: {
                                                type: "string"
                                            },
                                            name: {
                                                type: "string"
                                            },
                                            quicklink: {
                                                type: "string"
                                            }
                                        }
                                    }
                                },
                                //autoSync: true,
                                transport: {
                                    read: function ( params ) {
                                        var getParams = {
                                            limit: 0
                                        };
                                        if ( options.filter !== undefined ) {
                                            if ( options.filter.quicklinks ) {
                                                getParams.quicklinks = 1;
                                            }
                                        }
                                        presets.get( getParams, function ( response ) {
                                            params.success( response.data );
                                        }, function ( response ) {
                                            params.error( [] );
                                            NMSWebNotification.add( {
                                                type: 'majorwarning',
                                                isFadeable: true,
                                                title: 'An error occurred while getting data for presets',
                                                message: NMSUtils.parseBackendErrors( response.errors )
                                            }, 'body' );
                                        } );
                                    },
                                    create: function ( params ) {
                                        presets.create( params, function ( response ) {
                                            //read response and current dataSource
                                            var resp = response.data;
                                            var tmpArr = dataSource.data();
                                            tmpArr[ tmpArr.length - 1 ].id = resp.id;
                                            //Kendo will convert resp to new DS object, all comented below can be removed.
                                            // dataSource.data( [resp] );
                                            // resp = dataSource.data();
                                            //update old DS with new created value
                                            // tmpArr[tmpArr.length] = resp[0];
                                            // dataSource.data( tmpArr );

                                            dataSource._initalServerData = response.data;
                                            dataSource._requestInProgress = false;
                                            params.success();
                                            NMSWebNotification.add( {
                                                type: 'success',
                                                isFadeable: true,
                                                title: 'Query Saved',
                                                message: 'To access your saved queries, you can choose the Load Query option on any of the Configurator screens, or from the "Load Query" menu in the Mega-Menu.'
                                            }, 'body' );
                                        }, function ( response ) {
                                            NMSWebNotification.add( {
                                                type: 'majorwarning',
                                                isFadeable: true,
                                                title: 'An error occurred while creating presets',
                                                message: NMSUtils.parseBackendErrors( response.errors )
                                            }, 'body' );
                                        } );
                                    },
                                    update: function ( params ) {
                                        presets.update( params.data, function () {
                                            params.success();
                                            NMSWebNotification.add( {
                                                type: 'success',
                                                isFadeable: true,
                                                title: 'Preset Updated',
                                                message: 'Successfully updated preset "' + params.data.name + '"'
                                            }, 'body' );
                                        }, function ( response ) {
                                            NMSWebNotification.add( {
                                                type: 'majorwarning',
                                                isFadeable: true,
                                                title: 'An error occurred while updating presets',
                                                message: NMSUtils.parseBackendErrors( response.errors )
                                            }, 'body' );
                                        } );
                                    },
                                    destroy: function ( params ) {
                                        presets.delete( {
                                            "id": params.data.id
                                        }, function () {
                                            params.success();
                                            NMSWebNotification.add( {
                                                type: 'success',
                                                isFadeable: true,
                                                title: 'Preset Deleted',
                                                message: 'Successfully deleted preset "' + params.data.name + '"'
                                            }, 'body' );
                                        }, function ( response ) {
                                            NMSWebNotification.add( {
                                                type: 'majorwarning',
                                                isFadeable: true,
                                                title: 'An error occurred while deleting preset',
                                                message: NMSUtils.parseBackendErrors( response.errors )
                                            }, 'body' );
                                        } );
                                    }
                                }
                            };
                        $.extend( true, defaults, options );

                        dataSource = new kendo.data.DataSource( defaults );

                        return dataSource;
                    }
                };
 } ] );
    } );