define( [ 'angular',
    'module/core',
    'module/core/service/nmsweb-validation',
    'module/core/service/nmsutils',
    'module/core/service/nms-sort-options'
], function ( ng, core ) {
    'use strict';
    core.service( 'MetadataFormTransformer', [ 'NMSWebValidation', 'NMSUtils', 'NMSSortOptions', '$filter',
        function ( NMSWebValidation, NMSUtils, NMSSortOptions, $filter ) {
            var typesMappingOverride = {
                    'double precision': 'float',
                    'boolean': 'checkbox',
                    'inetv4': 'ipv4',
                    'inetv6': 'ipv6',
                    'inet': 'ip',
                    'arrayint': 'listbox',
                    'arraytext': 'listbox'
                },
                typesDirectivesMapping = {
                    'checkbox': 'nmsweb-input',
                    'float': 'nmsweb-numeric-text-box',
                    'integer': 'nmsweb-numeric-text-box',
                    'password': 'nmsweb-input',
                    'email': 'nmsweb-input',
                    'url': 'nmsweb-input',
                    'text': 'nmsweb-input',
                    'ipv4': 'nmsweb-input',
                    'ipv6': 'nmsweb-input',
                    'ip': 'nmsweb-input',
                    'dropdown': 'nmsweb-drop-down-list',
                    'time': 'nmsweb-time-picker',
                    'timestamp': 'nmsweb-date-time-picker',
                    'listbox': 'nmsweb-multiselect-form',
                    'blob': 'nmsweb-fileupload',
                    'bit': 'nmsweb-bitmask',
                    'hstore': 'nmsweb-keyvalue',
                    'textarea': 'nmsweb-textarea'
                },
                gridTypesMapping = {
                    'integer': 'number',
                    'double precision': 'number',
                    'timestamp': 'date',
                    'time': 'date',
                    'inetv4': 'string',
                    'inetv6': 'string',
                    'inet': 'string',
                    'text': 'string'
                },
                brokenFieldsMapping = {
                    'obj_parentid': 'obj_parent_id'
                },
                defaultFloatStep = '0.0000001',
                defaultIntegerStep = 1,
                restrictionsToColumnName = function ( fieldMetadata ) {
                    var columnAdditionalInfo = '';
                    if ( fieldMetadata.unit !== '' ) {
                        columnAdditionalInfo += '(' + fieldMetadata.unit + ')';
                    }
                    return columnAdditionalInfo;
                };

            return {
                generateForm: function ( metadata, errorMessages, model, directiveOptions ) {
                    var attrMetadataArray = metadata.attr_metadata_array,
                        compMetadataArray = metadata.comp_attr_metadata_array,
                        directives = {},
                        tmpDirectives = {},
                        layout = [],
                        nmswebOptions,
                        dependencies = {}, // dependencies that affect elements on same form
                        crossFormDependencies = {}, // dependencies which affect another form
                        obj_name = metadata.obj_name;
                    ng.forEach( attrMetadataArray, function ( value ) {
                        nmswebOptions = {};
                        if ( value.dependencies !== '' ) {
                            var deps = value.dependencies.split( "," );
                            if ( dependencies[ value.attr_name ] === undefined ) {
                                dependencies[ value.attr_name ] = {
                                    affects: [],
                                    affectedBy: []
                                };
                            }
                            var affectedBy = [],
                                affectedByCross = [];
                            ng.forEach( deps, function ( dep ) {
                                if ( dep.indexOf( '.' ) !== -1 ) {
                                    // it's dependency on another form
                                    if ( crossFormDependencies[ value.attr_name ] === undefined ) {
                                        crossFormDependencies[ value.attr_name ] = {
                                            affects: [],
                                            affectedBy: []
                                        };
                                    }
                                    affectedByCross.push( dep );
                                } else {
                                    affectedBy.push( dep );
                                }
                            } );
                            dependencies[ value.attr_name ].affectedBy = affectedBy;
                            if ( crossFormDependencies[ value.attr_name ] !== undefined ) {
                                crossFormDependencies[ value.attr_name ].affectedBy = affectedByCross;
                            }
                            ng.forEach( affectedBy, function ( depvalue ) {
                                if ( dependencies[ depvalue ] === undefined ) {
                                    dependencies[ depvalue ] = {
                                        affects: [],
                                        affectedBy: []
                                    };
                                }
                                dependencies[ depvalue ].affects.push( value.attr_name );
                            } );
                            ng.forEach( affectedByCross, function ( depvalue ) {
                                var convertedDepvalue = depvalue.toLowerCase().replace( '.', '-' ).replace( '/_/g', '-' );
                                if ( crossFormDependencies[ convertedDepvalue ] === undefined ) {
                                    crossFormDependencies[ convertedDepvalue ] = {
                                        affects: [],
                                        affectedBy: []
                                    };
                                }
                                crossFormDependencies[ convertedDepvalue ].affects.push( value.attr_name );
                            } );
                        }
                        var enum_type;
                        if ( value.attr_type === 'arrayint' || value.attr_type === 'arraytext' ) {
                            var arrayDefaultValue = [];
                            if ( value.default_value !== '' ) {
                                var trimmedDefaultValue = value.default_value.substring( 1, value.default_value.length - 1 );
                                arrayDefaultValue = trimmedDefaultValue.split( ',' );
                            }

                            nmswebOptions = {
                                dataSource: {
                                    data:[]
                                },
                                options: [],
                                value: arrayDefaultValue,
                                optionList: value.option_list
                            };

                            ng.forEach(value.option_list, function(value, key) {
                                if ( value !== '' && key !== '' ) {
                                    nmswebOptions.dataSource.data.push({
                                        value: key,
                                        display: value
                                    });
                                }
                            });
                            enum_type = ( 'enum_type' in value ) ? value.enum_type : 'default';
                            nmswebOptions.dataSource.data = NMSSortOptions.doSorting( nmswebOptions.dataSource.data, enum_type );

                        } else if ( Object.keys( value.option_list ).length > 0 ) {
                            var dropdownData = [];
                            ng.forEach( value.option_list, function ( value, key ) {
                                if ( value !== '' && key !== '' ) {
                                    dropdownData.push( {
                                        name: value,
                                        id: key
                                    } );
                                }
                            } );
                            enum_type = ( 'enum_type' in value ) ? value.enum_type : 'default';
                            dropdownData = NMSSortOptions.doSorting( dropdownData, enum_type );

                            nmswebOptions = {
                                type: 'dropdown',
                                dataSource: {
                                    data: dropdownData
                                },
                                value: value.default_value,
                                valuePrimitive: true,
                                optionLabel: ( value.option_label !== undefined ) ? value.option_label : 'Select ...',
                                dataTextField: 'name',
                                dataValueField: 'id',
                                label: value.attr_display_name,
                                optionList: value.option_list
                            };
                        } else if ( value.attr_type === 'bit' ) {
                            nmswebOptions = {
                                minlength: value.min_length,
                                maxlength: ( value.max_length !== 0 ) ? value.max_length : undefined, // TODO - see with Backend guys why is maxlength set to 0 by default
                                checkboxLabel: value.attr_display_name,
                                defaultValue: value.default_value
                            };
                        } else {
                            // format can be password, override the type with it
                            value.attr_type = ( value.format !== undefined && value.format !== '' ) ? value.format : value.attr_type;
                            var defaultValue = value.default_value,
                                splittedTime;
                            if ( value.attr_type === 'timestamp' ) {
                                if ( value.default_value === '' ) {
                                    defaultValue = '';
                                } else { //2013-12-09 21:59:32
                                    var splittedDateTime = value.default_value.split( ' ' ),
                                        splittedDate = splittedDateTime[ 0 ].split( '-' );
                                    splittedTime = splittedDateTime[ 1 ].split( ':' );
                                    defaultValue = new Date( splittedDate[ 0 ], splittedDate[ 1 ], splittedDate[ 2 ], splittedTime[ 0 ], splittedTime[ 1 ], splittedTime[ 2 ] );
                                }
                                // for date time only value is 'valuable' from metadata
                                nmswebOptions = {
                                    value: defaultValue
                                };
                            } else if ( value.attr_type === 'time' ) {
                                if ( value.default_value === '' ) {
                                    defaultValue = '';
                                } else {
                                    splittedTime = value.default_value.split( ':' );
                                    defaultValue = new Date();
                                    defaultValue.setHours( splittedTime[ 0 ] );
                                    defaultValue.setMinutes( splittedTime[ 1 ] );
                                    defaultValue.setSeconds( splittedTime[ 2 ] );
                                }
                                // for time only value is 'valuable' from metadata
                                nmswebOptions = {
                                    value: defaultValue
                                };
                            } else if ( value.attr_type === 'boolean' ) {
                                nmswebOptions = {
                                    value: value.default_value === 'true' ? true : false
                                };
                            } else if ( value.attr_type === 'double precision' ) {
                                value.step = value.step || defaultFloatStep;
                                value.decimals = String( value.step ).split( '.' )[ 1 ];

                                nmswebOptions = {
                                    decimals: value.decimals.length,
                                    format: '#.' + String( value.decimals ).replace( /[0-9]/g, '#' ), // to match step and format
                                    step: value.step,
                                    min: ( value.range_start !== '' ) ? value.range_start : undefined,
                                    max: ( value.range_end !== '' ) ? value.range_end : undefined,
                                    value: defaultValue
                                };
                            } else {
                                nmswebOptions = {
                                    minlength: value.min_length,
                                    maxlength: ( value.max_length !== 0 ) ? value.max_length : undefined, // TODO - see with Backend guys why is maxlength set to 0 by default
                                    min: value.range_start,
                                    max: value.range_end,
                                    value: defaultValue,
                                };
                            }
                        }
                        if ( ~Object.keys( brokenFieldsMapping ).indexOf( value.attr_name ) ) {
                            value.attr_name = brokenFieldsMapping[ value.attr_name ];
                        }
                        // common properties for all directives
                        if ( nmswebOptions.type === undefined ) {
                            nmswebOptions.type = ( typesMappingOverride[ value.attr_type ] !== undefined ) ? typesMappingOverride[ value.attr_type ] : value.attr_type;
                        }
                        nmswebOptions.required = ( value.attr_required !== undefined && value.attr_required === 1 ) ? true : false;
                        nmswebOptions.label = value.attr_display_name;
                        nmswebOptions.readonly = ( value.read_only !== undefined && value.read_only === 1 ) ? true : false;
                        nmswebOptions.enable = !nmswebOptions.readonly;
                        nmswebOptions.errorMessages = errorMessages;
                        nmswebOptions.hideOnGUI = value.hide_on_GUI;
                        nmswebOptions.is_unique = value.is_unique;
                        nmswebOptions.range_start = value.range_start;
                        nmswebOptions.range_end = value.range_end;
                        nmswebOptions.unit = value.unit;
                        nmswebOptions.step = value.step || "";
                        nmswebOptions.active_value = value.active_value;
                        nmswebOptions.fieldDetails = value.field_details;
                        nmswebOptions.inlineInfo = value.inline_info;
                        nmswebOptions.tooltips = value.tooltips || [];
                        if ( !( directiveOptions && directiveOptions.viewMode && nmswebOptions.type === "nmsweb-fileupload" ) ) {
                            var localDirectiveOptions = ng.extend( {}, directiveOptions );
                            if ( value.is_unique === true && directiveOptions.multiEditMode === true ) {
                                localDirectiveOptions.viewMode = true;
                            }
                            if(nmswebOptions.type === 'custom') {
                              directives[ value.attr_name ] = {
                                  directive: value.widget,
                                  parameters: value.options,
                                  requirePath: value.require_path
                              };
                            } else {
                              directives[ value.attr_name ] = {
                                  model: model,
                                  directive: ( typesDirectivesMapping[ nmswebOptions.type ] !== undefined ) ? typesDirectivesMapping[ nmswebOptions.type ] : "nmsweb-input",
                                  options: nmswebOptions,
                                  name: value.attr_name,
                                  additionalOptions: ng.copy( localDirectiveOptions ), // we need ng.copy, otherwise we can create .watch on additionalOptions (it would be called for each form element)
                              };
                            }
                            layout.push( value.attr_name );
                        }
                    } );
                    // let's generate mini tables based on composite metadata
                    ng.forEach( compMetadataArray, function ( value ) {
                        var compositionMetadata = value.attr_metadata_array,
                            compositionOptions = {},
                            validationFields = {},
                            fields = {
                                rowId: {
                                    editable: false,
                                    nullable: true
                                }
                            },
                            columns = [],
                            compositionData = [],
                            compositionDependencies = {};
                        if ( value.default_value !== '' ) {
                            // populate compositionData with encoded data from value.default_value based on composition metadata
                            NMSUtils.addEncodedCompositions( value.default_value, compositionMetadata, compositionData );
                        }
                        ng.forEach( compositionMetadata, function ( attrMetadata ) {
                            var column = {},
                                columnHeaderUnits = '';
                            if ( attrMetadata.dependencies !== '' ) {
                                var deps = attrMetadata.dependencies.split( "," );
                                if ( compositionDependencies[ attrMetadata.attr_name ] === undefined ) {
                                    compositionDependencies[ attrMetadata.attr_name ] = {
                                        affects: [],
                                        affectedBy: []
                                    };
                                }
                                compositionDependencies[ attrMetadata.attr_name ].affectedBy = deps;
                                ng.forEach( deps, function ( depvalue ) {
                                    if ( compositionDependencies[ depvalue ] === undefined ) {
                                        compositionDependencies[ depvalue ] = {
                                            affects: [],
                                            affectedBy: []
                                        };
                                    }
                                    compositionDependencies[ depvalue ].affects.push( attrMetadata.attr_name );
                                } );
                            }
                            // if(attrMetadata.dependencies !== '') {
                            // 	var deps = attrMetadata.dependencies.split(",");
                            // 	ng.forEach(deps, function(depvalue) {
                            // 		dependencies[depvalue] = attrMetadata.dependencies;
                            // 	});
                            // }
                            fields[ attrMetadata.attr_name ] = {
                                type: ( gridTypesMapping[ attrMetadata.attr_type ] !== undefined ) ? gridTypesMapping[ attrMetadata.attr_type ] : attrMetadata.attr_type,
                                editable: attrMetadata.read_only === 0 ? true : false,
                                validation: {
                                    required: attrMetadata.attr_required === 1 ? true : false,
                                    min: attrMetadata.range_start !== '' ? attrMetadata.range_start : undefined,
                                    max: attrMetadata.range_end !== '' ? attrMetadata.range_end : undefined,
                                    maxlength: ( attrMetadata.max_length !== '' && attrMetadata.max_length !== 0 ) ? attrMetadata.max_length : undefined,
                                    minlength: ( attrMetadata.min_length !== '' ) ? attrMetadata.min_length : undefined
                                }
                            };
                            // HTML5 doesn't have minlength built in validation
                            if ( attrMetadata.min_length !== 0 && attrMetadata.min_length !== '' ) {
                                fields[ attrMetadata.attr_name ].validation.pattern = '^.{' + attrMetadata.min_length + ',}$';
                                // if field has min length it means it's required
                                fields[ attrMetadata.attr_name ].validation.required = true;
                            }
                            columnHeaderUnits = restrictionsToColumnName( attrMetadata );
                            if ( columnHeaderUnits !== '' ) {
                                columnHeaderUnits = ' ' + columnHeaderUnits;
                            }
                            column = {
                                field: attrMetadata.attr_name,
                                title: attrMetadata.attr_display_name + columnHeaderUnits,
                                type: gridTypesMapping[ attrMetadata.attr_type ] !== undefined ? gridTypesMapping[ attrMetadata.attr_type ] : attrMetadata.attr_type
                            };
                            if ( Object.keys( attrMetadata.option_list ).length > 0 ) {
                                var dropdownDataSource = [];
                                ng.forEach( attrMetadata.option_list, function ( value, key ) {
                                    if ( ( column.type === 'number' ) && ( key === '' ) ) {
                                        // fix for '' as value for numeric fields
                                        fields[ attrMetadata.attr_name ].type = 'string';
                                    }
                                    if ( key === attrMetadata.default_value ) {
                                        fields[ attrMetadata.attr_name ].defaultValue = key;
                                    }
                                    dropdownDataSource.push( {
                                        value: value,
                                        id: key
                                    } );
                                } );
                                var enum_type = ( 'enum_type' in attrMetadata ) ? attrMetadata.enum_type : 'default';
                                dropdownDataSource = NMSSortOptions.doSorting( dropdownDataSource, enum_type );
                                column.type = 'select';
                                column.values = dropdownDataSource;
                                column.optionList = attrMetadata.option_list;
                            } else if ( attrMetadata.attr_type === 'time' ) {
                                // custom properties, not used by kendo but by our directives
                                column.type = 'time';
                            } else if ( attrMetadata.attr_type === 'timestamp' ) {
                                // custom properties, not used by kendo but by our directives
                                column.type = 'timestamp';
                            } else if ( attrMetadata.attr_type === 'integer' ) {
                                // custom properties, not used by kendo but by our directives
                                column.type = 'integer';
                                column.constraints = {
                                    decimals: 0,
                                    format: '0.',
                                    step: defaultIntegerStep,
                                    min: ( attrMetadata.range_start !== '' ) ? attrMetadata.range_start : undefined,
                                    max: ( attrMetadata.range_end !== '' ) ? attrMetadata.range_end : undefined
                                };
                            } else if ( attrMetadata.attr_type === 'double precision' ) {
                                var step = attrMetadata.step || defaultFloatStep,
                                    decimals = String( step ).split( '.' )[ 1 ];
                                column.type = 'double precision';
                                column.constraints = {
                                    decimals: decimals.length,
                                    format: '#.' + String( decimals ).replace( /[0-9]/g, '#' ), // to match step and format
                                    step: step,
                                    min: ( attrMetadata.range_start !== '' ) ? attrMetadata.range_start : undefined,
                                    max: ( attrMetadata.range_end !== '' ) ? attrMetadata.range_end : undefined
                                };
                                // custom validation for IPs (http://demos.telerik.com/kendo-ui/web/grid/editing-custom-validation.html)
                            } else if ( attrMetadata.attr_type === 'inetv4' ) {
                                // I have to do this because kendo calls validation for all fields and since my field names are dynamic I have to remember them somewhere
                                if ( validationFields[ attrMetadata.attr_name ] === undefined ) {
                                    validationFields[ attrMetadata.attr_name ] = {};
                                }
                                validationFields[ attrMetadata.attr_name ].ipv4 = true;
                                fields[ attrMetadata.attr_name ].validation.ipv4 = function ( input ) {
                                    if ( validationFields[ input.attr( 'name' ) ] !== undefined && validationFields[ input.attr( 'name' ) ].ipv4 !== undefined ) {
                                        var ipValue = input.val();
                                        if ( ipValue !== '' && !NMSWebValidation.isValidIpv4( ipValue ) ) {
                                            // TODO - pull invalid ipv4 message based on requirejs i18n
                                            input.attr( 'data-ipv4-msg', 'Invalid IPv4' );
                                            return false;
                                        } else {
                                            return true;
                                        }
                                    } else {
                                        return true;
                                    }
                                };
                            } else if ( attrMetadata.attr_type === 'inetv6' ) {
                                // I have to do this because kendo calls validation for all fields and since my field names are dynamic I have to remember them somewhere
                                if ( validationFields[ attrMetadata.attr_name ] === undefined ) {
                                    validationFields[ attrMetadata.attr_name ] = {};
                                }
                                validationFields[ attrMetadata.attr_name ].ipv6 = true;
                                fields[ attrMetadata.attr_name ].validation.ipv6 = function ( input ) {
                                    if ( validationFields[ input.attr( 'name' ) ] !== undefined && validationFields[ input.attr( 'name' ) ].ipv6 !== undefined ) {
                                        var ipValue = input.val();
                                        if ( ipValue !== '' && !NMSWebValidation.isValidIpv6( ipValue ) ) {
                                            // TODO - pull invalid ipv6 message based on requirejs i18n
                                            input.attr( 'data-ipv6-msg', 'Invalid IPv6' );
                                            return false;
                                        } else {
                                            return true;
                                        }
                                    } else {
                                        return true;
                                    }
                                };
                            } else if ( attrMetadata.attr_type === 'inet' ) {
                                // I have to do this because kendo calls validation for all fields and since my field names are dynamic I have to remember them somewhere
                                if ( validationFields[ attrMetadata.attr_name ] === undefined ) {
                                    validationFields[ attrMetadata.attr_name ] = {};
                                }
                                validationFields[ attrMetadata.attr_name ].ip = true;
                                fields[ attrMetadata.attr_name ].validation.ip = function ( input ) {
                                    if ( validationFields[ input.attr( 'name' ) ] !== undefined && validationFields[ input.attr( 'name' ) ].ip !== undefined ) {
                                        var ipValue = input.val();
                                        if ( ipValue !== '' && !NMSWebValidation.isValidIpv6( ipValue ) && !NMSWebValidation.isValidIpv4( ipValue ) ) {
                                            // TODO - pull invalid ip message based on requirejs i18n
                                            input.attr( 'data-ip-msg', 'Invalid IP' );
                                            return false;
                                        } else {
                                            return true;
                                        }
                                    } else {
                                        return true;
                                    }
                                };
                            } else if ( attrMetadata.attr_type === 'boolean' ) {
                                // in grid, checkbox will be always present
                                // and since kendo grid thinks required as true
                                // we are reseting this validation because it's not required
                                fields[ attrMetadata.attr_name ].validation.required = false;
                            }
                            columns.push( column );
                        } );
                        if ( !directiveOptions || !directiveOptions.viewMode ) {
                            columns.push( {
                                command: [ 'edit', 'destroy' ]
                            } );
                        }
                        if ( directiveOptions === undefined ) {
                            directiveOptions = {};
                        }
                        directiveOptions.dependencies = compositionDependencies;
                        directiveOptions.typeId = metadata.obj_type;
                        compositionOptions.columns = columns;
                        compositionOptions.label = value.comp_attr_display_name;
                        compositionOptions.fields = fields;
                        compositionOptions.rowId = 'rowId';
                        compositionOptions.data = compositionData;
                        compositionOptions.sortable = value.sortable || false;
                        compositionOptions.filterable = value.filterable || false;
                        if ( directiveOptions.multiEditMode && directiveOptions.multiEditMode === true ) {
                            compositionOptions.multiEditMode = true;
                        }
                        directives[ value.comp_attr_name ] = {
                            model: model,
                            directive: "nmsweb-composition",
                            options: compositionOptions,
                            name: value.comp_attr_name,
                            additionalOptions: ng.copy( directiveOptions ), // we need ng.copy, otherwise we can create .watch on additionalOptions (it would be called for each form element)
                            obj_name: obj_name
                        };
                        layout.push( value.comp_attr_name );
                    } );
                    ng.forEach( directives, function ( directive, key ) {
                        if ( directive.options ) {
                            model[ key ] = model[ key ] || directive.options.value;
                            delete directive.options.value;
                        }
                        // directive.dependencies = dependencies;
                        if ( !directive.options.hideOnGUI ) {
                            tmpDirectives[ key ] = directive;
                        }
                    } );
                    directives = tmpDirectives;
                    return {
                        fields: directives,
                        crossFormDependencies: crossFormDependencies,
                        dependencies: dependencies, // this will have collection of field1 => [affects_field_2, affects_field_3]
                        layout: layout,
                        viewMode: ( directiveOptions ) ? directiveOptions.viewMode : false
                    };
                }
            };
    } ] );
} );
