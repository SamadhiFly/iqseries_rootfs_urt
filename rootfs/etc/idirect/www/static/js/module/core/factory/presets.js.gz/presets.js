define( [ 'angular', 'module/core', 'module/core/factory/api' ], function ( ng, core ) {
    'use strict';
    /**
     * @ngdoc factory
     * @name core.factory:Presets
     * @description Resource API that will be used by Presets components.
     *
     * Implements query / create / update / delete Web Service queries.
     */

    core.factory( 'Presets', [ 'nmswebAPI',
        function ( nmswebAPI ) {
            function Presets() {
                var api = new nmswebAPI();

                return api.resource( 'config/element/presets', {}, {
                    query: {
                        method: 'GET'
                    },
                    create: {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    },
                    update: {
                        url: 'config/element/presets/:id',
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        params: {
                            id: '@id'
                        }
                    },
                    delete: {
                        url: 'config/element/presets/:id',
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        params: {
                            id: '@id'
                        }
                    }
                } );
            }

            return Presets;
    } ] );
} );