define( [ 'angular', 'kendo', 'module/core',
    'module/core/service/nmsweb-notification',
    'module/core/service/nmsutils',
    'module/core/factory/orgdata'
     ],
    function ( ng, kendo, core ) {
        'use strict';
        /**
         * @ngdoc factory
         * @name core.factory:OrgchartDatasource
         * @description Use Orgdata API factory.
         * It use params pased to into it and wraps them before passing to Orgdata API factory.
         * To initiate OrgChatDatasource it is OrgchartDatasource.init(..) method.
         * Returns instance of OrgchartDatasource object.

         An example of params taken in:
         ...
         dataSource: OrgchartDatasource.init(
         {
             filter: [
                 {
                     "field": "db_query_type",
                     "operator": "eq",
                     "value": "both"
                 }, {
                     "field": "type",
                     "operator": "eq",
                     "value": "dynamic"
                 }, {
                     "field": "obj_id",
                     "operator": "in",
                     "value": [ 1986, 1988 ]
                 }
             ]
         })
         */
        core.factory( 'OrgchartDatasource', [ 'NMSUtils', 'NMSWebNotification', 'Orgdata',
        function ( NMSUtils, NMSWebNotification, Orgdata ) {
                return {
                    init: function ( options ) {
                        var dataSource,
                            orgdata = new Orgdata(),
                            defaults = {
                                serverFiltering: true,
                                schema: {
                                    model: {
                                        children: "subordinates"
                                    }
                                },
                                transport: {
                                    read: function ( params ) {
                                        var paramsDefined = false;
                                        if ( typeof ( params ) !== undefined ) {
                                            if ( ( params.data ) !== undefined ) {
                                                if ( ( params.data.filter ) !== undefined ) {
                                                    if ( ( params.data.filter.filters ) !== undefined ) {
                                                        paramsDefined = true;
                                                    }
                                                }
                                            }
                                        }
                                        if ( paramsDefined ) {
                                            var requestItems = params.data.filter.filters,
                                                request = {};
                                            requestItems.forEach( function ( item ) {
                                                if ( ( item.field ).toLowerCase() === 'obj_id' ) {
                                                    request.ids = ( item.value ).join( ',' );
                                                } else if ( item.field === 'db_query_type' ) {
                                                    request.db_query_type = item.value;
                                                } else if ( item.field === 'type' ) {
                                                    request.type = item.value;
                                                } else if ( item.field === 'children' ) {
                                                    request.children = item.value;
                                                }
                                            } );
                                            if ( request.ids && request.ids.length > 0 ) {
                                                orgdata.get( request, function ( response ) {
                                                    dataSource.data( response.data.trees );
                                                    dataSource.trigger( 'nmsweb:dataSourceOrgchartGenerated' );
                                                }, function ( response ) {
                                                    NMSWebNotification.add( {
                                                        type: 'majorwarning',
                                                        isFadeable: true,
                                                        title: 'OrgchartDatasource - An error occurred while getting dataSource data',
                                                        message: NMSUtils.parseBackendErrors( response.errors )
                                                    }, 'body' );
                                                    dataSource.trigger( 'nmsweb:dataSourceOrgchartGenerated' );
                                                } );
                                            } else {
                                                dataSource.data( [] );
                                                dataSource.trigger( 'nmsweb:dataSourceOrgchartGenerated' );
                                            }
                                        }
                                    }
                                }
                            };
                        $.extend( true, defaults, options );
                        dataSource = new kendo.data.HierarchicalDataSource( defaults );
                        return dataSource;
                    }
                };
 } ] );
    } );