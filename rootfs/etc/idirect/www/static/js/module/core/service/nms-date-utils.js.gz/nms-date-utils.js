define( [ 'module/core' ], function ( core ) {
    'use strict';
    /**
     * @ngdoc service
     * @name nmsweb.service:NMSDateUtils
     * @returns NMSDateUtils object contains two properties a dateObj and a calculateDate function
     * @description  Enbles you to retrieve a date in the past using a template specifying the amount to rewind.
     *               In the example you would retreive the date 7 days ago from the current date and time.
     *               You must return the NMSDateUtils.dateObj as a parameter
     * @example: NMSDateUtils.calculateDate( -7d, NMSDateUtils.dateObj );
     */
    core.service( 'NMSDateUtils', [ function () {
            var dateObj = {
                    'y': {
                        method: 'FullYear',
                        expression: 0,
                        truncateMethod: function ( date ) {
                            date.setMonth( 0 );
                            date.setDate( 1 );
                            date.setHours( 0 );
                            date.setTime( date.getTime() );
                            return date;
                        }
                    },
                    'm': {
                        method: 'Month',
                        expression: 0,
                        truncateMethod: function ( date ) {
                            date.setDate( 1 );
                            date.setHours( 0 );
                            return date;
                        }
                    },
                    'w': {
                        method: 'Time',
                        expression: 7 * 24 * 3600 * 1000,
                        truncateMethod: function ( date ) {
                            var dayOfTheWeek = date.getDay();
                            if ( dayOfTheWeek === 0 ) {
                                date.setTime( date.getTime() - 6 * 24 * 3600 * 1000 );
                            } else {
                                date.setTime( date.getTime() - ( dayOfTheWeek - 1 ) * 24 * 3600 * 1000 );
                            }
                            date.setHours( 0 );
                            return date;
                        }
                    },
                    'd': {
                        method: 'Time',
                        expression: 24 * 3600 * 1000,
                        truncateMethod: function ( date ) {
                            date.setHours( 0 );
                            return date;
                        }
                    },
                    'h': {
                        method: 'Time',
                        expression: 3600 * 1000
                    },
                    's': {
                        method: 'Time',
                        expression: 1000
                    }
                },
                _truncate = function ( truncateParams, dateObj ) {
                    var date = _setCalculatedDate( truncateParams, dateObj );
                    date.setMinutes( 0 );
                    date.setSeconds( 0 );
                    return date;
                },
                _calculateTimespan = function ( timeSpanParams, dateObj ) {
                    var date = _setCalculatedDate( timeSpanParams, dateObj );
                    // if ( timeSpanParams.UTC ) {
                    //     date.setTime( timeSpanParams.date.getTime() + ( 60000 * date.getTimezoneOffset() ) );
                    // }
                    if ( timeSpanParams.unit === timeSpanParams.unit.toUpperCase() ) {
                        _truncate( timeSpanParams, dateObj );
                    }
                    return date;
                },
                _setCalculatedDate = function ( dateParams, dateObj ) {
                    dateParams.unit = dateParams.unit !== '' ? dateParams.unit : 'y'
                    var number = dateParams.number,
                        date = dateParams.date,
                        unit = dateParams.unit.toLowerCase(),
                        sign = dateParams.sign;
                    if ( sign === '+' || sign === undefined || sign === null || sign === '' ) {
                        date[ 'set' + dateObj[ unit ].method ]( date[ 'get' + dateObj[ unit ].method ]() + number * dateObj[ unit ].expression );
                    } else if ( sign === '-' ) {
                        date[ 'set' + dateObj[ unit ].method ]( date[ 'get' + dateObj[ unit ].method ]() - number * dateObj[ unit ].expression );
                    }
                    unit = dateParams.unit;
                    if ( unit === unit.toUpperCase() && dateObj[ unit ].truncateMethod ) {
                        date = dateObj[ unit ].truncateMethod( date );
                    }
                    return date;
                },
                calculateDate = function ( range, dateObj ) {
                    var rangePattern = /([\+\-]*)(\d+)([YMWDHymwdhs]*) ?(UTC)*/g,
                        rangeParts = [],
                        rangePart,
                        date = new Date();
                    while ( true ) {
                        rangePart = rangePattern.exec( range );
                        if ( rangePart ) {
                            rangePart[ 4 ] = rangePart[ 4 ] === 'UTC' ? true : false;
                            rangePart[ 4 ] = true; //For 1.0 UTC is always true
                            date = _calculateTimespan( {
                                'date': date,
                                'sign': rangePart[ 1 ],
                                'number': rangePart[ 2 ],
                                'unit': rangePart[ 3 ],
                                'UTC': rangePart[ 4 ]
                            }, dateObj );
                            rangeParts.push( rangePart );
                        } else {
                            break;
                        }
                    }
                    return date;
                };

            return {
                'dateObj': dateObj,
                'calculateDate': calculateDate
            }
        }

    ] );
} );