define( [
    'angular',
    'jquery',
    'module/core',
    'module/core/directive/form-element',
    'module/core/filter/underscore-to-dash',
    'module/core/service/nmsutils',
    'module/core/directive/nmsweb-spin',
    'module/core/service/metadata-form-transformer'
 ], function ( ng, $, core ) {
    'use strict';
    core.service( 'nmswebFormCompilator', [ '$q', '$compile', '$injector', 'NMSUtils', 'MetadataFormTransformer', 'NMSWebNotification', '$timeout', '$routeParams',
        function ( $q, $compile, $injector, NMSUtils, MetadataFormTransformer, NMSWebNotification, $timeout, $routeParams ) {
            return {
                compile: function ( scope, element, template ) {
                    var form = scope.schema,
                        otherFields;
                    if ( form.master === undefined ) {
                        //For easier access/debugging
                        window.testing = scope.schema;
                    } else {
                        if ( form.master.renderingChildren === undefined ) {
                            form.master.renderingChildren = [];
                        }

                        form.master.renderingChildren.push( form );
                    }
                    //Initial values
                    form._originalElement = $( element ).clone();
                    form.ready = false;
                    form.rendered = false;
                    form.$scope = scope;
                    if ( undefined === form.parent ) {
                        $( '.n-overlay .overlay' ).css( 'visibility', 'visible' ).spin( 'large' );
                    }
                    //Prevent propagation on 'toggle' and 'save' event
                    scope.$on( 'toggle', function ( event ) {
                        event.stopPropagation();
                    } );
                    form._getHookParams = function () {
                        return {
                            form: this,
                            fields: this.fields,
                            layout: this.layout,
                            model: {}, //deprecated default model
                            element: element,
                            resource: this.resource,
                            $routeParams: $routeParams,
                            $scope: scope
                        };
                    };
                    //Helper function to invoke hooks with proper params
                    form._hook = function ( name, localVar ) {
                        var form = this,
                            hooks = form.hook,
                            defer = $q.defer();
                        localVar = ng.extend( form._getHookParams(), localVar );
                        if ( typeof hooks === 'string' ) {
                            form.defer.loaded.promise.then( function () {
                                var ret;
                                hooks = form.hook;
                                if ( hooks && hooks[ name ] !== undefined && ( typeof hooks[ name ] === 'function' || hooks[ name ].constructor === Array ) ) {
                                    ret = $injector.invoke( hooks[ name ], null, localVar );
                                    if ( ret && ret.promise ) {
                                        ret.promise.then( function () {
                                            defer.resolve.call( defer, Array.prototype.slice.call( arguments, 0 ) );
                                        } );
                                    } else {
                                        defer.resolve( ret );
                                    }
                                } else {
                                    //This hook doesn't exist - still resolve deferred (especially for model hook)
                                    defer.resolve( name );
                                }
                            } );
                            return {
                                promise: defer.promise
                            };
                        } else {
                            if ( hooks && hooks[ name ] !== undefined && ( typeof hooks[ name ] === 'function' || hooks[ name ].constructor === Array ) ) {
                                return $injector.invoke( hooks[ name ], null, localVar );
                            } else {
                                //No hook avaialble - still resolve deferred
                                defer.resolve( name );
                            }
                        }
                    };
                    //Helper function to resolve deferred objects tied to the form
                    form._resolve = function ( name, data ) {
                        if ( this.defer && this.defer[ name ] && typeof this.defer[ name ].resolve === 'function' ) {
                            this.defer[ name ].resolve( data );
                        }
                    };

                    function render( params ) {
                        var parsed, mapped;

                        function getContainerForRemainingFields() {
                            var $ele = $( form.destination ),
                                $ele2;
                            if ( !$ele.hasClass( 'remaining-fields' ) ) {
                                $ele2 = $ele.find( '.remaining-fields' );
                                if ( !$ele2.length ) {
                                    $ele2 = $ele.find( '.directive-contents' );
                                    if ( !$ele2.length ) {
                                        $ele2 = $ele;
                                    }
                                    $ele2.append( '<div class="remaining-fields"></div>' );
                                    $ele = $ele2.find( '.remaining-fields' );
                                } else {
                                    $ele = $ele2;
                                }
                            }
                            return $ele;
                        }

                        function map( layout ) {
                            var promiseReady = [],
                                promiseRender = [];
                            //Map layout and add defer objects, it's needed to know when the form is ready and rendered
                            //Ready - all fields/groups/subforms are ready and we can show them
                            //Render - all fields/groups/subforms are ready and rendered
                            //          In case of lazy loading (when subform/group is waiting for user's input) this is resolved straight away
                            layout = layout.map( function ( item ) {
                                if ( typeof item === 'string' ) {
                                    item = {
                                        type: 'field',
                                        name: item
                                    };
                                }
                                item.defer = {
                                    ready: $q.defer(),
                                    render: $q.defer()
                                };
                                promiseReady.push( item.defer.ready.promise );
                                promiseRender.push( item.defer.render.promise );
                                return item;
                            } );
                            return {
                                promiseReady: promiseReady,
                                promiseRender: promiseRender,
                                layout: layout
                            };
                        }
                        if ( !params.fields && !params.schema ) {
                            throw 'Form needs fields or schema to render';
                        }
                        form.hook = params.hook;
                        form._resolve( 'loaded' );
                        form._resolve( 'prepared' );
                        //Prepare fields
                        //If fields are not passed translate schema to fields
                        if ( params.fields ) {
                            form.fields = params.fields;
                        } else if ( params.schema ) {
                            parsed = MetadataFormTransformer.generateForm( params.schema, form.errorsMap, form.model, {
                                viewMode: form.viewMode,
                                multiEditMode: ( form.mode !== undefined && form.mode === 'multi-edit' ) ? true : false
                            } );
                            form.fields = parsed.fields;
                            form.layout = parsed.layout;
                            form.dependencies = parsed.dependencies;
                            form.crossFormDependencies = parsed.crossFormDependencies;
                        }
                        //If layout is not defined, use default layout -> plain array
                        if ( form.layout === undefined ) {
                            form.layout = Object.keys( params.fields );
                        }
                        //Override default layout with custom one when it's set
                        form.layout = params.layout || form.layout;
                        form._resolve( 'schema' );
                        //Fire schema hook
                        form.fields = form._hook( 'schema' ) || form.fields;
                        form._resolve( 'layout' );
                        //Fire layout hook
                        form.layout = form._hook( 'layout' ) || form.layout;
                        //Track model changes and change status when the model was modified
                        form.defer.model.promise.then( function () {
                            if ( !form._collectionWatcher ) {
                                form._collectionWatcher = scope.$watchCollection( 'schema.model', function ( newVal, oldVal ) {
                                    if ( !ng.equals( newVal, oldVal ) && form.rendered ) {
                                        scope.schema.model._status = 'modified';
                                    }
                                } );
                            }
                        } );
                        //Add hidden class to mapped fields
                        ng.forEach( form._hide, function ( name ) {
                            var fieldSchema = form.fields[ name ];
                            if ( fieldSchema ) {
                                fieldSchema.container = fieldSchema.container || {};
                                fieldSchema.container.class = fieldSchema.container.class || '';
                                fieldSchema.container.class = fieldSchema.container.class + ' hidden';
                            }
                        } );
                        //Prepare remaining fields array and template
                        form.remaining = Object.keys( form.fields );
                        template = params.template || template;
                        template = ng.element( template );
                        mapped = map( form.layout );
                        form.layout = mapped.layout;
                        //When all contents are ready spinner is switched off with form.ready
                        $q.all( mapped.promiseReady ).then( function () {
                            console.info( '[Form ' + form.name + '][ready]' );
                            form._resolve( 'ready' );
                            form.ready = true;
                        } );
                        //When all contents are ready 'render hook' is fired
                        //It's in a case when some contents of groups/fields has to be loaded straight away
                        //In case of lazy loading it's fired straight away and engine doesn't wait for dependencies
                        //as they're loaded on user's input
                        //Also if there is no lazy loading in form's schema, remaining fields are rendered
                        $q.all( mapped.promiseRender ).then( function () {
                            var $ele, isolatedScope, mappedRemaining;

                            function rendered() {
                                var isIE,
                                    complexForms = [ 'terminal', 'gsp', 'sspp', 'mgsp', 'msspp' ];
                                form.rendered = true;
                                if ( form.parent ) {
                                    if ( form.parent.subforms[ form.name ] ) {
                                        NMSWebNotification.add( {
                                            type: "error",
                                            title: "Form error: " + form.parent.name,
                                            message: 'Subform name "' + form.name + '" already exists'
                                        }, "body" );
                                        console.warn( '[Form ' + form.parent.name + '][has already subform named ' + form.name + ']' );
                                    } else {
                                        form.parent.subforms[ form.name ] = form;
                                    }
                                }

                                console.info( '[Form ' + form.name + '][rendered]' );

                                form._resolve( 'render' );
                                form._hook( 'render' );

                                // horrible hack to fix the flash of unstyled content for complex forms in IE
                                isIE = /*@cc_on!@*/ false || !!document.documentMode; // At least IE6
                                if ( isIE && complexForms.indexOf( form.name ) > -1 ) {
                                    setTimeout( function () {
                                        form.$element.removeClass( 'hidden' );
                                        if ( undefined === form.parent ) {
                                            $( '.n-overlay .overlay' ).css( 'visibility', 'hidden' ).spin( false );
                                        }
                                    }, 2000 );
                                } else {
                                    form.$element.removeClass( 'hidden' );
                                    if ( undefined === form.parent ) {
                                        $( '.n-overlay .overlay' ).css( 'visibility', 'hidden' ).spin( false );
                                    }
                                }
                                if ( form.master ) {
                                    $timeout( function () {
                                        form.master.renderingChildren.pop();
                                    }, 1000 );
                                }

                            }
                            if ( !form.remaining.lazy && form.remaining.length > 0 ) {
                                $ele = getContainerForRemainingFields();
                                mappedRemaining = map( form.remaining );
                                $q.all( mappedRemaining.promiseRender ).then( rendered );
                                isolatedScope = scope.$new( true );
                                isolatedScope.schema = {
                                    contents: mappedRemaining.layout,
                                };
                                isolatedScope.form = form;
                                console.info( '[Form ' + form.name + '][rendering remaining fields]' );
                                $ele.append( '<nmsweb-form-element schema="schema" form="form"></nmsweb-form-element>' );
                                $compile( $ele.find( 'nmsweb-form-element' ) )( isolatedScope );

                                // check if the form has Unassigned fieldsets and tabs, show them if necessary and delete
                                // the temporary form._unassigned object
                                if ( form._unassigned ) {
                                    var needsRendering = $.grep( form.remaining, function ( field ) {
                                        return ( !( 'map' in form ) || !( 'master' in form ) || !( field in form.map ) );
                                    } );
                                    if ( needsRendering.length > 0 && form._unassigned.fieldset ) {
                                        form._unassigned.fieldset.hide = false;
                                        if ( form._unassigned.tab ) {
                                            form._unassigned.tab.hide = false;
                                        }
                                    }
                                    if ( form._unassigned.tab && form._unassigned.tab.hide ) {
                                        if ( form._unassigned.tab.contents.length > 1 || ( form._unassigned.tab.contents.length === 1 && !form._unassigned.fieldset ) ) {
                                            // unassigned tab has more/other content than just the unassigned fieldset - show it
                                            form._unassigned.tab.hide = false;
                                        }
                                    }
                                    delete form._unassigned;
                                }
                            } else {
                                rendered();
                            }
                        } );
                        if ( form.hook && form.hook.toggle && !form._toggleWatcher ) {
                            form._toggleWatcher = scope.$on( 'toggle', function ( event, toggleData ) {
                                var localVar = {
                                    element: scope.schema.$element,
                                    toggleData: toggleData
                                };
                                form._hook( 'toggle', localVar );
                            } );
                        }
                        scope.schema = form;
                        template = form.template || template;
                        template = ng.element( template );
                        NMSUtils.copyAttrs( element, template, [ 'schema' ] );
                        element.replaceWith( template );
                        otherFields = template.find( '.remaining-fields' );
                        if ( !otherFields.length ) {
                            otherFields = $( '<div class="remaining-fields"></div>' );
                            template.append( otherFields );
                        }
                        form.destination = template.find( '.remaining-fields:last' )[ 0 ];
                        element = $compile( template )( scope );
                        form.$element = ng.element( element );

                        // we will show the form later in rendered()
                        form.$element.addClass( 'hidden' );

                        //Let's not use that feature ATM
                        //Initiate watchers for relative subforms
                        // ng.forEach(form._relations, function (relation) {
                        //  ng.forEach(relation.fields, function (masterField, slaveField) {
                        //      scope.$watch(function () {
                        //          return relation.master.model[masterField];
                        //      }, function (newVal, oldVal) {
                        //          if (newVal !== oldVal) {
                        //              form.model[slaveField] = relation.master.model[masterField];
                        //          }
                        //      });
                        //  });
                        // });
                    }
                    if ( form.preloader ) {
                        form.defer.loaded = $q.defer();
                        form.preloader.setCallback( render );
                        form.preloader.compile( scope, element );
                    } else {
                        render( {
                            template: form.template,
                            model: form.model,
                            fields: form.fields,
                            schema: form.schema,
                            layout: form.layout,
                            $routeParams: $routeParams,
                            hook: form.hook
                        } );
                    }
                }
            };
        }
    ] );
} );