define( [ 'module/core' ], function ( core ) {
    'use strict';
    core.service( 'KendoAttributesMapping', [
        function () {
            return {
                mapAttributes: function ( element, attributes ) {
                    angular.forEach( attributes, function ( value, key ) {
                        if ( key.indexOf( "nmsweb" ) === 0 ) { // we could do str.match here as well
                            key = key.replace( "nmsweb", "" );
                            attributes[ "k" + key ] = value;
                            var $attr_value = attributes.$attr[ "nmsweb" + key ];
                            element.removeAttr( $attr_value );
                            $attr_value = $attr_value.replace( "nmsweb", "k" );
                            attributes.$attr[ "k" + key ] = $attr_value;
                            element.attr( $attr_value, value );
                        }
                    } );
                }
            };
    } ] );
} );