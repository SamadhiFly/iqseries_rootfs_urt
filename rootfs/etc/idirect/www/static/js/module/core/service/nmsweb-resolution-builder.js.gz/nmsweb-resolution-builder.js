define( [
    'jquery',
    'angular',
    'module/core',
    'module/core/service/nmsweb-notification'
 ], function ( $, ng, core ) {
    'use strict';
    /**
     * @ngdoc service
     * @name core.service:NmswebResolutionBuilder
     * @description Builds an array used to set the datetimerangepicker options resolution property
     */

    var ResolutionBuilder;

    core.service( 'NmswebResolutionBuilder', [
        function () {

            ResolutionBuilder = function ( scope ) {
                if ( scope ) {
                    this.init( scope );
                }
            };

            ResolutionBuilder.prototype = {
                init: function ( scope ) {
                    this.scope = scope;
                    this.intervalChange();
                },
                now: function () {
                    return new Date();
                },
                intervalChange: function () {
                    var from = this.scope.nmswebOptions.dateTimePickers[ 0 ].name,
                        to = this.scope.nmswebOptions.dateTimePickers[ 1 ].name;

                    this.update( this.getInterval( to, from, this.scope.model ) );
                },
                getInterval: function ( to, from, model ) {
                    if ( model.stream ) {
                        return Math.floor( this.now() / 1000 ) - Math.floor( new Date( model[ from ] ) / 1000 );
                    } else {
                        return Math.floor( new Date( model[ to ] ) / 1000 ) - Math.floor( new Date( model[ from ] ) / 1000 );
                    }
                },
                resolutionList: function ( interval ) {
                    var resolutionList = [],
                        ranges = this.scope.nmswebOptions.resolutions.profile.stats.default_resolution_configuration.range;

                    if ( interval === 0 ) {
                        return resolutionList;
                    }

                    // TODO: instead filter ranges and return first or empty array
                    $.each( ranges, function ( index, range ) {
                        if ( interval <= range.width ) {
                            resolutionList = range.resolutions;
                            return false; // return false, to break out of each loop
                        }
                    } );

                    return resolutionList;
                },
                optionsList: function ( resolutionList, dropDownOptions ) {
                    return resolutionList.map( function ( item ) {
                        var options = dropDownOptions.filter( function ( option ) {
                            return option.value.toString() === item.toString();
                        } );
                        return {
                            "value": item,
                            "label": options[ 0 ].label
                        };
                    } ).sort( this.compare );
                },
                dropDownOptions: function ( labels ) {
                    return $.map( labels, function ( label, value ) {
                        return {
                            "value": value,
                            "label": label
                        };
                    } );
                },
                compare: function ( a, b ) {
                    a = parseInt( a.value, 10 );
                    b = parseInt( b.value, 10 );

                    return a - b;
                },
                displayToolTip: function ( isShow ) {
                    var ranges, maxDays;

                    if ( isShow ) {
                        ranges = this.scope.nmswebOptions.resolutions.profile.stats.default_resolution_configuration.range;
                        maxDays = Math.floor( ranges.slice( -1 )[ 0 ].width / 86400 );
                        this.scope.widgetPopover.options.content = 'The query range is too wide, so there are no valid' + ' resolutions.<br />Please select a range less than ' + maxDays + ' days.';
                        this.scope.widgetPopover.refresh();
                        this.scope.enableTooltip = true;
                    } else {
                        this.scope.widgetPopover.hide();
                        this.scope.enableTooltip = false;
                    }
                },
                update: function ( interval ) {

                    var labels = this.scope.nmswebOptions.resolutions.profile.stats.default_resolution_configuration.label,
                        resolutionList = this.resolutionList( interval ),
                        dropDownOptions = this.dropDownOptions( labels ),
                        optionsList = this.optionsList( resolutionList, dropDownOptions );

                    this.scope.nmswebOptions.resolutions.labels = optionsList;

                    if ( optionsList.length ) {
                        var previousValue = parseInt( this.scope.model.resolution, 10 );

                        this.scope.resolutionEnabled = true;

                        // reselect previous value if available otherwise select first
                        if ( resolutionList.indexOf( previousValue ) !== -1 ) {
                            this.scope.model.resolution = optionsList.filter( function ( option ) {
                                return option.value.toString() === previousValue.toString();
                            } )[ 0 ].value;
                        } else {
                            this.scope.model.resolution = optionsList[ 0 ].value;
                        }

                        this.displayToolTip();

                    } else {
                        this.scope.resolutionEnabled = false;
                        this.scope.model.resolution = null;
                        this.displayToolTip( true );
                    }
                },
                isValid: function ( model ) {
                    this.scope = model;

                    model.stream = false;
                    var resolutionList = this.resolutionList( this.getInterval( "rangeTo", "rangeFrom", model ) );

                    if ( resolutionList.indexOf( model.resolution ) === -1 ) {
                        return false;
                    } else {
                        return true;
                    }
                }
            };

            return ResolutionBuilder;

    } ] );

} );