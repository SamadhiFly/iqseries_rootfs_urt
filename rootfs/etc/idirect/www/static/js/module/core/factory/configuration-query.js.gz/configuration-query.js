define( [ 'angular', 'module/core', 'module/core/factory/api' ], function ( ng, core ) {
    'use strict';
    core.factory( 'ConfigurationQuery', [ 'nmswebAPI',
        function ( nmswebAPI ) {
            function ConfigurationQuery() {
                var api = new nmswebAPI();
                return api.resource( 'core/configuration/:path', {}, {
                    query: { //To query elements
                        method: 'GET',
                        headers: {
                            'Use-Cookie': 'true'
                        },
                    }
                } );
            }
            return ConfigurationQuery;
 } ] );
} );