define( [ 'jquery', 'module/core', 'core/spin' ], function ( $, core ) { // jshint ignore:line
    'use strict';
    /**
     * @ngdoc factory
     * @name nmsweb.service:DataTransportMechanism
     * @returns Object
     * @description Classifies the transport mechanism used by a datasource
     * @example: DataTransportMechanism() // for example returns mechanism object with bindNotifications and mechanism methods
     */
    core.factory( 'DataTransportMechanism', [ function () {

        var ds = function ( component ) {
            var ds = Array.isArray( component.options.series ) ?
                component.options.series.map( function ( s ) {
                    if ( s.dataSources && s.dataSources.length ) {
                        return s.dataSources[ 0 ];
                    }
                } )[ 0 ] :
                component.dataSource;

            return typeof ds === 'string' ? nmsweb.DataSources[ ds ] : ds; // jshint ignore:line
        };

        var transport = function ( ds ) {
            if ( !ds ) {
                return null;
            } else if ( typeof ds.async !== 'undefined' ) {
                return ds.streaming && ds.streaming.query ? 'stream' : 'async';
            } else {
                return 'xhr';
            }
        };

        var events = {
            null: function ( notify, ds, logic ) {
                logic.end.call( notify );
            },
            xhr: function ( notify, ds, logic ) {
                ds.bind( 'change', logic.data ? logic.data.bind( notify, ds ) : $.noop );
                ds.bind( 'error', logic.error ? logic.error.bind( notify, ds ) : $.noop );
                ds.bind( 'requestEnd', logic.end ? logic.end.bind( notify, ds ) : $.noop );
                ds.bind( 'requestStart', logic.data ? logic.data.bind( notify, ds ) : $.noop );
                ds.bind( 'nmsweb:dataSourceServerFilteringDone', logic.data ? logic.data.bind( notify, ds ) : $.noop );
                ds.bind( 'nmsweb:dataSourceServerFilteringStarted', logic.data ? logic.data.bind( notify, ds ) : $.noop );
                // ds.bind( 'nmsweb:errorWhileGettingData', logic.error ? logic.error.bind(notify, ds) : $.noop);
                logic.start.call( notify, [] );
            },
            async: function ( notify, ds, logic ) {
                ds.bind( 'change', logic.data ? logic.data.bind( notify, ds ) : $.noop );
                ds.bind( 'error', logic.error ? logic.error.bind( notify, ds ) : $.noop );
                ds.bind( 'asyncDone', logic.end ? logic.end.bind( notify, ds ) : $.noop );
                $( 'body' ).on( 'nmsweb:jmrBack', logic.reconnect ? logic.reconnect.bind( notify, ds ) : $.noop );
                $( 'body' ).on( 'nmsweb:jmrDown', logic.disconnect ? logic.disconnect.bind( notify, ds ) : $.noop );
                $( 'body' ).on( 'nmsweb:jmrClose', logic.end ? logic.end.bind( notify, ds ) : $.noop );
                logic.start.call( notify, [] );
            },
            stream: function ( notify, ds, logic ) {
                ds.bind( 'change', logic.data ? logic.data.bind( notify, ds ) : $.noop );
                ds.bind( 'error', logic.error ? logic.error.bind( notify, ds ) : $.noop );
                $( 'body' ).on( 'nmsweb:jmrBack', logic.reconnect ? logic.reconnect.bind( notify, ds ) : $.noop );
                $( 'body' ).on( 'nmsweb:jmrDown', logic.disconnect ? logic.disconnect.bind( notify, ds ) : $.noop );
                $( 'body' ).on( 'nmsweb:jmrClose', logic.end ? logic.end.bind( notify, ds ) : $.noop );
                logic.start.call( notify, [] );
            }
        };

        var logic = {
            null: {
                end: function () {
                    var that = this;

                    if ( this.getChart().series.some( function ( series ) {
                            return series.data.length > 0;
                        } ) ) {
                        this.clear();
                    } else {
                        this.noData();
                    }

                    if ( this.component && this.component.options && this.component.options.errors ) {
                        this.component.options.errors.forEach( function ( error ) {
                            that.error( error );
                        } );
                    }
                }
            },
            xhr: {
                start: function ( _data, event ) { // jshint ignore:line

                    if ( this.component.$angular_scope && ( !this.component.options || !this.component.options.autoBind ) ) {
                        this.waitingForUserInput();
                    } else {
                        this.startLoading();
                    }

                },
                end: function ( _data, event ) {
                    var data = _data.data();

                    if ( !data.length && !event.response ||
                        ( !data.length && ( event.response !== undefined && ( !event.response.length && ( !event.response.data || ( event.response.data && !event.response.data.length ) ) ) ) ) ) {
                        this.noData();
                    }
                },
                error: function ( _data, event ) {
                    var that = this,
                        data = _data.data();

                    if ( !data.length ) {
                        this.noDataCurrently();
                    }

                    if ( event.errors !== undefined && event.errors.length ) {
                        event.errors.forEach( function ( error ) {
                            that.error( error.message );
                        } );
                    }
                },
                data: function ( _data, event ) { // jshint ignore:line
                    var data = _data.data();

                    if ( data.length > 0 ) {
                        this.clear();
                    }

                    //if an non-WS request calls .data() twice, but doesn't call .end(), don't try to overwrite the data.
                    //(by definition, XHR cannot update the chart after it is set, needs to be async/stream)
                    if ( nmsweb.DataSources[ event.sender.id ] && nmsweb.DataSources[ event.sender.id ].dataHasBeenSet === undefined ) {
                        nmsweb.DataSources[ event.sender.id ].dataHasBeenSet = true;
                        this.clear();

                        if ( this.component.$angular_scope ) {
                            if ( event.sender._requestInProgress ) {
                                this.startLoading();
                            }

                            if ( event.sender._requestInProgress === false && !data.length ) {
                                this.noDataCurrently();
                            }
                        } else { // old elSel's and charts
                            this.element.spin( false );
                        }
                    }
                }
            },
            async: {
                start: function ( _data, event ) { // jshint ignore:line
                    this.startLoading();
                },
                end: function ( _data, event ) {
                    var data = _data.data();

                    if ( !data.length && !event.response ||
                        !data.length && event.response !== undefined && !event.response.length ) {
                        this.noData();
                        if ( event.type === 'nmsweb:jmrClose' ) {
                            this.noDataCurrently();
                        }
                    }

                },
                error: function ( _data, event ) { // jshint ignore:line
                    var that = this,
                        data = _data.data();

                    if ( !data.length ) {
                        this.noDataCurrently();
                    }

                    if ( event.errors !== undefined && event.errors.length ) {
                        event.errors.forEach( function ( error ) {
                            that.error( error.message );
                        } );
                    }
                },
                data: function ( _data, event ) { // jshint ignore:line
                    var data = _data.data();
                    this.clear();

                    if ( !data.length ) {
                        this.startLoading();
                    }
                },
                reconnect: function ( _data, event ) { // jshint ignore:line
                    var data = _data.data();
                    if ( nmsweb.jmr.disconnect ) { // jshint ignore:line
                        if ( !data.length ) {
                            this.startLoading( 'Reconnected, waiting for data' );
                        } else {
                            this.error( {
                                type: 'success',
                                title: 'Reconnected',
                                message: 'Reconnected'
                            } );
                        }
                    } else {
                        if ( !data.length ) {
                            this.startLoading( 'Connected' );
                        } else {
                            this.error( {
                                type: 'success',
                                title: 'Reonnected',
                                message: 'Reconnected'
                            } );
                        }
                    }
                },
                disconnect: function ( _data, event ) { // jshint ignore:line
                    var data = _data.data();
                    nmsweb.jmr.disconnect = true; // jshint ignore:line

                    if ( !data.length ) {
                        this.startLoading( 'Lost contact, reconnecting' );
                    } else {
                        this.error( {
                            type: 'error',
                            title: 'Lost contact, reconnecting',
                            message: 'Lost contact, reconnecting'
                        });
                    }
                }
            },
            stream: {
                start: function () {
                    this.startLoading();
                },
                end: function ( _data, event ) {
                    var data = _data.data();

                    if ( !data.length && !event.response ||
                        !data.length && event.response !== undefined && !event.response.length ) {
                        this.noDataCurrently();
                    }
                },
                data: function ( _data, event ) { // jshint ignore:line
                    var data = _data.data();
                    this.clear();

                    if ( !data.length ) {
                        this.startLoading();
                    }
                },
                error: function ( _data, event ) {
                    var that = this,
                        data = _data.data();

                    if ( !data.length ) {
                        this.noDataCurrently();
                    } else {
                        this.error( {
                            type: 'error',
                            title: 'Lost contact, reconnecting',
                            message: 'Lost contact, reconnecting'
                        });
                    }

                    if ( event.errors !== undefined && event.errors.length ) {
                        event.errors.forEach( function ( error ) {
                            that.error( error.message );
                        } );
                    }
                },
                reconnect: function ( _data, event ) { // jshint ignore:line
                    var data = _data.data();
                    if ( nmsweb.jmr.disconnect ) { // jshint ignore:line
                        if ( !data.length ) {
                            this.startLoading( 'Reconnected, waiting for data' );
                        } else {
                            this.error( {
                                type: 'success',
                                title: 'Reconnected',
                                message: 'Reconnected'
                            } );
                        }
                    } else {
                        if ( !data.length ) {
                            this.startLoading( 'Reconnected' );
                        } else {
                            this.error( {
                                type: 'success',
                                title: 'Reconnected',
                                message: 'Reconnected'
                            } );
                        }
                    }
                },
                disconnect: function ( _data, event ) { // jshint ignore:line
                    var data = _data.data();
                    nmsweb.jmr.disconnect = true; // jshint ignore:line
                    if ( !data.length ) {
                        this.startLoading( 'Lost contact, reconnecting' );
                    } else {
                        this.error( {
                            type: 'error',
                            title: 'Lost contact, reconnecting',
                            message: 'Lost contact, reconnecting'
                        });
                    }
                }
            }
        };

        return {
            bindNotifications: function ( notify, ds, mechanism ) {
                events[ mechanism ]( notify, ds, logic[ mechanism ] );
            },
            mechanism: function ( component ) {
                return transport( ds( component ) );
            },
            events: events,
            logic: logic
        };
    } ] );

} );
