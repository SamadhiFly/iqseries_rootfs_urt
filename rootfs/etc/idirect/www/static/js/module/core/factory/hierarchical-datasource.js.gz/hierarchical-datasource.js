define( [ 'angular', 'kendo', 'module/core',
    'module/core/service/nmsweb-notification',
    'module/core/service/nmsutils',
    'module/core/factory/hierarchical',
     ],
    function ( ng, kendo, core ) {
        'use strict';
        /**
         * @ngdoc factory
         * @name core.factory:HierarchicalDatasource
         * @description Use Hierarchical API factory.
         * It use params pased to into it and wraps them before passing to Hierarchical API factory.
         * Returns instance of Kendo HierarchicalDataSource object.
         example:

         For 'params' we can pass:
         {
             filter: [
                 {
                     "field": "db_query_type",
                     "operator": "eq",
                     "value": "both"
                 }, {
                     "field": "type",
                     "operator": "eq",
                     "value": "dynamic"
                 }, {
                     "field": "obj_id",
                     "operator": "in",
                     "value": [ 1986, 1988 ]
                 }
             ]
         }

         The retrun will be 'dataSource' as new 'kendo.data.HierarchicalDataSource' object.
         */
        core.factory( 'HierarchicalDatasource', [ 'NMSUtils', 'NMSWebNotification', 'Hierarchical',
        function ( NMSUtils, NMSWebNotification, Hierarchical ) {
                return {
                    init: function ( options ) {
                        var dataSource,
                            hierarchical = new Hierarchical(),
                            defaults = {
                                serverFiltering: true,
                                schema: {
                                    model: {
                                        children: "subordinates"
                                    }
                                },
                                transport: {
                                    read: function ( params ) {
                                        var paramsDefined = false;
                                        if ( typeof ( params ) !== undefined ) {
                                            if ( ( params.data ) !== undefined ) {
                                                if ( ( params.data.filter ) !== undefined ) {
                                                    if ( ( params.data.filter.filters ) !== undefined ) {
                                                        paramsDefined = true;
                                                    }
                                                }
                                            }
                                        }
                                        if ( paramsDefined ) {
                                            var requestItems = params.data.filter.filters,
                                                request = {};
                                            requestItems.forEach( function ( item ) {
                                                if ( ( item.field ).toLowerCase() === 'obj_id' ) {
                                                    request.ids = ( item.value ).join( ',' );
                                                } else if ( item.field === 'db_query_type' ) {
                                                    request.db_query_type = item.value;
                                                } else if ( item.field === 'type' ) {
                                                    request.type = item.value;
                                                } else if ( item.field === 'children' ) {
                                                    request.children = item.value;
                                                }
                                            } );
                                            if ( request.ids && request.ids.length > 0 ) {
                                                hierarchical.get( request, function ( response ) {
                                                    dataSource.data( response.data.trees );
                                                    dataSource.trigger( 'nmsweb:dataSourceTreeGenerated' );
                                                }, function ( response ) {
                                                    NMSWebNotification.add( {
                                                        type: 'majorwarning',
                                                        isFadeable: true,
                                                        title: 'An error occurred while hierarchy',
                                                        message: NMSUtils.parseBackendErrors( response.errors )
                                                    }, 'body' );
                                                } );
                                            } else {
                                                dataSource.data( [] );
                                                dataSource.trigger( 'nmsweb:dataSourceTreeGenerated' );
                                            }
                                        }
                                    }
                                }
                            };
                        $.extend( true, defaults, options );
                        dataSource = new kendo.data.HierarchicalDataSource( defaults );
                        return dataSource;
                    }
                };
 } ] );
    } );