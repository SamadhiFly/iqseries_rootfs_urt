define(['module/core', 'kendo', 'angular', 'jquery', 'module/core/service/nmsweb-get-config'], function(core, kendo, ng, $) {
    'use strict';
    core.service('NMSUtils', ['$rootScope','NMSWebGetConfig', '$q',

    function($rootScope, NMSWebGetConfig, $q) {
        var compositionDataRegex = new RegExp(/\"\((.*?)\)\"/g),
            angular = ng,
            _populateObject = function(object, entry, columnMetadata) {
                angular.forEach(entry, function(property, index) {
                    if (columnMetadata.length > index) {
                        var fieldType = columnMetadata[index].type !== undefined ? columnMetadata[index].type : columnMetadata[index].attr_type,
                            fieldName = columnMetadata[index].field !== undefined ? columnMetadata[index].field : columnMetadata[index].attr_name;
                        // in case it's a dropdown
                        if (fieldType === "time") {
                            var dateValue = new Date();
                            dateValue.setHours(property.split(":")[0]);
                            dateValue.setMinutes(property.split(":")[1]);
                            property = dateValue;
                        }
                        else if (fieldType === "boolean") {
                            if (property === "t") {
                                property = true;
                            }
                            else {
                                property = false;
                            }
                        }
                        else {
                            // in some cases values from BE comes in with escaped quotes in case data is string with spaces, e.g. \"modem TX|IF port\"
                            // we don't need those escaped quotes so we are removing them
                            property = property.replace(/\\"/g, "");
                        }
                        object[fieldName] = property;
                    }
                });
            };
        var iconShapeMappingService = NMSWebGetConfig.getConfiguration('modules.core.fe-components.icon-shape-mapping.element_type_shape_mappings');
        var _real_escape_string = function(str) {
            //This function is to escape sql strings for composite elements.  Only for use in 1.1 where the back end does not accept json values.
            return str.replace(/[\0\(\)\x08\x09\x1a\n\r"'\\\%]/g, function(char) {
                switch (char) {
                case "\0":
                    return "\\0";
                case "\x08":
                    return "\\b";
                case "\x09":
                    return "\\t";
                case "\x1a":
                    return "\\z";
                case "\n":
                    return "\\n";
                case "\r":
                    return "\\r";
                case "\"":
                case "'":
                case "\\":
                case "(":
                case ")":
                case "%":
                    return "\\" + char; // prepends a backslash to backslash, percent,
                    // and double/single quotes
                }
            });
        };
        return {
            getPopoverIndex: function(increase) {
                if ($rootScope.nmswebPopoverIndex === undefined) {
                    $rootScope.nmswebPopoverIndex = 9999;
                }
                if (increase === undefined || increase === false) {
                    $rootScope.nmswebPopoverIndex++;
                }

                return $rootScope.nmswebPopoverIndex;
            },
            resetPopoverIndex: function() {
                $rootScope.nmswebPopoverIndex = undefined;
            },
            increasePopoverIndex: function() {
                $rootScope.nmswebPopoverIndex++;
            },
            getPropertyByString: function(object, string) {
                var splittedString, tempValue;
                string = string.replace(/^\./, ''); // strip leading dot
                splittedString = string.split('.');
                for (var i = 0, length = splittedString.length; i < length; i++) {
                    tempValue = splittedString[i];
                    if (tempValue in object) {
                        object = object[tempValue];
                    }
                    else {
                        return;
                    }
                }
                return object;
            },
            setPropertyByString: function(object, value, path) {
                path = path.split('.');
                for (var i = 0; i < path.length - 1; i++) {
                    object = object[path[i]];
                }

                object[path[i]] = value;
            },
            stringEscape: _real_escape_string,
            exportCSV: function(gridData, columns) {
                var csv = '';
                angular.forEach(columns, function(colobject) {
                    if (colobject.command === undefined && colobject.skipExport !== true) { // add only non-commands and those which don't need to be exported
                        var col = (typeof(colobject.title) !== "undefined") ? colobject.title : colobject.field;
                        col = col.replace(/"/g, '""');
                        csv += '"' + col + '",';
                    }
                });
                csv = csv.substring(0, csv.length - 1);
                csv += "\n";
                angular.forEach(gridData, function(row) {
                    angular.forEach(columns, function(colobject) {
                        var col = colobject.field,
                            value = row[col];
                        // do export only if column isn't command:
                        if (colobject.command === undefined && colobject.skipExport !== true) {
                            if (colobject.type === "select") {
                                //  custom added type='dropdown' in metadata transformer (not used for anything else)
                                // it means is complex object, we should use template to display value
                                value = kendo.template(colobject.template)(row);
                            }
                            else if (value === null || typeof(value) === "undefined") {
                                value = "";
                            }
                            else if (value instanceof Date) {
                                value = kendo.toString(kendo.parseDate(value), colobject.parseFormats[0]);
                            }
                            else if (colobject.template !== undefined && colobject.template.substring(0, 2) === '#=' && colobject.template.substring(colobject.template.length - 1, colobject.template.length) === '#') {
                                // it's enclosed kendo template
                                value = kendo.template(colobject.template)(row);
                            }
                            else {
                                value = value.toString();
                            }
                            if (value !== undefined) {
                                value = value.replace(/"/g, '""');
                                csv += '"' + value + '",';
                            }
                        }
                    });
                    csv = csv.substring(0, csv.length - 1);
                    csv += "\n";
                });
                return csv;
            },
            // adds postgres encoded string into data (parses it accordingly)
            // columnMetadata can be array of metadata, or array of columns
            // in case of metadata it will check attr_type and attr_name properties to get field type
            // in case of columns it will check type and field properties to get field name
            addEncodedCompositions: function(encodedComposition, columnMetadata, data) {
                var match = compositionDataRegex.exec(encodedComposition);
                while (match !== null) {
                    var object = {},
                    entry = match[1].split(",");
                    // Check if there was a ',' in a string which would truncate JSON strings
                    // If so, restore JSON string
                    if(entry.length !== columnMetadata.length) {
                        var newEntry = [],
                            currentEntry;
                        ng.forEach(entry, function(singleEntry) {
                            if(singleEntry.indexOf('{') !== -1) {
                                currentEntry = singleEntry;
                            } else if(singleEntry.indexOf('}') !== -1) {
                                newEntry.push(currentEntry+','+singleEntry);
                                currentEntry = undefined;
                            } else {
                                if(currentEntry) {
                                    currentEntry += ','+singleEntry;
                                } else {
                                    newEntry.push(singleEntry);
                                }
                            }
                        });
                        entry = newEntry;
                    }
                    _populateObject(object, entry, columnMetadata);
                    object.rowId = data.length;
                    data.push(object);
                    match = compositionDataRegex.exec(encodedComposition);
                }
            },
            encodeComposition: function(objectComposition, columns) {
                var compositionArray = [];
                ng.forEach(objectComposition, function(value) {
                    var tmpArray = [],
                        shouldPush = false;
                    ng.forEach(columns, function(column) {
                        if (!column.field) {
                            return;
                        }
                        if ((column.type === 'string' || column.type === 'select') && value[column.field] !== '') {
                            tmpArray.push('"' + value[column.field] + '"');
                        }
                        else {
                            tmpArray.push(value[column.field]);
                        }
                        if (value[column.field] !== undefined && value[column.field] !== null) {
                            shouldPush = true;
                        }
                    });
                    if (shouldPush === true) {
                        compositionArray.push("\"(" + _real_escape_string(tmpArray.join()) + ")\"");
                    }
                });
                return '{' + compositionArray.join() + '}';
            },
            formatTime: function(dateObject) {
                var hours = dateObject.getHours(),
                    minutes = dateObject.getMinutes(),
                    seconds = dateObject.getSeconds();
                hours = hours < 10 ? "0" + hours : hours;
                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;
                return hours + ":" + minutes + ":" + seconds;
            },
            formatDate: function(dateObject) {
                var year = dateObject.getFullYear(),
                    month = dateObject.getMonth() + 1,
                    date = dateObject.getDate();
                month = month < 10 ? "0" + month : month;
                date = date < 10 ? "0" + date : date;
                return year + "-" + month + "-" + date;
            },
            copyAttrs: function(el1, el2, exclude, attributes) {
                var $attr, i, excludeArr;
                excludeArr = ['class', 'ng-repeat'];
                attributes = attributes || {};
                if (exclude && exclude.constructor === Array) {
                    excludeArr = excludeArr.concat(exclude);
                }
                else if (exclude) {
                    excludeArr.push(exclude);
                }
                el1 = angular.element(el1);
                el2 = angular.element(el2);
                $attr = el1[0].attributes;
                for (i = 0; i < $attr.length; i++) {
                    if (!~excludeArr.indexOf($attr.item(i).nodeName)) {
                        el2.attr($attr.item(i).nodeName, $attr.item(i).nodeValue);
                    }
                    else if ($attr.item(i).nodeName === 'class') {
                        el2.addClass($attr.item(i).nodeValue);
                    }
                }
                attributes.class = attributes.class || '';
                angular.forEach(attributes.class.split(' '), function(cssClass) {
                    if (cssClass.charAt(0) === '!') {
                        el2.removeClass(cssClass.substring(1));
                    }
                    else {
                        el2.addClass(cssClass);
                    }
                });
                delete attributes.class;
                el2.attr(attributes);
                return el2;
            },
            parseBackendErrors: function(errors) {
                var message = [];
                angular.forEach(errors, function(error) {
                    message.push(error.message);
                    if (error.errors !== undefined && error.errors.length > 0) {
                        angular.forEach(error.errors, function(innerError) {
                            message.push(innerError.message);
                        });
                    }
                });
                return message;
            },
            // I've took this from elementselectorgrid.js - it can be used to generate options for icons
            // which can then be passed inside grid as options for template
            getIcon: function(type, objStates) {
                var shape, // big icon shape
                    color = "", // big icon colour
                    deferred = $q.defer(),
                    config = ""; // mini triangle icon (bottom-right)
                //type_name = this.getTypeName(type);
                if (typeof objStates === "undefined" || !objStates) {
                    return {
                        'big': 'placecard_light_grey',
                        'config': ''
                    };
                }
                // if (iconShapeMapping !== undefined && iconShapeMapping.element_type_shape_mappings !== undefined && iconShapeMapping.element_type_shape_mappings[type] !== undefined) {
                //     shape = iconShapeMapping.element_type_shape_mappings[type];
                // }
                if (objStates !== undefined) {
                    if (objStates.performanceOperationalState !== undefined) {
                        switch (objStates.performanceOperationalState) {
                        case 'deactivated':
                            color = 'dark_grey';
                            break;
                        case 'offline':
                            color = 'red';
                            break;
                        case 'online':
                            color = 'green';
                            break;
                        case 'unknown':
                            break;
                        default:
                            color = 'light_grey';
                            break;
                        }
                        // color = objStates.performance_operation_state.replace("_","-");
                    }
                    if (objStates.configUpdateState !== undefined) {
                        config = objStates.configUpdateState.replace("_", "-");
                    }
                }
                // return {
                //     'big': ([shape, color]).join('_'),
                //     'color': color,
                //     'config': config
                // };
                iconShapeMappingService.then(function(iconShapeMappingData){
                    if ( iconShapeMappingData[type] ) {
                        shape = iconShapeMappingData[type];
                        deferred.resolve({
                            'big': ([shape, color]).join('_'),
                            'color': color,
                            'config': config
                        });
                    }
                });

                return deferred.promise;
            },
            // Taken from underscore.js
            // Returns a function, that, when invoked, will only be triggered at most once
            // during a given window of time. Normally, the throttled function will run
            // as much as it can, without ever going more than once per `wait` duration;
            // but if you'd like to disable the execution on the leading edge, pass
            // `{leading: false}`. To disable execution on the trailing edge, ditto.
            throttle: function(func, wait, options) {
                var context, args, result;
                var timeout = null;
                var previous = 0;
                options || (options = {});
                var later = function() {
                    previous = options.leading === false ? 0 : $.now();
                    timeout = null;
                    result = func.apply(context, args);
                    context = args = null;
                };
                return function() {
                    var now = $.now();
                    if (!previous && options.leading === false) previous = now;
                    var remaining = wait - (now - previous);
                    context = this;
                    args = arguments;
                    if (remaining <= 0) {
                        clearTimeout(timeout);
                        timeout = null;
                        previous = now;
                        result = func.apply(context, args);
                        context = args = null;
                    }
                    else if (!timeout && options.trailing !== false) {
                        timeout = setTimeout(later, remaining);
                    }
                    return result;
                };
            },
            //This function only exists for backwards compatibility!
            checkTemplatePath: function(path) {
                if (!path.match(/^template/) && !path.match(/^\//)) {
                    console.warn('Path for a template should start with \'template/\' unless it starts with / or //');
                    path = 'template/' + path;
                }
                return path;
            },
            // Check for Emptiness of the variable passed. It could be an object, Array, a string etc.
            isEmpty: function(data) {
                var count = 0;
                // Number or Boolean are non-empty of course.
                if (typeof(data) == 'number' || typeof(data) == 'boolean') {
                    return false;
                }
                if (typeof(data) == 'undefined' || data === null) {
                    return true;
                }
                if (typeof(data.length) != 'undefined') {
                    return data.length == 0;
                }
                // For Object, check its keys.length to see if its empty object or not
                if (typeof(data) == 'object') {
                    return Object.keys(data).length === 0;
                }
                return count == 0;
            }
        };
    }]);
});