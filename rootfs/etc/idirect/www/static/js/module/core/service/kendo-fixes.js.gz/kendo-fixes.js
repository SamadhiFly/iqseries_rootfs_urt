define( [ 'kendoLib', 'underscore' ], function ( kendo, _ ) {
    'use strict';
    var defaultPageSize = 10; // using hardcoded value here to avoid circular dependency if we'd read it from web service

    function moveProperties( from, to ) {
        var exclude = [ "length", "name", "arguments", "caller", "prototype", "fn" ];
        Object.getOwnPropertyNames( from ).forEach( function ( prop ) {
            if ( !~exclude.indexOf( prop ) ) {
                to[ prop ] = from[ prop ];
            }
        } );
    }

    kendo.ui.Tooltip.prototype.render = function () {
        this._rendering = true;
        this.show();
        this.hide();
        this._rendering = false;
    };

    kendo.ui.VirtualScrollable.prototype._scroll = function ( e ) {
        var that = this,
            math = Math,
            scrollTop = e.currentTarget.scrollTop,
            dataSource = that.dataSource,
            rowHeight = that.itemHeight,
            skip = dataSource.skip() || 0,
            start = that._rangeStart || skip,
            height = that.element.innerHeight(),
            isScrollingUp = !!( that._scrollbarTop && that._scrollbarTop > scrollTop ),
            mathFun = isScrollingUp ? math.ceil : math.floor,
            firstItemIndex = math.max( mathFun( scrollTop / rowHeight ), 0 ),
            lastItemIndex = math.max( firstItemIndex + mathFun( height / rowHeight ), 0 );
        if ( that.oldHeight === height || that.oldHeight === undefined ) {
            that._scrollTop = scrollTop - ( start * rowHeight );
            that._scrollbarTop = scrollTop;
            if ( dataSource.pageSize() != defaultPageSize && ( lastItemIndex > start + dataSource.pageSize() || firstItemIndex < start ||  ( isScrollingUp && firstItemIndex <= start && start != 0 ) || ( !isScrollingUp && lastItemIndex >= start + dataSource.pageSize() && lastItemIndex < dataSource._data.length ) ) ) {
                if ( !that.spinnerTimeout ) {
                    $( this.element ).spin();
                    that.spinnerTimeout = setTimeout( function () {
                        $( that.element ).spin( false );
                        that.spinnerTimeout = false;
                    }, 500 );
                }
            }
            if ( !that._fetch( firstItemIndex, lastItemIndex, isScrollingUp ) ) {
                that.wrapper[ 0 ].scrollTop = that._scrollTop;
            }
        }
        that.oldHeight = height;
    };

    ( function extendDataSource() {
        var dsOriginalProto = kendo.data.DataSource.prototype,
            dsOriginal = kendo.data.DataSource;

        kendo.data.DataSource = kendo.data.DataSource.extend( {
            init: function ( options ) {
                dsOriginalProto.init.apply( this, arguments );
                this._selected = [];
                this.id = options && options.id || Math.random().toString( 36 ).substring( 2 );

                if ( options && options.transport ) {
                    this.remote = true;
                } else {
                    this.remote = false;
                }
            },
            getIdField: function () {
                try {
                    return this.options.schema.model.id;
                } catch ( e ) {
                    return 'uid';
                }
            },
            filteredData: function () {
                var data = this.data(),
                    filters = this.filter(),
                    sorting = this.sort() || [],
                    query = new kendo.data.Query( data );

                if ( this._registeredFilters ) {
                    filters = {
                        logic: 'and',
                        filters: []
                    };
                    _.each( this._registeredFilters, function ( filter ) {
                        if ( !filter.serverFiltering ) {
                            filters.filters.push( filter.filter );
                        }
                    } );
                }

                return query.sort( sorting ).filter( filters ).data;
            },
            get: function ( ids ) {
                var idField, obtained, data;

                if ( !_.isArray( ids ) ) {
                    return dsOriginalProto.get.apply( this, arguments );
                } else {
                    try {
                        idField = this.options.schema.model.id;
                        data = this.data();
                        obtained = _.filter( data, function ( item ) {
                            var found = false;
                            _.find( ids, function ( id ) {
                                //Sometimes ids are numbers stored as strings
                                if ( id == item[ idField ] ) {
                                    found = true;
                                    return true;
                                }
                            } );
                            return found;
                        } );

                        return obtained.length > 0 ? obtained : undefined;
                    } catch ( e ) {
                        return undefined;
                    }
                }
            },
            getByUid: function ( ids ) {
                var obtained, data;

                if ( !_.isArray( ids ) ) {
                    return dsOriginalProto.getByUid.apply( this, arguments );
                } else {
                    try {
                        data = this.data();
                        obtained = _.filter( data, function ( item ) {
                            return ~ids.indexOf( item.uid );
                        } );

                        return obtained.length > 0 ? obtained : undefined;
                    } catch ( e ) {
                        return undefined;
                    }
                }
            },
            selectedUids: function () {
                return _.pluck( this.selected(), 'uid' );
            },
            selectedIds: function () {
                return this._selected.concat();
            },
            selected: function () {
                var data = this._initalServerData || this.filteredData(),
                    selected = this._selected,
                    idField = this.getIdField();

                return _.filter( data, function ( item ) {
                    return ~selected.indexOf( item[ idField ] );
                } );
            },
            amountOfSelected: function () {
                return this._selected.length;
            },
            deselectView: function () {
                var view = this.view(),
                    idField = this.getIdField();

                view = _.pluck( view, idField );

                this.deselect( view );
            },
            selectView: function () {
                var view = this.view(),
                    idField = this.getIdField();

                view = _.pluck( view, idField );

                this.select( view );
            },
            select: function ( ids, options ) {
                var data, filter, selectionFilter, idField = this.getIdField(),
                    selected, clear, toggle, force, callback, dsOptions, initialFilter;

                dsOptions = this.options || {};
                initialFilter = dsOptions.initialFilter || {};
                initialFilter = initialFilter.filter;
                options = options || {};
                clear = options.clear;
                toggle = options.toggle;
                force = options.force;
                callback = options.callback || _.noop;

                data = this.get( ids );

                if ( force === true && this.remote && idField !== 'uid' && ids.length > 0 ) {
                    filter = this._filter;

                    selectionFilter = {
                        _selection: true,
                        logic: 'or',
                        filters: {
                            field: idField,
                            operator: 'eq',
                            value: ids
                        }
                    };

                    this._filter = { //not thru filter function to avoid calling 'read' and auto syncing
                        logic: 'and',
                        filters: []
                    };

                    if ( initialFilter ) {
                        this._filter.filters.push( initialFilter );
                    } else {
                        this._filter.filters.push( selectionFilter );
                    }

                    this.fetch( function () {
                        this.select( ids, {
                            toggle: toggle,
                            clear: clear,
                            callback: callback
                        } );
                        this._filter = filter;
                    } );
                } else {
                    this.selectByObject( data, options );
                    callback();
                }
            },
            selectByObject: function ( data, options ) {
                var clear, toggle, selected, ids, idField = this.getIdField();

                options = options || {};
                clear = options.clear;
                toggle = options.toggle;

                if ( clear ) {
                    this._selected.length = 0;
                }

                if ( data !== undefined ) {

                    if ( !_.isArray( data ) ) {
                        data = [ data ];
                    }

                    ids = _.pluck( data, idField );
                    selected = this._selected;
                    this._selected = _.union( selected, ids );

                    if ( toggle && !clear ) {
                        this.deselect( _.intersection( selected, ids ) ); //Toggle selection
                    }
                }
            },
            selectByUid: function ( ids, options ) {
                this.selectByObject( this.getByUid( ids ), options );
            },
            deselect: function ( ids ) {
                this.deselectByObject( this.get( ids ) );
            },
            deselectByObject: function ( data ) {
                var ids, idField = this.getIdField();
                if ( data !== undefined ) {
                    if ( !_.isArray( data ) ) {
                        data = [ data ];
                    }

                    ids = _.pluck( data, idField );
                    this._selected = _.difference( this._selected, ids );
                }
            },
            deselectByUid: function ( ids ) {
                this.deselectByObject( this.getByUid( ids ) );
            },
            selectAll: function () {
                this._selected.length = 0;
                this.select( _.pluck( this.filteredData(), this.getIdField() ) );
            },
            deselectAll: function () {
                this._selected.length = 0;
            },
            selectRange: function ( start, stop, toggle ) {
                //Won't work with grouping
                var idField = this.getIdField(),
                    data = this.filteredData(),
                    selectionRange = [],
                    selectionStarted = false;

                if ( data.length ) {
                    start = start || data[ 0 ];
                    stop = stop || data[ data.length - 1 ];

                    if ( !_.isObject( start ) ) {
                        if ( idField !== 'uid' ) {
                            start = this.get( start );
                        } else {
                            start = this.getByUid( start );
                        }
                    }

                    if ( !_.isObject( stop ) ) {
                        if ( idField !== 'uid' ) {
                            stop = this.get( stop );
                        } else {
                            stop = this.getByUid( stop );
                        }
                    }

                    _.find( data, function ( item ) {
                        if ( selectionStarted ) {
                            selectionRange.push( item[ idField ] );
                            return ( start[ idField ] === item[ idField ] || stop[ idField ] === item[ idField ] );
                        } else {
                            if ( start[ idField ] === item[ idField ] ) {
                                selectionRange.push( item[ idField ] );
                                selectionStarted = true;
                            } else if ( stop[ idField ] === item[ idField ] ) {
                                selectionRange.push( item[ idField ] );
                                selectionStarted = true;
                            }
                        }
                    } );
                }

                this.select( selectionRange, toggle );
            },
        } );

        moveProperties( dsOriginal, kendo.data.DataSource );
    } )();

    return window.kendo;
} );