define( [ 'module/core',
    'text!module/core/conf/state-cache-icon-mapping.json'
 ], function ( core, iconMapping ) {
    'use strict';
    core.service( 'ManagementStateCache', [ '$interval', '$timeout', 'nmswebAPI',
        function ( $interval, $timeout, nmswebAPI ) {
            return {
                initialized: false,
                blockExpireInterval: false,
                lastUpdated: 0,
                lastRegistered: 0,
                lastElementSelectorUpdated: 0,
                cache: {},
                shouldUpdate: {},
                updateIds: [],
                element_selector_config: {},
                dataSources: {},
                iconMapping: {},
                init: function () {
                    var that = this;
                    this.initialized = true;
                    var api = new nmswebAPI();
                    this.elementRes = api.resource( 'config/element/query/?limit=undefined&obj_id__in=:obj_id', {}, {} );
                    //this.element_selector_config = JSON.parse( element_selector_config );
                    that.iconMapping = JSON.parse( iconMapping );
                    // angular.forEach( iconMapping, function ( value ) {
                    //     if ( value.type_id ) {
                    //         that.iconMapping[ value.type_id ] = value.name_mapping;
                    //     }
                    // } );
                    $interval( function () {
                        that.update( true );
                    }, 15000 );
                    $interval( function () {
                        that.clearExpired();
                    }, 40000 );
                },
                getManagementStateOptions: function ( dataSourceId ) {
                    var that = this,
                        states = {
                            'cu_state': {},
                            'po_state': {}
                        },
                        dataSource;
                    if ( that.dataSources[ dataSourceId ] ) {
                        dataSource = that.dataSources[ dataSourceId ];
                        angular.forEach( dataSource._data, function ( element ) {
                            if ( that.cache[ element.obj_id ].cu_state ) {
                                states.cu_state[ that.cache[ element.obj_id ].cu_state ] = true;
                            }
                            if ( that.cache[ element.obj_id ].po_state ) {
                                states.po_state[ that.cache[ element.obj_id ].po_state ] = true;
                            }
                        } );
                        if ( states.cu_state ) {
                            states.cu_state = Object.keys( states.cu_state );
                        }
                        if ( states.po_state ) {
                            states.po_state = Object.keys( states.po_state );
                        }
                    }
                    return states;
                },
                calculateStates: function ( obj_states ) {
                    var po_state = "",
                        cu_state = "incomplete";
                    // operational_state_id - 0: Unknown
                    // operational_state_id - 1: Online
                    // operational_state_id - 2: Offline Init
                    // operational_state_id - 3: Offline Upgrade
                    // operational_state_id - 4: Offline Fail
                    // operational_state_id - 5: Offline Reason Unknown
                    if ( obj_states.activation_state && obj_states.activation_state === "deactivated" ) {
                        po_state = "deactivated";
                    } else if ( obj_states.operational_state_id && obj_states.operational_state_id === "1" ) {
                        po_state = "online";
                    } else if ( obj_states.operational_state_id && ( obj_states.operational_state_id === "2" || obj_states.operational_state_id === "3" || obj_states.operational_state_id === "4" || obj_states.operational_state_id === "5" ) ) {
                        po_state = "offline";
                    } else {
                        po_state = "n/a";
                    }
                    if ( obj_states.hasOwnProperty( 'config_state' ) && obj_states.hasOwnProperty( 'update_state' ) ) {
                        if ( obj_states.config_state === "error" ) {
                            cu_state = "error";
                        } else if ( obj_states.config_state === "incomplete" ) {
                            cu_state = "incomplete";
                        } else if ( obj_states.config_state === "changes_pending" ) {
                            cu_state = "changes_pending";
                        } else if ( obj_states.config_state === "warning" && ( obj_states.update_state === "In Sync" || obj_states.update_state === "Unknown" || obj_states.update_state === "" ) ) {
                            cu_state = "warning";
                        } else if ( ( obj_states.config_state === "warning" || obj_states.config_state === "nominal" ) && obj_states.update_state === "Out of Sync" ) {
                            cu_state = "out_of_sync";
                        } else if ( obj_states.config_state === "nominal" && ( obj_states.update_state === "In Sync" || obj_states.update_state === "" ) ) {
                            cu_state = "nominal";
                        } else if ( obj_states.config_state === "nominal" && obj_states.update_state === "Unknown" ) {
                            cu_state = "warning";
                        } else if ( obj_states.config_state === "" ) {
                            cu_state = "";
                        }
                    }
                    return {
                        'po_state': po_state,
                        'cu_state': cu_state
                    };
                },
                calculateIconSettings: function ( states, obj_type ) {
                    var that = this,
                        shape,
                        config,
                        color;
                    if ( typeof states === "undefined" || !states ) {
                        return {
                            'shape': 'n-element-selector-status-placecard_light_grey',
                            'config': ''
                        };
                    }
                    if ( !Object.keys( that.iconMapping ).length ) {
                        //Trigger init - happens if only pre defined values have been used so far
                        that.init();
                    }
                    if ( that.iconMapping !== undefined && that.iconMapping[ obj_type ] !== undefined ) {
                        shape = that.iconMapping[ obj_type ];
                    } else {
                        shape = ""; //Default shape!?
                    }
                    switch ( states.po_state ) {
                    case 'deactivated':
                        color = 'light_grey';
                        break;
                    case 'offline':
                        color = 'red';
                        break;
                    case 'online':
                        color = 'green';
                        break;
                    case 'n/a':
                        color = 'dark_grey';
                        break;
                    default:
                        break;
                    }
                    shape = 'n-element-selector-status-' + ( [ shape, color ] ).join( '_' );
                    if ( states.cu_state !== undefined ) {
                        config = states.cu_state; // Old logic: .replace("_", "-");
                    }
                    return {
                        'shape': shape,
                        'config': config
                    };
                },
                update: function ( full ) {
                    var that = this,
                        updateIds;
                    updateIds = ( full ) ? Object.keys( this.shouldUpdate ) : this.updateIds;
                    if ( !updateIds.length ) {
                        //No elements to update
                        return;
                    }

                    if ( that.updateTimeout ) {
                        $timeout.cancel( that.updateTimeout );
                    }

                    that.updateTimeout = $timeout( function () {
                        that.updateIds = [];
                        that.elementRes.get( {
                            obj_id: updateIds.join()
                        }, function ( res ) {
                            angular.forEach( res.data, function ( value ) {
                                var states = that.calculateStates( value.obj_attributes );
                                var tmpSetting = that.calculateIconSettings( states, value.obj_type );
                                if ( !that.cache[ value.obj_id ] ) {
                                    that.cache[ value.obj_id ] = {};
                                }
                                that.cache[ value.obj_id ].shape = tmpSetting.shape;
                                that.cache[ value.obj_id ].config = tmpSetting.config;
                                that.cache[ value.obj_id ].objName = value.obj_name;
                                that.cache[ value.obj_id ].objType = value.obj_type;
                                that.cache[ value.obj_id ].po_state = states.po_state;
                                that.cache[ value.obj_id ].cu_state = states.cu_state;
                            } );
                            that.syncCacheWithElementSelectorDs();
                            that.lastUpdated = new Date().getTime();
                        } );
                    }, 100 );
                },
                resetElementSelectorFlags: function () {
                    var that = this;
                    angular.forEach( this.cache, function ( value, key ) {
                        that.cache[ key ]._isElementSelector = false;
                    } );
                },
                elementSelectorDsUpdate: function ( dsId ) {
                    var that = this,
                        tmpModel,
                        dataSource;
                    that.blockExpireInterval = true;
                    that.resetElementSelectorFlags();
                    if ( that.dataSources[ dsId ] ) {
                        dataSource = that.dataSources[ dsId ];
                        angular.forEach( dataSource._data, function ( element ) {
                            if ( !that.cache[ element.obj_id ] ) {
                                tmpModel = that.calculateIconSettings( {
                                    'po_state': element.obj_states.performance_operational_state,
                                    'cu_state': element.obj_states.config_update_state
                                }, element.type );
                                tmpModel.po_state = element.obj_states.performance_operational_state;
                                tmpModel.cu_state = element.obj_states.config_update_state;
                                that.register( element.obj_id, tmpModel, $( 'div[data-ds="' + dsId + '"]' ).data( 'nmswebElementSelectorGrid' ).options.shouldUpdate, false, true );
                            } else {
                                that.cache[ element.obj_id ]._isElementSelector = true;
                            }
                        } );
                    }
                    that.blockExpireInterval = false;
                    that.lastElementSelectorUpdated = new Date().getTime();
                    //kick off clear expired elements
                    that.clearExpired();
                },
                syncCacheWithElementSelectorDs: function () {
                    var that = this;
                    angular.forEach( that.dataSources, function ( value ) {
                        angular.forEach( value._data, function ( element, index ) {
                            if ( that.cache[ element.obj_id ] ) {
                                if ( that.cache[ element.obj_id ].cu_state ) {
                                    value._data[ index ].obj_states.config_update_state = that.cache[ element.obj_id ].cu_state;
                                }
                                if ( that.cache[ element.obj_id ].po_state ) {
                                    value._data[ index ].obj_states.performance_operational_state = that.cache[ element.obj_id ].po_state;
                                }
                            }
                        } );
                        if ( value._initalServerData ) {
                            angular.forEach( value._initalServerData, function ( element, index ) {
                                if ( that.cache[ element.obj_id ] ) {
                                    if ( that.cache[ element.obj_id ].cu_state ) {
                                        value._initalServerData[ index ].obj_states.config_update_state = that.cache[ element.obj_id ].cu_state;
                                    }
                                    if ( that.cache[ element.obj_id ].po_state ) {
                                        value._initalServerData[ index ].obj_states.performance_operational_state = that.cache[ element.obj_id ].po_state;
                                    }
                                }
                            } );
                        }
			//Commenting this fixes reload issue in orgchart and ES but breaks management state grid filter updates
                        //value._doClientSideFiltering();
                    } );
                },
                clearExpired: function () {
                    var that = this;
                    if ( !that.blockExpireInterval ) {
                        angular.forEach( that.cache, function ( value, key ) {
                            if ( !value._isElementSelector && ( ( value._expire && value._expire < new Date().getTime() ) || value._expire === 0 ) ) {
                                //Element has expired
                                delete that.cache[ key ];
                                delete that.shouldUpdate[ key ];
                            }
                        } );
                    }
                },
                addExpire: function ( elementId, msDelay ) {
                    if ( !msDelay ) {
                        msDelay = 300000;
                    }
                    if ( this.cache[ elementId ] && !this.cache[ elementId ]._expire && this.cache[ elementId ]._expire !== 0 ) {
                        this.cache[ elementId ]._expire = ( new Date().getTime() ) + msDelay;
                    }
                },
                registerDataSource: function ( dataSource ) {
                    var that = this;
                    if ( !that.dataSources[ dataSource.id ] ) {
                        that.dataSources[ dataSource.id ] = dataSource;
                    }
                },
                register: function ( element_id, model, should_update, no_initial_value, is_element_selector ) {
                    var that = this;
                    if ( !this.initialized ) {
                        this.init();
                    }
                    that.lastRegistered = new Date().getTime();
                    if ( !this.cache[ element_id ] ) {
                        if ( is_element_selector ) {
                            model._expire = 0; // if it's a new entry for the ES then it should expire once removed from the ES DS
                            model._isElementSelector = true;
                        }
                        this.cache[ element_id ] = model;
                        if ( should_update ) {
                            this.shouldUpdate[ element_id ] = true;
                        }
                        if ( no_initial_value ) {
                            //Add element_id for immidiate incremental cache update
                            this.updateIds.push( element_id );
                        }
                    } else {
                        if ( should_update ) {
                            this.shouldUpdate[ element_id ] = true;
                        } else if ( this.shouldUpdate[ element_id ] ) {
                            delete this.shouldUpdate[ element_id ];
                        }
                        angular.forEach( model, function ( value, key ) {
                            model[ key ] = that.cache[ element_id ][ key ];
                        } );
                        if ( is_element_selector ) {
                            model._isElementSelector = true;
                        } else {
                            model._expire = false; // Reset expire count if the element has just been registered again
                        }
                        // that.cache[ element_id ] = $.extend( this.cache[ element_id ], model );
                        model = that.cache[ element_id ];
                    }
                    this.update();
                }
            };
    } ] );
} );
