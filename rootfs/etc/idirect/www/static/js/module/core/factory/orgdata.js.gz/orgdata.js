define( [ 'angular', 'module/core', 'module/core/factory/api' ], function ( ng, core ) {
    'use strict';
    /**
     * @ngdoc factory
     * @name core.factory:Orgdata
     * @description: Resource API used by Orgchart-datasource.
     * Implements query / takes ids parameters.
     * Returns Orgdata object
     */
    core.factory( 'Orgdata', [ 'nmswebAPI',
        function ( nmswebAPI ) {
            function Orgdata() {
                var api = new nmswebAPI();
                return api.resource( 'config/element/orgchart?obj_id=:ids', {}, {
                    query: {
                        method: 'GET',
                        headers: {
                            'Use-cookie': true
                        }
                    },
                    params: {
                        ids: '@ids'
                    }
                } );
            }
            return Orgdata;
    } ] );
} );