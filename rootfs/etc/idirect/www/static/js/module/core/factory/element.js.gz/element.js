define( [ 'angular', 'module/core', 'module/core/factory/api', 'module/core/service/nmsweb-notification', 'module/core/service/nmsutils' ], function ( ng, core ) {
    'use strict';
    core.factory( 'Element', [ 'nmswebAPI', 'NMSWebNotification', 'NMSUtils', '$location', '$q',
        function ( nmswebAPI, NMSWebNotification, NMSUtils, $location, $q ) {
            //Still I am looking for the 5th one... With Bruce.
            function Element( element, options ) { // options can have custom interceptor and transformRequest
                var params, addParams = {},
                    api, ret;
                options = options ? options : {};
                if ( element === undefined ) {
                    element = ':element';
                    addParams = {
                        element: '@element'
                    };
                } else if ( typeof element !== 'string' ) {
                    throw 'The new element must be described with string';
                }
                params = ng.extend( addParams, {
                    id: '@obj_id'
                } );
                api = new nmswebAPI();

                function removeElements( data ) {
                    // we shouldn't transform data itself (because it will change sent model)
                    var transformedData = ng.copy( data );
                    delete transformedData.element;
                    delete transformedData.obj_id;
                    return JSON.stringify( transformedData );
                }
                var notificationInterceptor = {
                    responseError: function ( response ) {
                        if ( response.data.errors ) {
                            angular.forEach( response.data.errors, function ( error ) {
                                NMSWebNotification.add( {
                                    type: "majorwarning",
                                    isFadeable: true,
                                    title: "An error occured whilst saving",
                                    message: NMSUtils.parseBackendErrors( error.errors )
                                }, "body" );
                            } );
                        }
                        return response;
                    },
                    response: function ( response ) {
                        NMSWebNotification.add( {
                            type: "success",
                            isFadeable: true,
                            title: "Save successful",
                            message: response.data.data.obj_name + " saved successfully"
                        }, "body" );
                        return response;
                    }
                };
                var notfoundInterceptor = {
                    responseError: function ( response ) {
                        if ( response.status === 404 ) {
                            $location.url( '/http-404' );
                            $( '.n-overlay .overlay' ).css( 'visibility', 'hidden' ).spin( false );
                            return $q.reject( response );
                        }
                        return $q.reject( response );
                    }
                };
                ret = api.resource( 'config/element/' + element + '/:id', {
                    limit: 0
                }, {
                    query: { //To query elements
                        method: 'GET',
                        headers: {
                            'Use-Cookie': 'true'
                        },
                        params: {
                            query_activedb: '@query_activedb',
                            limit: '@limit',
                            skip: '@skip'
                        }
                    },
                    add: { //To add element
                        method: 'POST',
                        headers: {
                            'Use-Cookie': 'true'
                        },
                        params: addParams,
                        transformRequest: removeElements,
                        interceptor: options.interceptor ? options.interceptor : notificationInterceptor
                    },
                    save: { //To save whole existing element
                        method: 'PUT',
                        headers: {
                            'Use-Cookie': 'true'
                        },
                        params: params,
                        interceptor: options.interceptor ? options.interceptor : notificationInterceptor
                    },
                    update: { //To update part of element
                        method: 'PATCH',
                        headers: {
                            'Use-Cookie': 'true'
                        },
                        params: params,
                        transformRequest: removeElements,
                        interceptor: options.interceptor ? options.interceptor : notificationInterceptor
                    },
                    // schema: { //To get information about element
                    //  method: 'GET',
                    //  url: '/api/1.0/config/element/meta/' + element
                    // }
                    schema: { //To get information about element
                        method: 'OPTIONS',
                        headers: {
                            'Use-Cookie': 'true'
                        },
                        interceptor: notfoundInterceptor
                    }
                } );
                ret.resource = element.replace( /^:/, '' );
                return ret;
            }
            return Element;
    } ] );
} );