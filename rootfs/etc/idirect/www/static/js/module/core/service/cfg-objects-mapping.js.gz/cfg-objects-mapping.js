define( [ 'module/core', 'angular', 'module/core/factory/api' ], function ( core, ng, api ) {
    'use strict';
    core.service( 'CfgObjectsMapping', [ '$q', 'nmswebAPI', '$timeout', function ( $q, NmswebAPI, $timeout ) {
        var api = new NmswebAPI(),
            cfgObjectsMapping,
            cfgObjectsMappingResource = api.resource( 'config/cfgobjectsmapping', {}, {
                get: {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'Use-Cookie': 'true'
                    }
                }
            } );
        var deffered = $q.defer(),
            dataReady = false;

        return {
            getCfgObjectMapping: function () {
                // this way it will query BE only once per browser window
                if ( dataReady ) {
                    $timeout( function () {
                        deffered.resolve( cfgObjectsMapping );
                    }, 1 );
                } else {
                    cfgObjectsMappingResource.get( function ( response ) {
                        cfgObjectsMapping = response.data[ 0 ];
                        Object.keys( cfgObjectsMapping ).forEach( function ( key ) {
                            if ( cfgObjectsMapping[ key ].url_override ) {
                                cfgObjectsMapping[ cfgObjectsMapping[ key ].url_override.toUpperCase() ] = cfgObjectsMapping[ key ];
                            }
                            cfgObjectsMapping[ cfgObjectsMapping[ key ].type_id ] = key.toUpperCase();
                            if ( cfgObjectsMapping[ key ].type_id == "612" ) { // using == on purpose
                                // hardcode to be able to use userrole and usergroup
                                cfgObjectsMapping[ cfgObjectsMapping[ key ].type_id ] = [ cfgObjectsMapping[ cfgObjectsMapping[ key ].type_id ] ];
                                cfgObjectsMapping[ cfgObjectsMapping[ key ].type_id ].push( 'USERROLE' );
                                cfgObjectsMapping.USERROLE = $.extend( {}, cfgObjectsMapping[ key ] );
                                cfgObjectsMapping.USERROLE.ui_display = 'User Role';
                                cfgObjectsMapping.USERROLE.ui_display_plural = 'User Roles';
                            }
                        } );
                        dataReady = true;
                        deffered.resolve( cfgObjectsMapping );
                    } );
                }
                return deffered.promise;
            }
        };
    } ] );
} );