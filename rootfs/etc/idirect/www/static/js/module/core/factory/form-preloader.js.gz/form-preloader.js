define( [ 'angular',
    'jquery',
    'module/core',
    'text!templates/nmsweb/module/core/factory/preloader.tpl',
    'module/core/directive/preloader',
    'module/core/service/nmsutils'
 ], function ( ng, $, core, template ) {
    "use strict";
    var hooks = [ 'schema', 'layout', 'model', 'render', 'submission', 'success', 'failure', 'toggle', 'multiSubmit' ],
        statics = [ 'schema', 'fields', 'layout', 'contents' ];
    core.factory( 'FormPreloader', [ 'NMSUtils', '$compile',
        function ( NMSUtils, $compile ) {
            return function ( options, params, callback ) {
                var preloader = {
                    dependencies: {},
                    params: {},
                    compile: function ( scope, element ) {
                        var newScope = scope.$new( true ),
                            callback = this.callback;
                        element = ng.element( element );
                        element.append( template );
                        if ( typeof callback === 'function' ) {
                            callback = [ 'params', callback ];
                        } else if ( callback && callback.constructor === Array ) {
                            preloader.callback = callback;
                        } else {
                            preloader.callback = $.noop;
                        }
                        newScope.options = {
                            dependencies: this.dependencies,
                            params: this.params,
                            callback: this.callback
                        };
                        return $compile( template )( newScope );
                    },
                    setCallback: function ( callback ) {
                        this.callback = callback;
                    }
                };
                ng.extend( preloader.params, params );
                options = options || {};
                preloader.callback = callback || $.noop;
                //If a template is not a path to an external file it should be passed wrapped with angular.element or with jQuery's $
                if ( typeof options.template === 'string' ) {
                    preloader.dependencies.template = 'text!' + NMSUtils.checkTemplatePath( options.template ) + '.tpl';
                } else if ( options.template !== undefined ) {
                    preloader.params.template = options.template;
                }
                if ( typeof options.hook === 'string' ) {
                    preloader.dependencies.hook = options.hook;
                } else {
                    preloader.params.hook = {};
                    if ( options.hook ) {
                        angular.forEach( hooks, function ( hookName ) {
                            if ( typeof options.hook[ hookName ] === 'string' ) {
                                if ( !preloader.dependencies.hook ) {
                                    preloader.dependencies.hook = {};
                                }
                                preloader.dependencies.hook[ hookName ] = options.hook[ hookName ];
                            } else if ( options.hook[ hookName ] === undefined ) {
                                preloader.params.hook[ hookName ] = $.noop;
                            } else if ( typeof options.hook[ hookName ] === 'function' || options.hook[ hookName ].constructor === Array ) {
                                preloader.params.hook[ hookName ] = options.hook[ hookName ];
                            }
                        } );
                    }
                }
                //Check if schema, fields or layout are paths to external files, if so add them to the dependency list
                angular.forEach( statics, function ( key ) {
                    if ( typeof options[ key ] === 'string' ) {
                        preloader.dependencies[ key ] = 'text!' + options[ key ] + '.json';
                    } else if ( options[ key ] !== undefined ) {
                        preloader.params[ key ] = options[ key ];
                    }
                } );
                return preloader;
            };
        } ] );
} );