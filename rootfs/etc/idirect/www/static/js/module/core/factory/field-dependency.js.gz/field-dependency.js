define( [ 'angular', 'module/core', 'module/core/factory/api', 'module/core/service/nmsweb-notification', 'module/core/service/nmsutils' ], function ( ng, core ) {
    'use strict';
    core.factory( 'FieldDependency', [ 'nmswebAPI',
        function ( nmswebAPI ) {
            //Still I am looking for the 5th one... With Bruce.
            function FieldDependency( element ) { // options can have custom interceptor and transformRequest
                var ret,
                    api = new nmswebAPI();
                ret = api.resource( 'config/element/' + element + '/dependency', {}, {
                    query: { //To query elements
                        method: 'GET'
                    }
                } );
                ret.resource = element.replace( /^:/, '' );
                return ret;
            }
            return FieldDependency;
        } ] );
} );