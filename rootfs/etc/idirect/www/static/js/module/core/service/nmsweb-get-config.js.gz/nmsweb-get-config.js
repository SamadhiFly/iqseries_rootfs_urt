define( [ 'module/core', 'angular', 'module/core/factory/configuration-query' ], function ( core, ng ) {
    'use strict';
    core.service( 'NMSWebGetConfig', [ '$q', 'nmswebAPI', '$timeout', 'ConfigurationQuery',
        function ( $q, NmswebAPI, $timeout, ConfigurationQuery ) {
            var cache = {},
                masterRequests = {},
                configurationResource = new ConfigurationQuery();

            return {
                /**
                 * @param path - JSON-like path of an object in *-fe-components.json
                 * @return deferred {Object} - Resolves when located in cache or factory method resolves.
                 */
                getConfiguration: function ( path ) {
                    var deferred = $q.defer();
                    // this way it will query BE only once per browser window
                    // could duck-type the cache variable, but could run into issues if a fe-component JSON key in the future
                    // matches what I test for ($promise).
                    if ( undefined !== cache[ path ] ) {
                        deferred.resolve( cache[ path ] );
                    } else {
                        //detect if there is already an ongoing request to the same path. If so, wait for the promise to resolve
                        //and then access the cache.
                        if ( typeof ( masterRequests[ path ] ) !== 'undefined' ) {
                            masterRequests[ path ].$promise.then( function () {
                                deferred.resolve( cache[ path ] );
                            } );
                        } else {
                            masterRequests[ path ] = configurationResource.get( {
                                    path: path
                                },
                                function ( response ) {
                                    cache[ path ] = response.data;
                                    deferred.resolve( cache[ path ] );
                                } );
                        }
                    }
                    return deferred.promise;
                }
            };
    } ] );
} );