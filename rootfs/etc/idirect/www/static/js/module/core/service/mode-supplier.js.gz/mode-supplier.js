define( [ 'module/core' ], function ( core ) {
    'use strict';
    core.service( 'ModeSupplier', [ '$http', '$q', function ( $http, $q ) {
        return {
            applyMode: function ( module, type, mode, modeObj ) {
                var modesMapping = $http.get( '/static/js/module/' + module + '/conf/modes.json' ),
                    merge = $q.defer(),
                    dataReady = false;
                modesMapping.success( function ( response ) {
                    var modeJSON = response;
                    if ( typeof modeJSON === 'string' ) {
                        modeJSON = JSON.parse( modeJSON );
                    }
                    dataReady = true;
                    if ( modeJSON[ type ] && modeJSON[ type ][ mode ] ) {
                        $.extend( true, modeObj, modeJSON[ type ][ mode ] );
                        merge.resolve( modeObj );
                    } else {
                        merge.resolve( modeObj );
                    }
                } );
                return merge.promise;
            }
        };
    } ] );
} );