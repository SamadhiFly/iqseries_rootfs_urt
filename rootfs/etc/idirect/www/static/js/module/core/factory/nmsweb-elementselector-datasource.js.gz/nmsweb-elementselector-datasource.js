define( [ 'angular', 'kendo', 'module/core', 'underscore' ], function ( ng, kendo, core, _ ) {
    'use strict';

    /**
     * @ngdoc factory
     * @name core.factory:NmswebElementselectorDatasource
     * @description Provided data source that will be shared amongst all elementselector components
     *
     * In this moment dataSource will be instance of Kendo DataSource and it will have all properties of it. This factory will extend features of kendo's datasource by allowing dynamic change of filters which would trigger immediate filtering
     * More details here: http://docs.telerik.com/kendo-ui/api/javascript/data/datasource.
     */
    core.factory( 'NmswebElementselectorDatasource', [ 'nmswebAPI', '$timeout', '$rootScope',
        function ( nmswebAPI, $timeout, $rootScope ) {
            var defaultPageSize = 10,
                api = new nmswebAPI();
            return {
                /**
                 * @ngdoc method
                 * @name init
                 * @methodOf core.factory:NmswebElementselectorDatasource
                 * @description Returns instance of datasource with expanded possibilities
                 * @param {Object} options - option parameters.
                 * @param {boolean} options.serverAggregates - If set to true the data source will leave the aggregate calculation to the remote service. By default the data source calculates aggregates client-side (default: false)
                 * @param {boolean} options.serverFiltering - If set to true the data source will leave the filtering implementation to the remote service. By default the data source performs filtering client-side (default: true)
                 * @param {boolean} options.serverGrouping - If set to true the data source will leave the grouping implementation to the remote service. By default the data source performs grouping client-side (default: false)
                 * @param {boolean} options.serverPaging - If set to true the data source will leave the data item paging implementation to the remote service. By default the data source performs paging client-side (default: false)
                 * @param {boolean} options.serverSorting - If set to true the data source will leave the data item sorting implementation to the remote service. By default the data source performs sorting client-side (default: false)
                 * @param {boolean} options.filterOnRegister - If set to true the data source will trigger filtering each time new filter is being registered, otherwise filterReady will have to be called when we want our filtering and watch over filters to start (default: true)
                 * @param {object} schema - The configuration used to parse the remote service response (more details here http://docs.telerik.com/kendo-ui/api/javascript/data/datasource#configuration-schema)
                 * @example
                 * var opts = {
                            initialFilter: {
                                filter: {
                                    logic: 'or',
                                    filters: [
                                        {
                                            field: 'obj_typeid',
                                            operator: 'eq',
                                            value: '101,102'
                                        }
                                    ]
                                }
                            },
                            filterOnRegister : false
                        },

                    var dataSource = NmswebElementselectorDatasource.init( opts );

                    After calling dataSource.read() or registering new filter request will be triggered toward elementselector Web Service with encoded initial filter
                 */
                init: function ( options ) {
                    var dataSource,
                        timeoutWatcher,
                        $scope = $rootScope.$new( true ),
                        defaults = {
                            pageSize: defaultPageSize, // using hardcoded value here to avoid race condition if we'd read it from web service
                            serverAggregates: false,
                            serverFiltering: true,
                            serverGrouping: false,
                            serverPaging: false,
                            serverSorting: false,
                            filterOnRegister: true, // if set to false, it will trigger filtering once filtersReady is called
                            schema: {
                                model: {
                                    fields: {
                                        obj_id: {
                                            type: 'text'
                                        },
                                        obj_name: {
                                            type: 'text'
                                        },
                                        obj_typeid: {
                                            type: 'text'
                                        }
                                    },
                                    id: 'obj_id'
                                }
                            },
                            transport: {
                                read: function ( params ) {
                                    var filterWith, queryID = params.data.queryID;
                                    delete params.data.queryID;
                                    // since we are not using kendo's native get (just pass in URL and data)
                                    // because we want to use Angular's $http to support testing
                                    // we need to join params ourself
                                    // join initial filter AND whatever comes in as a filter
                                    if ( params && params.data && params.data.filter !== undefined ) {
                                        filterWith = params.data;
                                    } else {
                                        filterWith = $.extend( true, {}, defaults.initialFilter );
                                    }
                                    var elementselectorResource = api.resource( 'config/element/elementselector?' + $.param( filterWith ), {}, {} );
                                    dataSource.trigger( 'nmsweb:dataSourceServerFilteringStarted' );
                                    elementselectorResource.get( {}, function ( response ) {
                                        if ( queryID === dataSource._lastID || queryID === undefined ) {
                                            if ( options.transportReadHook ) {
                                                options.transportReadHook( dataSource, params, response.data );
                                            } else {
                                                // this will be used for client side filtering
                                                dataSource._initalServerData = response.data;
                                                params.success( response.data );
                                                dataSource._doClientSideFiltering();
                                                dataSource._requestInProgress = false;
                                                dataSource.trigger( 'nmsweb:dataSourceServerFilteringDone', response.data );
                                            }
                                        }
                                    }, function ( response ) {
                                        if ( queryID === dataSource._lastID || queryID === undefined ) {
                                            params.error( [] );
                                            dataSource._requestInProgress = false;
                                            dataSource.trigger( 'nmsweb:dataSourceServerFilteringDone', response );
                                            dataSource.trigger( 'nmsweb:errorWhileGettingData', response );
                                        }
                                    } );
                                }
                            }
                        },
                        registerWatch = function ( dataSource, filter, name, callback ) {
                            dataSource._filterWatchers[ name ] = $scope.$watch( function () {
                                return filter;
                            }, function ( newValue, oldValue ) {
                                if ( newValue !== undefined && ( newValue !== oldValue || dataSource._filterOnRegister === true ) ) {
                                    dataSource._registeredFilters[ name ].filter = newValue;
                                    if ( dataSource._registeredFilters[ name ].serverFiltering === true ) {
                                        dataSource._doServerSideFiltering( callback );
                                    } else {
                                        dataSource._doClientSideFiltering();
                                    }
                                }
                            }, true );
                        };
                    $.extend( true, defaults, options );

                    dataSource = new kendo.data.DataSource( defaults );
                    dataSource._filterOnRegister = defaults.filterOnRegister;
                    dataSource._registeredFilters = {};
                    dataSource._filterWatchers = {};
                    dataSource.id = options.id || Math.random().toString( 36 ).substring( 2 );

                    dataSource._doClientSideFiltering = function () {
                        var tmpServerFiltering,
                            query,
                            filteredData;
                        tmpServerFiltering = dataSource.options.serverFiltering;
                        dataSource.options.serverFiltering = false;
                        var filterWith = [];
                        ng.forEach( dataSource._registeredFilters,
                            function ( filter ) {
                                if ( filter.serverFiltering === false ) {
                                    filterWith.push( filter.filter );
                                }
                            } );
                        var currentData = dataSource.data();
                        if ( dataSource._initalServerData && dataSource._initalServerData.length > 0 && currentData.length > 0 ) {
                            // no need to doing client filtering if server filtering returned 0 elements
                            dataSource.filter( filterWith );
                            query = new window.kendo.data.Query( dataSource._initalServerData );
                            filteredData = query.filter( dataSource.filter() ).data;
                            dataSource.data( filteredData );
                        } else if ( dataSource._initalServerData === undefined && tmpServerFiltering === false ) {
                            // it means serverFiltering was never done => it's client filtering only datasource (not likely to use it, but just in case)
                            // set it for next time
                            dataSource._initalServerData = dataSource.data();
                            dataSource.filter( filterWith );
                            query = new window.kendo.data.Query( dataSource._initalServerData );
                            filteredData = query.filter( dataSource.filter() ).data;
                            dataSource.data( filteredData );
                        } else if ( currentData.length === 0 && filterWith.length === 0 && dataSource._initalServerData && dataSource._initalServerData.length > 0 ) {
                            dataSource.data( dataSource._initalServerData );
                            dataSource.filter( {} );
                        } else if ( currentData.length === 0 && filterWith.length > 0 && dataSource._initalServerData && dataSource._initalServerData.length > 0 ) {
                            dataSource.data( dataSource._initalServerData );
                            dataSource.filter( filterWith );
                            query = new window.kendo.data.Query( dataSource._initalServerData );
                            filteredData = query.filter( dataSource.filter() ).data;
                            dataSource.data( filteredData );
                        }
                        dataSource.options.serverFiltering = tmpServerFiltering;
                        dataSource.trigger( 'nmsweb:dataSourceClientFilteringDone' );
                    };

                    /**
                     * @ngdoc method
                     * @name unregisterFilter
                     * @methodOf kendo.data.DataSource
                     * @description Method removes filter from datasource
                     * @param {string}
                     *          Name of the filter we want to unregister
                     */
                    dataSource.unregisterFilter = function ( name ) {
                        var serverSideFilter;
                        if ( dataSource._registeredFilters[ name ] !== undefined ) {
                            serverSideFilter = dataSource._registeredFilters[ name ].serverFiltering || false;
                            delete dataSource._registeredFilters[ name ];
                            // unregister watcher
                            dataSource._filterWatchers[ name ]();
                            // if unregistered filter was server side filter, do new server side filter and then client side filter
                            if ( serverSideFilter ) {
                                dataSource._doServerSideFiltering();
                            }
                            // if unregistered filter was client side filter, do new client side filter
                            dataSource._doClientSideFiltering();
                        }
                    };
                    dataSource._doServerSideFiltering = function ( callback ) {
                        var self = this;
                        if ( timeoutWatcher ) {
                            $timeout.cancel( timeoutWatcher );
                        }
                        timeoutWatcher = $timeout( function () {
                            var tmpServerFiltering = dataSource.options.serverFiltering;
                            var filterWith = [];
                            dataSource.options.serverFiltering = true;
                            ng.forEach( dataSource._registeredFilters,
                                function ( filter ) {
                                    if ( filter.serverFiltering === true ) {
                                        filterWith.push( filter.filter );
                                    }
                                } );
                            filterWith.push( defaults.initialFilter.filter );
                            dataSource._lastID = _.uniqueId();
                            dataSource.query( {
                                aggregate: dataSource.aggregate(),
                                group: dataSource.group(),
                                page: dataSource.page(),
                                pageSize: dataSource.pageSize(),
                                sort: dataSource.sort(),
                                filter: filterWith,
                                queryID: dataSource._lastID
                            } ).then( function () {
                                if ( typeof ( callback ) === 'function' ) {
                                    callback.apply( self );
                                }
                            } );
                            dataSource.options.serverFiltering = tmpServerFiltering;
                            dataSource._requestInProgress = undefined;
                        }, 500 );
                    };
                    /**
                     * @ngdoc method
                     * @name registerFilter
                     * @methodOf kendo.data.DataSource
                     * @description Method registers filter which will be triggering datasource to update itself
                     * @param {object}
                     * Object with following keys/values:
                     *           name - name of the filter you want to register. IMPORTANT!!!! MUST MATCH variable name from the scope
                     *           filter - Kendo filter you want to register
                     *           serverFiltering - True if filter should do server filtering, or false if it should do client filtering (true by default)
                     */
                    dataSource.registerFilter = function ( opts ) {
                        var name = opts.name,
                            filter = opts.filter,
                            serverFiltering = opts.serverFiltering !== undefined ? opts.serverFiltering : true;
                        if ( name in dataSource._registeredFilters ) {
                            throw 'Filter with given name already exists (' + name + ')';
                        } else {
                            dataSource._registeredFilters[ name ] = {
                                filter: filter,
                                serverFiltering: serverFiltering
                            };
                            registerWatch( dataSource, filter, name, opts.callback );
                        }
                    };
                    /**
                     * @ngdoc method
                     * @name filtersReady
                     * @methodOf kendo.data.DataSource
                     * @description When we initially don't want that our filters are triggered during registration, in one moment we would want to call filtersReady so next change of filter triggers change towards server
                     */
                    dataSource.filtersReady = function () {
                        dataSource._doServerSideFiltering();
                    };
                    return dataSource;
                }
            };
 } ] );
} );