define( [ 'module/core' ], function ( core ) {
    'use strict';
    core.service( 'NMSWebValidation', [

        function () {
            var ipv6partRegex = new RegExp( "^[0-9A-Fa-f]{0,4}$" );
            return {
                isValidIpv4: function ( value ) {
                    var isValid = true;
                    if ( value !== undefined && value !== "" ) {
                        var octets = value.split( "." );
                        if ( octets.length !== 4 ) {
                            isValid = false;
                        }
                        angular.forEach( octets, function ( octetValue ) {
                            if ( !( parseInt( octetValue ) >= 0 && parseInt( octetValue ) <= 255 ) || octetValue === "" || isNaN( octetValue ) ) {
                                isValid = false;
                            }
                        } );
                    }
                    return isValid;
                },
                isValidIpv6: function ( value ) {
                    var isValid = true;
                    if ( value !== undefined && value !== "" ) {
                        var parts = value.split( ":" );
                        if ( parts.length !== 8 ) {
                            isValid = false;
                        }
                        angular.forEach( parts, function ( part ) {
                            if ( part !== "" && !ipv6partRegex.test( part ) ) {
                                isValid = false;
                            }
                        } );
                    }
                    return isValid;
                }
            };
    } ] );
} );