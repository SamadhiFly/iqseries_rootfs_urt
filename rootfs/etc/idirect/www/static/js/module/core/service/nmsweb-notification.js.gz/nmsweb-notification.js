define( [ 'angular', 'module/core', 'module/core/directive/nmsweb-notificationtray' ], function ( ng, core ) {
    'use strict';
    core.service( 'NMSWebNotification', [ function () {
        var results = [],
            compiled = false;

        return {
            add: function ( options, selector, clear ) {
                // This method aggregates all notification messages of all types
                // if clear is set, we empty the results array and don't push anything
                if ( clear ) {
                    results.length = 0;
                } else {
                    results.push( options );
                    if ( !compiled ) {
                        $( 'nmsweb-notification-tray' ).trigger( 'angularCompile' );
                        compiled = true;
                    }
                }
            },
            addSingleNotification: function ( options, selector ) {
                // This method shows a single notification of info, error or success type
                if ( !selector ) {
                    selector = "#content";
                }
                $( selector ).trigger( 'nmsweb:notify', options );
            },
            getMessages: function () {
                return results;
            }
        };
    } ] );
} );
