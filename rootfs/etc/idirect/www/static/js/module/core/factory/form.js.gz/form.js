define( [
    'jquery',
    'angular',
    'module/core',
    'module/core/directive/form',
    'module/core/service/nmsutils',
    'module/core/service/nms-sort-options',
    'module/core/factory/resources',
    'module/core/factory/form-preloader'
 ], function ( $, ng, core ) {
    'use strict';
    core.factory( 'NmswebForm', [ 'FormPreloader', 'NMSUtils', 'NMSSortOptions', 'Resources', '$q', '$routeParams', '$compile',
        function ( FormPreloader, NMSUtils, NMSSortOptions, ResourcesFactory, $q, $routeParams, $compile ) {
            var resourcesFactory = new ResourcesFactory();

            function NmswebForm( options, parent ) {
                var form, master, deferredNames = [ 'prepared', 'schema', 'layout', 'model', 'render', 'submission', 'success', 'failure' ],
                    loadSchema = false,
                    defer,
                    modelHookData,
                    toolTipsContent,
                    schemaObjRequest = {},
                    defaultOptions = {
                        errorsMap: {
                            min: 'Value should be greater than',
                            max: 'Value should be less than',
                            required: 'Field is required',
                            maxlength: 'Field length should be less than',
                            minlength: 'Field length should be greater than'
                        },
                        mode: 'add',
                        viewMode: false,
                        model: {},
                        _route: $routeParams,
                        _pdModel: {},
                        actions: [ {
                            'type': 'save',
                            'label': 'Save',
                            'redirectTo': '/config/:element/edit/:id',
                            'mode': 'add'
                        }, {
                            'type': 'close',
                            'label': 'Save and Close',
                            'redirectTo': '/obj/:element/view',
                            'mode': 'add'
                        }, {
                            'type': 'impact',
                            'label': 'Save and View Impact',
                            'redirectTo': '/config/:element/impact_analysis/:id',
                            'mode': 'add'
                        }, {
                            'type': 'save',
                            'label': 'Save',
                            'redirectTo': '/config/:element/edit/:id',
                            'mode': 'edit'
                        }, {
                            'type': 'close',
                            'label': 'Save and Close',
                            'redirectTo': '/obj/:element/view',
                            'mode': 'edit'
                        }, {
                            'type': 'impact',
                            'label': 'Save and View Impact',
                            'redirectTo': '/config/:element/impact_analysis/:id',
                            'mode': 'edit'
                        }, {
                            'type': 'save',
                            'label': 'Apply on ?? elements',
                            'redirectTo': '/obj/:element/view',
                            'mode': 'multi-edit'
                        }, {
                            'type': 'cancel',
                            'label': 'Cancel',
                            'redirectTo': '/obj/:element/view'
                        } ]
                    };

                function migrateValues( from, to, map ) {
                    ng.forEach( map, function ( masterField, slaveField ) {
                        to[ slaveField ] = from[ masterField ];
                    } );
                };
                //Helper function to find form in given path
                function findForm( path, form ) {
                    var tempName;
                    if ( path[ 0 ] !== 'parent' || path[ 0 ] === 'master' ) {
                        form = form.master;
                        path.shift();
                    }
                    while ( path.length ) {
                        tempName = path.shift();
                        if ( tempName === 'parent' ) {
                            form = form.parent;
                        } else {
                            form = form.subforms[ tempName ];
                        }
                    }
                    return form;
                };
                //Helper function to translate returned items to what JS understands
                function prepareReturnedVal( item ) {
                    item = item || {};
                    if ( item.constructor === Array ) {
                        item = item.map( prepareReturnedVal );
                    } else {
                        ng.extend( item, item.obj_attributes );
                        delete item.obj_attributes;
                        ng.forEach( item, function ( value, key ) {
                            if ( value === 't' || value === 'true' ) {
                                item[ key ] = true;
                            } else if ( value === 'f' || value === 'false' ) {
                                item[ key ] = false;
                            } else {
                                item[ key ] = value;
                            }
                        } );
                    }
                    return item;
                };

                function functionalities( form ) {
                    function reject() {
                        var args = Array.prototype.slice.call( arguments );
                        return $q.reject.apply( $q, args );
                    };
                    form.refresh = function () {
                        var form = this,
                            parentScope = form.$scope.$parent,
                            obj_ancestor_id, scope, originalElement, options;
                        if ( form.model && form.model.obj_parent_id ) {
                            obj_ancestor_id = form.model.obj_parent_id;
                        } else {
                            obj_ancestor_id = form.obj_ancestor_id;
                        }
                        scope = parentScope.$new( true );
                        originalElement = form._originalElement;
                        options = form.options;
                        options._defaultModel = form._defaultModel;
                        options.model = form.model;
                        scope.form = new NmswebForm( options );
                        delete scope.form.options.model;
                        delete scope.form.options._defaultModel;
                        scope.form.obj_ancestor_id = obj_ancestor_id;
                        form.$element.replaceWith( originalElement );
                        $compile( originalElement )( scope );
                    };
                    form.isMany = function () {
                        return ( this.relation && ~this.relation.indexOf( 'many' ) );
                    };
                    form.request = function ( model ) {
                        var deferred = $q.defer(),
                            fun, form = this,
                            subfromsCache, modelStatusCache;
                        if ( model.id !== undefined || model.obj_id !== undefined ) {
                            fun = 'update';
                            console.info( '[Form ' + form.name + '][model id: ' + model.id + '][' + fun + ']' );
                        } else {
                            fun = 'add';
                            console.info( '[Form ' + form.name + '][model][' + fun + ']' );
                        }
                        subfromsCache = model._subforms;
                        modelStatusCache = model._status;
                        delete model._subforms;
                        delete model._status;
                        $( '.n-overlay .overlay' ).css( 'visibility', 'visible' ).spin( 'large' );
                        form.resource[ fun ]( {}, model, function ( response, responseHeaders ) {
                            deferred.resolve( {
                                response: response,
                                responseHeaders: responseHeaders
                            } );
                            model._subforms = subfromsCache;
                            model._status = modelStatusCache;
                        }, function ( httpResponse ) {
                            deferred.reject( httpResponse );
                            model._subforms = subfromsCache;
                            model._status = modelStatusCache;
                            $( '.n-overlay .overlay' ).css( 'visibility', 'hidden' ).spin( 'false' );
                        } );
                        return deferred.promise.then( function ( ret ) {
                            var data = ret.response.data;
                            data = data.data || data;
                            if ( data.constructor === Array ) {
                                data = data[ 0 ];
                            }
                            ret.response.data = prepareReturnedVal( data );
                            $( '.n-overlay .overlay' ).css( 'visibility', 'hidden' ).spin( 'false' );
                            return ret;
                        }, reject );
                    };
                    form.delete = function ( id ) {
                        return form.resource.delete( {
                            obj_id: id
                        } );
                    };
                    form.send = function ( action, model ) {
                        var form = this,
                            promise, master, submissionHookData, mainDeferred, multiEditDeferreds = [],
                            multiEditPromises = [],
                            deletePromises = [],
                            subFormPromises = [],
                            isArr, multiEditSubFormPromises = [];;
                        //Create deferred object for the element submission
                        mainDeferred = $q.defer();
                        //If the model is not passed, take default/displayed data
                        if ( model === undefined ) {
                            if ( form.relation && ~form.relation.indexOf( 'many' ) ) {
                                model = form.data;
                            } else {
                                model = form.model;
                            }
                        }
                        if ( model && model.constructor === Array ) {
                            isArr = true;
                            ng.forEach( model, function ( model ) {
                                ng.forEach( model, function ( modelVal, modelKey ) {
                                    var arr = [];
                                    if ( form.fields[ modelKey ] && form.fields[ modelKey ].directive === "nmsweb-composition" ) {
                                        if ( model[ modelKey ] !== undefined ) {
                                            if ( model[ modelKey ].toJSON !== undefined && model[ modelKey ].toJSON.constructor === Function ) {
                                                model[ modelKey ] = model[ modelKey ].map( function ( el ) {
                                                    return el.toJSON();
                                                } );
                                            }
                                            if ( model[ modelKey ].constructor === Array ) {
                                                modelVal = model[ modelKey ] = NMSUtils.encodeComposition( model[ modelKey ], form.fields[ modelKey ].options.columns );
                                            } else if ( model[ modelKey ].constructor !== String ) {
                                                modelVal = '';
                                            }
                                            if ( '{}' === modelVal ) {
                                                model[ modelKey ] = '';
                                            }
                                        } else {
                                            model[ modelKey ] = '';
                                        }
                                    }
                                } );
                            } );
                        } else {
                            //Convert compositions to correct format for BE
                            ng.forEach( model, function ( modelVal, modelKey ) {
                                var arr = [];
                                if ( form.fields[ modelKey ] && form.fields[ modelKey ].directive === "nmsweb-composition" ) {
                                    if ( model[ modelKey ] !== undefined ) {
                                        if ( model[ modelKey ].toJSON !== undefined && model[ modelKey ].toJSON.constructor === Function ) {
                                            model[ modelKey ] = model[ modelKey ].map( function ( el ) {
                                                return el.toJSON();
                                            } );
                                        }
                                        if ( model[ modelKey ].constructor === Array ) {
                                            modelVal = model[ modelKey ] = NMSUtils.encodeComposition( model[ modelKey ], form.fields[ modelKey ].options.columns );
                                        } else if ( model[ modelKey ].constructor !== String ) {
                                            modelVal = '';
                                        }
                                        if ( '{}' === modelVal ) {
                                            model[ modelKey ] = '';
                                        }
                                    } else {
                                        model[ modelKey ] = '';
                                    }
                                }
                            } );
                        }
                        //Fire the submission hook
                        submissionHookData = this._hook( 'submission', {
                            action: action,
                            model: model
                        } );
                        //Returning false from the submission hook breaks the submit's chain
                        if ( submissionHookData === false ) {
                            mainDeferred.resolve( false );
                        } else {
                            //It's possible to block the default behavior of sending a form model and don't break the submit-chain
                            //Submission hook in this case returns promise
                            if ( submissionHookData && submissionHookData.preventSubmit ) {
                                promise = submissionHookData.promise;
                            } else {
                                if ( isArr ) {
                                    if ( form._toDelete !== undefined ) {
                                        while ( form._toDelete.length ) {
                                            deletePromises.push( form.delete( form._toDelete.pop() ) );
                                        }
                                    }
                                    //prepare deferred objects for models' requests
                                    multiEditDeferreds = model.map( function () {
                                        return $q.defer();
                                    } );
                                    multiEditPromises = multiEditDeferreds.map( function ( deferred ) {
                                        return deferred.promise;
                                    } );
                                    $q.all( deletePromises ).then( function () {
                                        //Gather all promises and produce one from all of them
                                        ng.forEach( model, function ( model, index ) {
                                            //Delete child form models
                                            form.request( model ).then( function ( ret ) {
                                                //Extend data models with response
                                                var foundModel = false;
                                                if ( form.models !== undefined ) {
                                                    ng.forEach( form.models, function ( formModel ) {
                                                        if ( formModel.obj_id === ret.response.data.obj_id ) {
                                                            ng.extend( formModel, ret.response.data );
                                                            foundModel = true;
                                                        }
                                                    } );
                                                }
                                                if ( foundModel === false ) {
                                                    if ( form.models === undefined ) {
                                                        form.models = [];
                                                    }
                                                    form.models.push( ret.response.data );
                                                }
                                                ng.extend( model, ret.response.data );
                                                multiEditDeferreds[ index ].resolve( ret );
                                            }, function () {
                                                multiEditDeferreds[ index ].reject();
                                            } );
                                        } );
                                    } );
                                    promise = multiEditPromises;
                                } else {
                                    promise = form.request( model ).then( function ( ret ) {
                                        ng.extend( model, ret.response.data );
                                        return ret;
                                    }, reject );
                                }
                            }
                            if ( promise && promise.constructor !== Array ) {
                                promise = [ promise ];
                            }
                            if ( promise === undefined || promise.length === 0 ) {
                                if ( submissionHookData !== undefined ) {
                                    mainDeferred.resolve( submissionHookData );
                                } else {
                                    mainDeferred.resolve( {} );
                                }
                            }
                            ng.forEach( promise, function ( promise ) {
                                if ( promise && typeof promise.then === 'function' ) {
                                    promise.then( function ( returned ) {
                                        var responses = [],
                                            responsesHeaders = [],
                                            successHookData, multi = false,
                                            modelArr, submitSubform;
                                        //Here it's a tricky part, as we can get array of responses or just one response
                                        if ( returned && returned.constructor === Array ) {
                                            ng.forEach( returned, function ( resp ) {
                                                responses.push( resp.response );
                                                responsesHeaders.push( resp.responseHeaders );
                                            } );
                                        } else {
                                            responses = returned.response;
                                            responsesHeaders = returned.responseHeaders;
                                        }
                                        if ( form.grid && form.grid.widget ) {
                                            form.grid.widget.dataSource.data( form.data );
                                        }
                                        //Now the success hook is fired, it obviously happens when the response comes back
                                        successHookData = form._hook( 'success', {
                                            response: responses,
                                            responseHeaders: responsesHeaders,
                                            action: action
                                        } ) || {};
                                        //When the success hook returns false it breaks execution of the chain
                                        if ( successHookData === false ) {
                                            //Main deferred object is resolved with false, also it prevents default action
                                            mainDeferred.resolve( false );
                                        } else {
                                            //We can prevent copy values from master form to slave forms
                                            if ( !( successHookData && successHookData.preventCopy ) && !( submissionHookData && submissionHookData.preventCopy ) ) {
                                                $q.all( successHookData.promise ).then( function () {
                                                    ng.forEach( form._affects, function ( subform, name ) {
                                                        if ( form.isMany() ) {
                                                            if ( subform.isMany() ) {
                                                                if ( model.constructor === Array ) {
                                                                    ng.forEach( model, function ( entity ) {
                                                                        if ( entity._subforms && entity._subforms[ name ] ) {
                                                                            ng.forEach( entity._subforms[ name ], function ( submodel ) {
                                                                                migrateValues( entity, submodel, subform._relations[ form.name ].fields );
                                                                            } );
                                                                        }
                                                                    } );
                                                                } else if ( subform.data !== undefined && subform.data.constructor === Array ) {
                                                                    ng.forEach( subform.data, function ( entity ) {
                                                                        ng.forEach( entity._subforms[ name ], function ( submodel ) {
                                                                            migrateValues( entity, submodel, subform._relations[ form.name ].fields );
                                                                        } );
                                                                    } );
                                                                }
                                                            } else {
                                                                ng.forEach( model, function ( entity ) {
                                                                    entity._subforms = entity._subforms || {};
                                                                    entity._subforms[ name ] = entity._subforms[ name ] || ng.copy( subform._defaultModel ) || {};
                                                                    migrateValues( entity, entity._subforms[ name ], subform._relations[ form.name ].fields );
                                                                } );
                                                            }
                                                        } else {
                                                            if ( subform.isMany() ) {
                                                                ng.forEach( model._subforms[ name ], function ( submodel ) {
                                                                    migrateValues( model, submodel, subform._relations[ form.name ].fields );
                                                                } );
                                                            } else {
                                                                migrateValues( model, model._subforms[ name ], subform._relations[ form.name ].fields );
                                                            }
                                                        }
                                                    } );
                                                    //We can prevent submission subforms of this form
                                                    if ( !( successHookData && successHookData.preventSubmitChain ) && !( submissionHookData && submissionHookData.preventSubmitChain ) ) {
                                                        //Now go thru model's subforms and send them
                                                        if ( model && model.constructor !== Array ) {
                                                            modelArr = [ model ];
                                                        } else {
                                                            modelArr = model;
                                                        }
                                                        ng.forEach( modelArr, function ( entity ) {
                                                            //In case a form has got multiple subforms which each have subforms of the same type
                                                            //it would try to patch all elements each time the subform type comes up
                                                            //this will only update the required subset
                                                            if ( responses === undefined || responses.data === undefined ) {
                                                                submitSubform = true;
                                                            } else if ( responses === Array ) {
                                                                ng.forEach( responses, function ( resp ) {
                                                                    if ( entity.obj_id == resp.data.obj_id ) {
                                                                        submitSubform = true;
                                                                    }
                                                                } );
                                                            } else {
                                                                submitSubform = entity.obj_id == responses.data.obj_id;
                                                            }
                                                            if ( submitSubform ) {
                                                                ng.forEach( entity._subforms, function ( subformModel, name ) {
                                                                    var subform = form.subforms[ name ];
                                                                    if ( subform ) {
                                                                        subFormPromises.push( subform.send( action, subformModel ) );
                                                                    }
                                                                } );
                                                            }
                                                        } )
                                                        submissionHookData = submissionHookData || {};
                                                        //When the subFormPromises array is empty, $q resolves promise straight away
                                                        $q.all( subFormPromises ).then( function ( ret ) {
                                                            if ( successHookData !== false ) {
                                                                successHookData = successHookData || {};
                                                                $.each( ret, function ( i, returned ) {
                                                                    if ( returned !== false ) {
                                                                        returned = returned || {};
                                                                        successHookData.preventRedirect = successHookData.preventRedirect || returned.preventRedirect || submissionHookData.preventRedirect;
                                                                    } else {
                                                                        successHookData = false;
                                                                        return false;
                                                                    }
                                                                } );
                                                            }
                                                            mainDeferred.resolve( successHookData );
                                                        }, function ( ret ) {
                                                            mainDeferred.reject( ret );
                                                        } );
                                                    }
                                                } );
                                            }
                                        }
                                    }, function ( httpResponse ) {
                                        if ( form.master ) {
                                            form.master._childSaveFailed = true;
                                        }
                                        mainDeferred.reject( form._hook( 'failure', {
                                            httpResponse: httpResponse,
                                            action: action
                                        } ) );
                                    } );
                                }
                            } );
                        }
                        return mainDeferred.promise;
                    };
                    form.load = function ( request, deferred ) {
                        var form = this,
                            arr = [],
                            pass, keys, i;

                        function decorate( request, form ) {
                            var filter, attrname;
                            if ( typeof ( request ) === 'number' || ( parseInt( request ) + '' === request ) ) {
                                request = {
                                    id: request
                                };
                            } else if ( request === undefined || ( request.id === undefined && request.obj_parent_id === undefined ) ) {
                                return request;
                            }
                            if ( typeof ( form.filter ) !== 'undefined' ) {
                                filter = form.filter;
                                for ( attrname in request ) {
                                    filter[ attrname ] = request[ attrname ];
                                }
                                request = filter;
                            }
                            return request;
                        }

                        function resolve( data ) {
                            if ( data && data.constructor === Array ) {
                                ng.forEach( data, function ( model ) {
                                    if ( model && model.constructor === Array ) {
                                        ng.forEach( model, function ( model ) {
                                            model._status = 'loaded';
                                        } );
                                    } else {
                                        model._status = 'loaded';
                                    }
                                } );
                            } else if ( data ) {
                                data._status = 'loaded';
                            }
                            if ( deferred && deferred.resolve ) {
                                deferred.resolve( data );
                            }
                            form.defer.loaded.promise.then( function () {
                                ng.forEach( form.tooltips, function ( tooltipValue, attributeName ) {
                                    if ( form.fields[ attributeName ] !== undefined ) {
                                        var tooltipVal = '';
                                        ng.forEach( tooltipValue, function ( attrValue, objName ) {
                                            if ( form.fields[ attributeName ].options !== undefined && form.fields[ attributeName ].options.type === 'dropdown' ) {
                                                tooltipVal += objName + ': ' + form.fields[ attributeName ].options.optionList[ attrValue ] + '<br />';
                                            } else if ( form.fields[ attributeName ].options !== undefined && form.fields[ attributeName ].options.type === 'listbox' ) {
                                                var parsedValue = '<ul>';
                                                if ( attrValue !== '' && attrValue !== '{}' ) {
                                                    var optionsSelected = attrValue.substring( 1, attrValue.length - 1 ).split( ',' );
                                                    ng.forEach( optionsSelected, function ( id ) {
                                                        parsedValue += '<li>' + form.fields[ attributeName ].options.optionList[ id ] + '</li>';
                                                    } );
                                                } else {
                                                    parsedValue += '<i>None</i>';
                                                }
                                                parsedValue += '</ul>';
                                                tooltipVal += objName + ': <br />' + parsedValue + '<br />';
                                            } else {
                                                tooltipVal += objName + ': ' + attrValue + '<br />';
                                            }
                                        } );
                                        form.fields[ attributeName ].options.tooltips = form.fields[ attributeName ].options.tooltips || [];
                                        form.fields[ attributeName ].options.tooltips.push( {
                                            'type': 'info',
                                            'title': 'Values',
                                            'content': tooltipVal.substring( 0, tooltipVal.length - 4 )
                                        } );
                                        delete form.tooltips[ attributeName ];
                                        // we are doing tooltips for all fields, check (in case of multi-edit), if field is unique, set model value to empty one
                                        // e.g. one SSPP has FAP, other one doesn't, it will try to create fap with same name for other, we don't want that because it should be unique
                                        if ( form.mode === 'multi-edit' ) {
                                            if ( form.fields[ attributeName ].options.is_unique === true ) {
                                                form.model[ attributeName ] = '';
                                                if ( form.masterModel ) {
                                                    form.masterModel[ attributeName ] = '';
                                                }
                                            }
                                        }
                                    }
                                } );
                            } );
                        }
                        if ( request && request.constructor === Array ) {
                            ng.forEach( request, function ( req, index ) {
                                var deferred = $q.defer();
                                arr.push( deferred.promise );
                                form.load( req, deferred );
                            } );
                            $q.all( arr ).then( function ( data ) {
                                resolve( data );
                            } );
                        } else if ( request ) {
                            request = decorate( request, form );
                            request.limit = request.limit || 0;
                            pass = false;
                            keys = Object.keys( request );
                            for ( i = 0; i < keys.length; i++ ) {
                                if ( request[ keys[ i ] ] !== undefined ) {
                                    pass = true;
                                }
                            }
                            if ( !pass ) {
                                return;
                            }
                            form.resource.get( request, function ( ret ) {
                                console.info( '[Form ' + form.name + '][model for id:' + request.id + '][loaded]' );
                                resolve( prepareReturnedVal( ret.data ) );
                            } );
                        }
                    };
                    //This function creates 'new' models. Basically it resets all fields to default values. Also reset index of edited entity (if there was any).
                    form._clear = function ( clearData ) {
                        var form = this;
                        ng.copy( form._defaultModel, form.model );
                        ng.forEach( form.fields, function ( fieldData, fieldKey ) {
                            if ( fieldData.directive === 'nmsweb-composition' ) {
                                fieldData.options.data.length = 0;
                                fieldData.element.find( '.n-grid.k-grid' ).data( 'kendoGrid' ).dataSource.data( [] );
                            }
                        } );
                        if ( ~form.relation.indexOf( 'many' ) ) {
                            if ( clearData ) {
                                form.data.length = 0;
                                form.grid.widget.dataSource.data( ng.copy( form.data ) );
                            }
                            clearData = true;
                        }
                        ng.forEach( form.subforms, function ( subform, name ) {
                            subform._clear( clearData );
                        } );
                    };
                    //Function which caches model into data array
                    form._cache = function ( place, model, stopPropagation ) {
                        var form = this,
                            multiple = !!( ~form.relation.indexOf( 'many' ) ),
                            localStop = false;
                        if ( place !== undefined ) {
                            if ( model === undefined || model === null ) {
                                model = form.model;
                            }
                            model._subforms = model._subforms || {};
                            if ( !stopPropagation ) {
                                if ( multiple ) {
                                    localStop = true;
                                }
                                ng.forEach( form.subforms, function ( subform, name ) {
                                    if ( ~subform.relation.indexOf( 'many' ) ) {
                                        model._subforms[ name ] = model._subforms[ name ] || [];
                                    } else {
                                        model._subforms[ name ] = model._subforms[ name ] || {};
                                    }
                                    subform._cache( model._subforms[ name ], null, localStop );
                                } );
                            }
                            if ( multiple && stopPropagation ) {
                                if ( form.data !== place ) {
                                    ng.copy( form.data, place );
                                }
                            } else {
                                ng.copy( model, place );
                            }
                            if ( multiple && !stopPropagation ) {
                                if ( form.grid && form.grid.widget ) {
                                    form.grid.widget.dataSource.data( ng.copy( form.data ) );
                                }
                            }
                        }
                    };
                    form._retrieve = function ( model, stopPropagation ) {
                        var form = this,
                            multiple = !!( ~form.relation.indexOf( 'many' ) ),
                            localStop = false,
                            data;
                        if ( model !== undefined ) {
                            if ( model.constructor === Array ) {
                                if ( form.data ) {
                                    if ( typeof form.data.toJSON === 'function' ) {
                                        data = form.data.toJSON();
                                    } else {
                                        data = form.data;
                                    }
                                    ng.copy( model, data );
                                    if ( form.grid && form.grid.widget ) {
                                        form.grid.widget.dataSource.data( data );
                                    } else {
                                        form.grid.dataSource = form.grid.dataSource || {};
                                        form.grid.dataSource.data = data;
                                    }
                                }
                            } else {
                                ng.copy( model, form.model );
                            }
                            if ( !stopPropagation ) {
                                if ( multiple ) {
                                    localStop = true;
                                }
                                model._subforms = model._subforms || {}; // jshint ignore:line
                                ng.forEach( form.subforms, function ( subform, name ) {
                                    if ( model._subforms[ name ] === undefined ) {
                                        if ( ~subform.relation.indexOf( 'many' ) ) {
                                            model._subforms[ name ] = [];
                                        } else {
                                            model._subforms[ name ] = {};
                                        }
                                    }
                                    subform._retrieve( model._subforms[ name ], localStop );
                                } );
                            }
                        }
                    }
                };
                //First extend default options with given params and assign it to 'form'
                form = ng.extend( {}, defaultOptions, options );
                form.options = $.extend( true, {}, options );
                //Add deferred objects
                form.defer = {};
                //Initiate object of models which the form affects
                form._affects = {};
                form._relations = {};
                //default redirection
                form.redirectTo = form.redirectTo || 'config/:element/edit/:id';
                //Set the mode of form (backwards compability)
                if ( form.viewMode ) {
                    form.mode = 'view'
                };
                if ( form.mode === 'view' ) {
                    form.viewMode = true;
                }
                //End of backwards compability hack
                ng.forEach( deferredNames, function ( hookName ) {
                    form.defer[ hookName ] = $q.defer();
                } );
                if ( form.fields === undefined && form.schema === undefined ) {
                    loadSchema = true;
                }
                if ( form.element ) {
                    form.resource = 'element';
                    form.spec = {
                        element: form.element,
                        options: {}
                    };
                    delete form.element;
                } else if ( form.resource === undefined && !loadSchema ) {
                    throw 'Form needs either resource, fields or schema to generate its contents';
                }
                if ( typeof form.resource === 'string' ) {
                    form.resource = form.resource.split( '-' ).map( function ( val ) {
                        return val.charAt( 0 ).toUpperCase() + val.substr( 1 );
                    } ).join( '' );
                    form.resource = resourcesFactory.create( form.resource, form.spec );
                }
                form.name = form.name || form.resource.resource || 'form';
                form.title = form.title || form.name;
                //Check if it's a subform
                if ( parent ) {
                    master = form.master = parent.master || parent;
                    form.parent = parent;
                    form._uname = parent._uname + '.' + form.name;
                    if ( form.layout === undefined ) {
                        form.layout = 'layouts/config/generic';
                    }
                } else {
                    //If not create array of pending requests
                    form._pending = [];
                    form._uname = form.name;
                }
                form.subforms = {};
                functionalities( form );
                form.preloader = new FormPreloader( form );
                //If form doesn't have fields or schema to load or straight away, obtain schema and translate it to fields from WebService
                if ( loadSchema ) {
                    if ( form.obj_ancestor_id ) {
                        schemaObjRequest.ancestor_id = form.obj_ancestor_id;
                    } else if ( master && master.obj_ancestor_id ) {
                        schemaObjRequest.obj_ancestor_id = master.obj_ancestor_id;
                    } else if ( form.id ) {
                        if ( form.master === undefined ) {
                            form.obj_ancestor_id = form.obj_ancestor_id || form.id;
                        }
                        schemaObjRequest.id = form.id;
                    }
                    form.preloader.dependencies.schema = form.resource.schema( schemaObjRequest ).$promise.then( function ( response ) {
                        if ( form._route.clone_id ) {
                            return response.POST.parameters;
                        } else {
                            return response.POST.parameters;
                        }
                    } );
                }
                form.defer.schema.promise.then( function () {
                    form._defaultModel = form._defaultModel || ng.copy( form.model );
                } );
                //When form has specified ID, load model and related objects
                if ( !parent && ( form.id === undefined || ( form.model !== undefined && form.model._status ) ) ) {
                    form.defer.prepared.promise.then( function () {
                        modelHookData = form._hook( 'model', {
                            model: form.model
                        } ) || {};
                        $q.all( modelHookData.promise ).then( function () {
                            form.defer.model.resolve( form.model );
                        } );
                    } );
                } else if ( form.id ) {
                    form.mode = 'edit';
                    defer = $q.defer();
                    defer.promise.then( function ( data ) {
                        var modelHookData;
                        ng.extend( form.model, data );
                        modelHookData = form._hook( 'model', {
                            model: form.model
                        } ) || {};
                        $q.all( modelHookData.promise ).then( function () {
                            form.defer.model.resolve( form.model );
                        } );
                    } );
                    form.load( form.id, defer );
                } else if ( parent ) {
                    form.mode = parent.mode;
                    parent.model._subforms = parent.model._subforms || {};
                    form._broken = parent._broken;
                    if ( form.isMany() ) {
                        form.data = form.data || [];
                        form._broken = true;
                        if ( !parent._broken ) {
                            parent.model._subforms[ form.name ] = parent.model._subforms[ form.name ] || form.data;
                        } else {
                            parent.model._subforms[ form.name ] = parent.model._subforms[ form.name ] || [];
                        }
                    } else {
                        if ( !parent._broken ) {
                            parent.model._subforms[ form.name ] = parent.model._subforms[ form.name ] || form.model;
                        } else {
                            parent.model._subforms[ form.name ] = parent.model._subforms[ form.name ] || {};
                        }
                    }
                    form.master.defer.render.promise.then( function () {
                        var masterFormModelPromises = [],
                            refreshing = false;
                        //When the master form is rendered it means it has loaded all subforms and requested for models
                        //Now it goes thru mapping and waits for all corresponding models to be loaded
                        $.each( form.map, function ( slaveField, masterField ) {
                            var path, masterForm, field, relation;
                            path = masterField.split( '.' );
                            field = path.pop();
                            masterForm = findForm( path, form ); //Find the corresponding form based on the path
                            if ( masterForm ) {
                                masterForm._affects[ form.name ] = form; //master form affects slave form (after master form is sent, send the slave form)
                                relation = form._relations[ masterForm.name ] || {};
                                relation.form = masterForm;
                                relation.fields = relation.fields || {};
                                relation.fields[ slaveField ] = field;
                                form._relations[ masterForm.name ] = relation;
                                form._hide = form._hide || [];
                                form._hide.push( slaveField );
                            }
                        } );
                        //Subforms model loading
                        if ( !parent._broken && parent.model._subforms[ form.name ] && ( parent.model._subforms[ form.name ].length || parent.model._subforms[ form.name ]._status ) ) {
                            if ( form.isMany() ) {
                                form.data = parent.model._subforms[ form.name ];
                            } else {
                                form.model = parent.model._subforms[ form.name ];
                            }
                            refreshing = true;
                        }
                        if ( refreshing || ( form.mode !== 'edit' && form.mode !== 'multi-edit' ) ) {
                            form.defer.prepared.promise.then( function () {
                                if ( form.isMany() ) {
                                    modelHookData = form._hook( 'model', {
                                        model: form.master.model
                                    } ) || {};
                                    $q.all( modelHookData.promise ).then( function () {
                                        form.defer.model.resolve( form.data );
                                    } );
                                } else {
                                    modelHookData = form._hook( 'model', {
                                        model: form.master.model
                                    } ) || {};
                                    $q.all( modelHookData.promise ).then( function () {
                                        form.defer.model.resolve( form.model );
                                    } );
                                }
                            } );
                        } else {
                            $.each( form._relations, function ( nullIndex, relation ) {
                                masterFormModelPromises.push( relation.form.defer.model.promise.then( function ( models ) {
                                    form._requests = form._requests || [];
                                    form._places = form._places || [];
                                    if ( models && models.constructor !== Array ) {
                                        models = [ models ];
                                    }
                                    $.each( models, function ( i, model ) {
                                        var request = form._requests[ i ] = form._requests[ i ] || {};
                                        // form._places[i] = model._subforms[form.name];
                                        migrateValues( model, request, relation.fields );
                                        if ( !form.isMany() && !relation.form.isMany() && form.mode === 'multi-edit' ) {
                                            migrateValues( model, request, relation.fields );
                                        } else if ( form.mode !== 'multi-edit' ) {
                                            //If form is not in multi-edit mode, than it has to load proper values
                                            //4 cases:
                                            // single -> single | {} -> {}
                                            // single -> many   | {} -> []
                                            // many -> single   | [] -> {}
                                            // many -> many     | [] -> []
                                            model._subforms = model._subforms || {};
                                            if ( !form.isMany() ) {
                                                if ( !form.parent._broken ) {
                                                    model._subforms[ form.name ] = model._subforms[ form.name ] || form.model;
                                                } else {
                                                    model._subforms[ form.name ] = model._subforms[ form.name ] || {};
                                                }
                                            } else {
                                                if ( !form.parent._broken ) {
                                                    model._subforms[ form.name ] = model._subforms[ form.name ] || form.data;
                                                } else {
                                                    model._subforms[ form.name ] = model._subforms[ form.name ] || [];
                                                }
                                            }
                                            form._places[ i ] = model._subforms[ form.name ];
                                        }
                                    } );
                                } ) );
                            } );
                            $q.all( masterFormModelPromises ).then( function () {
                                // Now when all promises are fulfilled, engine can send request:
                                var defer = $q.defer();
                                //Borrowed from underscore.js
                                var flatten = function ( input, shallow, _stop ) {
                                    var output = [];
                                    ng.forEach( input, function ( entity ) {
                                        var localStp = false;
                                        if ( entity && entity.constructor === Array && !_stop ) {
                                            if ( shallow ) {
                                                localStp = true;
                                            }
                                            output = output.concat( flatten( entity, shallow, localStp ) );
                                        } else {
                                            if ( entity !== undefined ) {
                                                output.push( entity );
                                            }
                                        }
                                    } );
                                    return output;
                                };
                                defer.promise.then( function ( data ) {
                                    var hookData;
                                    if ( !form.isMany() ) {
                                        data = flatten( data, true );
                                    }
                                    ng.forEach( form._places, function ( place, i ) {
                                        ng.copy( data[ i ], form._places[ i ] );
                                    } );
                                    hookData = form._hook( 'model', {
                                        model: form.master.model
                                    } ) || {};
                                    $q.all( hookData.promise ).then( function () {
                                        form.defer.model.resolve( flatten( form._places, true ) );
                                    } );
                                } );
                                form.load( form._requests, defer );
                            } );
                        }
                    } );
                }
                form.actions = form.actions.map( function ( action ) {
                    action.mode = action.mode || form.mode;
                    return action;
                } );
                if ( form.use ) {
                    $.each( form.use, function ( nullIndex, useSchema ) {
                        var resource, spec, promise;
                        useSchema.exclude = useSchema.exclude === undefined ? true : useSchema.exclude;
                        useSchema.widget = useSchema.widget || {};
                        useSchema.widget.dataSource = useSchema.widget.dataSource || {};
                        // removed default alphabetic sorting and replaced it with our default natural sort
                        // useSchema.widget.dataSource.sort = useSchema.widget.dataSource.sort || {
                        //     field: useSchema.widget.dataTextField || 'name',
                        //     dir: 'asc'
                        // };
                        if ( useSchema.field === undefined ) {
                            //Look for relation between dataValueField and mapping to handle item removal from subformgrid
                            //Map has rule: {masterField: slaveField}  (it always copy value from right hand side to left hand side, this time is coppied from slave to master)
                            $.each( useSchema.map, function ( masterField, slaveField ) {
                                if ( useSchema.widget === undefined || useSchema.widget.dataValueField === undefined ) {
                                    useSchema.mappingOriginKey = slaveField.substring( slaveField.lastIndexOf( '.' ) + 1 );
                                    useSchema.mappingDestinationKey = masterField.substring( masterField.lastIndexOf( '.' ) + 1 );
                                    return false;
                                } else if ( slaveField === useSchema.widget.dataValueField ) {
                                    useSchema.mappingOriginKey = slaveField.substring( slaveField.lastIndexOf( '.' ) + 1 );
                                    useSchema.mappingDestinationKey = masterField.substring( masterField.lastIndexOf( '.' ) + 1 );
                                    return false;
                                }
                            } );
                        } else {
                            useSchema.mappingOriginKey = useSchema.field;
                            useSchema.mappingDestinationKey = useSchema.field;
                        }
                        if ( typeof useSchema.resource === 'string' || useSchema.resource === undefined ) {
                            resource = useSchema.resource || 'element',
                                spec = useSchema.resource || {
                                    element: useSchema.element,
                                    options: {}
                                };
                            resource = resource.charAt( 0 ).toUpperCase() + resource.substr( 1 );
                            useSchema.resource = resourcesFactory.create( resource, spec );
                            useSchema._resourceName = resource;
                        } else {
                            resource = useSchema._resourceName;
                        }
                        if ( resource || useSchema.field ) {
                            if ( !useSchema.field ) {
                                promise = useSchema.resource.get().$promise;
                            } else {
                                promise = form.defer.schema.promise;
                            }
                            //Too tired to refactor, for future: move these functions outside of map scope and use bind or proxy
                            useSchema.promise = $q.all( [ promise, form.defer.model.promise ] ).then( function ( ret ) {
                                var data, desiredData = [],
                                    excludedData = {};
                                if ( !useSchema.field ) {
                                    data = ret[ 0 ].data
                                    data = prepareReturnedVal( data );
                                } else {
                                    data = form.fields[ useSchema.field ].options.dataSource.data;
                                    useSchema.select = {} || useSchema.select;
                                    //Angular doesn't support deep extend, using jQuery since it does
                                    $.extend( true, useSchema.select, useSchema.widget, form.fields[ useSchema.field ].options );
                                }
                                $.extend( true, useSchema.select, {
                                    filter: 'contains'
                                } );
                                useSchema.select.store = useSchema.select.store || {};
                                if ( useSchema.exclude && form.data ) {
                                    //ng.forEach -> reverse params -> $.each (which allows to break/continue)
                                    $.each( data, function ( index, dropdownItem ) {
                                        var excluded = false;
                                        $.each( form.data, function ( nullIndex, item ) {
                                            if ( !useSchema.field ) {
                                                $.each( useSchema.map, function ( masterField, slaveField ) {
                                                    masterField = masterField.replace( 'parent.', '' );
                                                    if ( item[ masterField ] == dropdownItem[ slaveField ] ) {
                                                        excluded = true;
                                                    } else {
                                                        excluded = false;
                                                        return false;
                                                    }
                                                } );
                                            } else {
                                                if ( dropdownItem[ useSchema.field ] === item[ useSchema.field ] || dropdownItem.id === item[ useSchema.field ] ) {
                                                    excluded = true;
                                                } else {
                                                    excluded = false;
                                                }
                                            }
                                            if ( excluded ) {
                                                return false;
                                            }
                                        } );
                                        if ( !excluded ) {
                                            desiredData.push( dropdownItem );
                                        } else {
                                            if ( dropdownItem[ useSchema.mappingOriginKey ] ) {
                                                excludedData[ dropdownItem[ useSchema.mappingOriginKey ] ] = dropdownItem;
                                            } else if ( dropdownItem.id !== undefined ) {
                                                excludedData[ dropdownItem.id ] = dropdownItem;
                                            }
                                        }
                                    } );
                                    data = desiredData;
                                }
                                ng.extend( useSchema.select.store, excludedData );
                                if ( useSchema.select.widget ) {
                                    useSchema.select.widget.dataSource.data( data );
                                } else {
                                	useSchema.select.dataSource = useSchema.select.dataSource || {}
                                    useSchema.select.dataSource.data = useSchema.select.dataSource.data || [];
                                    useSchema.select.dataSource.data.length = 0;
                                    Array.prototype.push.apply(useSchema.select.dataSource.data, data);
				}
                            } );
                            useSchema.window = useSchema.window || {};
                            useSchema.window.title = useSchema.title || form.title;
                            useSchema.window.save = function () {
                                var select = useSchema.select,
                                    widget = select.widget,
                                    models = widget.dataItems();
                                if ( !select.store ) {
                                    select.store = {};
                                }
                                if ( models.constructor !== Array ) {
                                    models = [ models ];
                                }
                                ng.forEach( models, function ( dsItem ) {
                                    var newModel = ng.copy( form._defaultModel ),
                                        model = dsItem.toJSON();
                                    if ( !useSchema.field ) {
                                        ng.forEach( useSchema.map, function ( slaveField, masterField ) {
                                            masterField = masterField.replace( 'parent.', '' );
                                            newModel[ masterField ] = model[ slaveField ];
                                        } );
                                    } else {
                                        newModel[ useSchema.field ] = model.name;
                                    }
                                    form.data.push( newModel );
                                    select.store[ newModel[ useSchema.mappingDestinationKey ] ] = model;
                                    if ( useSchema.exclude ) {
                                        widget.dataSource.remove( dsItem );
                                    }
                                } );
                                form.grid.widget.dataSource.data( ng.copy( form.data ) );
                                useSchema.select.widget.value( [] );
                                useSchema.window.widget.close();
                                form.$element.trigger( 'toggle' );
                                return false;
                            }
                        }
                    } );
                }
                return form;
            };
            return NmswebForm;
        }
    ] );
} );
