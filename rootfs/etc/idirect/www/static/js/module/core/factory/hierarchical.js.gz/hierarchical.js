define( [ 'angular', 'module/core', 'module/core/factory/api' ], function ( ng, core ) {
    'use strict';
    /**
     * @ngdoc factory
     * @name core.factory:Hierarchical
     * @description: Resource API used by Hierarchical-datasource.
     * Implements query / takes ids parameters.
     * Returns Hierarchical object

     example:
     This takes input object for API GET request
     The input object example:

     {
        db_query_type: "both",
        type: "dynamic",
        ids: "1986,1988",
        children: 4
      }
     */
    core.factory( 'Hierarchical', [ 'nmswebAPI',
        function ( nmswebAPI ) {
            function Hierarchical() {
                var api = new nmswebAPI();
                return api.resource( 'config/element/hierarchy?obj_id=:ids', {}, {
                    query: {
                        method: 'GET'
                    },
                    params: {
                        ids: '@ids'
                    }
                } );
            }
            return Hierarchical;
    } ] );
} );