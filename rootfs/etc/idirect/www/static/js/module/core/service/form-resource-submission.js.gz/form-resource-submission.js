define( [ 'module/core' ], function ( core ) {
    'use strict';
    core.service( 'FormResourceSubmission', [
        function () {
            return {
                add: function ( resource, data, success, error ) {
                    resource.add( {}, data, success, error );
                },
                edit: function ( resource, data, success, error ) {
                    resource.save( {}, data, success, error );
                }
            };
    } ] );
} );