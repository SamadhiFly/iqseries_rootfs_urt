////////
///
/// use: "grunt bundle-complete" to compile orgchart and yfiles lib
///////
module.exports = function (grunt) {

  // Project configuration.
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),

    'string-replace': {
      dist: {
        files: [{
          'expand':true,
          'src': ['yfiles/*.js', 'orgchart/*.js'],
          // the path to the original library files - the directory that contains the "yfiles" directory
          'cwd': '.',
          'dest': 'tmp/',
        }],
        options: {
          replacements: [{
            // the module files have this pattern at the top - requirejs optimizer does not recognize it, so we replace it with a simple "define" call.
            pattern: /\s*\(\s*typeof\s+define\s*==\s*'function'\s*\?\s*define\s*:\s*\(\s*function\s*\(\w*\s*,\s*\w+\s*\)\s*\{\s*\w+\(\s*\)\s*;\s*\}\s*\)\s*\)/,
            replacement: 'define'
          }, {
            // the lang.js file has a different pattern, replace that too
            pattern: /\s*\(\s*"undefined"\s*!=\s*typeof\s+define\s*\?\s*define\s*:\s*function\(\s*\w+\s*,\s*\w+\s*\)\s*\{\s*\w+\s*\(\s*\)\}\s*\)/,
            replacement: 'define'
          }]
        }
      }
    },

    'requirejs': {
      options: {
        'findNestedDependencies': true,
        'baseUrl': 'tmp',
        'optimize': 'none',
        'onModuleBundleComplete': function (data) {
          var fs = require('fs'),
              amdclean = require('amdclean'),
              outputFile = data.path;

          fs.writeFileSync(outputFile, amdclean.clean({
            'filePath': outputFile,
            'escodegen': {
              'comment': false,
              'format': {
                'compact': true,
              }
            },
            'removeUseStricts': false,
          }));
        }
      },

      complete: {
        options: {
          // first option - build a file that includes *everything* but the license file
          // NOTE: this variant currently breaks Node because it requires too much memory
          // the workaround is to provide Grunt with more memory
          // by running the node interpreter with the additional --max-old-space-size=4096 command line option
          // this worked flawlessly at the time of writing - the process required slightly more than 2GB of memory, but finished successfully
          // see also https://github.com/assemble/assemble-middleware-i18n/issues/37
          'include': ['yfiles/graph-base',
    'yfiles/graph-graphml',
    'yfiles/graph-style-simple',
    'yfiles/graph-style-extra',
    'yfiles/graph-style-control',
    'yfiles/layout-tree',
    'yfiles/layout-misc',
    'yfiles/graph-layout-bridge',
    'yfiles/graph-binding',
    'yfiles/canvas-core',
    'yfiles/lang',
    'orgchart/FixNodeLocationStage',
    'orgchart/TreeDataBuilder',
    'orgchart/ParentDataItem',
    'orgchart/LeafDataItem',
    'orgchart/ReferenceStructure',
    'orgchart/LevelOfDetailNodeStyle',
    'orgchart/BackgroundConverter',
    'orgchart/BorderConverter',
    'orgchart/OverviewNameConverter',
    'orgchart/AddHashConverter',
    'orgchart/OrgChartUI'],
          'out': 'yfiles-complete.js',
        }
      },
      viewer: {
        options: {
          // second option include everything in the viewer package - no layout so far
          'include': ['yfiles/viewer'],
          'out': 'yfiles-viewer.js',
        }
      },
      layout: {
        options: {
          // third option include a sample layout algorithm and the bridge, but not the part that is in the viewer package above, already
          // this file can be loaded on top of "yfiles-viewer.js" from the "viewer" configuration above
          'include': ['yfiles/layout-hierarchic', 'yfiles/graph-layout-bridge'],
          // exclude core-lib and its dependencies recursively - they are loaded by "viewer" already
          'exclude': ['yfiles/core-lib', 'yfiles/canvas-core', 'yfiles/graph-base'],
          'out': 'yfiles-layout.js',
        }
      },
    }
  });

  grunt.loadNpmTasks('grunt-contrib-requirejs');
  grunt.loadNpmTasks('grunt-string-replace');
  grunt.registerTask('adjustdefine', ['string-replace:dist']);
  grunt.registerTask('bundle-complete', ['adjustdefine', 'requirejs:complete']);
  grunt.registerTask('bundle-viewer', ['adjustdefine', 'requirejs:viewer']);
  grunt.registerTask('bundle-layout', ['adjustdefine', 'requirejs:layout']);
};
