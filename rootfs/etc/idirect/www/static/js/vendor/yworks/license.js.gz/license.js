(function(g){(typeof define=='function'?define:(function(dependencies, fn){fn();}))([],function(){
  g.yfiles = g.yfiles || {};
  g.yfiles.license = {
  "company": "iDirect",
  "contact": "Guy Adams",
  "date": "12/18/2014",
  "distribution": true,
  "domains": [
    "*"
  ],
  "email": "gadams@idirect.net",
  "fileSystemAllowed": true,
  "licensefileversion": "1.1",
  "localhost": true,
  "oobAllowed": true,
  "package": "complete",
  "product": "yFiles for HTML",
  "projectname": "Pulse",
  "subscription": "12/17/2015",
  "type": "project",
  "version": "1.2",
  "key": "65676ca76420c7e22faf230f7dc790705f115cd4"
}})}(self));
