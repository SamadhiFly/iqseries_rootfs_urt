define( 'routing', window.nmsweb.__routes, function () {
    var args = arguments,
        dependencies = [],
        i;
    try {
        for ( i = 0; i < args.length; i++ ) {
            dependencies.push( JSON.parse( args[ i ] ) );
        };
    } catch ( e ) {
        throw 'Error while parsing ' + files[ i ] + '. ' + e.message;
    }
    return dependencies;
} );