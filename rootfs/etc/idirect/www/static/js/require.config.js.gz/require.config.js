var requireJSConfig = {
    baseUrl: '/static/js',
    //alias libs' paths
    paths: {
        routes: '/static/routes',
        templates: '/static/templates',
        layouts: '/static/layouts',
        csses: '/static/css',
        configurators: '/static/configurators',

        text: 'vendor/requirejs/text-2.0.10',
        json: 'vendor/requirejs/json-0.4.0',
        css: 'vendor/requirejs/css-0.1.2',
        async: 'vendor/requirejs/async-0.1.2',
        domReady: 'vendor/requirejs/domReady-2.0.1',

        angular: 'vendor/angularjs/angular-1.2.28.min',
        angularRoute: 'vendor/angularjs/route-1.2.28.min',
        angularResource: 'vendor/angularjs/resource-1.2.28.min',
        angularSanitize: 'vendor/angularjs/sanitize-1.2.28.min',

        underscore: 'vendor/underscore/underscore-1.8.3.min',

        jquery: 'vendor/jquery/jquery.1.11.0.min',
        jqueryConfirm: 'vendor/jquery-confirm/jquery-confirm.min',

        kendo: 'module/core/service/kendo-fixes',
        kendoLib: 'vendor/kendoui/all.min.2015.1.429.fixed',
        spin: 'vendor/spin/spin-2.0.1',
        waypoints: 'external/waypoints/waypoints.min',
        yfiles: 'vendor/yworks/lib/yfiles',
        orgchart: 'vendor/yworks/lib/orgchart',
        openlayers: 'vendor/openlayers/build/ol'
    },
    //angularJS doesn't provide code written as an AMD module, we need to create shim for it
    shim: {
        'jquery': {
            exports: '$'
        },
        'jqueryConfirm': {
            exports: 'jqueryConfirm',
            deps: [ 'jquery' ]
        },
        'angular': {
            exports: 'angular'
        },
        'angularRoute': {
            exports: 'ngRoute',
            deps: [ 'angular' ]
        },
        'angularResource': {
            exports: 'ngResource',
            deps: [ 'angular' ]
        },
        'angularSanitize': {
            exports: 'ngSanitize',
            deps: [ 'angular' ]
        },
        'kendoLib': {
            exports: 'kendo',
            deps: [ 'jquery', 'angular' ]
        },
        'spin': {
            exports: 'Spinner',
            deps: [ 'jquery' ]
        },
        'openlayers': {}
    },
    //wait 25sec for deps
    waitSeconds: 90,
    //start app
    deps: [ 'module/core', 'bootstrap' ]
};

//Recognize if we work on nodeJS or on a browser
if ( typeof module !== 'undefined' && module.exports ) {
    module.exports = requireJSConfig;
} else {
    require.config( requireJSConfig );
    window.requireJSConfig = requireJSConfig;
}
