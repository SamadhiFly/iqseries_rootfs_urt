// Karma configuration
module.exports = function ( config ) {
    config.set( {

        basePath: './..',

        // switch off html2js preprocessor - fixes loading html bug
        preprocessors: [ {
            'templates/**': ''
        } ],

        // frameworks to use
        frameworks: [ 'jasmine', 'requirejs' ],

        plugins: [
            'karma-requirejs',
            'karma-jasmine',
            'karma-chrome-launcher',
            'karma-firefox-launcher',
            'karma-phantomjs-launcher'
        ],

        // list of files / patterns to load in the browser
        files: [
            'js/external/require-jquery.js',
            'js/tests/helpers.js',
            'js/tests/tests.config.js',
            'js/tests/bind.polyfill.js',
            'js/tests/utils.js',
            {
                pattern: 'js/app.js',
                included: false
            },
            {
                pattern: 'js/bootstrap.js',
                included: false
            },

            {
                pattern: 'js/vendor/**',
                included: false
            },
            {
                pattern: 'js/external/**',
                included: false
            },
            {
                pattern: 'js/core/**',
                included: false
            },
            {
                pattern: 'js/module/**',
                included: false
            },

            {
                pattern: 'js/tests/unit/**',
                included: false
            },
            {
                pattern: 'js/tests/mock/**',
                included: false
            },
            {
                pattern: 'js/tests/templates/**',
                included: false
            },
            {
                pattern: 'js/tests/vendor/**',
                included: false
            },

            {
                pattern: 'routes/**',
                included: false
            },
            {
                pattern: 'templates/**',
                included: false
            },
            {
                pattern: 'layouts/**',
                included: false
            },
            {
                pattern: 'css/**',
                included: false
            }
        ],

        // list of files to exclude
        exclude: [],

        // test results reporter to use
        // possible values: 'dots', 'progress', 'junit', 'growl', 'coverage'
        reporters: [ 'progress' ],

        // web server port
        port: 9876,

        // enable / disable colors in the output (reporters and logs)
        colors: true,

        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        logLevel: config.LOG_DEBUG,

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true,

        // Start these browsers, currently available:
        // - Chrome
        // - ChromeCanary
        // - Firefox
        // - Opera (has to be installed with `npm install karma-opera-launcher`)
        // - Safari (only Mac; has to be installed with `npm install karma-safari-launcher`)
        // - PhantomJS
        // - IE (only Windows; has to be installed with `npm install karma-ie-launcher`)
        browsers: [ 'Chrome' ],

        // If browser does not capture in given timeout [ms], kill it
        captureTimeout: 60000,

        // Continuous Integration mode
        // if true, it capture browsers, run tests and exit
        singleRun: false
    } );
};