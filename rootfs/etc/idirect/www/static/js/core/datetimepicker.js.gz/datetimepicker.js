define( [ "jquery", "kendo", "core/nmsweb", "core/input_validation" ], function ( $ ) {
    "use strict";
    var FOCUSED = "k-state-focused",
        CHANGE = "change",
        DateTimePicker = window.kendo.ui.DateTimePicker.extend( {
            _valueTemplate: "",
            init: function ( element, options ) {
                var that = this,
                    defaults = {
                        format: "yyyy-MM-dd HH:mm:ss",
                        timeFormat: "HH:mm"
                    },
                    $element = $( element ),
                    validationFunction = function () {
                        $element.validate_input( options.opts, element.selector );
                    };
                if ( options.opts ) {
                    // forcing format (if developer (while creating form) put's additional options (tries to force it's own format)) because it has been decided that everywhere throughout nms time will be displayed in the following format HH:mm:ss
                    options.opts.format = defaults.format;
                    nmsweb.extendOptions( defaults, options.opts );
                } else if ( options ) {
                    options.format = defaults.format;
                    nmsweb.extendOptions( defaults, options );
                }
                window.kendo.ui.DateTimePicker.fn.init.call( that, element, defaults );
                $element.off( 'blur' );
                $element.on( 'blur', function () {
                    that._inputWrapper.removeClass( FOCUSED );
                    that._change( element.prop( 'value' ) );
                    that.close( "date" );
                    that.close( "time" );
                } );
                if ( element.prop( 'value' ) !== "" ) {
                    that._oldText = that.val();
                }
                if ( $element.hasClass( 'validate' ) ) {
                    $element.change( validationFunction );
                    $element.bind( 'blur', validationFunction );
                }
            },
            formatDate: function ( d ) {
                function addZero( n ) {
                    return n < 10 ? '0' + n : '' + n;
                }
                return d.getFullYear() + "-" + addZero( d.getMonth() + 1 ) + "-" + addZero( d.getDate() ) + " " +
                    addZero( d.getHours() ) + ":" + addZero( d.getMinutes() ) + ":" + addZero( d.getMinutes() );
            },
            val: function ( value ) {
                var that = this,
                    regex = /\D+/,
                    date;
                if ( value ) {
                    if ( typeof value === 'number' || ( typeof value === 'string' && !regex.test( value ) ) ) {
                        value = new Date( value );
                    }
                    window.kendo.ui.DateTimePicker.fn.value.call( that, value );
                } else {
                    date = window.kendo.ui.DateTimePicker.fn.value.call( that );
                    if ( typeof date === 'object' ) {
                        date = Date.parse( date );
                    } else if ( typeof date === 'string' ) {
                        date = Date.parse( new Date( date ) );
                    }
                    if ( isNaN( date ) ) {
                        date = '';
                    } else {
                        date = date - ( 60 * ( new Date( date ) ).getTimezoneOffset() );
                    }
                    return date;
                }
            },
            _change: function ( value ) {
                var that = this;
                that._update( value );
                that.template( '' );
                that.trigger( CHANGE );
                that.element.trigger( CHANGE );
            },
            value: function ( value ) {
                var that = this,
                    regex = /\D+/;
                if ( value ) {
                    if ( typeof value === 'number' || ( typeof value === 'string' && !regex.test( value ) ) ) {
                        value = new Date( value );
                    }
                    if ( that.options.returnComparison ) {
                        value = new Date( value.getTime() + 60 * value.getTimezoneOffset() );
                    }
                    if ( that.options.inlineEdit ) {
                        value = new window.oldDate( value );
                    }
                    window.kendo.ui.DateTimePicker.fn.value.call( that, value );
                } else {
                    if ( that.options.returnComparison ) {
                        value = window.kendo.ui.DateTimePicker.fn.value.call( that );
                        if ( value ) {
                            value = ( value.getTime() / 1000 ) - 60 * value.getTimezoneOffset();
                            return new Date( value );
                        }
                    }
                    if ( that.options.inlineEdit ) {
                        value = window.kendo.ui.DateTimePicker.fn.value.call( that );
                        if ( value ) {
                            return new window.oldDate( value );
                        }
                    }
                    return window.kendo.ui.DateTimePicker.fn.value.call( that );
                }
            },
            template: function ( template ) {
                var that = this;
                if ( template !== undefined ) {
                    that._valueTemplate = template;
                } else {
                    return that._valueTemplate;
                }
            }
        } );
    window.nmsweb.registerComponent( 'DateTimePicker', DateTimePicker );
    return DateTimePicker;
} );