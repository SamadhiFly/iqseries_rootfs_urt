define( [ 'jquery', 'kendo', 'require' ], function ( $, kendo, require ) {
    "use strict";
    /*
     *	if you modify selectorClickableSidebarElements, you also need to modify nmsweb/templates/_ui/menu.html.ep line 3
     */
    var asyncLinksClass,
        popstateHandler,
        contentId,
        $content,
        History,
        initAsyncLinks;
    asyncLinksClass = '.n-history';
    contentId = '#content';
    initAsyncLinks = function () {
        var that = this; //that === nmsweb.history
        $( 'body' ).on( 'click', asyncLinksClass, function ( event ) {
            var url = $( this ).attr( 'href' );
            that.load( url );
            event.preventDefault();
        } );
    };
    popstateHandler = function ( event ) {
        var that = this; //that === nmsweb.history
        event.stopPropagation();
        event.preventDefault();
        if ( !( event && event.state && event.state.url ) || event.state.url === '#' ) {
            return;
        }
        if ( event &&
            event.state &&
            event.state.url &&
            event.state.stateNumber ) {
            that.load( event.state.url, event.state.stateNumber );
        }
        return false;
    };
    History = window.kendo.Observable.extend( {
        init: function () {
            var that = this;
            window.kendo.Observable.fn.init.call( that );
            $.proxy( initAsyncLinks, that )();
            window.addEventListener( 'popstate', $.proxy( popstateHandler, that ) );
            $content = $( contentId );
        },
        load: function ( url, stateNumber ) {
            var that = this;
            that.trigger( 'load' );
            $content.empty();
            require( [ 'core/spin' ], function () {
                $( '.n-overlay .overlay' ).css( 'visibility', 'visible' ).spin( 'large' );
                //Fire destroy event for angular
                $( '.ng-scope' ).trigger( 'destroy' );
                if ( typeof stateNumber === 'undefined' ) {
                    window.history.pushState( {
                            url: url,
                            stateNumber: window.history.length
                        },
                        window.document.title,
                        url );
                }

                $.ajax( {
                    url: url,
                    context: that,
                    error: function ( jqXHR, textStatus, errorThrown ) {
                        var that = this, // history object as well
                            responseObj;
                        that.trigger( 'loaded', jqXHR.responseText );
                        $( '.n-overlay .overlay' ).css( 'visibility', 'hidden' ).spin( false );
                        try {
                            responseObj = JSON.parse( jqXHR.responseText );
                            $content.html( window.unescape( responseObj.contents ) );
                        } catch ( e ) {
                            $content.html( jqXHR.responseText );
                        }
                        that.title( errorThrown );
                        that.trigger( 'error', textStatus, jqXHR.responseText );
                    },
                    success: function ( data, textStatus ) {
                        var that = this; // history object as well
                        that.trigger( 'loaded', data );
                        $( '.n-overlay .overlay' ).css( 'visibility', 'hidden' ).spin( false );
                        if ( data && data.contents ) {
                            $content.html( window.unescape( data.contents ) );
                        }
                        that.title( data.title );
                        // that.breadcrumbs(data.breadcrumbs);
                        that.trigger( 'success', data, textStatus );
                    }
                } );
            } );
        },
        breadcrumbs: function ( breadcrumbs ) {
            var separator = " &gt; ",
                container = $( '#breadcrumbs' ),
                i,
                length,
                active,
                first;
            first = container.find( 'a:first' );
            container.empty();
            container.append( first );
            if ( breadcrumbs ) {
                for ( i = 0, length = breadcrumbs.length; i < length; i++ ) {
                    active = breadcrumbs[ i ].active ? 'active' : '';
                    if ( breadcrumbs[ i ].link === false ) {
                        container.append( separator + " <span class=\"" + active + "\">" + breadcrumbs[ i ].name + "</span>" );
                    } else {
                        container.append( separator + " <a href=\"" + breadcrumbs[ i ].url + "\" class=\"" + active + "\">" + breadcrumbs[ i ].name + "</a>" );
                    }
                }
            }
        },
        title: function ( title ) {
            //
            // Temporarily override HTML title on all pages
            //
            // document.title = title;
            document.title = title || "iDirect NMS";
        }
    } );
    window.nmsweb = window.nmsweb || {};
    window.nmsweb.history = window.nmsweb.history || new History();
    return window.nmsweb.history;
} );