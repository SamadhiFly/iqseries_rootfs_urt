define( [], function () {
    "use strict";
    window.nmsweb = window.nmsweb || {};
    window.nmsweb.clusterinfo = function ( $siteName, $clusterRole, $clusterStatus, refreshInterval, clusterInfoService ) {
        var updateClusterInfo = function () {
            $.ajax( {
                type: 'GET',
                url: clusterInfoService,
                headers: {
                    'Use-Cookie': 'true'
                },
                dataType: 'json',
                success: function ( json ) {
                    if ( json !== undefined && json.data !== undefined ) {
                        $siteName.html( json.data[ 0 ].site_name || '-' );
                        $clusterRole.html( json.data[ 0 ].cluster_role || '-' );
                        $clusterStatus.html( json.data[ 0 ].cluster_status || '-' );
                    }
                },
                error: function () {
                    $siteName.html( '-' );
                    $clusterRole.html( '-' );
                    $clusterStatus.html( '-' );
                }
            } );
        };
        refreshInterval = refreshInterval || 60000;
        clusterInfoService = clusterInfoService || '/api/1.0/core/cluster_info';
        updateClusterInfo();
        setInterval( function () {
            updateClusterInfo();
        }, refreshInterval );
    };
    return window.nmsweb.clusterinfo;
} );