define( [ 'kendo', 'core/nmsweb' ], function () {
    "use strict";
    var defaults = {},
        Slider = window.kendo.ui.Slider.extend( {
            init: function ( element, options ) {
                var that = this;
                if ( options ) {
                    nmsweb.extendOptions( defaults, options );
                }
                window.kendo.ui.Slider.fn.init.call( that, element[ 0 ], defaults );
            }
        } );
    window.nmsweb.registerComponent( 'Slider', Slider );
    return Slider;
} );