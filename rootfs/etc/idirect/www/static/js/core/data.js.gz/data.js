define( [ "jquery", "kendo", "core/jmr" ], function ( $ ) {
    "use strict";
    var kendo = window.kendo;
    window.nmsweb = window.nmsweb || {};
    window.nmsweb.DataSources = window.nmsweb.DataSources || {};
    window.nmsweb.extendOptions = function ( target, defaultOptions, newOptions, component ) {
        var parseForJSStuff, recursiveSearch, kendoTemplate;
        kendoTemplate = function ( selector, component ) {
            var tmpl = kendo.template( $( '#' + selector ).html() );
            return $.proxy( tmpl, component );
        };
        parseForJSStuff = function ( str, key ) {
            if ( key === 'dataSource' ) {
                if ( typeof str === 'string' ) {
                    return window.nmsweb.DataSources[ str ];
                } else if ( str.id === undefined ) {
                    return new window.nmsweb.DataSource( str );
                } else {
                    return str;
                }
            } else if ( str.indexOf( 'n-jstemplate' ) !== -1 ) {
                return kendoTemplate( str, component );
            } else if ( str.indexOf( '__callback' ) !== -1 ) {
                if ( typeof window.nmsweb.callbacks[ str ] === 'function' ) {
                    return window.nmsweb.callbacks[ str ];
                } else {
                    console.error( 'Couldn\'t find requested callback. ' + str );
                    return $.noop;
                }
            } else {
                return str;
            }
        };
        recursiveSearch = function ( target ) {
            $.each( target, function ( key ) {
                if ( target.hasOwnProperty( key ) ) {
                    if ( typeof target[ key ] === 'string' ) {
                        target[ key ] = parseForJSStuff( target[ key ], key );
                    } else if ( typeof target[ key ] === 'object' && target[ key ] !== null ) {
                        if ( key === 'dataSource' ) {
                            target[ key ] = parseForJSStuff( target[ key ], key );
                        } else {
                            recursiveSearch( target[ key ] );
                        }
                    }
                }
            } );
        };
        $.extend( true, target, defaultOptions, newOptions );
        recursiveSearch( target );
        return target;
    };
    window.nmsweb.DataSource = kendo.data.DataSource.extend( { // DataSource's extensions
        init: function ( options ) {
            var that = this,
                source,
                createFields,
                mergingFunction,
                auto_load = false,
                substitutesEventsTrigger,
                defaultValues;
            if ( typeof options.dsId !== 'undefined' ) {
                that.id = options.dsId;
            }
            that.options = {
                id: that.id,
                schema: {
                    data: function ( result ) {
                        var dsOrigin,
                            dsFilter,
                            dsFilterStringified;
                        if ( that.dataSources !== undefined ) { //only for complex datasource
                            dsOrigin = window.nmsweb.DataSources[ that.dataSources[ 0 ] ];
                            dsFilter = dsOrigin.filter();
                            dsFilterStringified = JSON.stringify( dsFilter );
                            if ( dsFilter !== undefined && ( that.currentFilter === undefined || that.currentFilter !== dsFilterStringified ) ) {
                                that.currentFilter = dsFilterStringified;
                                that.page( 1 );
                            }
                            if ( that.page() !== dsOrigin.page() ) {
                                dsOrigin.page( that.page() );
                            }
                        }
                        if ( result.failures !== undefined && result.failures.length ) {
                            that.trigger( 'error', {
                                errors: result.failures
                            } );
                        }
                        return result.data || result;
                    },
                    total: function ( result ) {
                        return result.total || result.length || 0;
                    }
                }
            };
            if ( options ) {
                window.nmsweb.extendOptions( that.options, options );
            }
            defaultValues = {
                datetime: new Date(),
                time: new Date()
            };
            if ( that.options.schema.model && that.options.schema.model.fields ) {
                $.each( that.options.schema.model.fields, function ( key ) {
                    var type = that.options.schema.model.fields[ key ].type || '',
                        field = that.options.schema.model.fields[ key ],
                        dateObj;
                    if ( field.defaultValue === undefined && defaultValues[ type ] !== undefined ) {
                        that.options.schema.model.fields[ key ].defaultValue = defaultValues[ type ];
                    }
                    if ( type === 'date' || type === 'datetime' ) {
                        that.options.schema.model.fields[ key ].parse = function ( fieldVal ) {
                            dateObj = new Date( fieldVal );
                            if ( field.format === undefined ) {
                                return dateObj;
                            } else {
                                return kendo.toString( dateObj, field.format );
                            }
                        };
                    } else if ( type === 'time' ) {
                        that.options.schema.model.fields[ key ].parse = function ( fieldVal ) {
                            var format = field.format || 'HH:mm:ss',
                                ret;
                            dateObj = kendo.parseDate( fieldVal );
                            if ( dateObj ) {
                                ret = kendo.toString( dateObj, format );
                            } else {
                                ret = fieldVal;
                            }
                            return ret;
                        };
                    }
                } );
            }
            //A complex DataSource bit
            createFields = function ( dataSources ) {
                var preparedFields = {},
                    dataArraysLen = dataSources.length,
                    i,
                    ds,
                    schema,
                    fields,
                    item,
                    field,
                    firstItem,
                    toReturn,
                    model;
                for ( i = 0; i < dataArraysLen; i += 1 ) {
                    ds = window.nmsweb.DataSources[ dataSources[ i ] ];
                    schema = ds.options.schema || {};
                    model = schema.model || {};
                    fields = model.fields;
                    if ( typeof fields === 'undefined' ) {
                        firstItem = ds._data[ 0 ] || {};
                        fields = {};
                        for ( item in firstItem ) {
                            if ( firstItem.hasOwnProperty( item ) && ( typeof firstItem[ item ] === 'string' || typeof firstItem[ item ] === 'number' ) ) {
                                fields[ item ] = firstItem[ item ];
                            }
                        }
                    }
                    for ( field in fields ) {
                        if ( fields.hasOwnProperty( field ) && typeof preparedFields[ field ] === 'undefined' ) {
                            preparedFields[ field ] = fields[ field ];
                            toReturn = preparedFields;
                        }
                    }
                }
                return toReturn;
            };
            if ( that.options.transport !== undefined &&
                that.options.transport.source !== undefined ) {
                source = that.options.transport.source;
                delete that.options.transport;
                that.options.schema.model = {
                    fields: createFields( source.dataSources )
                };
                that.options.data = [];
            }
            // Calling parent constructor
            window.kendo.data.DataSource.fn.init.call( that, that.options );
            that.transport.parameterMap = function ( options ) {
                var len, i, type,
                    models = options.models,
                    func = function ( models ) { // implemented due to jshint W083; function inside loop.
                        $.each( models, function ( key ) {
                            type = that.options.schema.model.fields[ key ].type;
                            if ( type && type.indexOf( 'date' ) !== -1 && options.models[ i ][ key ] instanceof Date ) {
                                options.models[ i ][ key ] = Date.parse( options.models[ i ][ key ] );
                            }
                        } );
                    };
                if ( models ) {
                    for ( i = 0, len = models.length; i < len; i++ ) {
                        func( models[ i ] );
                    }
                }
                return options;
            };
            //Complex DS creation
            if ( source !== undefined ) {
                if ( typeof source.callback === 'function' ) {
                    that.defaultMerging = source.callback;
                } else {
                    that.defaultMerging = $.noop;
                }
                if ( source.dataSources.length ) {
                    that.dataSources = source.dataSources;
                    source.events = source.events || [];
                    mergingFunction = function () {
                        var dataSourcesData = [],
                            dataSources = [],
                            evnt;
                        $.each( source.dataSources, function ( element ) {
                            var dataSourceObject = window.nmsweb.DataSources[ source.dataSources[ element ] ];
                            dataSources.push( dataSourceObject );
                            if ( source.applyCompFilters ) {
                                dataSourcesData.push( dataSourceObject.filterData().slice() );
                            } else {
                                dataSourcesData.push( dataSourceObject.data().slice() );
                            }
                        } );
                        evnt = {
                            dataArrays: dataSourcesData,
                            options: source.options,
                            dataSources: dataSources,
                            isChangePrevented: function () {
                                this._changePrevented = this._changePrevented || false;
                                return this._changePrevented;
                            },
                            preventChange: function () {
                                this._changePrevented = true;
                            }
                        };
                        that.trigger( 'merge', evnt );
                        if ( !( typeof evnt.isDefaultPrevented === 'function' && evnt.isDefaultPrevented() ) && typeof that.defaultMerging === 'function' ) {
                            that.defaultMerging( evnt );
                        }
                        if ( !evnt.isChangePrevented() ) {
                            that.read();
                        }
                    };
                    substitutesEventsTrigger = function ( eventName ) {
                        return function () {
                            that.trigger( eventName );
                        };
                    };
                    $.each( source.dataSources, function ( element ) {
                        var dataSourceName = source.dataSources[ element ],
                            dataSourceObject = window.nmsweb.DataSources[ dataSourceName ],
                            eventsArr = [ 'filter', 'sort', 'page', 'group', 'update', 'create', 'delete', 'change' ],
                            eventIndex,
                            eventName;
                        if ( source.events.length === 0 ) {
                            dataSourceObject.bind( 'change', mergingFunction );
                        } else {
                            dataSourceObject.one( 'change', mergingFunction );
                        }
                        for ( eventIndex in eventsArr ) {
                            if ( eventsArr.hasOwnProperty( eventIndex ) ) {
                                eventName = eventsArr[ eventIndex ];
                                if ( source.events.length > 0 ) {
                                    if ( source.events.indexOf( eventName ) !== -1 ) {
                                        dataSourceObject.bind( eventName, substitutesEventsTrigger( eventName ) );
                                        dataSourceObject.bind( eventName, mergingFunction );
                                    }
                                }
                            }
                        }
                    } );
                }
            }
            if ( that.options !== undefined ) {
                if ( that.options.streaming !== undefined ) {
                    that.streaming = that.options.streaming;
                    delete that.options.streaming;
                    that.streaming.status = false;
                    auto_load = that.streaming.auto_load || auto_load;
                    if ( auto_load === true ) {
                        that.startStreaming();
                    }
                }
                if ( that.options.async !== undefined ) {
                    that.async = that.options.async;
                    delete that.options.async;
                    if ( that.async.auto_load ) {
                        that.startAsync();
                    }
                }
            }
            // Check if we have remote options on
            that.remote = that.options.serverSorting || that.options.serverPaging || that.options.serverFiltering || that.options.serverGrouping || that.options.serverAggregates;
            // Create an empty array for selection memory
            // Not perfect solution!
            that._selected = [];
        },
        _pipeData: function ( async ) {
            var that = this,
                streaming,
                jmr = new window.nmsweb.jmr(),
                evntName = that.id,
                interval,
                idKey,
                addRow,
                pushDataRow,
                throttle,
                throttled;
            if ( that.options.schema !== undefined &&
                that.options.schema.model !== undefined ) {
                idKey = that.options.schema.model.id;
            }
            // Taken from underscore.js
            // Returns a function, that, when invoked, will only be triggered at most once
            // during a given window of time. Normally, the throttled function will run
            // as much as it can, without ever going more than once per `wait` duration;
            // but if you'd like to disable the execution on the leading edge, pass
            // `{leading: false}`. To disable execution on the trailing edge, ditto.
            throttle = function ( func, wait, options ) {
                var context, args, result;
                var timeout = null;
                var previous = 0;
                options = options || ( options = {} );
                var later = function () {
                    previous = options.leading === false ? 0 : $.now();
                    timeout = null;
                    result = func.apply( context, args );
                    context = args = null;
                };
                return function () {
                    var now = $.now();
                    if ( !previous && options.leading === false ) {
                        previous = now;
                    }
                    var remaining = wait - ( now - previous );
                    context = this;
                    args = arguments;
                    if ( remaining <= 0 ) {
                        clearTimeout( timeout );
                        timeout = null;
                        previous = now;
                        result = func.apply( context, args );
                        context = args = null;
                    } else if ( !timeout && options.trailing !== false ) {
                        timeout = setTimeout( later, remaining );
                    }
                    return result;
                };
            };
            pushDataRow = function ( data, item ) {
                data.push( item );
                return data;
            };
            addRow = function ( item, async ) {
                //data is the point currently in the DataSource, item is the point incoming from the response.
                var data, len, i, updated;
                data = that.transport.data = that.transport.data || [];
                try {
                    if ( !async ) {
                        updated = false;
                        if ( idKey !== undefined ) {
                            //if we're updating the same ID key, consider if we're going to be merging properties of the data item based on DS option.
                            for ( i = 0, len = data.length; i < len; i++ ) {
                                if ( data[ i ][ idKey ] === item[ idKey ] ) {
                                    if ( that.options.mergeResults ) {
                                        for ( var propName in item ) {
                                            if ( item.hasOwnProperty( propName ) ) {
                                                data[ i ][ propName ] = item[ propName ];
                                            }
                                        }
                                    } else {
                                        data[ i ] = item;
                                    }
                                    updated = true;
                                    break;
                                }
                            }
                            if ( !updated ) {
                                data = pushDataRow( data, item );
                                updated = false;
                            }
                        } else {
                            data = pushDataRow( data, item );
                        }
                    } else {
                        data = pushDataRow( data, item );
                    }
                } catch ( e ) {
                    console.error( e );
                }
            };
            if ( async ) {
                streaming = that.async;
                evntName = evntName + ':async';
            } else {
                streaming = that.streaming;
                that.streaming.status = true;
            }
            interval = streaming.interval | 100;
            jmr.bind( evntName + ':error', function ( response ) {
                that.trigger( 'error', {
                    errors: response.errors,
                    status: response.message
                } );
            } );
            throttled = throttle( function () {
                var data = that.transport.data || [];
                if ( that.options.fe_limit && that.options.fe_limit.qty && data.length >= that.options.fe_limit.qty ) {
                    data.sort( function ( b, a ) {
                        var raw_a, raw_b;
                        if ( typeof a[ that.options.fe_limit.order_by ] === "object" && a[ that.options.fe_limit.order_by ].getTime ) {
                            raw_a = a[ that.options.fe_limit.order_by ].getTime();
                        } else {
                            raw_a = a[ that.options.fe_limit.order_by ];
                        }
                        if ( typeof b[ that.options.fe_limit.order_by ] === "object" && b[ that.options.fe_limit.order_by ].getTime ) {
                            raw_b = b[ that.options.fe_limit.order_by ].getTime();
                        } else {
                            raw_b = b[ that.options.fe_limit.order_by ];
                        }
                        return raw_b - raw_a;
                    } );
                    that.transport.data = data.slice( data.length - that.options.fe_limit.qty );
                    that.trigger( 'feLimitReached' );
                }
                that.read();
                that.trigger( 'streamed' );
            }, interval );
            jmr.bind( evntName, function ( response ) {
                var i, data, len;
                data = response.payload.data;
                if ( response.IsLastSegment || response.queryDone ) {
                    that.trigger( 'asyncDone' );
                }
                if ( data !== undefined ) {
                    if ( !$.isArray( data ) ) {
                        data = [ data ];
                    }
                    len = data.length;
                    if ( len ) {
                        for ( i = 0; i < len; i++ ) {
                            if ( typeof data[ i ] === 'object' && response.payload.data[ i ] !== null ) {
                                addRow( data[ i ], response.async );
                            }
                        }
                        var filters = [],
                            filtersSelect = [];
                        $( '.k-animation-container:visible input' ).each( function ( key, el ) {
                            filters.push( {
                                id: $( el ).attr( 'data-bind' ),
                                value: $( el ).val()
                            } );
                        } );
                        $( '.k-animation-container:visible select' ).each( function ( key, el ) {
                            filtersSelect.push( {
                                id: $( el ).attr( 'data-bind' ),
                                value: $( el ).data( "kendoDropDownList" ).select()
                            } );
                        } );
                        if ( !interval ) {
                            that.read();
                            that.trigger( 'streamed' );
                        } else {
                            throttled();
                        }
                        $( filters ).each( function ( key, value ) {
                            $( '[data-bind="' + value.id + '"]' ).val( value.value );
                        } );
                        $( filtersSelect ).each( function ( key, value ) {
                            $( '[data-bind="' + value.id + '"]' ).data( "kendoDropDownList" ).select( value.value );
                        } );
                    }
                }
            } );
            that.trigger( 'streamRequestSend' );
            jmr.send( {
                request: streaming.request,
                cid: that.id,
                query: streaming.query,
                async: async
            } );
        },
        startAsync: function () {
            this._pipeData( true );
        },
        stopAsync: function () {
            var that = this,
                evntName = that.id + ':async',
                jmr = window.nmsweb.jmr();
            jmr.unbind( evntName );
            jmr.unbind( evntName + ':error' );
        },
        startStreaming: function () {
            var that = this;
            if ( !that.streaming.fired ) {
                $( 'body' ).on( 'nmsweb:jmrBack', function () {
                    if ( that.streaming.status ) {
                        console.info( 'Renewing streaming for ', that.id );
                        that.startStreaming();
                    }
                } );
            }
            that._pipeData( false );
            that.streaming.fired = true;
        },
        stopStreaming: function () {
            var that = this,
                evntName = that.id,
                jmr = window.nmsweb.jmr();
            jmr.unbind( evntName );
            jmr.unbind( evntName + ':error' );
            that.streaming.status = false;
            jmr.send( {
                request: 'stopstream',
                cid: that.id
            } );
        },
        filterData: function () {
            var that = this,
                data = that.data(),
                filters = that.filter(),
                query = new window.kendo.data.Query( data ),
                filteredData = query.filter( filters ).data;
            return filteredData.slice();
        },
        keys: function () {
            var that = this,
                keys = that._data[ 0 ].toJSON(),
                fields = Object.keys( keys );
            return fields.slice();
        },
        //Functions which provide extra callbacks!
        success: function ( data ) {
            data = data || [];
            var that = this,
                result = window.kendo.data.DataSource.fn.success.call( that, data );
            that.trigger( 'successPrivate' );
            return result;
        },
        _accept: function ( result ) {
            var that = this,
                originalResult,
                type = result.type;
            originalResult = window.kendo.data.DataSource.fn._accept.call( that, result );
            if ( type === 'destroy' ) {
                that.trigger( 'delete' );
            } else if ( type === 'update' ) {
                that.trigger( 'update' );
            } else if ( type === 'create' ) {
                that.trigger( 'create' );
            }
            return originalResult;
        },
        sort: function ( val ) {
            var that = this,
                result;
            if ( typeof val !== 'undefined' && that.remote ) {
                // that.unbind('successPrivate');
                that.one( 'successPrivate', function () {
                    that.trigger( 'sort' );
                } );
            }
            result = window.kendo.data.DataSource.fn.sort.call( that, val );
            if ( typeof val !== 'undefined' && !that.remote ) {
                that.trigger( 'sort' );
            }
            return result;
        },
        page: function ( val ) {
            var that = this,
                result;
            if ( typeof val !== 'undefined' && that.remote ) {
                // that.unbind('successPrivate');
                that.one( 'successPrivate', function () {
                    that.trigger( 'page' );
                } );
            }
            result = window.kendo.data.DataSource.fn.page.call( that, val );
            if ( typeof val !== 'undefined' && !that.remote ) {
                that.trigger( 'page' );
            }
            return result;
        },
        filter: function ( val ) {
            var that = this,
                result;
            if ( typeof val !== 'undefined' && that.remote ) {
                // that.unbind('successPrivate');
                that.one( 'successPrivate', function () {
                    that.trigger( 'filter' );
                } );
            }
            result = window.kendo.data.DataSource.fn.filter.call( that, val );
            if ( typeof val !== 'undefined' && !that.remote ) {
                that.trigger( 'filter' );
            }
            return result;
        },
        group: function ( val ) {
            var that = this,
                result;
            if ( typeof val !== 'undefined' && that.remote ) {
                // that.unbind('successPrivate');
                that.one( 'successPrivate', function () {
                    that.trigger( 'group' );
                } );
            }
            result = window.kendo.data.DataSource.fn.group.call( that, val );
            if ( typeof val !== 'undefined' && !that.remote ) {
                that.trigger( 'group' );
            }
            return result;
        },
        selectFrom: function ( element ) {
            var that = this,
                obj;
            if ( element !== undefined ) {
                if ( typeof element === 'object' && element !== null ) {
                    obj = element;
                } else {
                    obj = that.getByUid( element );
                }
                if ( typeof obj !== 'undefined' ) {
                    if ( typeof obj.idField !== 'undefined' ) {
                        element = obj[ obj.idField ];
                    } else if ( typeof obj === 'object' && obj !== null ) {
                        element = obj.uid;
                    }
                    that._las = element;
                }
            }
            return that._las;
        },
        selectTo: function ( element ) {
            var that = this,
                obj,
                data,
                i,
                len,
                idField,
                finish,
                started = false;
            if ( element !== undefined ) {
                if ( typeof element === 'object' && element !== null ) {
                    obj = element;
                } else {
                    obj = that.getByUid( element );
                }
                idField = obj.idField || 'uid';
                try {
                    data = that.filterData();
                    data = data.length ? data : that.data();
                } catch ( e ) {
                    data = that.data();
                }
                that._selected.length = 0;
                for ( i = 0, len = data.length; i < len; i++ ) {
                    if ( started ) {
                        that._selected.push( data[ i ][ idField ] );
                        if ( finish === data[ i ][ idField ] ) {
                            break;
                        }
                    } else if ( data[ i ][ idField ] === that._las || data[ i ][ idField ] === obj[ idField ] ) {
                        started = true;
                        finish = ( data[ i ][ idField ] !== obj[ idField ] ) ? obj[ idField ] : that._las;
                        i--;
                    }
                }
                that.trigger( 'change' );
            }
        },
        // A selection memory logic (added 'Mem' to prevent colisions with future DS changes which they come from Kendo)
        _selectMem: function ( element ) {
            var that = this,
                obj;
            if ( typeof element === 'object' && element !== null ) {
                obj = element;
            } else {
                obj = that.getByUid( element );
            }
            if ( typeof obj === 'undefined' ) {
                obj = that.get( element );
            }
            if ( typeof obj !== 'undefined' ) {
                if ( typeof obj.idField !== 'undefined' ) {
                    element = obj[ obj.idField ];
                } else if ( typeof obj === 'object' && obj !== null ) {
                    element = obj.uid;
                }
                if ( that._selected.indexOf( element ) === -1 ) {
                    that._selected.push( element );
                }
            }
        },
        selectMem: function () {
            var that = this,
                i, len;
            for ( i = 0, len = arguments.length; i < len; i++ ) {
                that._selectMem( arguments[ i ] );
            }
        },
        _unselectMem: function ( element ) {
            var that = this,
                obj, index;
            if ( typeof element === 'object' && element !== null ) {
                obj = element;
            } else {
                obj = that.getByUid( element );
            }
            if ( typeof obj === 'undefined' ) {
                obj = that.get( element );
            }
            if ( typeof obj !== 'undefined' ) {
                if ( typeof obj.idField !== 'undefined' ) {
                    element = obj[ obj.idField ];
                } else if ( typeof obj === 'object' && obj !== null ) {
                    element = obj.uid;
                }
                index = that._selected.indexOf( element );
                if ( index !== -1 ) {
                    that._selected.splice( index, 1 );
                }
            }
        },
        unselectMem: function () {
            var that = this,
                i, len;
            for ( i = 0, len = arguments.length; i < len; i++ ) {
                that._unselectMem( arguments[ i ] );
            }
        },
        getSelectedIds: function () {
            var that = this;
            return that._selected;
        },
        forceSelect: function ( elements ) {
            var that = this;
            that._selected = elements;
        },
        deselectAll: function () {
            var that = this;
            that._selected = [];
        },
        selectAll: function () {
            var that = this,
                data, i, len;
            that.deselectAll();
            if ( that.options.serverFiltering ) {
                data = that._data;
            } else {
                data = that.filterData();
            }
            for ( i = 0, len = data.length; i < len; i++ ) {
                that.selectMem( data[ i ] );
            }
        },
        selectedLen: function () {
            var that = this;
            return that._selected.length;
        },
        destroy: function () {
            var that = this;
            if ( that.streaming !== undefined && that.streaming.status ) {
                that.stopStreaming();
            }
            if ( that.async !== undefined ) {
                that.stopAsync();
            }
            //unset myself from globalnamespace
            delete window.nmsweb.DataSources[ that.id ];
        }
    } );
    return window.nmsweb.DataSource;
} );