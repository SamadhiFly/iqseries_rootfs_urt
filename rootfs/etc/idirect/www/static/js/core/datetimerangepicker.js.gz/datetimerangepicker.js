define( [ "jquery", "kendo", "core/datetimepicker", "core/nmsweb", "core/input_validation" ], function ( $ ) {
    "use strict";
    var DateTimeRangePicker,
        kendo = window.kendo,
        Observable = kendo.Observable,
        truncate,
        calculateTimespan,
        calculateDate;
    truncate = function ( truncateParams ) {
        var currentDate = truncateParams.currentDate,
            sign = truncateParams.sign,
            number = parseInt( truncateParams.number, 10 ),
            unit = truncateParams.unit,
            calculatedDate = currentDate,
            dayOfTheWeek;
        return ( function () {
            switch ( unit ) {
            case 'Y':
                if ( sign === '+' || sign === undefined || sign === null || sign === '' ) {
                    calculatedDate.setFullYear( calculatedDate.getFullYear() + number );
                } else if ( sign === '-' ) {
                    calculatedDate.setFullYear( calculatedDate.getFullYear() - number );
                }
                calculatedDate.setMonth( 0 );
                calculatedDate.setDate( 1 );
                calculatedDate.setHours( 0 );
                calculatedDate.setTime( calculatedDate.getTime() );
                break;
            case 'M':
                if ( sign === '+' || sign === undefined || sign === null || sign === '' ) {
                    calculatedDate.setMonth( calculatedDate.getMonth() + number );
                } else if ( sign === '-' ) {
                    calculatedDate.setMonth( calculatedDate.getMonth() - number );
                }
                calculatedDate.setDate( 1 );
                calculatedDate.setHours( 0 );
                break;
            case 'W':
                // go into that week
                if ( sign === '+' || sign === undefined || sign === null || sign === '' ) {
                    calculatedDate.setTime( calculatedDate.getTime() + number * 7 * 24 * 3600 * 1000 );
                } else if ( sign === '-' ) {
                    calculatedDate.setTime( calculatedDate.getTime() - number * 7 * 24 * 3600 * 1000 );
                }
                // check what day of week is in that week and adjust it to monday
                dayOfTheWeek = calculatedDate.getDay();
                if ( dayOfTheWeek === 0 ) {
                    calculatedDate.setTime( calculatedDate.getTime() - 6 * 24 * 3600 * 1000 );
                } else {
                    calculatedDate.setTime( calculatedDate.getTime() - ( dayOfTheWeek - 1 ) * 24 * 3600 * 1000 );
                }
                calculatedDate.setHours( 0 );
                break;
            case 'D':
                // go to that day
                if ( sign === '+' || sign === undefined || sign === null || sign === '' ) {
                    calculatedDate.setTime( calculatedDate.getTime() + number * 24 * 3600 * 1000 );
                } else if ( sign === '-' ) {
                    calculatedDate.setTime( calculatedDate.getTime() - number * 24 * 3600 * 1000 );
                }
                // reset to midnight
                calculatedDate.setHours( 0 );
                break;
            case 'H':
                // go to that hour
                if ( sign === '+' || sign === undefined || sign === null || sign === '' ) {
                    calculatedDate.setTime( calculatedDate.getTime() + number * 3600 * 1000 );
                } else if ( sign === '-' ) {
                    calculatedDate.setTime( calculatedDate.getTime() - number * 3600 * 1000 );
                }
                break;
            }
            calculatedDate.setMinutes( 0 );
            calculatedDate.setSeconds( 0 );
            return calculatedDate;
        }() );
    };
    calculateTimespan = function ( timeSpanParams ) {
        var currentDate = timeSpanParams.currentDate,
            sign = timeSpanParams.sign,
            number = parseInt( timeSpanParams.number, 10 ),
            unit = timeSpanParams.unit,
            UTC = timeSpanParams.UTC,
            calculatedDate = currentDate,
            setCalculatedDate = function () {
                switch ( unit ) {
                case 'y':
                    if ( sign === '+' || sign === undefined || sign === null || sign === '' ) {
                        calculatedDate.setFullYear( calculatedDate.getFullYear() + number );
                    } else if ( sign === '-' ) {
                        calculatedDate.setFullYear( calculatedDate.getFullYear() - number );
                    }
                    break;
                case 'm':
                    if ( sign === '+' || sign === undefined || sign === null || sign === '' ) {
                        calculatedDate.setMonth( calculatedDate.getMonth() + number );
                    } else if ( sign === '-' ) {
                        calculatedDate.setMonth( calculatedDate.getMonth() - number );
                    }
                    break;
                case 'w':
                    if ( sign === '+' || sign === undefined || sign === null || sign === '' ) {
                        calculatedDate.setTime( calculatedDate.getTime() + number * 7 * 24 * 3600 * 1000 );
                    } else if ( sign === '-' ) {
                        calculatedDate.setTime( calculatedDate.getTime() - number * 7 * 24 * 3600 * 1000 );
                    }
                    break;
                case 'd':
                    if ( sign === '+' || sign === undefined || sign === null || sign === '' ) {
                        calculatedDate.setTime( calculatedDate.getTime() + number * 24 * 3600 * 1000 );
                    } else if ( sign === '-' ) {
                        calculatedDate.setTime( calculatedDate.getTime() - number * 24 * 3600 * 1000 );
                    }
                    break;
                case 'h':
                    if ( sign === '+' || sign === undefined || sign === null || sign === '' ) {
                        calculatedDate.setTime( calculatedDate.getTime() + number * 3600 * 1000 );
                    } else if ( sign === '-' ) {
                        calculatedDate.setTime( calculatedDate.getTime() - number * 3600 * 1000 );
                    }
                    break;
                case 's':
                    if ( sign === '+' || sign === undefined || sign === null || sign === '' ) {
                        calculatedDate.setTime( calculatedDate.getTime() + number * 1000 );
                    } else if ( sign === '-' ) {
                        calculatedDate.setTime( calculatedDate.getTime() - number * 1000 );
                    }
                    break;
                }
            };
        if ( UTC ) {
            calculatedDate.setTime( currentDate.getTime() + ( 60000 * calculatedDate.getTimezoneOffset() ) );
        }
        if ( unit === 'Y' || unit === 'M' || unit === 'W' || unit === 'D' || unit === 'H' || unit === 'S' ) {
            calculatedDate = truncate( {
                'sign': timeSpanParams.sign,
                'number': timeSpanParams.number,
                'unit': timeSpanParams.unit,
                'UTC': timeSpanParams.UTC,
                'currentDate': currentDate
            } );
        } else {
            setCalculatedDate();
        }
        return calculatedDate;
    };
    calculateDate = function ( range ) {
        var rangePattern = /([\+\-]*)(\d+)([YMWDHymwdhs]*) ?(UTC)*/g,
            rangeParts = [],
            rangePart,
            calculatedDate = new Date();
        while ( true ) {
            rangePart = rangePattern.exec( range );
            if ( rangePart ) {
                rangePart[ 4 ] = rangePart[ 4 ] === 'UTC' ? true : false;
                rangePart[ 4 ] = true; //For 1.0 UTC is always true
                calculatedDate = calculateTimespan( {
                    'currentDate': calculatedDate,
                    'sign': rangePart[ 1 ],
                    'number': rangePart[ 2 ],
                    'unit': rangePart[ 3 ],
                    'UTC': rangePart[ 4 ]
                } );
                rangeParts.push( rangePart );
            } else {
                break;
            }
        }
        return calculatedDate;
    };
    DateTimeRangePicker = Observable.extend( {
        defaults: {
            format: "yyyy-MM-dd HH:mm:ss",
            auto_fillers: {
                "Last 30 Minutes": {
                    start_range: "-1800s",
                    end_range: "0"
                },
                "Last Hour": {
                    start_range: "-1h",
                    end_range: "0"
                },
                "Last 6 Hours": {
                    start_range: "-6h",
                    end_range: "0"
                },
                "Last 24 Hours": {
                    start_range: "-1d",
                    end_range: "0"
                },
                "Last 48 Hours": {
                    start_range: "-2d",
                    end_range: "0"
                },
                "Last 7 Days": {
                    start_range: "-7d",
                    end_range: "0"
                }
            }
        },
        stream: false,
        relative: false,
        current_flag: false,
        init: function ( selector, options ) {
            var that = this,
                $current_flag, $current_link;
            that.proxy = {
                'truncate': truncate,
                'calculateTimespan': calculateTimespan,
                'calculateDate': calculateDate
            };
            that.element = $( selector );
            if ( options.opts ) {
                nmsweb.extendOptions( that.defaults, options.opts );
            } else {
                nmsweb.extendOptions( that.defaults, options );
            }
            //Add reference date elements if needed
            if ( that.element.find( '.n-datetimerangepicker-start' ).length < 1 && that.element.find( '.n-datetimerangepicker-end' ).length < 1 ) {
                that.default_date = -1;
            } else if ( that.element.find( '.n-datetimerangepicker-start' ).length < 1 ) {
                that.element.append( $( '<input />', {
                    class: 'n-datetimerangepicker-start n-datetimerangepicker-default'
                } ).hide() );
                that.default_date = 0;
            } else if ( that.element.find( '.n-datetimerangepicker-end' ).length < 1 ) {
                that.element.append( $( '<input />', {
                    class: 'n-datetimerangepicker-end n-datetimerangepicker-default'
                } ).hide() );
                that.default_date = 1;
            }
            that.startDate = that.element.find( '.n-datetimerangepicker-start' ).nmswebDateTimePicker( that.defaults ).data( 'nmswebDateTimePicker' );
            that.startDate.cleanValue = '';
            that.startDate.bind( 'change', function () {
                var startDate = that.startDate.value();
                if ( startDate ) {
                    startDate = new Date( startDate );
                    startDate.setDate( startDate.getDate() );
                    that.endDate.min( startDate );
                    //Reset relative
                    that.relative = false;
                }
            } );
            that.endDate = that.element.find( '.n-datetimerangepicker-end' ).nmswebDateTimePicker( that.defaults ).data( 'nmswebDateTimePicker' );
            that.endDate.bind( 'change', function () {
                var endDate = that.endDate.value();
                if ( endDate ) {
                    endDate = new Date( endDate );
                    endDate.setDate( endDate.getDate() );
                    that.startDate.max( endDate );
                    //Reset resolution
                    that.relative = false;
                }
            } );
            that.resolutionObj = that.element.closest( '.n-datetimerangepicker-form-holder' ).find( 'select[name=Resolution]' );
            that.stream = that.element.find( '.n-datetimerangepicker-checks-holder .n-datetimerangepicker-stream-check' ).prop( 'checked' );
            that.element.find( '.n-datetimerangepicker-intervals' ).on( 'click', 'a', function ( e ) {
                $current_link = $( this ).text();
                that.endDate.min( kendo.ui.DateTimePicker.fn.options.min );
                that.startDate.max( kendo.ui.DateTimePicker.fn.options.max );
                that.setDateTimeInterval( $current_link, that.defaults );
                // This is a clean value of start date here
                that.startDate.cleanValue = that.startDate.val();
                that.endDate.trigger( 'change' );
                that.startDate.trigger( 'change' );
                that.endDate.element.trigger( 'change' );
                that.startDate.element.trigger( 'change' );
                that.relative = true;
                e.preventDefault();
            } );
            that.element.find( '.n-datetimerangepicker-streaming-intervals' ).on( 'click', 'a', function ( e ) {
                var link = this;
                $current_link = $( this ).text();
                that.endDate.min( kendo.ui.DateTimePicker.fn.options.min );
                that.startDate.max( kendo.ui.DateTimePicker.fn.options.max );
                that.setDateTimeInterval( $( link ).text(), that.defaults );
                // This is a clean value of start date here
                that.startDate.cleanValue = that.startDate.val();
                that.startDate.trigger( 'change' );
                that.endDate.trigger( 'change' );
                that.endDate.element.trigger( 'change' );
                that.startDate.element.trigger( 'change' );
                that.relative = true;
                e.preventDefault();
            } );
            that.element.find( '.n-datetimerangepicker-checks-holder .n-datetimerangepicker-stream-check' ).on( 'click', function () {
                var cleanValueUpdate = false;
                if ( $( this ).is( ':checked' ) ) {
                    that.stream = true;
                    var newDate = new Date();
                    // If start-end date fields are clean, let's update them
                    if ( that.startDate.val() === that.startDate.cleanValue ) {
                        that.setDateTimeInterval( $current_link, that.defaults );
                        that.startDate.trigger( 'change' );
                        that.endDate.trigger( 'change' );
                        that.endDate.element.trigger( 'change' );
                        that.startDate.element.trigger( 'change' );
                        cleanValueUpdate = true;
                    } else {
                        // Just change the end date
                        that.startDate.max( newDate );
                        that.element.find( '.n-datetimerangepicker-end' ).val( newDate );
                    }
                    that.element.find( '.n-datetimerangepicker-end' ).trigger( 'blur' );
                    that.element.find( '.n-datetimerangepicker-end' ).attr( 'disabled', 'true' );
                    that.element.find( '.n-datetimerangepicker-intervals' ).addClass( 'hide' );
                    that.element.find( '.n-datetimerangepicker-streaming-intervals' ).removeClass( 'hide' );
                } else {
                    that.stream = false;
                    that.startDate.max( that.endDate.value() );
                    that.element.find( '.n-datetimerangepicker-end' ).removeAttr( 'disabled' );
                    that.element.find( '.n-datetimerangepicker-intervals' ).removeClass( 'hide' );
                    that.element.find( '.n-datetimerangepicker-streaming-intervals' ).addClass( 'hide' );
                }
                that.resolutionObj.trigger( 'change' );
                if ( cleanValueUpdate ) {
                    that.startDate.cleanValue = that.startDate.val();
                }

            } );
            //set current_flag to default
            if ( that.element.closest( '.n-datetimerangepicker-form-holder' ).find( '.n-current-flag' ).length > 0 ) {
                $current_flag = that.element.closest( '.n-datetimerangepicker-form-holder' ).find( '.n-current-flag' );
                that.current_flag = $current_flag.val();
                $current_flag.on( 'change', function () {
                    that.current_flag = $( this ).prop( 'checked' );
                } );
            }
            that.resolutionObj.on( 'change', function () {
                if ( typeof $( this ).val() !== undefined ) {
                    that.resolution = $( this ).val();
                }
            } );
            if ( that.element.closest( '.n-configurator-section-form-DateRange' ) ) {
                var conf = $( '.n-configurator' ).data( 'nmswebConfigurator' );
                if ( conf ) {
                    conf._applySectionTemplate(
                        conf.options.sections.DateRange, {
                            Date_Range: that.val()
                        } );
                }
            }
            return that;
        },
        setDateTimeInterval: function ( interval, options ) {
            var that = this,
                auto_fillers,
                start_range,
                end_range;
            if ( options.opts ) {
                if ( options.opts.streaming && options.opts.streaming.streaming_auto_fillers ) {
                    auto_fillers = $.extend( options.opts.auto_fillers, options.opts.streaming.streaming_auto_fillers );
                } else {
                    auto_fillers = options.opts.auto_fillers;
                }
            } else {
                if ( options.streaming && options.streaming.streaming_auto_fillers ) {
                    auto_fillers = $.extend( options.auto_fillers, options.streaming.streaming_auto_fillers );
                } else {
                    auto_fillers = options.auto_fillers;
                }
            }
            start_range = calculateDate( auto_fillers[ interval ].start_range );
            end_range = calculateDate( auto_fillers[ interval ].end_range );
            that.startDate.value( start_range );
            that.startDate.template( auto_fillers[ interval ].start_range );
            //var streamCheckbox = that.element.parents('.n-configurator-section-form').find('.n-datetimerangepicker-checks-holder .n-datetimerangepicker-stream-check');
            //if ((streamCheckbox.length === 0) || !streamCheckbox.prop('checked')) {
            that.endDate.value( end_range );
            that.endDate.template( auto_fillers[ interval ].end_range );
            //}
            return that;
        },
        setValue: function ( value ) {
            var that = this,
                startTemplate = value.template[ 0 ],
                endTemplate = value.template[ 1 ],
                newStartDate,
                newEndDate;
            if ( startTemplate !== "" && ( that.relative || value.value[ 0 ] === "" ) ) {
                newStartDate = calculateDate( startTemplate );
            } else {
                newStartDate = value.value[ 0 ];
            }
            that.startDate.template( startTemplate );
            if ( typeof ( value.value[ 1 ] ) !== "undefined" ) {
                if ( endTemplate !== "" && ( that.relative || value.value[ 1 ] === "" ) ) {
                    newEndDate = calculateDate( endTemplate );
                } else {
                    newEndDate = value.value[ 1 ];
                }
            }
            that.endDate.template( endTemplate );
            if ( newStartDate > newEndDate ) {
                that.startDate.val( newEndDate );
            } else {
                that.startDate.val( newStartDate );
            }
            if ( that.stream ) {
                that.endDate.val( new Date() );
            } else {
                that.endDate.val( newEndDate );
            }
        },
        val: function ( value ) {
            var that = this,
                createValueObject = function ( stream, dtvalue, dttemplate ) {
                    return {
                        stream: stream,
                        relative: that.relative,
                        value: dtvalue,
                        template: dttemplate,
                        default_date: that.default_date,
                        resolution: that.resolution,
                        current_flag: that.current_flag
                    };
                };
            if ( !value ) {
                if ( that.stream ) {
                    value = createValueObject( true, [ that.startDate.val() ], [ that.startDate.template(), "" ] );
                } else {
                    value = createValueObject( false, [
                        that.startDate.val(),
                        that.endDate.val()
                    ], [
                        that.startDate.template(),
                        that.endDate.template()
                    ] );
                }
            } else {
                if ( typeof value === 'string' ) {
                    value = JSON.parse( value );
                }
                var streamCheckbox = that.element.find( '.n-datetimerangepicker-checks-holder .n-datetimerangepicker-stream-check' );
                if ( ( value.stream && !streamCheckbox.is( ':checked' ) ) || ( !value.stream && streamCheckbox.is( ':checked' ) ) ) {
                    streamCheckbox.click();
                }
                that.stream = value.stream;
                if ( value.resolution ) {
		    that.resolution = value.resolution;
                    that.resolutionObj.val( value.resolution );
                }
                if ( value.relative ) {
                    that.relative = value.relative;
                }
                if ( !$.isArray( value.value ) && value.value.length > 2 ) {
                    throw 'val for range picker expects array of 2 or less elements: start and  optional end time';
                } else {
                    that.setValue( value );
                }
            }
            return value;
        }
    } );
    window.nmsweb.registerComponent( 'DateTimeRangePicker', DateTimeRangePicker );
    return DateTimeRangePicker;
} );
