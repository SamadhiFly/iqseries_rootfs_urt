define( "core/configurator", [ "jquery", "jqueryConfirm", "kendo", "core/nmsweb", "core/notification", "core/input", "core/popover", "core/utils" ], function ( $ ) {
    'use strict';
    var that,
        thatelement,
        configurator_values,
        Configurator = window.kendo.Observable.extend( {
            that: that,
            levels: [],
            level: 'simple',
            asyncSections: [ 'ElementSelector' ],
            waitForSections: {},
            intermediate_level: false,
            advanced_level: false,
            thatelement: thatelement,
            configurator_values: configurator_values,
            init: function ( element, options ) {
                var that = this,
                    thatelement = element,
                    defaults = {};
                this.configurator_values = [];
                if ( options ) {
                    options = $.extend( true, defaults, options );
                }
                window.kendo.Observable.fn.init.call( that, element, defaults );
                that.that = that;
                that.thatelement = thatelement;
                that.options = options;
                that._populateValuesHolder( defaults );
                that._checkForLevels( defaults );
                that._createSections( defaults );
                if ( !window.callbacksReady ) {
                    $( document ).one( 'callbacksReady', function () {
                        that._applyConfiguratorStyles( defaults );
                    } );
                } else {
                    that._applyConfiguratorStyles( defaults );
                }
            },
            _checkForLevels: function ( options ) {
                var $configurator = this;
                this.levels = []; //clear any previous entries if any
                $.each( options.sections, function ( key, val ) {
                    if ( val.levels !== undefined && val.levels !== null && val.levels.length > 1 ) {
                        var sectionLevels = val.levels;
                        $.each( sectionLevels, function ( key, level ) {
                            var sectionLevel = level;
                            if ( $.inArray( sectionLevel, $configurator.levels ) === -1 ) {
                                $configurator.levels.push( sectionLevel );
                            }
                        } );
                    }
                } );
            },
            _handleSectionTemplateExpand: function ( $expandLink, forceCollapse ) {
                if ( $expandLink && $expandLink.length > 0 ) {
                    var that = this,
                        section = that.options.sections[ $( $expandLink.parents( 'fieldset[data-configurator-name]' ) ).attr( 'data-configurator-name' ) ],
                        $popover = $( 'fieldset[data-configurator-name=' + section.name + ']' ).find( '.n-configurator-section-title' ).data( 'nmswebPopover' ),
                        $form = $( '.n-configurator-section-form-' + section.name ),
                        values = that._getFieldValues( $form ),
                        event = jQuery.Event( section.name + ":submit" );
                    if ( $expandLink.text() === "Show More..." && !forceCollapse ) {
                        $expandLink.text( "Show Less..." );
                        $( that.thatelement ).trigger( event, {
                            'values': values,
                            'options': section,
                            'popover': $popover,
                            'showAllValues': true
                        } );
                        if ( !event.isDefaultPrevented() ) {
                            that._applySectionTemplate( section, values, true );
                        }
                    } else {
                        $expandLink.text( "Show More..." );
                        $( that.thatelement ).trigger( event, {
                            'values': values,
                            'options': section,
                            'popover': $popover,
                            'showAllValues': false
                        } );
                        if ( !event.isDefaultPrevented() ) {
                            that._applySectionTemplate( section, values, false );
                        }
                    }
                }
            },
            _updateConfiguratorValues: function ( values ) {
                var that = this,
                    fieldValue,
                    $sectionForm;
                $.each( that.configurator_values, function () {
                    that = this;
                    if ( values !== undefined ) {
                        $.each( values, function ( key, value ) {
                            if ( value.section !== undefined && value.section === that.templatename ) {
                                $.each( that.items, function () {
                                    if ( this.text === value.name ) {
                                        this.value = value.value;
                                        return false;
                                    }
                                } );
                            }
                        } );
                    } else {
                        $sectionForm = $( '.n-configurator-section-form-' + that.templatename );
                        $.each( that.items, function ( key, value ) {
                            fieldValue = $sectionForm.find( '[data-configurator-name=' + value.text + ']' ).val();
                            if ( fieldValue !== undefined ) {
                                value.value = fieldValue;
                            }
                        } );
                    }
                } );
            },
            _populateValuesHolder: function ( options ) {
                var $configurator = this.that;
                $.each( options.sections, function () {
                    var $section = $( ".n-configurator-section-form-" + this.name ),
                        $fields,
                        section = {};
                    section.text = this.title;
                    section.title = this.title.replace( /_/g, ' ' );
                    section.templatename = this.name;
                    section.items = [];
                    $fields = $section.children( 'div' )
                        .each( function () {
                            var $fieldname,
                                that = this;
                            if ( $( that ).attr( 'data-configurator-name' ) ) {
                                $fieldname = $( that ).attr( 'data-configurator-name' );
                            } else {
                                $fieldname = $( that ).find( '[data-configurator-tracked]' ).attr( 'data-configurator-name' );
                            }
                            if ( $fieldname !== undefined ) {
                                section.items.push( {
                                    text: $fieldname,
                                    title: $( that ).find( '[data-configurator-title]' ).attr( 'data-configurator-title' ) || $fieldname.replace( /_/g, ' ' ),
                                    value: 'not configured'
                                } );
                            }
                        } );
                    $configurator.configurator_values.push( section );
                } );
            },
            _getTreeStructure: function ( presetValues ) {
                var sections = this.configurator_values,
                    addSection = false,
                    specifyData = [];
                $.each( sections, function () {
                    var section = this,
                        sectionObject = {};
                    sectionObject.text = section.text;
                    sectionObject.title = section.text.replace( /_/g, ' ' );
                    sectionObject.items = [];
                    addSection = false;
                    $.each( section.items, function () {
                        var fieldName = this.text;
                        $.each( presetValues, function () {
                            var presetName = this.name,
                                presetFieldTitle = this.label;
                            if ( presetName === fieldName ) {
                                addSection = true;
                                sectionObject.items.push( {
                                    text: presetName,
                                    title: presetFieldTitle.replace( /_/g, ' ' ),
                                    value: this.value,
                                    section: section.templatename
                                } );
                            }
                        } );
                    } );
                    if ( addSection === true ) {
                        specifyData.push( sectionObject );
                    }
                } );
                return specifyData;
            },
            _getPresetJSON: function ( $tree, $presetData, $allFields ) {
                var $checkboxes = $tree.children( 'ul' ).children( 'li' ).find( 'li' ).find( '[type=checkbox]' ),
                    preset = {};
                preset.fields = [];
                $checkboxes.each( function () {
                    if ( this.checked || $allFields ) {
                        var name = this.name;
                        $.each( $presetData, function () {
                            $.each( this.items, function () {
                                if ( this.text === name ) {
                                    preset.fields.push( {
                                        name: name,
                                        value: this.value,
                                        section: this.section
                                    } );
                                }
                            } );
                        } );
                    }
                } );
                return preset;
            },
            _getTree: function ( treeObject ) {
                var $presetTree = $( '<div></div>' );
                $presetTree.kendoTreeView( {
                    template: "#= item.title # ",
                    dataSource: treeObject,
                    checkboxes: {
                        template: "<input type='checkbox' checked='checked' configname='#= item.text #' titlename='#= item.title #' name='#= item.text #' value='true' />"
                    }
                } );
                $presetTree.find( '[type=checkbox]' ).change( function () {
                    var chkBox = $( this ),
                        pBoxes,
                        checkBoxes,
                        parent = chkBox.parent();
                    if ( parent !== null && chkBox.parent()[ 0 ].nodeName !== 'DIV' ) {
                        parent = parent.parent();
                        if ( parent !== null && parent[ 0 ].nodeName === 'DIV' ) {
                            pBoxes = $( parent ).closest( '.k-item' ).find( ":checkbox" );
                            if ( pBoxes.length > 0 ) {
                                $( pBoxes ).prop( 'checked', this.checked ? "checked" : "" );
                            }
                        }
                        checkBoxes = chkBox.parent().find( ":checkbox" );
                        if ( checkBoxes.length > 0 ) {
                            $( checkBoxes ).prop( 'checked', this.checked ? "checked" : "" );
                        }
                    }
                } );
                return $presetTree;
            },
            _getContent: function ( data ) {
                var that = this,
                    $grid = $( '<div class="n-configurator-presets-grid"></div>' ).nmswebGrid( {
                        pageable: true,
                        navigatable: false,
                        autoBind: true,
                        dataSource: {
                            data: data.presets,
                            pageSize: 10
                        },
                        columns: [ {
                            field: "name",
                            width: 250,
                            title: "Name"
                        } ],
                        rowTemplate: '<tr ${ window.kendo.attr(\'uid\') + \'="\' + uid + \'"\' }> ' +
                            '<td><a class="n-configurator-preset-link" data-item-id="#= id #">#= name #</a></td>' +
                            '<td style="width:80px;">' +
                            '<button class="btn btn-primary specify-preset-button">Specify</button>' +
                            '</td>' +
                            '<td style="width:160px;">' +
                            '<div class="n-elementselectorgrid n-element-selector-toggle-holder">' +
                            '<div class="n-tree-builder-div">' +
                            '<div class="n-button-container btn-group">' +
                            '<button type="button" class="n-splitbutton-action btn default" data-item-id="#= id #" action="rename">Rename</button>' +
                            '<button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">' +
                            '<span class="caret"></span>' +
                            '</button>' +
                            '<ul class="n-action-list dropdown-menu hide">' +
                            '<li actionvalue="rename" actionname="Rename">' +
                            '<a>Rename</a>' +
                            '</li>' +
                            '<li actionvalue="delete" actionname="Delete">' +
                            '<a>Delete</a>' +
                            '</li>' +
                            '</ul>' +
                            '</div>' +
                            '</div>' +
                            '</div>' +
                            '</td>' +
                            '</tr>'
                    } )
                    .on( 'click', '.n-splitbutton-choose', function () {
                        $( this ).parent( '.n-splitbutton-container' ).toggleClass( 'open' );
                    } )
                    .on( 'click', 'li[actionvalue]', function () {
                        var $listitem = $( this );
                        var $actionButton = $listitem.parents( '.n-button-container' ).find( 'button.n-splitbutton-action' );
                        var text = $actionButton.text();
                        var action_val = $actionButton.attr( 'action' );
                        $actionButton.text( $listitem.attr( 'actionname' ) )
                            .attr( 'action', $listitem.attr( 'actionvalue' ) );
                        $listitem.parents( '.n-button-container' ).removeClass( 'open' );
                        that.executeItemAction( $actionButton, $actionButton.parents( '.n-grid' ).data( 'nmswebGrid' ).dataSource.get( parseInt( $actionButton.attr( 'data-item-id' ), 10 ) ) );
                        $actionButton.text( text )
                            .attr( 'action', action_val );
                    } )
                    .on( 'click', '.n-splitbutton-action', function () {
                        var $actionButton = $( this );
                        that.executeItemAction( $actionButton, $actionButton.parents( '.n-grid' ).data( 'nmswebGrid' ).dataSource.get( parseInt( $actionButton.attr( 'data-item-id' ), 10 ) ) );
                    } )
                    .on( 'click', '.specify-preset-button', function () {
                        var $specButton = $( this ),
                            $grid = $specButton.parents( '.n-configurator-presets-grid' ),
                            presetData = $grid.data( 'nmswebGrid' ).dataSource.getByUid( $specButton.parents( 'tr' ).data( 'uid' ).replace( /"/g, '' ) ),
                            getPresetContent = function () {
                                var $content,
                                    specNew,
                                    $specTree,
                                    $applyPresetAsSpecBtn;
                                if ( presetData.values.length > 0 ) {
                                    specNew = that._getTreeStructure( presetData.values );
                                    $specTree = that._getTree( specNew );
                                    $applyPresetAsSpecBtn = $( '<button class="btn btn-primary">Load Preset As Specified</button>' )
                                        .on( 'click', function () {
                                            var presetToApply = that._getPresetJSON( $specTree, specNew );
                                            window.nmsutils.preset.applyPreset( presetToApply.fields );
                                            $( "#content" ).trigger( 'nmsweb:notify', {
                                                "target": "content",
                                                "type": "success",
                                                "title": "Successfully applied Preset",
                                                "message": "'" + presetData.name + "' has been successfully applied."
                                            } );
                                            $( this ).parents( '.n-popoverbody' ).addClass( 'hide' );
                                            $specButton.parents( '.n-popoverbody' ).addClass( 'hide' );
                                            $( '#n-apply-preset-popover' ).addClass( 'hide' );
                                            that._applyFilter( that.level, true );
                                        } );
                                    $content = $( '<div class="n-specify-preset-box"></div>' )
                                        .append( $specTree )
                                        .append( $applyPresetAsSpecBtn );
                                }
                                return $content;
                            };
                        if ( !$specButton.attr( 'data-presets-obtained' ) ) {
                            $specButton.nmswebPopover( {
                                    'listen': {
                                        'event': 'nmsweb:configclose',
                                        'container': $( that.thatelement )
                                    },
                                    'cssclass': 'n-configurator-specify-preset-popover',
                                    'nested': true,
                                    'exclusive': false,
                                    'toggle': true,
                                    'persistent': true,
                                    'showOnCreation': true,
                                    'data': {
                                        'preset-id': presetData.id
                                    },
                                    'placement': 'right',
                                    'title': 'Specify Preset',
                                    'manual': true,
                                    'content': getPresetContent()
                                } )
                                .attr( 'data-presets-obtained', true );
                        }
                        $( '.n-configurator-specify-preset-popover:not(.n-configurator-specify-preset-popover[data-preset-id=' + presetData.id + '])' ).addClass( 'hide' );
                    } );
                //Initially fires dataSource change event for the preset grid
                $grid.data('nmswebGrid').dataSource.fetch();
                $grid.find( '.k-grid-content' ).removeAttr( 'style' );
                $grid.find( '.k-grouping-header, .k-grid-header, .k-scrollbar' ).addClass( 'hide' );
                return $( '<div></div>' ).append( $grid ).css( {} );
            },
            bindPresetClick: function () {
                var that = this,
                    $grid = $( '.n-configurator-presets-grid' );
                $grid.on( 'click', '.n-configurator-preset-link', function () {
                    var $presetLink = $( this ),
                        presetData = $grid.data( 'nmswebGrid' ).dataSource.getByUid( $presetLink.parents( 'tr' ).data( 'uid' ).replace( /"/g, '' ) );
                    $presetLink.parents( '.n-popoverbody' ).addClass( 'hide' );
                    var specNew = that._getTreeStructure( presetData.values ),
                        $specTree = that._getTree( specNew ),
                        presetToApply = that._getPresetJSON( $specTree, specNew, true );
                    var presetFeedback = window.nmsutils.preset.applyPreset( presetToApply.fields );
                    if ( presetFeedback.isValid && presetToApply.fields.length > 0 ) {
                        $( "#content" ).trigger( 'nmsweb:notify', {
                            "target": "content",
                            "type": "success",
                            "title": "Successfully applied Preset",
                            "message": "'" + presetData.name + "' has been successfully applied."
                        } );
                    } else {
                        $( "#content" ).trigger( 'nmsweb:notify', {
                            "target": "content",
                            "type": "warning",
                            "title": "Invalid Preset " + presetData.name,
                            "message": presetFeedback.message || "This preset is not valid for this configurator"
                        } );
                    }
                } );
            },
            _applyPresetClick: function ( $applyButton ) {
                var that = this,
                    $popover;
                if ( !$( '#n-configurator-apply-preset-popover' ).length ) {
                    $popover = $applyButton.nmswebPopover( {
                        'cssclass': 'n-configurator-apply-preset-popover',
                        'listen': {
                            'event': 'nmsweb:configclose',
                            'container': $( that.thatelement )
                        },
                        'showOnCreation': true,
                        'persistent': true,
                        'toggle': true,
                        'id': 'n-configurator-apply-preset-popover',
                        'placement': 'right',
                        'title': 'Load Query',
                        'manual': true,
                        'content': '<div class="spinWrapper" style="margin: 20px 100px;">&nbsp;</div>'
                    } );
                }
                $( '#n-configurator-apply-preset-popover .n-popover-content' ).html( '<div class="spinWrapper" style="margin:30px 100px;">&nbsp;</div>' );
                $( '.spinWrapper' ).spin();
                $.ajax( {
                    type: 'GET',
                    url: '/core/presets/index',
                    success: function ( data ) {
                        $( '#n-configurator-apply-preset-popover .n-popover-content' ).html( that._getContent( data ) );
                        that.bindPresetClick();
                    }
                } );
            },
            _applyFilter: function ( option, noHighlight ) {
                var highlightSection = function ( section ) {
                        $( section ).css( "-webkit-transition", "all 0.6s ease" )
                            .css( "backgroundColor", "white" )
                            .css( "-moz-transition", "all 0.6s ease" )
                            .css( "-o-transition", "all 0.6s ease" )
                            .css( "-ms-transition", "all 0.6s ease" )
                            .delay( 1000 ).queue( function () {
                                $( this ).css( "backgroundColor", "white" );
                            } );
                    },
                    that = this;
                $( '.n-configurator-section.' + option ).each( function () {
                    var $section = $( this );
                    if ( $section.hasClass( 'hide' ) ) {
                        $section.removeClass( 'hide' );
                        if ( !noHighlight ) {
                            highlightSection( $section );
                        }
                    }
                } );
                $( '.n-configurator-section:not(.n-configurator-section.' + option + ')' ).each( function () {
                    $( this ).addClass( 'hide' );
                } );
                $( '.n-configurator-section-field.' + option ).each( function () {
                    var $field = $( this );
                    if ( $field.hasClass( 'hide' ) ) {
                        $field.removeClass( 'hide' );
                        if ( !noHighlight ) {
                            highlightSection( $field );
                        }
                    }
                } );
                $( '.n-configurator-section-field:not(.n-configurator-section-field.' + option + ')' ).each( function () {
                    $( this ).addClass( 'hide' );
                } );
                $( '.n-configurator-section-template .' + option ).each( function () {
                    var $levelTemplate = $( this );
                    if ( $levelTemplate.hasClass( 'hide' ) ) {
                        $levelTemplate.removeClass( 'hide' );
                        if ( !noHighlight ) {
                            highlightSection( $levelTemplate );
                        }
                    }
                    $levelTemplate.find( '.hide' ).removeClass( 'hide' );
                } );
                $( '.n-configurator-section-template *:not(.n-configurator-section-template .' + option + ' *, .n-configurator-section-template .' + option + ')' ).each( function () {
                    if ( !$( this ).children( '.' + option ).length && !$( this ).parents( '.' + option ).length ) {
                        $( this ).addClass( 'hide' );
                    }
                } );
                $.each( $( '.n-configurator-section-template' ), function () {
                    var $sectionTemplate = $( this ),
                        containsLevels = false;
                    $.each( that.levels, function () {
                        if ( $sectionTemplate.find( '.' + this ).length > 0 ) {
                            containsLevels = true;
                        }
                    } );
                    if ( !containsLevels ) {
                        $sectionTemplate.find( '.hide' ).removeClass( 'hide' );
                    } else {
                        $.each( $( '.n-configurator-section-template div' ), function () {
                            var $divTemplate = $( this );
                            for ( var i = 0; i < that.levels.length; i++ ) {
                                if ( option != that.levels[ i ] && $divTemplate.hasClass( that.levels[ i ] ) && !$divTemplate.hasClass( option ) ) {
                                    $divTemplate.addClass( 'hide' );
                                }
                            }
                        } );
                    }
                } );
                $( this.thatelement ).trigger( 'nmsweb:configfiltered' );
            },
            _generateJSON: function ( presettree, type, additional ) {
                var $checkboxes = presettree.children( 'ul' ).children( 'li' ).find( 'li' ).find( '[type=checkbox]' ),
                    d,
                    preset = {};
                if ( $( '#n-save-query-name' )[ 0 ].value === '' ) {
                    d = new Date();
                    preset.name = 'myPreset' + d.getDate() + '/' + d.getMonth() + '/' + d.getFullYear();
                } else {
                    preset.name = $( '#n-save-query-name' )[ 0 ].value;
                }
                preset.url = window.location.protocol + "//" + window.location.host + window.location.pathname;
                preset.fields = [];
                $checkboxes.each( function () {
                    if ( this.checked ) {
                        var $section = $( '[data-configurator-name=' + this.attributes.configname.value + ']' ),
                            fieldValue = $section.val(),
                            type = ( $section.hasClass( 'n-elementselector' ) ) ? 'Element_Selector' : '',
                            filter,
                            elementselectorDs;
                        if ( fieldValue !== undefined ) {
                            if ( type === "Element_Selector" ) {
                                elementselectorDs = $section.find( '.n-elementselectorgrid' ).data( 'nmswebElementSelectorGrid' ).dataSource;
                                filter = elementselectorDs.origFilter;
                                //Remove intial Filter
                                if ( elementselectorDs.options.initialFilter ) {
                                    if ( filter && filter.filters && filter.filters[ 0 ] && JSON.stringify( filter.filters[ 0 ].filters ) === JSON.stringify( elementselectorDs.options.initialFilter ) ) {
                                        delete filter.filters[ 0 ];
                                        if ( filter.filters[ 1 ] ) {
                                            filter = filter.filters[ 1 ];
                                        }
                                    }
                                }
                                fieldValue.query = filter;
                            }
                            if ( typeof ( fieldValue ) === 'object' ) {
                                fieldValue = JSON.stringify( fieldValue );
                            }
                            preset.fields.push( {
                                name: this.attributes.configname.value,
                                title: this.attributes.titlename.value,
                                value: fieldValue,
                                type: type
                            } );
                        }
                    }
                } );
                preset.additional = additional;
                return preset;
            },
            _generateSaveContent: function ( type ) {
                var $content,
                    that = this,
                    popover_loaded = false,
                    type = $( 'input[name=query_type]:checked' ).val(),
                    $preset_input = $( '<p><input type="radio" name="query_type" value="preset" checked>Save Query Only</input><span id="presets_tooltip" class="label label-info n-popover mouse-pointer-setting" style="float:right;" >?</span></p>' )
                    .on( 'change', function () {
                        $( '#quicklink_specific_fields' ).toggle();
                    } ),
                    $quicklink_input = $( '<p><input type="radio" name="query_type" value="quicklink">Save Query and Tool</input><span id="ql_tooltip" class="label label-info n-popover mouse-pointer-setting" style="float:right;">?</span></p>' )
                    .on( 'change', function () {
                        $( '#quicklink_specific_fields' ).toggle();
                    } ),
                    $queryType = $( '<div class="save-query-radio"></div>' )
                    .append( $preset_input )
                    .append( $quicklink_input ),
                    $itemNameInput = $( '<div><label for=\'n-save-query-name\'>Query Name:</label><input id=\'n-save-query-name\' type=\'text\' eaass=\'query-name\'></input></div>' ),
                    $includeLabel = $( '<h4>Include:</h4>' ),
                    address = '/core/' + type + 's/index/',
                    $itemTree = that._getTree( that.configurator_values )
                    .css( 'padding', '10px' ),
                    $additionalButtons = "",
                    $saveItemButton = $( '<button class=\' n-cnf-btn blue n-configurator-save-preset-button\'>Save Query</button>' )
                    .on( 'click', function () {
                        var savebutton = this;
                        type = $( 'input[name=query_type]:checked' ).val();
                        address = '/core/' + type + 's/index/';
                        $( this ).parents( '.n-popover-content' ).css( 'min-height', $( this ).parents( '.n-popover-content' ).height() );
                        $( this ).parents( '.n-popover-content' ).css( 'min-width', $( this ).parents( '.n-popover-content' ).width() );
                        $( this ).parents( '.n-popover-content' ).children().hide();
                        $( this ).parents( '.n-popover-content' ).spin();
                        var item = that._generateJSON( $itemTree, type, {
                            "shouldSubmit": $( '.n-configurator-should-submit' ).prop( 'checked' ),
                            "configuratorState": $( '.n-configurator-state' ).val()
                        } );
                        if ( $( this ).parents( '.n-popoverbody' ).find( '.n-configurator-relative-daterange' ).is( ':checked' ) ) {
                            //Reset fixed dates within datetimerange component
                            $.each( item.fields, function ( key, value ) {
                                if ( value.name === "Date_Range" ) {
                                    var json = jQuery.parseJSON( value.value );
                                    if ( json.template[ 0 ] !== "" ) {
                                        json.value[ 0 ] = "";
                                    }
                                    if ( json.template[ 1 ] !== "" ) {
                                        json.value[ 1 ] = "";
                                    }
                                    json.relative = true;
                                    item.fields[ key ].value = JSON.stringify( json );
                                }
                            } );
                        } else {
                            $.each( item.fields, function ( key, value ) {
                                if ( value.name === "Date_Range" ) {
                                    var json = jQuery.parseJSON( value.value );
                                    json.relative = false;
                                    item.fields[ key ].value = JSON.stringify( json );
                                }
                            } );
                        }
                        if ( $( this ).parents( '.n-popoverbody' ).find( '.n-configurator-relative-elements' ).is( ':checked' ) ) {
                            //Reset element selector value to include filter instead of elements
                            $.each( item.fields, function ( key, value ) {
                                if ( value.type === "Element_Selector" ) {
                                    var json = jQuery.parseJSON( value.value );
                                    json.selectResult = 1;
                                    item.fields[ key ].value = JSON.stringify( json );
                                }
                            } );
                        } else {
                            //Reset element selector query to include elements ids
                            $.each( item.fields, function ( key, value ) {
                                if ( value.type === "Element_Selector" ) {
                                    var json = jQuery.parseJSON( value.value );
                                    delete json.query;
                                    json.selectResult = 1;
                                    item.fields[ key ].value = JSON.stringify( json );
                                }
                            } );
                        }
                        if ( !item.fields.length && type !== "quicklink" ) {
                            $( "#content" ).trigger( 'nmsweb:notify', {
                                "target": "content",
                                "type": "error",
                                "title": "Please correct the following before continuing",
                                "message": "At least one field has to be selected."
                            } );
                            $( this ).parents( '.n-popover-content' ).spin( false );
                            $( this ).parents( '.n-popover-content' ).children().show();
                            return;
                        }
                        $.ajax( {
                            type: 'PUT',
                            url: address,
                            data: {
                                preset: JSON.stringify( item )
                            },
                            success: function () {
                                $( "#content" ).trigger( 'nmsweb:notify', {
                                    "target": "content",
                                    "type": "success",
                                    "title": "Query Saved ",
                                    "message": "To access your saved queries, you can choose the Load Query option on any of the Configurator screens, or from the \"Load Query\" menu in the Mega-Menu."
                                } );
                                $( savebutton ).parents( '.n-popoverbody' ).addClass( 'hide' );
                            },
                            complete: function ( xhr ) {
                                var response = $.parseJSON( xhr.responseText );
                                if ( response.error === "duplicateName" ) {
                                    $( "#content" ).trigger( 'nmsweb:notify', {
                                        "target": "content",
                                        "type": "error",
                                        "title": "Please correct the following before continuing",
                                        "message": "'" + item.name + "' is already in use. Please enter a unique " + ( type.charAt( 0 ).toUpperCase() + type.slice( 1 ) ) + " name."
                                    } );
                                }
                                $( savebutton ).parents( '.n-popover-content' ).spin( false );
                                $( savebutton ).parents( '.n-popover-content' ).children().show();
                            }
                        } );
                        return;
                    } );
                $additionalButtons = '<h4>Additional:</h4>' +
                    '<p><span class="daterange-relative">Relative Daterange:</span><input type="checkbox" value="1" class="n-configurator-relative-daterange" checked="checked"></p>' +
                    '<p><span class="elements-relative">Relative Elements:</span><input type="checkbox" value="1" class="n-configurator-relative-elements"></p>';

                $additionalButtons += '<div id="quicklink_specific_fields" style="display: none;"> <p><span class="quicklink-should-submit">Submit configurator:</span>' +
                    '<input type="checkbox" checked="checked" value="true" class="n-configurator-should-submit"></p>' +
                    '<p><span class="quicklink-configurator-state">Configurator state:</span>' +
                    '<select class="n-configurator-state quicklink-select">' +
                    '<option value="open" selected="selected">Open</option>' +
                    '<option value="closed">Closed</option></select></p></div>';

                $queryType.on( "mouseenter", function () {
                    if ( !popover_loaded ) {
                        $queryType.find( '#presets_tooltip' ).nmswebPopover( {
                            'showOnCreation': false,
                            'placement': 'right',
                            'manual': false,
                            'exclusive': false,
                            'content': "Use this when you want to use the selections you have made to run reports in different tools."
                        } );

                        $queryType.find( '#ql_tooltip' ).nmswebPopover( {
                            'showOnCreation': false,
                            'placement': 'right',
                            'manual': false,
                            'exclusive': false,
                            'content': "Use this when you want to recreate this exact report again."
                        } );
                        popover_loaded = true;
                    }
                } );
                $additionalButtons = $( $additionalButtons );
                $itemNameInput.keyup( function ( e ) {
                    var code = ( e.keyCode ? e.keyCode : e.which );
                    if ( code === 13 ) {
                        $saveItemButton.trigger( 'click' );
                    }
                } );
                $itemTree.find( 'input[name="Date_Range"], input[name="Date Range"]' ).on( 'change', function () {
                    var relativeCheckbox = $additionalButtons.find( '.n-configurator-relative-daterange' ).parent();
                    if ( $( this ).is( ':checked' ) ) {
                        relativeCheckbox.removeClass( 'hide' );
                    } else {
                        relativeCheckbox.addClass( 'hide' );
                    }
                } );
                $content = $( '<div></div>' )
                    .append( $queryType )
                    .append( $itemNameInput )
                    .append( $includeLabel )
                    .append( $itemTree )
                    .append( $additionalButtons )
                    .append( $saveItemButton );

                return $content;
            },
            _applyConfiguratorStyles: function () {
                var that = this,
                    $content = $( '.main' ),
                    pos = $content.getPosition();
                if ( that.levels.length > 1 ) {
                    $.each( that.levels, function () {
                        var level = this;
                        $( '#' + that.thatelement.attr( 'id' ) + '-container' ).find( '.n-select' ).first()
                            .append( $( '<option value=\'' + level + '\'>' + ( level.charAt( 0 ).toUpperCase() + level.slice( 1 ) ) + ' View</option>' ) );
                    } );
                    $( '#' + that.thatelement.attr( 'id' ) + '-container' ).find( '.n-configurator-controls-top .n-select' ).first()
                        .on( 'change', function () {
                            var newLevel = $( this ).find( ':selected' ).val();
                            that.level = newLevel;
                            that._applyFilter( newLevel );
                        } );
                } else {
                    $( '#' + that.thatelement.attr( 'id' ) + '-container' ).find( '.n-configurator-controls-top .n-select' ).first().parent( 'span.n-select-container' ).remove();
                }
                $( '#' + that.thatelement.attr( 'id' ) + '-triangle' )
                    .css( {
                        position: 'absolute',
                        left: pos.left - 10,
                        top: 120
                    } );
                $( '#' + that.thatelement.attr( 'id' ) + '-hidden-configurator a' )
                    .on( 'click', function () {
                        that.expand();
                    } );
                $( '#' + that.thatelement.attr( 'id' ) + '-container' ).css( {
                    position: 'absolute',
                    left: pos.left - 10
                } );
                $( '#' + that.thatelement.attr( 'id' ) + '-hidden-configurator .n-configurator-hidden-tab' )
                    .css( {
                        position: 'absolute',
                        left: pos.left - 10
                    } );
                $( '#' + that.thatelement.attr( 'id' ) + '-container .n-apply-preset-btn' ).on( 'click', function () {
                    that._applyPresetClick( $( this ) );
                } );
                $( '#' + that.thatelement.attr( 'id' ) + '-container' ).find( '.n-configurator-minimize' )
                    .on( 'click', function () {
                        that.minimize();
                    } );
                $( '#' + that.thatelement.attr( 'id' ) + '-container' ).find( '.n-configurator-generate-button' )
                    .on( 'click', function () {
                        var container = $( '#report-container' );
                        if ( container.length > 0 ) {
                            that._destroyDataSources( container );
                        }
                    } ).on( 'click', function () {
                        that._updateConfiguratorValues();
                        var event = $.Event( 'submit:configurator' );
                        that.thatelement.trigger( event, {
                            'values': that.configurator_values
                        } );
                        if ( !event.isDefaultPrevented() ) {
                            $.ajax( {
                                type: 'GET',
                                url: that.options.action,
                                data: {
                                    configuration: JSON.stringify( that.configurator_values )
                                },
                                success: function ( data ) {
                                    var container = $( '#report-container' );
                                    if ( container.length > 0 ) {
                                        container.html( data.html );
                                    }
                                }
                            } );
                        }
                    } );
                if ( that.options.submit_label !== undefined && that.options.submit_label !== null ) {
                    $( '#' + that.thatelement.attr( 'id' ) + '-container' ).find( '.n-configurator-generate-button' ).val( that.options.submit_label );
                }
                $( '#' + that.thatelement.attr( 'id' ) + '-container' ).find( '.n-configurator-preset-button' ).nmswebPopover( {
                    'id': 'save-preset-popover',
                    'listen': {
                        'event': 'nmsweb:configclose',
                        'container': $( that.thatelement )
                    },
                    'placement': 'right',
                    'title': 'Save Query',
                    'persistent': true,
                    'toggle': true,
                    'manual': true,
                    'content': that._generateSaveContent( 'preset' )
                } );
                $( '.n-configurator-expand-values-button' ).on( 'click', function () {
                    that._handleSectionTemplateExpand( $( this ) );
                } );
                $( '.n-configurator-section:not(.n-configurator-section.simple), .n-configurator-section-field:not(.n-configurator-section-field.simple)' ).addClass( 'hide' );
                $( '.n-configurator-section-template *:not(.n-configurator-section-template .simple, .n-configurator-section-template .simple *)' ).addClass( 'hide' );
                $.each( $( '.n-configurator-section-template' ), function () {
                    var $sectionTemplate = $( this ),
                        containsLevels = false;
                    $.each( that.levels, function () {
                        if ( $sectionTemplate.find( '.' + this ).length > 0 ) {
                            containsLevels = true;
                        }
                    } );
                    if ( !containsLevels ) {
                        $sectionTemplate.find( '.hide' ).removeClass( 'hide' );
                    }
                } );
            },
            _destroyDataSources: function ( container ) {
                container = $( container );
                var dataSourceScripts = container.find( 'script.datasource' ),
                    datasources = window.nmsweb.DataSources, //Datasources scope
                    datasource; //a Datasource
                dataSourceScripts.each( function () {
                    datasource = datasources[ this.id ];
                    if ( datasource ) {
                        if ( typeof datasource.destroy === 'function' ) {
                            datasource.destroy();
                        }
                    }
                } );
            },
            _createSections: function ( options ) {
                var that = this,
                    commandsTooltip = false,
                    addressmodesTooltip = false,
                    dataRangeTooltip = false;
                $( document ).on( 'sectionLoadComplete', function ( e, params ) {
                    if ( that.waitForSections[ params.sectionName ] ) {
                        delete that.waitForSections[ params.sectionName ];
                    }
                    if ( options.auto_submit && jQuery.isEmptyObject( that.waitForSections ) ) {
                        $( document ).off( 'sectionLoadComplete' );
                        $( '#' + that.thatelement.attr( 'id' ) + '-container' ).find( '.n-configurator-generate-button' ).click();
                    }
                } );
                $.each( options.sections, function ( key, value ) {
                    if ( this.popover !== undefined && this.popover === true ) {
                        var $expand = $( '<a class=\'n-configurator-expand-section\'></a>' ),
                            $applyButton,
                            $popover,
                            section = this,
                            $section = that.thatelement.find( '.n-configurator-section[data-configurator-name=' + section.name + ']' ),
                            $form = $section.find( '.n-configurator-section-form' ),
                            values = that._getFieldValues( $form ),
                            event = jQuery.Event( section.name + ":submit" ),
                            eventBefore = jQuery.Event( options.name + ":submit:before" ),
                            eventAfter = jQuery.Event( options.name + ":submit:after" ),
                            $sectionTitle = $section.find( '.n-configurator-section-title' ),
                            popover_opts = value.popover_opts || {},
                            buttonText = popover_opts.buttonText || 'Done',
                            headerText = popover_opts.headerText || '';
                        that._applySectionTemplate( section, values );
                        that.trigger( eventBefore );
                        that.trigger( event );
                        that.trigger( eventAfter );
                        $section.find( 'script' ).remove();
                        $sectionTitle.append( $expand );
                        $section.append( $( '<div class="n-configurator-section-template"></div>' ) );
                        $applyButton = $( '<button class=\'n-cnf-btn blue n-configurator-apply-change-button\'>' + buttonText + '</button>' );
                        $form.append( $applyButton );
                        $applyButton.wrap( $( '<div class=\'n-configurator-apply-change-button-holder\'></div>' ) );
                        $popover = $section.find( '.n-configurator-expand-section' ).parent().nmswebPopover( {
                            'listen': {
                                'event': 'nmsweb:configclose',
                                'container': $( that.thatelement )
                            },
                            'placement': 'right',
                            'manual': true,
                            'toggle': true,
                            'content': $form,
                            title: headerText
                        } );
                        if ( options.auto_submit && that.asyncSections.indexOf( value.name ) !== -1 ) {
                            that.waitForSections[ value.name ] = true;
                        }
                        $( $popover.data( 'nmswebPopover' ).that ).addClass( "n-configurator-popover" );
                        // An exception in creating function inside of loop (max couple iterations, each handler has to be unique)
                        $form.on( 'dataBound', function ( e, component ) {
                            $section.trigger( 'dataBound', component );
                        } );
                        $applyButton.on( 'click', function () {
                            var gridElement = $form.find( '.n-elementselectorgrid' );
                            if ( gridElement !== undefined && gridElement.length > 0 ) {
                                var grid = gridElement.data( 'nmswebElementSelectorGrid' );
                                var min_elements = grid.options.min_elements;
                                if ( min_elements === undefined || grid.select().length >= min_elements ) {
                                    that._submitSectionTrigger( section, that.thatelement, $form, $popover );
                                    $( this ).parents( '.n-popoverbody' ).addClass( 'hide' );
                                } else {
                                    $( "#content" ).trigger( 'nmsweb:notify', {
                                        type: "error",
                                        title: "An error occured whilst saving",
                                        message: 'Select minimum ' + min_elements + ' elements to submit'
                                    } );
                                }
                            } else {
                                that._submitSectionTrigger( section, that.thatelement, $form, $popover );
                                $( this ).parents( '.n-popoverbody' ).addClass( 'hide' );
                            }
                        } );
                        $sectionTitle.on( 'click', function () {
                            if ( $form.parents( '.n-popoverbody' ).hasClass( 'hide' ) ) {
                                that._submitSectionTrigger( section, that.thatelement, $form, $popover );
                            } else {
                                if ( ( $sectionTitle.find( "h2" ).text().toLowerCase() ) === "commands" && !commandsTooltip ) { //tooltip for Commands
                                    commandsTooltip = true;
                                    var $tooltipMountForCommands = $( '#commands_tooltip' );
                                    $tooltipMountForCommands.nmswebPopover( {
                                        'showOnCreation': false,
                                        'placement': 'right',
                                        'manual': false,
                                        'exclusive': false,
                                        'content': $tooltipMountForCommands.find( '.tooltip-data-to-dispaly' ).text()
                                    } );
                                }
                                if ( ( $sectionTitle.find( "h2" ).text().toLowerCase() ) === "address modes" && !addressmodesTooltip ) { //tooltip for Address Modes
                                    addressmodesTooltip = true;
                                    var $tooltipMountForAddress = $( '#address_modes_tooltip' );
                                    $tooltipMountForAddress.nmswebPopover( {
                                        'showOnCreation': false,
                                        'placement': 'right',
                                        'manual': false,
                                        'exclusive': false,
                                        'content': $tooltipMountForAddress.find( '.tooltip-data-to-dispaly' ).text()
                                    } );
                                }
                                if ( ( $sectionTitle.find( "h2" ).text().toLowerCase() ) === "date range" && $form.parents( '.n-popoverbody' ).find( '#data_range_tooltip' ).length === 1 && !dataRangeTooltip ) { //tooltip for Date Range
                                    dataRangeTooltip = true;
                                    var $tooltipMountForDataRange = $( '#data_range_tooltip' );
                                    $tooltipMountForDataRange.nmswebPopover( {
                                        'showOnCreation': false,
                                        'placement': 'right',
                                        'manual': false,
                                        'exclusive': false,
                                        'content': $tooltipMountForDataRange.find( '.tooltip-data-to-dispaly' ).text()
                                    } );
                                }
                            }
                        } );
                        $section.on( 'click', '.n-configurator-section-info', function () {
                            $sectionTitle.trigger( 'click' );
                        } );
                        $form.parent().parent().find( '.close' ).remove();
                        //THIS NEEDS TO FIRE BUT IT ISNT OR ISNT BEING CAUGHT YET
                        $( that.thatelement ).trigger( event, {
                            'values': values,
                            'options': section,
                            'popover': $popover.data( 'nmswebPopover' ),
                            'showAllValues': false
                        } );
                        if ( !event.isDefaultPrevented() ) {
                            that._applySectionTemplate( section, values );
                        }
                    }
                } );
                that.thatelement.trigger( 'sectionsCreated' );
            },
            _submitSectionTrigger: function ( options, element, $form, $popover, presetValues ) {
                var eventBefore = jQuery.Event( options.name + ":submit:before" ),
                    event = jQuery.Event( options.name + ":submit" ),
                    eventAfter = jQuery.Event( options.name + ":submit:after" ),
                    that = this,
                    values = that._getFieldValues( $form );

                that._updateConfiguratorValues();

                if ( values.Date_Range !== undefined && values.Resolution !== undefined ) {
                    values = that._formatDateRangeValue( values, presetValues );
                }

                $( element ).trigger( eventBefore, {
                    'values': values,
                    'options': options,
                    'popover': $popover.data( 'nmswebPopover' ),
                    'showAllValues': false
                } );
                $( element ).trigger( event, {
                    'values': values,
                    'options': options,
                    'popover': $popover.data( 'nmswebPopover' ),
                    'showAllValues': false
                } );
                $( element ).trigger( eventAfter, {
                    'values': values,
                    'options': options,
                    'popover': $popover.data( 'nmswebPopover' ),
                    'showAllValues': false
                } );
                if ( !event.isDefaultPrevented() ) {
                    that._applySectionTemplate( options, values, false );
                }
                var expandButton = $( 'fieldset[data-configurator-name=' + options.name + ']' ).find( '.n-configurator-expand-values-button' );
                that._handleSectionTemplateExpand( expandButton, true );
            },
            _applySectionTemplate: function ( section, values, showAllValues ) {
                var $section = this.thatelement.find( '.n-configurator-section[data-configurator-name=' + section.name + ']' ),
                    template_html = $( "#" + section.result_template ).html(),
                    expand_html = $( 'fieldset[data-configurator-name=' + section.name + ']' ).find( '.n-configurator-expand-section-values' ),
                    expand_button = $( 'fieldset[data-configurator-name=' + section.name + ']' ).find( '.n-configurator-expand-values-button' ),
                    template = ( template_html !== null ) ? window.kendo.template( template_html ) : undefined,
                    valuesLength = 0,
                    that = this,
                    $sectionTemplate,
                    valuesArr = [],
                    rebuiltValues = {},
                    rebuildCounter = 0,
                    $compiledTemplate,
                    compiledTemplate,
                    calculateNumberOfValues = function ( templateValues ) {
                        valuesArr = [];
                        valuesLength = 0;
                        if ( templateValues !== null ) {
                            $.each( templateValues, function ( key, value ) {
                                if ( typeof value === "object" ) {
                                    calculateNumberOfValues( value );
                                } else {
                                    valuesArr.push( value );
                                    valuesLength = valuesLength + 1;
                                }
                            } );
                        }
                    },
                    rebuildValues = function ( values, limit, rebuildTemp ) {
                        if ( rebuildCounter < limit ) {
                            $.each( values, function ( key, value ) {
                                rebuildCounter = 0;
                                if ( value === null || rebuildCounter === limit ) {
                                    return;
                                }
                                if ( typeof value === "object" && !$.isArray( value ) && !rebuiltValues[ key ] ) {
                                    rebuildTemp[ key ] = {};
                                    rebuildValues( value, limit, rebuildTemp[ key ] );
                                } else if ( typeof value === "object" && $.isArray( value ) ) {
                                    rebuildTemp[ key ] = [];
                                    $.each( value, function ( index, val ) {
                                        if ( rebuildCounter < limit ) {
                                            rebuildTemp[ key ].push( val );
                                            rebuildCounter = rebuildCounter + 1;
                                        }
                                    } );
                                }
                            } );
                        } else {
                            return rebuiltValues;
                        }
                    };
                if ( values !== null ) {
                    calculateNumberOfValues( values );
                }
                if ( section.default_render_amount === undefined || section.default_render_amount === null ) {
                    section.default_render_amount = 10;
                }
                if ( !showAllValues ) {
                    if ( section.default_render_amount ) {
                        showAllValues = section.default_render_amount;
                    } else {
                        showAllValues = valuesLength;
                    }
                } else {
                    showAllValues = valuesLength;
                }
                if ( valuesLength > showAllValues ) {
                    rebuildValues( values, showAllValues, rebuiltValues );
                    values = rebuiltValues;
                    expand_html.removeClass( 'hide' );
                    expand_button.removeClass( 'hide' );
                    $sectionTemplate = $( '<div class="n-configurator-section-template hidden-content"></div>' );
                } else if ( valuesLength === showAllValues && section.default_render_amount !== "0" && valuesLength > section.default_render_amount ) {
                    expand_button.removeClass( 'hide' ).text( 'Show Less...' );
                    $sectionTemplate = $( '<div class="n-configurator-section-template hidden-content"></div>' );
                } else {
                    expand_html.addClass( 'hide' );
                    expand_button.addClass( 'hide' );
                    $sectionTemplate = $( '<div class="n-configurator-section-template"></div>' );
                }
                if ( template !== undefined && template.length !== null && $section.data( 'configuratorPopup' ) !== undefined && $section.data( 'configuratorPopup' ) === true ) {
                    if ( section.result_template_opts ) {
                        values.template_opts = section.result_template_opts;
                    }
                    $section.find( '.n-configurator-section-template' ).remove();
                    compiledTemplate = $.parseHTML( template( values ).trim() );
                    if ( compiledTemplate.length === 1 ) {
                        $compiledTemplate = $( compiledTemplate[ 0 ] );
                        if ( $compiledTemplate.html().trim() === "" || ( $compiledTemplate.find( 'ul' ).length && $compiledTemplate.find( 'ul' ).html().trim() === "" ) ) {
                            compiledTemplate = "";
                        }
                    }
                    if ( compiledTemplate === "" ) {
                        $section.append( $sectionTemplate.html( compiledTemplate ) );
                        if ( $section.find( '.n-configurator-section-template' ).length ) {
                            $section.find( '.n-configurator-section-template' ).spin( 'small' );
                        }
                    } else {
                        $section.append( $sectionTemplate.html( compiledTemplate ) );
                    }
                    $section.find( '.n-configurator-short-name' ).each( function ( index, shortNameEl ) {
                        $( this ).nmswebPopover( {
                            'showOnCreation': false,
                            'placement': 'right',
                            'manual': false,
                            'content': $( shortNameEl ).data().originalName
                        } );
                    } );
                }
                that._applyFilter( that.level, true );
            },
            resyncTemplates: function () {
                var that = this,
                    section;
                $.each( that.options.sections, function () {
                    section = this;
                    if ( section.popover !== undefined && section.popover === true ) {
                        var $popover = $( 'fieldset[data-configurator-name=' + section.name + ']' ).find( '.n-configurator-section-title' ).data( 'nmswebPopover' ),
                            $form = $( '.n-configurator-section-form-' + section.name ),
                            values = that._getFieldValues( $form ),
                            event = jQuery.Event( section.name + ":submit" );
                        $( that.thatelement ).trigger( event, {
                            'values': values,
                            'options': section,
                            'popover': $popover,
                            'showAllValues': false
                        } );
                        if ( !event.isDefaultPrevented() ) {
                            that._applySectionTemplate( section, values );
                        }
                        that._applyFilter( that.level );
                    }
                } );
            },
            minimize: function () {
                this.thatelement.parents( '.n-configurator-container' ).each( function () {
                    $( this ).addClass( 'hide' );
                    $( '.n-configurator-hidden-configurator' ).children().css( 'display', '' );
                    $( 'body' ).trigger( 'nmsweb:configclose', {
                        'type': 'close'
                    } );
                } );
                $( '#content' ).trigger( 'nmsweb:pagelevelwidth' );
            },
            expand: function () {
                this.thatelement.parents( '.n-configurator-container' ).each( function () {
                    $( this ).removeClass( 'hide' );
                    $( '.n-configurator-hidden-configurator' ).children().css( 'display', 'none' );
                } );
                $( '#content' ).trigger( 'nmsweb:pagelevelwidth' );
            },
            executeItemAction: function ( $actionButton, preset ) {
                var that = this;
                var action = $actionButton.attr( 'action' ),
                    $nameLink,
                    oldName,
                    $newNameInput;
                switch ( action ) {
                case 'rename':
                    $nameLink = $actionButton.parents( 'tr' ).first().find( 'a.n-configurator-preset-link' );
                    oldName = $nameLink.text();
                    $newNameInput = $( '<input type=\'text\' class=\'renameInput\'></input>' )
                        .on( 'keyup', function ( e ) {
                            if ( e.keyCode !== undefined && e.keyCode === 13 ) {
                                that.bindPresetClick();
                                var newName = $( this ).val();
                                var inputParent = $( this ).parent();
                                if ( newName !== '' ) {
                                    inputParent.empty().append( "Please wait.." );
                                    $.ajax( {
                                        type: 'POST',
                                        url: '/core/presets/change',
                                        data: {
                                            id: preset.id,
                                            name: newName
                                        },
                                        complete: function ( xhr ) {
                                            var response = $.parseJSON( xhr.responseText );
                                            if ( response.error ) {
                                                if ( response.errorCode === "duplicateName" ) {
                                                    $( "#content" ).trigger( 'nmsweb:notify', {
                                                        "target": "content",
                                                        "type": "error",
                                                        "title": "Please correct the following before continuing",
                                                        "message": "'" + newName + "' is already in use. Please enter a unique Preset name."
                                                    } );
                                                }
                                                inputParent.empty().append( oldName );
                                            } else {
                                                $( "#content" ).trigger( 'nmsweb:notify', {
                                                    "target": "content",
                                                    "type": "success",
                                                    "title": "Successfully renamed Preset",
                                                    "message": "Preset '" + oldName + "' has been successfully renamed to '" + newName + "'."
                                                } );
                                                inputParent.empty().append( newName );
                                            }
                                        }
                                    } );
                                }
                            }
                        } );
                    $( '.n-configurator-apply-preset-popover .n-grid' ).off( 'click', '.n-configurator-preset-link' );
                    $nameLink.empty().append( $newNameInput );
                    $newNameInput.focus()
                        .val( oldName )
                        .select();
                    break;
                case 'delete':
                    $.confirm( {
                        title: "Remove Preset?",
                        content: "Are you sure you want to delete '" + preset.name + "'?",
                        confirmButton: 'Yes',
                        cancelButton: 'No',
                        confirm: function () {
                            $.ajax( {
                                type: 'DELETE',
                                url: '/core/presets/index',
                                data: {
                                    id: preset.id
                                },
                                success: function () {
                                    $( "#content" ).trigger( 'nmsweb:notify', {
                                        "target": "content",
                                        "type": "success",
                                        "title": "Successfully deleted Preset",
                                        "message": "'" + preset.name + "' has been successfully deleted."
                                    } );
                                    var $rowToDelete = $actionButton.parents( 'tr' ).first();
                                    $( '.n-configurator-apply-preset-popover' ).find( '.n-grid' ).data( 'nmswebGrid' ).removeRow( $rowToDelete );
                                }
                            } );
                        },
                        cancel: function () {}
                    } );
                    break;
                }
            },
            _getFieldValues: function ( $form ) {
                var values = {},
                    propertyName;
                $form.find( 'input, textarea, select, div' ).each( function () {
                    var $field = $( this ),
                        fieldValue = $field.val();
                    if ( $field.attr( 'data-configurator-tracked' ) === 'true' ) {
                        propertyName = $field.attr( 'data-configurator-name' );
                        values[ propertyName ] = fieldValue;
                    }
                } );
                return values;
            },
            _formatDateRangeValue: function ( values, presetValues ) {
                if ( values.Date_Range !== undefined && presetValues !== undefined && presetValues.length > 0 ) {
                    presetValues.forEach( function ( item ) {
                        if ( item.section === 'DateRange' &&
                            ( item.value !== undefined || item.value !== "" ) ) {
                            var origValue;
                            try {
                                origValue = JSON.parse( item.value );
                            } catch ( e ) {}

                            if ( origValue !== undefined &&
                                origValue.resolution !== undefined &&
                                origValue.resolution !== "" ) {
                                values.Date_Range.resolution = origValue.resolution;
                            }
                        }
                    } );
                }

                return values;
            }
        } );
    window.nmsweb.registerComponent( 'Configurator', Configurator );
    return Configurator;
} );