define( [ 'external/notifier/notifier', 'core/popover' ], function () {
    "use strict";
    var getWarningContent = function ( message, callback ) {
            var $container = $( '<div></div>' ),
                $confirmButton = $( '<button class=\'btn n-warning-confirm\'>Confirm</button>' )
                .on( 'click', function () {
                    callback();
                    $( this ).parents( '.n-popoverbody' ).addClass( 'hide' ).remove();
                } ),
                $cancelButton = $( '<button class=\'btn n-warning-cancel\'>Cancel</button>' )
                .on( 'click', function () {
                    $( this ).parents( '.n-popoverbody' ).addClass( 'hide' ).remove();
                } );
            return $container.append( $( '<div style=\'padding: 10px 10px 10px 10px;\'>' + message + '</div>' ) )
                .append( $confirmButton )
                .append( $cancelButton );
        },
        getWarningTitle = function ( title ) {
            var $iconElement = $( "<img/>", {
                    src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAA5SSURBVHja5FsJkBXFGf57jvf2vV12F1ZYWHaXGxWzKB4oCipE5DKYi2AhhWupW7WWJilSSVFlTJUJVVawrCSVCqixclgajSalaBIFjRFFTBAPghFFJMoly7H327fvvZnu/H/P1TPzFgku96vt6pmenp7+v//u7mXi7TlwJv8MEHCGA3DiEKjAMhXLYCzrsWw/EZNgQhxfAMRbszWsVmFpijx6GUszu+iFbcdzPtpxh1zA01ia5KfLJwNUzUQ5HEjtM7C8KzbNHn/aSoDYNGs5VndBogrYOLw0q7GRIxY6iJ0rAQ69SN3eYBevufy0kwDx5qzhyOFmMjlsxPcALLxo34LlPYDOj4ANvxkgNZokYQr2/dHpB4AQy7EMgoHTAPQqgN79rgwyADsLkNkFULOE+lG5hW+8tuK0AYBvnInWXjQC04EN/RZA7iB+GR0QM7E2nZpbwBI1wCovIbjqsfz89JEAgXpPol/9dSTUtTnMUECgWkdg2oDV3OR550b+r5mTT3kA+D+vWYQyPZssPRs8F3W/2yFWEm2Ea0JJaMCGfIV0hspdpzwAqM93kF6zmhuQw61O3MU059No/R3ideee2gtdCMB1IPQyene+/caXF52yANgbZtyLVExh6dHAKlCarR4kUsq/Y/wk0R7xzGkHdIv5TtBql3hS0HRKAmBvmI5WXCwilrN6pCG71xVxcGvhECtstxbBcyvjAJaqp7arcKxlpxwASM/PsdRD5aXI5HIkqtcJeiSxbs2ReGE5tdpOoPTsAa2u0RUCaLZen15xygBgrb96Ks66ER2+I8rZPSQTDoFEHBV0ew7xau0+o34YG7AkucXJhEA9lvtPmVDYeu2q1VjN12pvAK38Isf4KS4vlxfw8a4WIICk2ssp2DCmrhqSCeaCUZA2QaSrwf73na50wERj2rot/ZwO9++v8OqVZLXngzEAtKrpGOZ+GAiaRsQxaO3Iwg1N98TeXfPEfTCsKhVIBAVHhR6MH+YC/+w56kK5xPUntwqg2yOl1etR9Ls/QcbmHIIkUcRVC8xk0gt5Q6UklZLPZT/hSkFmN+jV81FYBtDY8wvrpi08aQEovDL1Lun2SseAVnYeiv4BhZsFvyQTBnDOY8UwcDo8r/Sl99B4du9AQBcfE7fYbwDk/3FFBXKxiTip1d0I0Pauw33JzUJQY9uAtFlUAgak0EbY+XB/qrP7QBswAaCkhvrNwG8tO/kkQGDygtZaG3QpDppA7rfHOC+J4zlZJ0wzxH26d7ifc/up72Fb62bQR97qS0H+5cvLThoAcn+fcgFyplFgWKvXoQ1s24yTVInIB8V2asPQQ9xPJBOh50Fxx8i3gqaVABt4CfUfJfrJLfaPBHBxD2V5+tC5wDp3yHg+RniklJamQxKQKkketr+UgkObwKhdgOCSNxFNuRcvazjhAOTWXkrZnnR7RvVMgK5trujnI6KfD4l4wjQiKmC4NiMXkRZFivLdwLItoNdc56nC8hMOgGf4jFGYxx980yGCoj4Kb6Mc9AoSmUyEDSHdx/upwNmOi2x/HyVtFmaLpTJb7F0zed4JA6D3hUuW4SyuYqnhoKdHgsjsDEJZL+yNSoB7TSJfVAVifQvhMW10iwc3glG/0JOCpScEgOzzF5Pba5bcH3MriJZ1UvQFTlZwJab3Y/9CIOJYJxJ6WAXwXn0eEB6MQ+MKiiu6d4JRieqPwJNbxLksO/4SIMQKcnv6WVNAownmDgWZHU3WJzxaO64xGbEBdO8HP0XeC42H0iH2vQLm2Ns8KVh0XAHI/nVSA7JDRmRm/QLk/mvItUIwaRFMWohwm0NEHtKpsA2geyn24gjGIJDQGGoInEaSIHgDzunB4waA4GK5ILc3HGP0jg/kCk5xQm1FdFXVoHBYi9gAw4n8ivXn8bEFSotoeRXM0bRmwGhOTT3PXdBwzAHoefb8r5HbY+T2hs0E0fqOm7hExdT22/1kCIuQdsJCkQ8DYOpCtgtuhfr77/Mi6pBvB9b1McYG1x/1Iqp2FG5PLnIaozHe3/sSeqZsaJIe9/zJR3XaNYjpkrARTJME2PmY9AQLJYqB5QGogjzC0KsxW0zR3BZmVk+cd8wAyDzTQG5vhpauxbhnNIiu7Y4oRiblcNp2uRlZ/XGNYLpEiwCghfsoq0RSaiLj+2AXMgBog8zRi4/KLR4xAN1PfylFW1bEfXP8bcB3Pefm+gF3iom/UFyjLxkyF+CRQAhcIxjuL/jh1MAFu2MrusVzgCFjyC3iXJv7XwI4ZntcjNWrJoNmdWPQs9d1Wx7RgX4Hk41LgCMZBSiNqEBJAhRpiqwTcssH1bcTXAHE6gX+6TNgjlns7Dxx0b8AdP9pQoOzEMEgMXoh8N3Py4DFcVFWzPL7QETF2b9GN0iBn6oCSeZLQLH3AsKjbtJ9ltkFuqaDPuh8UoMGnPOD/QaAEHw5FjBGfBXz8ndAyB0e1fApXFGMnxBFnlGNMUNJIrIchvdOLKFKi+WrEIRUwVLGtf3lNvvT1ZAYfxPtRNCcm7qeOmfUFwag68mz50m3h1Y2UTMdOAU9fRk+UYRYEeagQ1BeEhxWASHbhapKxcZR1SxkEC1nCa51M5i113oG8d4vDAByZ6k0fOOWIMJ/dnJ9oeijavg8PeWKPy+qAmQDICQB5WnmSEBRTxAdM/heoIZOX/7Zy2DWzfHdYucfx887agA6Hx+3FA0Kur06MMtHYdCzJW6AQoZPnXgg/jFASAUMKxwIacpCqLDi73I79o3AzihzyXeB2PUXSIy7yTOI3znqfQEhd3cAkufeAvb2R5xUlGmoY84+HiP8hLOrK5jm7/oySo7oWriboG5NIauzcQhQWWbApIk1zs4wTr6yDJ/bLgig7h+qNXe+7afbwXaaUO75wU1gNkyHfMkQ4NmWmR1/GNtcsWj7qv9rZ6jjsTFkRZuMsy6EZP10sD98mEyLQxjt6HoEY2GScKa0OTu/zNvx9Xd+XQB0HdiACmBnDQGWSoPI9mBEtx8Dqw4Exw4AUIgX/maqAoBsj4Ah1RP7DBgJgCFydtOPabAtFTd+PPGIAWh/dNQErP5DhJZN+xnwLZj55trCBCscD9qZstWtbHkrADiX+MwwgCUSEgwiWuTRBVqWw2URBwBUAMAJolQJ8K59QPAbxrm3Q/aTNWAdeJsGvK9y8X9/cGQAPDLyCawWJsZ8E0zM2uydz7rb+nqIaBbhuHfNPGmIct87GwBqHT5LE4h/MRA8FRAK4SJMuAIGlFSBNmEpZF6T0XEH7S1WLvlk52GNYPvvR5DbW0huLzl8KtgU9NhKhMaLuT07ErR8TjAUy/j6eB4Jgvx4IGpoi4wh23v2o1t8C8wRcwioCrmI83lewHN7iQk3g73jcfStncUXJ2Juz44Tofht1b8LsGB/lw2r3y7IQtd+RBfty+NjhpOteI4glIUXjsFRcuQ83y22/a5+Rp9eoO23dRRDz9DKaiFRXgv5bSvlB6S1V8RRMDKGXPECXGIprby0/tyxB6oX8FQAn/9ts4CfPNUjt8mll0kwuHtBGuZOZO4psuIqIBRV8GvfJvCIargeId8BbMdjkDz7Ruh97yEa9PvgnEuOS4C3yFmC3C+8/yv3VIcdDnZiuX/xxCfKeU9E93YJ+OGjHdCdyUOhUJCFrqmNnhULfkILJZEESbjSEFqAUYIkGSK3bABz0Fj0OEOIxtmtv6ltjgHQ+vDwBxH9BmPwhaDxTkwxP3IH5ErEFV2iUibR16kPlRjkzEtb85DpyUEerb5aqI2eUZ9Y4FQ0tFbAF1ZsAdVnGs3f6gF760pINTR7wVFjCIBDv66plxsceJs6rxGsrQ85qamIL28HeX0UdcvnhoiuC3iHHXQUSd2OEe8VekZ9ikWVoKwTitCRmvBKtAhli9zPGO32D0ATXZgtnkdSMBlpvjeQAMFXUOfEyFkgPlsLonefz/3QGj9XFyWtPpa+o8YvbKmvmWzgfR5yuVyoUBs9c7bEbUV97CJJVnzJXKhnjHh4L8HZUMkhYx9AKbjFsw9Nhx4aOly/c9iqsxGCB5hZCqWTbgf7vfudkDfql50TO/4RMIhe02HI0DPl6BsEvrpioAbV49Kwdl07ct3GGMjGWIjDiruHwRUj8K0u/LYdRHqh02MglNA3erIsfC38NmUMqxu09GCAVB3YbR+lJE0HVg1GSODh5LhvgGnvAXvPWpdQNZILR3dFA51IzUJBEDjX9Jc2QatJQQszYM3rGRn5zr2yFKqRs3xvFn235U4agtrzPkWjwz4CJTVsVtsSA0G/6KfQ9Qo5A9iI8ihkjKyXVALf8aQjvpJICMfv/nEuBsK9ZqDG+G7xEh95DQEIwh0jg3ZgTwGGlCdgyWWG86izG3gn2pwsomELV7ZEJCmKJEgRAAREiRUxAKRU5FqBtb7pjTnJQIOwWyZonTtAo6Osrg8W5NsFc/25cAnUFEKFBMojmAmF4/41uDEA+PfCRnC6aXupgAbPaxOS8OD/t4pIQEi9VKJFH8DwIvGDU1stm9w22G2gS1gv9/l3boAULc2K3hBHBSgiDSLOcbWfB0aU+yEg3GvuHgUslg+IYrmBJxd9S0HfgZNS45zy3Rnv2P56mQwd+OUgmfwwMwWm3gE69GI/O5LIeNlcvC2m66raME+ZoskPC+dDQiUYAmKjRrcvlVAAEMXaOEOaTQzCB6JDoDMMcEAevPQiwLwF5QnRMycHJm15HovTw59zf9gDrX1kj0d1qoGY/6nG4Loh327bZ+z/RSVUf7eDRl/x1O2lH44ZrDVUlbEJJSYbBqfRz+LQ1ZkV23e18i13PNbzxLZ9/ECLqATDNQa0LwMLVmbojO9qODN+ptzjdPWpxZX71BlCPBmBvTJ423d/GZzJv+P+v8Mn2+9/AgwAgKghoLylNOAAAAAASUVORK5CYII%3D"
                } )
                .addClass( 'n-notification-image' );
            return $( '<span>' + title + '</span>' )
                .prepend( $iconElement );
        },
        generateNotification = function ( options ) {
            if ( !options.silent ) {
                if ( options.message !== undefined && options.type !== undefined && options.title !== undefined ) {
                    if ( options.type === 'confirm' && options.owner !== undefined && options.callback !== undefined ) {
                        var $owner;
                        if ( typeof ( options.owner ) === 'object' ) {
                            $owner = options.owner;
                        } else if ( typeof ( options.owner ) === 'string' ) {
                            $owner = $( options.owner );
                        }
                        $owner.nmswebPopover( {
                            'placement': 'right',
                            'title': getWarningTitle( options.title ),
                            'manual': true,
                            'persistent': false,
                            'content': getWarningContent( options.message, options.callback )
                        } );
                    } else {
                        if ( options.type !== 'success' ) {
                            options.isFadeable = false;
                            options.isPersistent = false;
                        }
                        return window.Notifier.getNotification( options );
                    }
                }
            }
        },
        initNotificationListener = function () {
            var pageLevEl = $( '#content' ).addClass( 'page-level-notice' );
            $( "body" ).on( 'nmsweb:notify', function ( e, data ) {
                data.selector = typeof data.selector !== 'undefined' ? data.selector : $( this );
                generateNotification( data );
            } );
            //Listen for event and show Notification
            pageLevEl.on( 'nmsweb:notify', function ( e, data ) {
                e.preventDefault();
                data = typeof data !== 'undefined' ? data : {};
                data.target = typeof data.target !== 'undefined' ? data.target : '';
                var options = $.extend( {}, data, {
                    'type': typeof data.type !== 'undefined' ? data.type : 'success',
                    'selector': $( this ),
                    'title': typeof data.title !== 'undefined' ? data.title : 'Good News',
                    'message': typeof data.message !== 'undefined' ? data.message : 'Data Loaded all is well',
                    'isFadeable': typeof data.isFadeable !== 'undefined' ? data.isFadeable : true
                } );
                console.log( 'First off ', $( this ) );
                console.log( 'Second off ' + e.currentTarget.id );
                if ( e.currentTarget.id === 'content' || options.target === 'content' ) {
                    e.stopPropagation();
                    generateNotification( options );
                    //Event also triggered by configurator
                    $( this ).trigger( 'nmsweb:pagelevelwidth' );
                }
            } );
            pageLevEl.on( 'nmsweb:pagelevelwidth', function ( e ) {
                var containerId = e.currentTarget.id;
                if ( $( '.n-configurator-container' ).length > 0 ) {
                    $( '#' + containerId + '_notifications' ).width( $( '#report-container' ).width() );
                } else {
                    $( '#' + containerId + '_notifications' ).width( $( this ).width() );
                }
            } );
        },
        notification = function ( selector, options ) {
            var that = this,
                init;
            that.options = {
                'selector': selector,
                title: "Why am I so default?!",
                type: "error",
                message: "I don't want to be like the others.",
                isFadeable: true
            };
            init = function ( options ) {
                var newOptions = $.extend( {}, that.options, options );
                generateNotification( newOptions );
                if ( selector.attr( 'id' ) === 'content' || options.target === 'content' ) {
                    selector.trigger( 'nmsweb:pagelevelwidth' );
                }
                return that;
            };
            return init( options );
        };
    window.nmsweb.registerComponent( 'Notification', notification );
    $( document ).ready( function () {
        initNotificationListener();
    } );
    return notification;
} );