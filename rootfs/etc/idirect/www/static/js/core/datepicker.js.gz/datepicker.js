define( [ "jquery", "kendo", "core/nmsweb", "core/input_validation" ], function ( $ ) {
    "use strict";
    var FOCUSED = "k-state-focused",
        CHANGE = "change",
        DatePicker = window.kendo.ui.DatePicker.extend( {
            init: function ( element, options ) {
                var that = this,
                    defaults = {
                        format: "yyyy-MM-dd"
                    },
                    validationFunction = function () {
                        $( element.selector ).validate_input( options.opts, element.selector );
                    };
                if ( options.opts ) {
                    // forcing format (if developer (while creating form) put's additional options (tries to force it's own format)) because it has been decided that everywhere throughout nms time will be displayed in the following format HH:mm:ss
                    options.opts.format = defaults.format;
                    nmsweb.extendOptions( defaults, options.opts );
                } else if ( options ) {
                    options.format = defaults.format;
                    nmsweb.extendOptions( defaults, options );
                }
                if ( $( element.selector ).hasClass( 'validate' ) ) {
                    $( element.selector ).change( validationFunction );
                    $( element.selector ).bind( 'blur', validationFunction );
                }
                window.kendo.ui.DatePicker.fn.init.call( that, element, defaults );
            },
            val: function ( value ) {
                var that = this,
                    regex = /\D+/,
                    date;
                if ( value ) {
                    if ( typeof value === 'number' || ( typeof value === 'string' && !regex.test( value ) ) ) {
                        value = new Date( value );
                    }
                    window.kendo.ui.DateTimePicker.fn.value.call( that, value );
                } else {
                    date = window.kendo.ui.DateTimePicker.fn.value.call( that );
                    if ( typeof date === 'object' ) {
                        date = Date.parse( date );
                    } else if ( typeof date === 'string' ) {
                        date = Date.parse( new Date( date ) );
                    }
                    if ( isNaN( date ) ) {
                        date = '';
                    }
                    return date;
                }
            },
            _blur: function () {
                var that = this;
                that.close();
                that._change( that.element.attr( 'value' ) );
                that._inputWrapper.removeClass( FOCUSED );
            },
            _change: function ( value ) {
                var that = this;
                that._update( value );
                that.trigger( CHANGE );
                that.element.trigger( CHANGE );
            },
            value: function ( value ) {
                var that = this,
                    regex = /\D+/;
                if ( value ) {
                    if ( typeof value === 'number' || ( typeof value === 'string' && !regex.test( value ) ) ) {
                        value = new Date( value );
                    }
                    window.kendo.ui.DateTimePicker.fn.value.call( that, value );
                } else {
                    return window.kendo.ui.DateTimePicker.fn.value.call( that );
                }
            }
        } );
    window.nmsweb.registerComponent( 'DatePicker', DatePicker );
    return DatePicker;
} );