define( [ 'kendo', 'core/nmsweb' ], function () {
    "use strict";
    var Window = window.kendo.ui.Window.extend( {
        init: function ( element, options ) {
            var that = this,
                defaults = {
                    actions: [ "Maximize", "Close" ],
                    draggable: false,
                    resizable: false,
                    minWidth: 200,
                    visible: true
                };
            if ( options ) {
                nmsweb.extendOptions( defaults, options );
            }
            window.kendo.ui.Window.fn.init.call( that, element, defaults );
        }
    } );
    window.nmsweb.registerComponent( 'Window', Window );
    return Window;
} );