define( [ 'kendo', 'core/spin', 'core/nmsweb' ], function ( kendo ) {
    "use strict";
    window.kendo.ui.progress = function ( container, toggle, spinOpts ) {
        var mask = container.find( ".k-loading-mask" );
        if ( toggle ) {
            if ( !mask.length ) {
                mask = $( "<div class='k-loading-mask'></div>" )
                    .width( "100%" ).height( "100%" )
                    .prependTo( container )
                    .spin( spinOpts );
            }
        } else if ( mask ) {
            mask.remove();
        }
    };
    return window.kendo.ui.progress;
} );