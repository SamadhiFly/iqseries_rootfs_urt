define( [ 
    'jquery', 
    'core/utils', 
    'kendo', 
    'kendo', 
    'core/notification', 
    'core/timepicker', 
    'core/datetimepicker', 
    'core/datepicker',
    'module/core/factory/nmsweb-element-notification',
    'module/core/factory/data-transport-mechanism'
    ], function ( $, nmsutils ) {
    "use strict";
    var kendo = window.kendo,
        Grid = kendo.ui.Grid.extend( {
            init: function ( element, options ) {
                var that = this,
                    defaults = {
                        columns: [],
                        scrollable: {
                            virtual: true
                        },
                        sortable: {
                            mode: 'multiple',
                            allowUnsort: true
                        },
                        pageable: false,
                        groupable: true,
                        selectable: true,
                        navigatable: false,
                        autoBind: true
                    },
                    length,
                    i,
                    editors,
                    operators,
                    keys,
                    input,
                    selectable,
                    toggle,
                    index;
                that.hasData = false;
                that.isRecoverable = true,
                    that.isWaitingForUserInput; // jshint ignore:line
                if ( options ) {
                    nmsweb.extendOptions( defaults, defaults, options, that );
                }
                selectable = defaults.selectable;
                toggle = typeof selectable === 'string' && selectable.toLowerCase().indexOf( "toggle" ) > -1;
                if ( toggle ) {
                    defaults.columns.unshift( {
                        title: '',
                        width: '30px',
                        template: '<input type="checkbox"></input>'
                    } );
                }
                editors = {
                    datetime: function ( container, options ) {
                        var opts = {};
                        if ( options.model.id === 0 ) {
                            options.model[ options.field ] = options.model[ options.field ] + 60 * new Date().getTimezoneOffset();
                        }
                        input = $( '<input type="text"/>' );
                        input.attr( kendo.attr( 'type' ), 'datetime' ).attr( kendo.attr( 'bind' ), 'value: ' + options.field );
                        if ( options.required ) {
                            input.attr( 'required', 'required' );
                        }
                        if ( options.format !== undefined ) {
                            opts.format = options.format;
                        }
                        opts.inlineEdit = true;
                        input.appendTo( container ).nmswebDateTimePicker( opts ).data( 'nmswebDateTimePicker' );
                        $( '<span ' + kendo.attr( "for" ) + '="' + options.field + '" class="k-invalid-msg"/>' ).hide().appendTo( container );
                    },
                    date: function ( container, options ) {
                        var opts = {};
                        input = $( '<input type="text"/>' );
                        input.attr( kendo.attr( 'type' ), 'datetime' ).attr( kendo.attr( 'bind' ), 'value: ' + options.field );
                        if ( options.required ) {
                            input.attr( 'required', 'required' );
                        }
                        if ( options.format !== undefined ) {
                            opts.format = options.format;
                        }
                        opts.inlineEdit = true;
                        input.appendTo( container ).nmswebDatePicker( opts ).data( 'nmswebDateTimePicker' );
                        $( '<span ' + kendo.attr( "for" ) + '="' + options.field + '" class="k-invalid-msg"/>' ).hide().appendTo( container );
                    },
                    time: function ( container, options ) {
                        var opts = {};
                        input = $( '<input type="text"/>' );
                        input.attr( kendo.attr( 'type' ), 'datetime' ).attr( kendo.attr( 'bind' ), 'value: ' + options.field );
                        if ( options.required ) {
                            input.attr( 'required', 'required' );
                        }
                        if ( options.format !== undefined ) {
                            opts.format = options.format;
                        }
                        input.appendTo( container ).nmswebTimePicker( opts ).data( 'nmswebDateTimePicker' );
                        $( '<span ' + kendo.attr( "for" ) + '="' + options.field + '" class="k-invalid-msg"/>' ).hide().appendTo( container );
                    }
                };
                operators = {
                    datetime: {
                        gt: "After",
                        lt: "Before",
                        eq: "Equal"
                    },
                    date: {
                        gt: "After",
                        lt: "Before",
                        eq: "Equal"
                    }
                };
                defaults.columns = defaults.columns || [];

                if ( defaults.filterDropDownData ) {
                    Object.getOwnPropertyNames(defaults.filterDropDownData).forEach(function(val) {
                        for ( i = 0, length = defaults.columns.length; i < length; i++ ) {
                            if ( defaults.columns[ i ].field && defaults.columns[ i ].field === val ) {
                                if ( !defaults.columns[ i ].filterable ) {
                                    defaults.columns[ i ].filterable = {};
                                }
                                defaults.columns[ i ].filterable.extra = false;
                                defaults.columns[ i ].filterable.ui = function ( element ) {
                                    element.kendoDropDownList( {
                                        dataSource: defaults.filterDropDownData[val]
                                    } );
                                };
                            }
                        }
                    });
                }

                keys = Object.keys( editors );
                for ( i = 0, length = defaults.columns.length; i < length; i++ ) {
                    index = keys.indexOf( defaults.columns[ i ].type );
                    if ( index !== -1 ) {
                        defaults.columns[ i ].editor = editors[ defaults.columns[ i ].type ];
                    }
                    if ( typeof defaults.columns[ i ] !== "string" ) {
                        if ( !defaults.columns[ i ].filterable ) {
                            defaults.columns[ i ].filterable = {};
                        }
                        if ( !defaults.columns[ i ].filterable.ui ) {
                            if ( defaults.columns[ i ].type === "datetime" ) {
                                defaults.columns[ i ].filterable.ui = function ( element ) {
                                    element.nmswebDateTimePicker( {
                                        format: "yyyy-MM-dd hh:mm:ss",
                                        returnComparison: true
                                    } );
                                };
                            }
                            if ( defaults.columns[ i ].type === "date" ) {
                                defaults.columns[ i ].filterable.ui = function ( element ) {
                                    element.kendoDatePicker( {
                                        format: "yyyy-MM-dd"
                                    } );
                                };
                            }
                        }
                    }
                }
                if ( defaults.filterable === true ) {
                    defaults.filterable = {
                        operators: operators
                    };
                } else if ( defaults.filterable ) {
                    defaults.filterable.operators = operators;
                }
                var csvToolbarIcon = {
                    text: "CSV Export",
                    name: "csv-export",
                    className: "k-grid-csv-export",
                    imageClass: "k-csv-export"
                };
                if ( ( typeof ( options.export ) === "undefined" || options.export === true ) && !$( element ).hasClass( "data-elementselectorgrid" ) && !$( element ).hasClass( "n-configurator-presets-grid" ) ) {
                    if ( jQuery.isArray( defaults.toolbar ) ) {
                        ( defaults.toolbar ).push( csvToolbarIcon );
                    } else if ( typeof defaults.toolbar === "function" ) {
                        var templateContent = defaults.toolbar( true );
                        defaults.toolbar = [ {
                            template: templateContent
                        }, csvToolbarIcon ];
                    } else {
                        defaults.toolbar = [ csvToolbarIcon ];
                    }
                }
                defaults.groupable = false; //Grouping ablility has been switched off for 1.0
                kendo.ui.Grid.fn.init.call( that, element, defaults );
                //remove auto-generated inline CSS - it causes 0 width grids in Firefox.
                $(that.element.selector + ' .k-grid-content').css('width', '');
                that.selectionFix = '.k-hierarchy-cell';
                if ( typeof that.options.selectable === 'string' && that.options.selectable.indexOf( 'multiple' ) !== -1 ) {
                    that._applyMemorySelection();
                    that._createSelectionLabel();
                }
                that._fixSelection();
                that._createGridFooter();
                that._initCsvExport();
                if ( ( ( that.element.attr( 'id' ) && that.options.groupable ) || ( that.element.attr( 'id' ) && that.options.extraControls ) ) && !that.element.hasClass( 'data-elementselectorgrid' ) ) {
                    that._applyPopoutMenu();
                }
                if ( that.options.detailTemplate && that.options.scrollable && that.options.scrollable.virtual ) {
                    that._applyMemoryExpanded();
                }
                //Adds the virtual-scroll paging for FF
                if ( that.virtualScrollable ) {
                    var vSObj = Object.getPrototypeOf( that.virtualScrollable );
                    vSObj._scroll = function ( e ) {
                        var that = this,
                            math = Math,
                            scrollTop = e.currentTarget.scrollTop,
                            dataSource = that.dataSource,
                            rowHeight = that.itemHeight,
                            skip = dataSource.skip() || 0,
                            start = that._rangeStart || skip,
                            height = that.element.innerHeight(),
                            isScrollingUp = !!( that._scrollbarTop && that._scrollbarTop > scrollTop ),
                            mathFun = isScrollingUp ? math.ceil : math.floor,
                            firstItemIndex = math.max( mathFun( scrollTop / rowHeight ), 0 ),
                            lastItemIndex = math.max( firstItemIndex + mathFun( height / rowHeight ), 0 );
                        if ( that.oldHeight === height || that.oldHeight === undefined ) {
                            that._scrollTop = scrollTop - ( start * rowHeight );
                            that._scrollbarTop = scrollTop;
                            if ( !that._fetch( firstItemIndex, lastItemIndex, isScrollingUp ) ) {
                                that.wrapper[ 0 ].scrollTop = that._scrollTop;
                            }
                        }
                        that.oldHeight = height;
                    };
                }
                if ( that.dataSource._data.length > 0 ) {
                    that.hasData = true;
                }

                var elem = angular.element( $( '#app' ) );
                that.injector = elem.injector();
                var NmswebElementNotification = that.injector.get( 'NmswebElementNotification' );
                this.notificationService = new NmswebElementNotification( {
                    element: element, 
                    type: 'grid', 
                    component: that,
                    isApplyNeeded: true
                } );

                that._initListeners( $( element ), that.dataSource );
                $( element ).trigger( 'nmsweb:positionNotification' );
            },
            _initCsvExport: function () {
                var that = this;
                if ( $( '#' + that.element.attr( 'id' ) + ' .k-grid-csv-export' ) ) {
                    $( '#' + that.element.attr( 'id' ) + ' .k-grid-csv-export' ).click( function () {
                        var d = new Date();
                        var filename = d.getFullYear() + "-" + ( d.getMonth() + 1 ) + "-" + d.getDate() + "_" + d.getHours() + "-" + d.getMinutes() + ".csv";
                        var grid = $( '#' + that.element.attr( 'id' ) ).data( 'nmswebGrid' );
                        if ( typeof ( grid.virtualScrollable ) !== "undefined" || grid.dataSource.options.serverPaging ) {
                            //Virtual Scrolling or RemotePaging
                            var pageSize = grid.dataSource.pageSize();
                            if ( pageSize ) {
                                grid.dataSource.pageSize( 0 );
                            }
                            grid.dataSource.fetch( function () {
                                var data = this.data();
                                this.pageSize( pageSize );
                                this.fetch( function () {
                                    grid.refresh();
                                    nmsutils.triggerPostRequest( '/core/csv/export', {
                                        'filename': filename,
                                        'payload': nmsutils.exportCsv( data, grid.columns )
                                    } );
                                } );
                            } );
                        } else {
                            nmsutils.triggerPostRequest( '/core/csv/export', {
                                'filename': filename,
                                'payload': nmsutils.exportCsv( grid.dataSource.data(), grid.columns )
                            } );
                        }
                    } );
                }
            },
            _initListeners: function ( $el, ds ) {
                var that = this;

                var dataTransportMechanism = that.injector.get( 'DataTransportMechanism' );
                that.mechanism = dataTransportMechanism.mechanism( that );
                dataTransportMechanism.bindNotifications( that.notificationService, ds, that.mechanism );

                $el.on( 'nmsweb:positionNotification', function () {
                    that._positionChildEls();
                } );
                $el.on( 'nmsweb:notify', function ( e, data ) {
                    e.preventDefault();
                    e.stopPropagation();
                    var options = $.extend( {}, data, {
                        'selector': $( this ),
                        'type': typeof data.type !== 'undefined' ? data.type : 'success',
                        'title': typeof data.title !== 'undefined' ? data.title : 'Good News',
                        'message': typeof data.message !== 'undefined' ? data.message : 'Data Loaded all is well',
                        'isFadeable': typeof data.isFadeable !== 'undefined' ? data.isFadeable : true,
                        'isPersistent': typeof data.isPersistent !== 'undefined' ? data.isPersistent : false
                    } );
                    //window.Notifier.getNotification(options);
                    $el.nmswebNotification( options );
                    $el.trigger( 'nmsweb:positionNotification' );
                } );
                // if( !that.hasData ) {
                //  $el.trigger('nmsweb:notify', {type: 'progress', title: 'Status', message:'Waiting for data...', isFadeable: false, isPersistent: true});
                //  $el.trigger('nmsweb:positionNotification');
                // }
                // ds.bind( 'asyncDone', function () {
                //     $el.trigger( 'nmsweb:notify', {
                //         type: 'progress',
                //         title: 'Status',
                //         message: 'No data currently available',
                //         isFadeable: false,
                //         isPersistent: true
                //     } );
                // } );
                // ds.bind( 'error', function ( e ) {
                //     if ( ( e.xhr ) && ( e.xhr.status >= 500 ) ) {
                //         var xhrResponse,
                //             message = e.errorThrown;
                //         try {
                //             xhrResponse = JSON.parse( e.xhr.responseText );
                //             if ( xhrResponse.message ) {
                //                 message = xhrResponse.message;
                //             }
                //         } catch ( e ) {}; // jshint ignore:line
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'No data currently available',
                //             isFadeable: false,
                //             isPersistent: true
                //         } );
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'error',
                //             title: 'Error ' + e.xhr.status,
                //             message: message,
                //             isFadeable: true
                //         } );
                //         if ( $el.data( 'nmswebElementSelectorGrid' ) ) {
                //             $el.data( 'nmswebElementSelectorGrid' ).dataSource.data( [] );
                //         }
                //         that._errorReported = true;
                //         $el.trigger( 'nmsweb:positionNotification' );
                //         that.isRecoverable = false;
                //     } else if ( ( e.xhr ) && ( e.xhr.status >= 200 ) && ( e.sender._data.length < 1 ) ) {
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'No data currently available',
                //             isFadeable: false,
                //             isPersistent: true
                //         } );
                //         $el.trigger( 'nmsweb:positionNotification' );
                //         that.isRecoverable = false;
                //     } else if ( e.errors ) {
                //         $.each( e.errors, function ( idx, errObj ) {
                //             var message = typeof errObj.message !== 'object' ? errObj.message : errObj.message.message;
                //             var source = ( errObj.source ) ? ' in ' + errObj.source : '';
                //             $el.trigger( 'nmsweb:notify', {
                //                 type: that._getNotificationType( errObj.severity ),
                //                 title: 'Code ' + errObj.code,
                //                 message: message + source
                //             } );
                //             if ( e.sender._data.length > 0 ) {
                //                 $el.find( '.n-progress-notifications-container .n-progress-notification' ).remove();
                //             }
                //         } );
                //     }
                // } );
                // ds.bind( 'streamRequestSend', function () {
                //     $el.trigger( 'nmsweb:notify', {
                //         type: 'progress',
                //         title: 'Status',
                //         message: 'Waiting for data...',
                //         isFadeable: false,
                //         isPersistent: true
                //     } );
                // } );
                // ds.bind( 'requestStart', function () {
                //     that.isWaitingForUserInput = false;
                //     $el.trigger( 'nmsweb:notify', {
                //         type: 'progress',
                //         title: 'Status',
                //         message: 'Loading',
                //         isFadeable: false,
                //         isPersistent: true
                //     } );
                // } );
                // ds.bind( 'streamed', function () {
                //     $el.find( '.n-progress-notifications-container .n-progress-notification' ).remove();
                // } );
                // ds.bind( 'feLimitReached', function () {
                //     if ( !ds.notifiedLimit ) {
                //         $el.trigger( 'nmsweb:notify', {
                //             "type": "info",
                //             "title": "Data limit reached",
                //             "message": "The oldest items are being removed."
                //         } );
                //         ds.notifiedLimit = true;
                //     }
                // } );
                // ds.bind( 'change', function ( e ) {
                //     if ( ( e.sender._data.length > 0 ) ) {
                //         that.hasData = true;
                //         that.isWaitingForUserInput = false;
                //         $el.find( '.n-progress-notifications-container .n-progress-notification' ).remove();
                //     } else if ( that._errorReported ) {
                //         that._errorReported = false;
                //     } else {
                //         if ( that._initialChangeRun === undefined && ( that.options.initialFilterFireOnLoad === undefined || that.options.initialFilterFireOnLoad === false ) ) {
                //             $el.trigger( 'nmsweb:notify', {
                //                 type: 'progress',
                //                 title: 'Status',
                //                 message: 'Waiting for user input',
                //                 isFadeable: false,
                //                 isPersistent: true
                //             } );
                //         } else {
                //             that.isWaitingForUserInput = false;
                //             $el.trigger( 'nmsweb:notify', {
                //                 type: 'progress',
                //                 title: 'Status',
                //                 message: 'No data available',
                //                 isFadeable: false,
                //                 isPersistent: true
                //             } );
                //         }
                //     }
                //     that._initialChangeRun = true;
                // } );
                that.bind( 'save', function ( e ) {
                    var updateDataSource = false;
                    $.each( that.columns, function ( key, column ) {
                        if ( column.type === "datetime" ) {
                            var model = e.model[ column.field ],
                                item = that.dataSource.getByUid( e.model[ 'uid' ] ), // jshint ignore:line
                                date = new window.oldDate( model );
                            if ( typeof model === "number" ) {
                                date = new window.oldDate( model * 1000 );
                            }
                            date = new window.oldDate( ( ( date.getTime() / 1000 ) - 60 * date.getTimezoneOffset() ) * 1000 );
                            item[ column.field ] = date;
                            updateDataSource = true;
                        }
                    } );
                    that.dataSource.bind( 'change', function () {
                        if ( updateDataSource ) {
                            that.dataSource.read();
                            updateDataSource = false;
                        }
                    } );
                } );
                // $( 'body' ).on( 'nmsweb:jmrBack', function ( e ) {
                //     var $connectionNotification = $el.find( ':contains("Lost connection. Reconnecting...")' ),
                //         $reconnectionNotification = $el.find( ':contains("Reconnected")' );
                //     if ( ( !that.hasData ) && ( that.isRecoverable ) && ( e.errors ) ) {
                //         if ( $connectionNotification.length > 0 ) {
                //             $connectionNotification.closest( '.n-warning-notification' ).trigger( 'click' );
                //             if ( $reconnectionNotification.length < 1 ) {
                //                 $el.trigger( 'nmsweb:notify', {
                //                     type: 'info',
                //                     title: 'Status',
                //                     message: 'Reconnected',
                //                     isFadeable: true
                //                 } );
                //             }
                //         }
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'Waiting for data with errors...',
                //             isFadeable: false,
                //             isPersistent: true
                //         } );
                //     } else if ( ( !that.hasData ) && ( that.isRecoverable ) ) {
                //         if ( $connectionNotification.length > 0 ) {
                //             $connectionNotification.closest( '.n-warning-notification' ).trigger( 'click' );
                //             if ( $reconnectionNotification.length < 1 ) {
                //                 $el.trigger( 'nmsweb:notify', {
                //                     type: 'info',
                //                     title: 'Status',
                //                     message: 'Reconnected',
                //                     isFadeable: true
                //                 } );
                //             }
                //         }
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'Waiting for data...',
                //             isFadeable: false,
                //             isPersistent: true
                //         } );
                //     } else if ( !that.isRecoverable ) {
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'No data currently available',
                //             isFadeable: false,
                //             isPersistent: true
                //         } );
                //     } else {
                //         if ( $connectionNotification.length > 0 ) {
                //             $connectionNotification.closest( '.n-warning-notification' ).trigger( 'click' );
                //             if ( $reconnectionNotification.length < 1 ) {
                //                 $el.trigger( 'nmsweb:notify', {
                //                     type: 'info',
                //                     title: 'Status',
                //                     message: 'Reconnected',
                //                     isFadeable: true
                //                 } );
                //             }
                //         }
                //     }
                // } );
                // $( 'body' ).on( 'nmsweb:jmrDown', function () {
                //     var $connectionNotification = $el.find( ':contains("Lost connection. Reconnecting...")' );
                //     if ( ( !that.hasData ) && ( that.isRecoverable ) ) {
                //         //Do not respawn this notification
                //         if ( $connectionNotification.length < 1 ) {
                //             $el.trigger( 'nmsweb:notify', {
                //                 type: 'warning',
                //                 title: 'Status',
                //                 message: 'Lost connection. Reconnecting...',
                //                 isFadeable: false,
                //                 spin: true
                //             } );
                //         }
                //     } else if ( !that.isRecoverable ) {
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'No data currently available',
                //             isFadeable: false,
                //             isPersistent: true
                //         } );
                //     }
                // } );

                that.element.on( 'nmswebClassApplied', function () {
                    if ( that.options.initialFilterFireOnLoad === true ) {
                        $el.trigger( 'nmsweb:notify', {
                            type: 'progress',
                            title: 'Status',
                            message: 'Loading',
                            isFadeable: false,
                            isPersistent: true
                        } );
                    }
                } );
            },
            _positionChildEls: function () {
                var headerWrap = ( $( this.element ).find( '.k-grid-header-wrap' ).length > 0 ) ? $( this.element ).find( '.k-grid-header-wrap' ).outerHeight() : 0,
                    progressEl = $( this.element ).find( '.n-progress-notifications-container' ),
                    height;
                headerWrap += ( $( this.element ).find( '.k-grid-toolbar' ).length > 0 ) ? $( this.element ).find( '.k-grid-toolbar' ).outerHeight() : 0;
                height = $( this.element ).height() - ( headerWrap + $( this.element ).find( '.k-grid-content' ).outerHeight() );
                if ( $( this.element ).hasClass( 'data-elementselectorgrid' ) ) {
                    height = $( this.element ).find( '.k-pager-wrap' ).outerHeight();
                    progressEl.css( {
                        'bottom': height + 'px'
                    } );
                } else {
                    progressEl.css( {
                        'bottom': height + 'px'
                    } );
                }
            },
            _getNotificationType: function ( severity ) {
                if ( ( severity === 5 ) || ( severity === 6 ) ) {
                    return 'error';
                } else if ( ( severity === 3 ) || ( severity === 4 ) ) {
                    return 'warning';
                } else {
                    return 'info';
                }
            },
            _applyPopoutMenu: function () {
                var that = this,
                    $content = $( '<div></div>' ).append( that.element.find( '.k-grouping-header' ), that.element.find( '.k-grid-toolbar' ) ),
                    btn,
                    pp,
                    ap,
                    gridPosition,
                    gridMenuHeight,
                    gridWidth,
                    setMenuControlsPopoverWidthAndPosition = function () {
                        btn = that.element.find( '.n-grid-menu-button' );
                        gridPosition = $( '#' + that.element.attr( 'id' ) ).getPosition();
                        gridWidth = $( '#' + that.element.attr( 'id' ) )[ 0 ].offsetWidth;
                        gridMenuHeight = $( '#' + that.element.attr( 'id' ) + '-menu-popover' )[ 0 ].offsetHeight;
                        pp = {
                            padding: '0px 0px 5px 0px',
                            top: ( btn.getPosition().top - gridMenuHeight ) + 5,
                            width: gridWidth,
                            left: gridPosition.left
                        };
                        $( '#' + that.element.attr( 'id' ) + '-menu-popover' ).removeAttr( 'style' ).css( pp );
                        ap = {
                            left: ( ( gridWidth ) + ( gridPosition.left ) ) - 60
                        };
                        $( '#' + that.element.attr( 'id' ) + '-menu-popover' ).find( '.overlayarrow, .arrow' ).css( ap );
                    };
                that.element.find( '.k-grid-header' ).append( $( '<div class="n-grid-menu-button"></div>' ).nmswebPopover( {
                    'manual': true,
                    'placement': 'top',
                    'id': that.element.attr( 'id' ) + '-menu-popover',
                    'toggle': true,
                    'content': $content
                } ).on( 'click', function () {
                    setMenuControlsPopoverWidthAndPosition();
                } ) );
                setMenuControlsPopoverWidthAndPosition();
                $( '#' + that.element.attr( 'id' ) + '-menu-popover' ).find( '.close' ).remove();
            },
            _applyMemoryExpanded: function () {
                var that = this,
                    detail = '.k-master-row',
                    detailIcon = '.k-minus',
                    idField = that.dataSource.options.schema.model.id || 'uid',
                    dataSource = that.dataSource,
                    id,
                    item;
                that.detailExpanded = [];
                //Doubles side scrollbar, fix to show wide detail rows
                that.element.find( '.k-grid-content' ).css( 'overflow', 'auto' );
                that.table.on( 'click', detail + ' .k-icon', function () {
                    var uid = $( this ).closest( detail ).attr( kendo.attr( 'uid' ) ),
                        idx;
                    item = dataSource.getByUid( uid );
                    if ( item !== undefined ) {
                        id = item.get( idField );
                        idx = that.detailExpanded.indexOf( id );
                        if ( $( this ).hasClass( detailIcon.substr( 1 ) ) && !~idx ) {
                            that.detailExpanded.push( id );
                        } else if ( ~idx ) {
                            that.detailExpanded.splice( idx, 1 ); //remove from array if we find id there
                        }
                    }
                } );
                that.dataSource.bind( 'streamed', function () {
                    var rows = that.table.find( that.selectable.options.filter ),
                        row,
                        uid,
                        i,
                        item,
                        id,
                        dataSource = that.dataSource,
                        tempArr = [],
                        len;
                    for ( i = 0, len = rows.length; i < len; i++ ) {
                        row = $( rows[ i ] );
                        uid = row.attr( kendo.attr( 'uid' ) );
                        item = dataSource.getByUid( uid );
                        //If row is not expanded but it is in array, then do it
                        if ( item ) {
                            id = item.get( idField );
                            if ( ~that.detailExpanded.indexOf( id ) ) {
                                that.expandRow( row, id );
                                tempArr.push( id );
                            }
                        }
                    }
                    that.detailExpanded = tempArr;
                } );
            },
            _applyMemorySelection: function () {
                var that = this,
                    selected = 'k-state-selected',
                    counter = '.n-selection-counter',
                    selectionTotal = '.n-selection-total',
                    selectable = that.options.selectable,
                    toggle = typeof selectable === 'string' && selectable.toLowerCase().indexOf( "toggle" ) > -1;
                if ( typeof that.options.scrollable === 'object' && that.options.scrollable.virtual ) {
                    that.selectable.selectRange = function () {};
                }
                that.selectable.bind( 'change', function () {
                    var rows = that.table.find( that.selectable.options.filter ),
                        i,
                        len,
                        uid,
                        row;
                    for ( i = 0, len = rows.length; i < len; i++ ) {
                        row = $( rows[ i ] );
                        uid = row.attr( kendo.attr( 'uid' ) );
                        if ( row.hasClass( selected ) ) {
                            that.dataSource.selectMem( uid );
                        } else {
                            that.dataSource.unselectMem( uid );
                        }
                    }
                    that.dataSource.trigger( 'selected' );
                    that.wrapper.find( counter ).html( that.dataSource.selectedLen() );
                    that.wrapper.find( selectionTotal ).html( that.dataSource.total() );
                } );
                that.table.on( 'mousedown', 'tbody>tr:not(.k-detail-row):not(.k-grouping-row):not(.k-group-footer)', function ( event ) {
                    var uid = $( this ).attr( kendo.attr( 'uid' ) );
                    if ( typeof that.options.scrollable === 'object' && that.options.scrollable.virtual ) {
                        if ( !event.ctrlKey ) {
                            that.dataSource.deselectAll();
                        }
                        if ( !event.shiftKey ) {
                            that.dataSource.selectFrom( uid );
                        } else {
                            that.dataSource.selectTo( uid );
                        }
                    }
                    if ( toggle ) {
                        that.trigger( 'selected:toggle', {
                            "uid": uid
                        } );
                    }
                } );
                that.bind( 'dataBound', function () {
                    var data = that.dataSource.view(),
                        idField,
                        fun,
                        obj,
                        selectFun;
                    if ( typeof that.dataSource.options.schema !== 'undefined' && typeof that.dataSource.options.schema.model !== 'undefined' && typeof that.dataSource.options.schema.model.id !== 'undefined' ) {
                        idField = that.dataSource.options.schema.model.id;
                        fun = 'get';
                    } else {
                        idField = 'uid';
                        fun = 'getByUid';
                    }
                    selectFun = function ( data ) {
                        var i, len, id, row;
                        for ( i = 0, len = data.length; i < len; i++ ) {
                            id = data[ i ][ idField ];
                            if ( data[ i ].items !== undefined ) {
                                selectFun( data[ i ].items );
                            }
                            if ( that.dataSource._selected.indexOf( id ) !== -1 ) {
                                obj = that.dataSource[ fun ]( id );
                                row = that.table.find( '[' + kendo.attr( 'uid' ) + '="' + obj.uid + '"]' ).addClass( 'k-state-selected' );
                                if ( toggle ) {
                                    row.find( ':checkbox:first' ).prop( 'checked', true );
                                }
                            }
                        }
                    };
                    selectFun( data );
                    that.selectable.trigger( 'change' );
                } );
            },
            _selectable: function () {
                var that = this,
                    selectable = that.options.selectable,
                    toggle = typeof selectable === 'string' && selectable.toLowerCase().indexOf( "toggle" ) > -1;
                if ( toggle ) {
                    that.table.on( 'mousedown', 'tr', function ( e ) {
                        var checkbox = $( this ).find( ':checkbox:first' );
                        e.ctrlKey = true;
                        e.shiftKey = false;
                        checkbox.prop( 'checked', !checkbox.prop( 'checked' ) );
                    } );
                    that.table.on( 'click', 'input[type="checkbox"]', function ( e ) {
                        e.preventDefault();
                    } );
                }
                kendo.ui.Grid.fn._selectable.call( that );
            },
            _fixSelection: function () {
                var that = this;
                that.table.find( 'tbody' ).on( 'mousedown', that.selectionFix, function () {
                    return false;
                } );
            },
            _createGridFooter: function () {
                var that = this,
                    wrapper = that.wrapper.children( "div.k-grid-pager" );
                if ( !wrapper.length ) {
                    wrapper = $( '<div class="k-pager-wrap k-grid-pager"/>' ).appendTo( that.wrapper );
                }
            },
            _createSelectionLabel: function () {
                var that = this,
                    wrapper = that.wrapper.children( "div.k-grid-pager" );
                if ( !wrapper.length ) {
                    wrapper = $( '<div class="k-pager-wrap k-grid-pager"/>' ).appendTo( that.wrapper );
                }
                if ( typeof that.options.selectable !== 'undefined' && that.options.selectable ) {
                    wrapper.append( '<span class="k-label n-selection-info"><span class="n-selection-counter">0</span> of <span class="n-selection-total">' + that.dataSource.total() + '</span> selected (<span class="n-selection-options"><a class="k-label n-deselect" href="#">deselect all</a></span>)</span>' );
                    if ( !that.dataSource.options.serverPaging ) {
                        wrapper.find( '.n-selection-options' ).prepend( '<a class="k-label n-select-all" href="#">select all</a> | ' );
                    }
                    wrapper.on( 'click', '.n-select-all', function ( e ) {
                        that.tbody.children( 'tr' ).addClass( 'k-state-selected' );
                        that.dataSource.selectAll();
                        that.refresh();
                        e.preventDefault();
                    } );
                    wrapper.on( 'click', '.n-deselect', function ( e ) {
                        that.dataSource.deselectAll();
                        that.refresh();
                        e.preventDefault();
                    } );
                }
            },
            forceSelect: function ( elements ) {
                var that = this;
                $.each( elements, function ( key ) {
                    if ( that.dataSource.get( elements[ key ] ) === undefined ) {
                        elements.splice( key, 1 );
                    }
                } );
                if ( elements.length ) {
                    that.dataSource.forceSelect( elements );
                    that.refresh();
                    that.selectable.trigger( 'change' );
                }
            },
            val: function ( elements ) {
                var ret;
                if ( typeof elements === 'string' ) {
                    elements = JSON.parse( elements );
                }
                if ( typeof this.options.valCallback === 'function' ) {
                    ret = $.proxy( this, this.options.valCallback( elements ) );
                } else {
                    if ( elements ) {
                        this.forceSelect( elements );
                    } else {
                        ret = this.dataSource.getSelectedIds();
                    }
                }
                return ret;
            }
        } );
    window.nmsweb.registerComponent( 'Grid', Grid );
    return Grid;
} );