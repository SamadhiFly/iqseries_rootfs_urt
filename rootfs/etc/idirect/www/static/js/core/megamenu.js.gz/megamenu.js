define( [ "jquery", "angular", "kendo", "module/core", "core/popover" ], function ( $, angular ) {
    'use strict';
    ( function ( $ ) {
        $.fn.extend( {
            nmsMegaMenu: function ( options ) {
                var defaults = {
                        groupColumns: 3,
                        reactive: true,
                        width: '100%',
                        categoryWidth: '100px',
                        fullwidth: true,
                        hoverDelay: 400
                    },
                    container,
                    tab,
                    tabs,
                    setSingleClickExpandCollapse = function ( $tree ) {
                        $tree.on( "click", ".k-in", function ( e ) {
                            $tree.data( "kendoTreeView" ).toggle( $( e.target ).closest( ".k-item" ) );
                        } );
                    },
                    getTree = function ( treeObject ) {
                        var $elementHierarchyTree = $( '<div></div>' );
                        $elementHierarchyTree.kendoTreeView( {
                            template: "# if (item.link !== undefined) { #" +
                                "<a class='n-megamenu-tree-node' href='#= item.link #'>#= item.text #</a>" +
                                "# } else { #" +
                                "<a class='n-megamenu-tree-node'>#= item.text #</a>" +
                                "# } #",
                            dataSource: treeObject
                        } );
                        setSingleClickExpandCollapse( $elementHierarchyTree );
                        return $elementHierarchyTree;
                    },
                    getGroupContents = function ( container ) {
                        var items = [],
                            $groupContentItems;
                        $groupContentItems = container.children( 'li' )
                            .each( function () {
                                var item = $( this ),
                                    groupItem = $( '<li class=\'n-megamenu-group-item\'></li>' ),
                                    groupItemTitle,
                                    subHeader,
                                    treedata,
                                    tree,
                                    $tree,
                                    groupItemContent;
                                if ( item.children( 'span' ).children( 'a' ).length !== 0 ) {
                                    groupItemTitle = item.children( 'span' ).children( 'a' );
                                }
                                if ( item.children( '.n-megamenu-category' ).children( 'ul' ).length !== 0 || item.find( 'a[data-name]' ).length !== 0 ) {
                                    subHeader = item.children( 'span' ).children( 'a' );
                                    groupItemContent = getGroupContents( $( '.n-megamenu-category[data-name="' + item.find( 'a[data-name]' ).data( 'name' ) + '"]' ).find( 'ul' ).first() );
                                    treedata = [];
                                    tree = {};
                                    tree.text = subHeader.text();
                                    tree.items = [];
                                    $.each( groupItemContent, function ( index, value ) {
                                        var childtree = value.tree;
                                        var text = $( this ).find( 'a' ).first().text(),
                                            link = $( this ).find( 'a' ).attr( 'href' );
                                        if ( link || text ) {
                                            if ( childtree !== undefined ) {
                                                tree.items.push( {
                                                    text: text,
                                                    link: link,
                                                    items: childtree.items
                                                } );
                                            } else {
                                                tree.items.push( {
                                                    text: text,
                                                    link: link
                                                } );
                                            }
                                        }
                                    } );
                                    treedata.push( tree );
                                    $tree = getTree( treedata );
                                    $tree.find( 'li:has(ul)' ).addClass( "tree-parent" );
                                    if ( item.find( 'a[data-name]' ).data( 'name' ).indexOf( "More Options" ) === -1 ) {
                                        $tree.data( 'kendoTreeView' ).expand( $tree.find( 'li:has(ul)' ) );
                                    }
                                    groupItemContent = $tree;
                                } else {
                                    groupItem.append( groupItemTitle );
                                }
                                if ( groupItemContent !== undefined ) {
                                    $.each( groupItemContent, function () {
                                        groupItem.append( this );
                                    } );
                                    groupItem.tree = tree;
                                }
                                items.push( groupItem );
                            } );
                        return items;
                    },
                    hideMegamenu = function ( $megamenu ) {
                        $megamenu.addClass( 'hide' );
                        $( '.n-megamenu-tab-opened' ).removeClass( 'n-megamenu-tab-opened' );
                    },
                    addHoverDelayToMegaMenu = function ( megamenu ) {
                        var timer;
                        megamenu.parents( 'nav' ).on( {
                            'mouseenter focus': function () {
                                clearTimeout( timer );
                            },
                            'mouseleave blur': function () {
                                timer = setTimeout( function () {
                                    hideMegamenu( megamenu );
                                }, options.hoverDelay );
                            }
                        } );
                    },
                    switchTab = function ( tab, megamenu ) {
                        if ( !megamenu.hasClass( 'hide' ) ) {
                            megamenu.addClass( 'hide' );
                            tab.removeClass( 'n-megamenu-tab-opened' );
                        } else {
                            var elem = angular.element( $( '#app' ) ),
                                injector = elem.injector(),
                                NMSUtils = injector.get( 'NMSUtils' );
                            $( '.n-megamenu-category' ).addClass( 'hide' );
                            $( '.n-megamenu-tab' ).removeClass( 'n-megamenu-tab-opened' );
                            tab.addClass( 'n-megamenu-tab-opened' );
                            megamenu.toggleClass( 'hide' );
                            megamenu.css( 'z-index', NMSUtils.getPopoverIndex( false ) );
                        }
                    },
                    openSubMenu = function ( container, text ) {
                        var $openedSubMenu = $( container )
                            .find( ".tree-parent > div > span.k-in > a:not(:contains('" + text + "'))" )
                            .closest( 'li:has(ul)' )
                            .addClass( 'open-submenu' );
                        $openedSubMenu.each( function () {
                            var $openedSubMenuParent = $( this ).parent( 'ul' ).addClass( 'open-submenu-parent' );
                            if ( $openedSubMenuParent.siblings( 'div' ).find( 'span[role=presentation]' ).length > 0 ) {
                                $( this ).addClass( 'open-submenu-child' );
                            }
                        } );
                        $openedSubMenu.find( 'ul' ).css( 'display', 'block' );
                        $openedSubMenu.off( 'click' ).find( '.k-icon' ).remove();
                    },
                    createMegaMenu = function ( tab ) {
                        var category = tab,
                            categoryGroupsContainer = $( '.n-megamenu-category[data-name="' + tab.find( 'a[data-name]' ).data( 'name' ) + '"]' ).find( 'ul' ).first(),
                            groups = categoryGroupsContainer.children( 'li' ),
                            rows = [],
                            groupRow,
                            groupRows = [],
                            $megamenu = $( '.n-megamenu-category[data-name="' + tab.find( 'a[data-name]' ).data( 'name' ) + '"]' ).first();
                        tab.on( 'click', function () {
                            switchTab( category, $megamenu );
                        } );
                        categoryGroupsContainer.on( 'click', 'a[href], a[content]', function ( e ) {
                            var location = angular.element( categoryGroupsContainer ).injector().get( '$location' ),
                                rootScope = angular.element( categoryGroupsContainer ).injector().get( '$rootScope' );

                            if ( rootScope !== undefined && location !== undefined ) {
                                rootScope.$broadcast( 'megaMenuItemClicked', location.path(), $( e.target ).attr( 'href' ) );
                            }
                            hideMegamenu( $megamenu );
                            $( '.n-configurator-popover' ).addClass( 'hide' );
                        } );
                        addHoverDelayToMegaMenu( $megamenu );
                        categoryGroupsContainer.addClass( 'n-megamenu-groups-container' );
                        while ( groups.length ) {
                            groupRow = groups.splice( 0, options.groupColumns );
                            rows.push( groupRow );
                        }
                        categoryGroupsContainer.children( 'li' ).remove();
                        $.each( rows, function () {
                            var $groupRow = $( '<li class=\'n-megamenu-row\'></li>' ),
                                $rowGroups = $( this ),
                                count = 0;
                            $.each( $rowGroups, function () {
                                var $group = $( this ),
                                    $groupPackage = $( '<ul class=\'n-megamenu-group\'></ul>' ),
                                    $groupHeader = $( '<li class=\'n-megamenu-group-title\'></li>' ),
                                    groupContent,
                                    contentContainer,
                                    actualGroupHeader = $group.children( 'span' ).children( 'a' );
                                if ( count === 0 ) {
                                    $groupPackage.addClass( 'firstGroup' ).css( {
                                        'border-left': 'none',
                                        'padding-left': '0px'
                                    } );
                                } else if ( count === $rowGroups.length - 1 ) {
                                    $groupPackage.addClass( 'lastGroup' );
                                }
                                if ( $group.find( 'a[data-name]' ).length !== 0 ) {
                                    contentContainer = $( '.n-megamenu-category[data-name="' + $group.find( 'a[data-name]' ).data( 'name' ) + '"]' ).first().children( 'ul' );
                                    groupContent = getGroupContents( contentContainer );
                                    contentContainer.remove();
                                }
                                $groupHeader.append( actualGroupHeader );
                                $groupPackage.append( $groupHeader );
                                if ( groupContent !== undefined ) {
                                    $.each( groupContent, function () {
                                        $groupPackage.append( this );
                                    } );
                                }
                                $groupRow.append( $groupPackage );
                                count++;
                            } );
                            groupRows.push( $groupRow );
                        } );
                        $.each( groupRows, function () {
                            var $row = $( this );
                            categoryGroupsContainer.append( $row );
                        } );
                        categoryGroupsContainer.find( '.n-megamenu-category' ).remove();
                        openSubMenu( categoryGroupsContainer, 'More Options' );
                        $megamenu.append( categoryGroupsContainer );
                    };
                options = $.extend( defaults, options );
                return this.each( function () {
                    container = $( this )
                        .css( {
                            width: options.width
                        } );
                    if ( ( options.reactive !== undefined ) && ( options.reactive === true ) ) {
                        $( window ).resize( function () {
                            $( '.n-megamenu-category' ).css( {
                                width: $( '.n-megamenu' )[ 0 ].offsetWidth - 20
                            } );
                        } );
                    }
                    tabs = $( container ).children( 'li' )
                        .each( function () {
                            tab = $( this );
                            if ( tab.find( '>span>a[href]' ).length === 0 ) {
                                // assign this class only if the tab isn't already a link
                                tab.addClass( 'n-megamenu-tab' );
                            } else {
                                tab.addClass( 'n-megamenu-tab-link' );
                            }

                            if ( $( '.n-megamenu-category[data-name="' + tab.find( 'a[data-name]' ).data( 'name' ) + '"]' ).length !== 0 ) {
                                createMegaMenu( tab );
                            } else {
                                tab.on( 'click', function () {
                                    $( '.n-megamenu-category' ).addClass( 'hide' );
                                    $( '.n-megamenu li' ).removeClass( 'n-megamenu-tab-opened' );
                                } );
                            }
                            $( '.n-megamenu-category' ).css( {
                                width: $( '.n-megamenu' )[ 0 ].offsetWidth - 20
                            } );
                        } );

                    $( document ).click( function ( event ) {
                        if ( $( '#megamenuToggler' ).is( ':visible' ) && $( '#megamenuHolder' ).is( ':visible' ) ) {
                            if ( $( '#megamenuToggler' ).css( 'visibility' ) === 'visible' && !$( event.target ).parents( '#megamenuHolder' ).length ) {
                                $( '#megamenuOverlay' ).addClass( 'visible' );
                            }
                        } else {
                            $( '#megamenuOverlay' ).removeClass( 'visible' );
                        }
                        if ( !$( event.target ).closest( '#megamenuHolder' ).length && $( event.target ).attr( 'id' ) !== "megamenuToggler" ) {
                            if ( $( '#megamenuToggler' ).css( 'visibility' ) === 'visible' ) {
                                $( '#megamenuHolder' ).removeClass( 'visible' );
                                $( '#megamenuOverlay' ).removeClass( 'visible' );
                            }
                        }
                    } );
                    $( '#megamenuToggler' ).click( function () {
                        $( '#megamenuHolder' ).toggleClass( 'visible' );
                        if ( $( '#megamenuHolder' ).is( ':visible' ) ) {
                            $( '#megamenuOverlay' ).addClass( 'visible' );
                        } else {
                            $( '#megamenuOverlay' ).removeClass( 'visible' );
                        }
                    } );

                    var $elementContent = $( '<div><a href="/logout">Log Out</a></div>' );
                    $( '.n-megamenu-actions-tab.n-megamenu-tab' ).nmswebPopover( {
                        'placement': 'bottom',
                        'manual': true,
                        'toggle': true,
                        'nested': false,
                        'exclusive': true,
                        'persistent': true,
                        'cssclass': 'menu-controls-popover',
                        'content': $elementContent
                    } )
                        .on( 'click', function () {
                            $( '.n-popoverbody.menu-controls-popover' ).css( {
                                'left': $( this ).getPosition().left - 200
                            } );
                        } );
                    $( '#js-eraser' ).prepend( $( '.n-popoverbody.menu-controls-popover' ) );
                    $( '.n-popoverbody.menu-controls-popover .close, .n-popoverbody.menu-controls-popover h3' ).remove();
                } );
            }
        } );
    }( $ ) );
} );