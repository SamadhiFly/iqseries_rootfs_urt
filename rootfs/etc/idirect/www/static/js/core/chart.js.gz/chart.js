define( [ "kendo",
 'external/notifier/notifier',
 'core/nmsweb',
 'external/highcharts/highstock',
 'core/data',
 'module/core/factory/nmsweb-element-notification',
 'module/core/factory/data-transport-mechanism' ],
    function () {
        'use strict';
        var Chart = window.kendo.Observable.extend( {
            init: function ( selector, options ) {
                var yAxisFormatter = function () { // yAxisFormatter option makes Chart Y-Axis work with small numbers e.g. 0.00000015
                    if ( isNaN( this.value ) || this.value === 0 || this.value === ' ' ) { // (' ' == 0) === true; isNaN(' ') === false
                        return this.value;
                    }
                    var order = Math.round( ( Math.log( Math.abs( this.value ) ) / Math.LN10 ) );
                    return ( order < 0 ) ? ( this.value.toFixed( 1 - order ) ) : this.value;
                };
                options = window.nmsweb.extendOptions( {
                    legend: {
                        useHTML: true
                    },
                    yAxis: {
                        labels: {
                            formatter: yAxisFormatter
                        }
                    }
                }, options );
                var that = this,
                    dataSource,
                    Ref,
                    series,
                    i,
                    j,
                    fields,
                    len,
                    fieldsLength,
                    dataSourcesArray = [],
                    updateDataSource = function () {
                        that.update( this );
                    };
                window.kendo.Observable.fn.init.call( that );

                var elem = angular.element( $( '#app' ) );
                that.injector = elem.injector();
                if ( that.injector.has( 'NmswebElementNotification' ) ) {
                    var NmswebElementNotification = that.injector.get( 'NmswebElementNotification' );
                    if ( NmswebElementNotification ) {
                        this.notificationService = new NmswebElementNotification( {
                            element: selector,
                            type: 'chart',
                            component: that,
                            isApplyNeeded: true
                        } );
                    }
                }

                that.dataSource = options.dataSource;
                that.options = options;
                that.hasData = false;
                that.isRecoverable = true;

                series = that.options.series || [];
                if ( series.length < 1 ) {
                    selector.addClass( 'noSeries' );
                }
                if ( options.lib === 'stock' ) {
                    Ref = window.Highcharts.StockChart;
                } else {
                    Ref = window.Highcharts.Chart;
                }
                that.chart = new Ref( options );
                for ( len = series.length, i = 0; i < len; i++ ) {
                    fields = series[ i ].fields;
                    series[ i ].dataSources = series[ i ].dataSources || [];
                    that.hasData = series[ i ].data.length > 1 ? true : false;

                    if ( fields ) {
                        for ( fieldsLength = fields.length, j = 0; j < fieldsLength; j++ ) {
                            dataSource = fields[ j ].dataSource || that.dataSource;
                            fields[ j ].dataSource = dataSource;
                            if ( dataSourcesArray.indexOf( dataSource.id ) === -1 ) {
                                dataSourcesArray.push( dataSource.id );
                            }
                            if ( series[ i ].dataSources.indexOf( dataSource.id ) === -1 ) {
                                series[ i ].dataSources.push( dataSource.id );
                                if ( options.events !== undefined ) {
                                    dataSource.bind( options.events, updateDataSource );
                                } else {
                                    dataSource.bind( 'change', updateDataSource );
                                }
                            }
                            if ( dataSource ) {
                                that._initDataSourceBinds( selector, dataSource );
                            }
                        }
                    }
                }
                for ( len = dataSourcesArray.length, i = 0; i < len; i++ ) {
                    window.nmsweb.DataSources[ dataSourcesArray[ i ] ].read();
                }

                if ( !that.mechanism ) {
                    if ( that.injector.has( 'DataTransportMechanism' ) ) {
                        var dataTransportMechanism = that.injector.get( 'DataTransportMechanism' );
                        that.mechanism = dataTransportMechanism.mechanism( that );
                        dataTransportMechanism.bindNotifications( that.notificationService, that.dataSource, that.mechanism );
                    }
                }

                // that._initListeners( selector );
                return that;
            },
            _initListeners: function ( $el ) {
                var that = this;
                //Listen for event and show Notification
                // $el.on( 'nmsweb:notify', function ( e, data ) {
                //     e.preventDefault();
                //     e.stopPropagation();
                //     var options = $.extend( {}, data, {
                //         'selector': $( this ),
                //         'type': typeof data.type !== 'undefined' ? data.type : 'success',
                //         'title': typeof data.title !== 'undefined' ? data.title : 'Good News',
                //         'message': typeof data.message !== 'undefined' ? data.message : 'Data Loaded all is well',
                //         'isFadeable': typeof data.isFadeable !== 'undefined' ? data.isFadeable : true
                //     } );
                //     if ( data.type === 'progress' ) {
                //         var message = typeof data.message !== 'undefined' ? data.message : 'Progress message goes here';
                //         that.chart.showLoading( message );
                //         if ( that.chart.loadingShown && that.hasData ) {
                //             that.chart.hideLoading();
                //         }
                //         $el.find( '.highcharts-legend, .highcharts-axis').css('visibility', 'hidden');
                //         $el.find( '.highcharts-legend, .highcharts-axis').find('rect').css('visibility', 'hidden');
                //     } else {
                //         //window.Notifier.getNotification(options);
                //         $el.nmswebNotification( options );
                //     }
                // } );
                // $( 'body' ).on( 'nmsweb:jmrBack', function ( e ) {
                //     if ( ( !that.hasData ) && ( that.isRecoverable ) && ( e.errors ) ) {
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'Waiting for data with errors...',
                //             isFadeable: false
                //         } );
                //     } else if ( ( !that.hasData ) && ( that.isRecoverable ) ) {
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'Waiting for data...',
                //             isFadeable: false
                //         } );
                //     } else if ( !that.isRecoverable ) {
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'No data currently available',
                //             isFadeable: false
                //         } );
                //     } else {
                //         that.chart.hideLoading();
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'info',
                //             title: 'Status',
                //             message: 'Reconnected',
                //             isFadeable: true
                //         } );
                //     }
                // } );
                // $( 'body' ).on( 'nmsweb:jmrDown', function () {
                //     if ( ( !that.hasData ) && ( that.isRecoverable ) ) {
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'Lost connection. Reconnecting...',
                //             isFadeable: false,
                //             spin: true
                //         } );
                //     } else if ( !that.isRecoverable ) {
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'No data currently available',
                //             isFadeable: false
                //         } );
                //     }
                // } );
            },
            _initDataSourceBinds: function ( $el, ds ) {
                var that = this;

                var dataTransportMechanism = that.injector.get( 'DataTransportMechanism' );
                that.mechanism = dataTransportMechanism.mechanism( that );
                dataTransportMechanism.bindNotifications( that.notificationService, ds, that.mechanism );

                // $el.bind( 'ready', '.highcharts-container', function () {
                //     $( this ).trigger( 'nmsweb:notify', {
                //         type: 'progress',
                //         title: 'Status',
                //         message: 'Waiting for data...',
                //         isFadeable: false
                //     } );
                // } );
                // ds.bind( 'asyncDone', function () {
                //     $el.trigger( 'nmsweb:notify', {
                //         type: 'progress',
                //         title: 'Status',
                //         message: 'No data currently available',
                //         isFadeable: false,
                //         isPersistent: true
                //     } );
                // } );
                // ds.bind( 'error', function ( e ) {
                //     if ( ( e.xhr ) && ( e.xhr.status >= 500 ) ) {
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'No data currently available',
                //             isFadeable: false
                //         } );
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'error',
                //             title: 'Error ' + e.xhr.status,
                //             message: e.errorThrown,
                //             isFadeable: true
                //         } );
                //     } else if ( ( e.xhr ) && ( e.xhr.status >= 200 ) && ( e.sender._data.length < 1 ) ) {
                //         $el.trigger( 'nmsweb:notify', {
                //             type: 'progress',
                //             title: 'Status',
                //             message: 'No data currently available',
                //             isFadeable: false
                //         } );
                //         that.isRecoverable = false;
                //     } else if ( e.errors ) {
                //         $.each( e.errors, function ( idx, errObj ) {
                //             var message = typeof errObj.message !== 'object' ? errObj.message : errObj.message.message;
                //             $el.trigger( 'nmsweb:notify', {
                //                 type: that._getNotificationType( errObj.severity ),
                //                 title: 'Code ' + errObj.code,
                //                 message: message
                //             } );
                //             if ( e.sender._data.length > 0 ) {
                //                 $el.find( '.n-progress-notifications-container .n-progress-notification' ).trigger( 'click' );
                //             }
                //         } );
                //     }
                // } );
                // ds.bind( 'streamed', function () {
                //     $el.find( '.n-progress-notifications-container .n-progress-notification' ).remove();
                // } );
                // ds.bind( 'change', function ( e ) {
                //     if ( ( e.sender._data.length > 0 ) ) {
                //         that.hasData = true;
                //         that.chart.hideLoading();
                //         $el.find( '.highcharts-legend, .highcharts-axis').css('visibility', 'visible');
                //         $el.find( '.highcharts-legend, .highcharts-axis').find('rect').css('visibility', 'visible');
                //         $el.find( '.highcharts-legend, .highcharts-axis' ).show();
                //         $el.find( '.n-progress-notifications-container .n-progress-notification' ).remove();
                //     }
                // } );
            },
            _getNotificationType: function ( severity ) {
                switch ( severity ) {
                case 1:
                    return 'info';
                case 2:
                    return 'success';
                case 3:
                    return 'progress';
                case 4:
                    return 'warning';
                case 5:
                    return 'majorwarning';
                case 6:
                    return 'error';
                default:
                    return 'info';
                }
            },
            update: function ( dataSource ) {
                var that = this,
                    options = that.options,
                    series = options.series,
                    seriesLength,
                    fieldsLength,
                    fields,
                    serieField,
                    dataMinLength = 0,
                    tempDataLength,
                    tempDataSource,
                    tempData,
                    i,
                    j,
                    k,
                    storage = [],
                    item = [],
                    fieldDataSource,
                    preventDefault,
                    isDefaultPrevented,
                    evnt;
                if ( !series ) {
                    return false;
                } else {
                    seriesLength = series.length;
                }
                preventDefault = function () {
                    this._defaultPrevented = true;
                };
                isDefaultPrevented = function () {
                    this._defaultPrevented = this._defaultPrevented || false;
                    return this._defaultPrevented;
                };
                for ( i = 0; i < seriesLength; i++ ) {
                    if ( series[ i ].dataSources.indexOf( dataSource.id ) !== -1 ) {
                        evnt = {
                            preventDefault: preventDefault,
                            isDefaultPrevented: isDefaultPrevented
                        };
                        if ( typeof series[ i ].callback === 'function' ) {
                            evnt.options = series[ i ];
                            series[ i ].callback.call( that, evnt );
                        }
                        if ( !evnt.isDefaultPrevented() ) {
                            fields = series[ i ].fields;
                            fieldsLength = fields.length;
                            dataMinLength = undefined;
                            tempDataLength = 0;
                            for ( j = 0; j < fieldsLength; j++ ) {
                                fieldDataSource = fields[ j ].dataSource || {};
                                if ( fieldDataSource.id === dataSource.id ) {
                                    tempDataLength = fieldDataSource.view().length;
                                    if ( dataMinLength === undefined || dataMinLength > tempDataLength ) {
                                        dataMinLength = tempDataLength;
                                    }
                                }
                            }
                            storage = [];
                            for ( k = 0; k < dataMinLength; k++ ) {
                                item = [];
                                for ( j = 0; j < fieldsLength; j++ ) {
                                    tempDataSource = fields[ j ].dataSource;
                                    if ( tempDataSource ) {
                                        tempData = tempDataSource.view();
                                        tempDataLength = tempData.length;
                                        serieField = fields[ j ].field;
                                        if ( tempDataLength > 0 && tempDataLength > k ) {
                                            item.push( tempData[ k ][ serieField ] );
                                        }
                                    }
                                }
                                if ( item.length === 1 ) {
                                    storage.push( item[ 0 ] );
                                } else if ( item.length > 1 ) {
                                    storage.push( item );
                                }
                            }
                            that.chart.series[ i ].setData( storage, false );
                        }
                    }
                }
                that.chart.redraw();
            }
        } );
        window.nmsweb.registerComponent( 'Chart', Chart );
        return Chart;
    } );