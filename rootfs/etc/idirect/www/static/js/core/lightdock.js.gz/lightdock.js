define( [ 'jquery' ], function ( $ ) {
    'use strict';
    ( function ( $ ) {
        $.fn.extend( {
            lightdock: function ( options ) {
                var defaults = {
                        lights: [ {
                            name: 'Status One',
                            color: 'green'
                        } ],
                        width: '400px'
                    },
                    lightWidth,
                    createLight = function ( light ) {
                        var lightHtmlString = '<div class=\'n-lightholder\'>' +
                            '<label>' + light.name + '</label>' +
                            '<div id=\'n-light-' + light.name + '\' class=\'n-light n-light-' + light.name + '\' style=\'margin-left: ' + ( ( lightWidth / 2 ) - 10 ) + 'px;\'></div>' +
                            '</div>',
                            $light = $( lightHtmlString ).css( {
                                'width': lightWidth
                            } );
                        if ( light.data !== undefined ) {
                            $light.find( '.n-light' ).attr( 'data-bind', light.data );
                        } else {
                            if ( light.color !== undefined ) {
                                $light.find( '.n-light' ).addClass( light.color );
                            }
                        }
                        return $light;
                    },
                    createLightDock = function ( $lightdock, options ) {
                        $lightdock.empty();
                        $lightdock.addClass( 'n-lightdock' )
                            .css( {
                                'width': options.width
                            } );
                        lightWidth = ( parseInt( options.width, 10 ) / options.lights.length ) - 10;
                        $.each( options.lights, function () {
                            $lightdock.append( createLight( this ) );
                        } );
                    };
                options = $.extend( defaults, options );
                return this.each( function () {
                    var $lightdock = $( this );
                    createLightDock( $lightdock, options );
                } );
            }
        } );
    }( $ ) );
} );