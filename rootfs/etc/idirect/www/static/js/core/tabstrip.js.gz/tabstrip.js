define( [ 'kendo', 'core/nmsweb' ], function () {
    "use strict";
    var TabStrip = window.kendo.ui.TabStrip.extend( {
        init: function ( element, options ) {
            var that = this,
                defaults = {
                    animation: false
                };
            if ( options ) {
                nmsweb.extendOptions( defaults, options );
            }
            window.kendo.ui.TabStrip.fn.init.call( that, element, defaults );
        },
        // Fix for tabstrip to use our representation
        ajaxRequest: function ( element, content, complete, url ) {
            var that = this,
                json,
                mock = {};
            mock.html = function ( data ) {
                json = JSON.parse( data );
                if ( json.contents !== undefined ) {
                    $( content ).html( json.contents );
                } else {
                    $( content ).html( data );
                }
            };
            return window.kendo.ui.TabStrip.fn.ajaxRequest.call( that, element, mock, complete, url );
        }
    } );
    window.nmsweb.registerComponent( 'TabStrip', TabStrip );
    return TabStrip;
} );