define( [ 'jquery', 'core/nmsweb', 'core/popover' ], function ( $ ) {
    'use strict';
    ( function ( $ ) {
        $.fn.extend( {
            validate_input: function ( options, id, additionalFields ) {
                var $that = this,
                    val = $that.val(),
                    name = $that.attr( 'name' ),
                    url = '/core/validate/index?',
                    module = options.module,
                    lib = options.lib,
                    element_id = id.substring( 1 ),
                    form_id = options.form_id,
                    additionalValues = [],
                    i,
                    additionalFieldsLength;
                $( form_id ).find( 'input' ).each( function () {
                    for ( i = 0, additionalFieldsLength = additionalFields.length; i < additionalFieldsLength; i++ ) {
                        if ( additionalFields[ i ] === $( this ).attr( "name" ) ) {
                            additionalValues.push( {
                                name: $( this ).attr( "name" ),
                                value: $( this ).attr( "value" )
                            } );
                        }
                    }
                } );
                $.get( url, {
                        name: name,
                        value: val,
                        module: module,
                        lib: lib,
                        id: element_id,
                        field_values: JSON.stringify( additionalValues )
                    },
                    function ( data ) {
                        $( '#' + element_id + '_popover' ).remove();
                        if ( !$( '#' + element_id ).is( ':visible' ) ) {
                            return false;
                        }
                        var errors,
                            errorString,
                            i,
                            $appendTo,
                            contents = JSON.parse( data.contents );
                        if ( contents.error === true ) {
                            return;
                        }
                        if ( !contents.payload.valid ) {
                            errors = contents.payload.errors;
                            errorString = '';
                            for ( i = 0; i < errors.length; i += 1 ) {
                                errorString += errors[ i ] + '<br />';
                            }
                            $appendTo = $( '#' + element_id + '_container' ).children().last().prev();
                            $appendTo.nmswebPopover( {
                                'id': element_id + '_popover',
                                'listen': {
                                    'container': $that.parents().find( ".n-tabstrip" )
                                },
                                'persistent': false,
                                'formtooltip': true,
                                'cssclass': 'form-error',
                                'content': '<div>' + errorString + '</div>'
                            } );
                        }
                    }
                );
            }
        } );
    }( $ ) );
} );