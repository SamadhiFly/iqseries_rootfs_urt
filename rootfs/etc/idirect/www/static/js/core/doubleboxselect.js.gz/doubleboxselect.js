define( [ 'jquery', 'kendo', 'core/nmsweb' ], function ( $ ) {
    "use strict";
    var doubleboxselect = window.kendo.Observable.extend( {
        init: function ( selector, options ) {
            //You can add onCreate and onDrop callbacks
            var that = this,
                defaults = {
                    submitBtnTxt: "submit",
                    resetBtnTxt: "reset",
                    optionsBoxClass: "n-double-box-select-list"
                };
            that.options = $.extend( true, {}, defaults, options );
            that.element = $( selector );
            that.domId = $( selector ).attr( "id" );
            that.availableView = $( "#" + that.domId + "_available-list" ).addClass( that.options.optionsBoxClass );
            that.selectedView = $( "#" + that.domId + "_selected-list" ).addClass( that.options.optionsBoxClass );
            that.btn = that.element.find( '.btn' );
            that.btn.filter( "[type='submit']" ).text( that.options.submitBtnTxt );
            that.btn.filter( "[type='reset']" ).text( that.options.resetBtnTxt );
            that._initListViews();
            that._initEvents();
            //Allow callback function
            $.each( that.options, function ( key, val ) {
                if ( typeof val === "function" ) {
                    that.element.on( key + ".doubleboxselect", function ( e, param ) {
                        return val( e, that.element, param );
                    } );
                }
            } );
            that.element.trigger( "onCreate.doubleboxselect" );
            return that;
        },
        _initListViews: function () {
            var that = this,
                kendo = window.kendo,
                listOpts = {
                    dataSource: new kendo.data.DataSource( {
                        data: that._getData( 0, that.options.data )
                    } ),
                    template: kendo.template( $( "#" + that.domId + "_template" ).html() )
                };
            that.availableView.kendoListView( listOpts );
            //Update data source for selected list
            listOpts.dataSource = new kendo.data.DataSource( {
                data: that._getData( 1, that.options.data )
            } );
            that.selectedView.kendoListView( listOpts );
        },
        _initEvents: function () {
            this._initBtns();
            this._initDrag();
            this._initDblClick();
            this._initDrop();
            this._initSelect();
        },
        _initDrag: function () {
            var that = this,
                doc = $( document );
            var dragOpts = {
                filter: ".n-doubleboxselect-item",
                hint: function ( row ) {
                    if ( $( '.n-doubleboxselect-item.selected' ).length > 1 ) {
                        var tmpUl = $( '<ul />' );
                        $( '.n-doubleboxselect-item.selected' ).each( function () {
                            var tmpLi = $( this ).clone().addClass( 'clone' ).width( row.width() );
                            tmpUl.append( tmpLi );
                        } );
                        return tmpUl;
                    }
                    return row.clone().addClass( 'clone' ).width( row.width() ); //returns the same mark up as the template
                }
            };
            doc.on( 'mousemove', function ( e ) {
                that.cursorX = e.pageX;
                that.cursorY = e.pageY;
            } );
            this.availableView.kendoDraggable( dragOpts );
            this.selectedView.kendoDraggable( dragOpts );
        },
        _initDrop: function () {
            var that = this,
                target1 = that.availableView,
                target2 = that.selectedView;
            that.element.kendoDropTargetArea( {
                filter: "#" + that.domId + "_available-list, #" + that.domId + "_selected-list",
                drop: function ( e ) {
                    var target = e.draggable.currentTarget,
                        uid = target.data().uid,
                        parent = $( ".n-doubleboxselect-item[data-uid='" + uid + "']" ).closest( '.' + that.options.optionsBoxClass ),
                        isDroppable = ( e.dropTarget[ 0 ] !== parent[ 0 ] );
                    that._addSelectedUids( target, uid );
                    //Target Selected box
                    if ( ( e.dropTarget[ 0 ] === target2[ 0 ] ) && isDroppable ) {
                        that._dropHandler( target2, target1, uid, true );
                    } else if ( isDroppable ) {
                        that._dropHandler( target1, target2, uid, true );
                    }
                }
            } );
        },
        _addSelectedUids: function ( target, tUid ) {
            var that = this;
            this.siblingsArr = [];
            if ( target.siblings( '.selected' ).length > 0 ) {
                this.siblingsArr.push( {
                    'uid': tUid
                } );
                target.siblings( '.selected' ).each( function () {
                    that.siblingsArr.push( {
                        'uid': $( this ).data().uid
                    } );
                    console.log( 'uids ' + target.siblings( '.selected' ).data().uid + '\n' );
                } );
            }
        },
        _addSelectedSiblings: function ( container ) {
            if ( this.siblingsArr.length > 0 ) {
                for ( var i = 0, len = this.siblingsArr.length; i < len; i++ ) {
                    this.siblingsArr[ i ].el = container.data( "kendoListView" ).dataSource.getByUid( this.siblingsArr[ i ].uid );
                }
            }
        },
        _initDblClick: function () {
            var that = this;
            $( ".n-doubleboxselect-item" ).on( 'dblclick', function () {
                var parent = $( this ).closest( '.' + that.options.optionsBoxClass ),
                    target1 = that.availableView,
                    target2 = that.selectedView,
                    isSelecting = ( target2[ 0 ] !== parent[ 0 ] ),
                    uid = $( this ).data().uid;
                //Target Selected box
                if ( isSelecting ) {
                    that._dropHandler( target2, target1, uid, false );
                } else {
                    that._dropHandler( target1, target2, uid, false );
                }
            } );
        },
        _initSelect: function () {
            var $lastSelected = [],
                collection = $( '.n-doubleboxselect-item' );
            collection.on( 'click', function ( e ) {
                var that = $( this ),
                    $selected,
                    direction;
                if ( e.shiftKey ) {
                    if ( $lastSelected.length > 0 ) {
                        if ( that[ 0 ] === $lastSelected[ 0 ] ) {
                            // The user has clicked on the same item, so do nothing.
                            return false;
                        }
                        direction = that.nextAll( '.lastSelected' ).length > 0 ? 'forward' : 'back';
                        if ( 'forward' === direction ) {
                            // Last selected is after the current selection
                            $selected = that.nextUntil( $lastSelected, '.n-doubleboxselect-item' );
                        } else {
                            // Last selected is before the current selection
                            $selected = $lastSelected.nextUntil( that, '.n-doubleboxselect-item' );
                        }
                        //Add and remove classes as necessary
                        collection.removeClass( 'selected' );
                        $selected.addClass( 'selected' );
                        $lastSelected.addClass( 'selected' );
                        that.addClass( 'selected' );
                    } else {
                        $lastSelected = that;
                        // Mark previously selected item
                        that.addClass( 'lastSelected' );
                        collection.removeClass( 'selected' );
                        that.addClass( 'selected' );
                    }
                } else if ( e.ctrlKey ) {
                    // Not a shift select
                    $lastSelected = that;
                    collection.removeClass( 'lastSelected' );
                    that.addClass( 'lastSelected selected' );
                } else {
                    // Not a shift select
                    $lastSelected = that;
                    collection.removeClass( 'lastSelected selected' );
                    that.addClass( 'lastSelected selected' );
                }
            } );
        },
        _dropHandler: function ( to, from, uid, isInsert ) {
            isInsert = isInsert || false;
            var dataElement = from.data( "kendoListView" ).dataSource.getByUid( uid );
            dataElement.selected = ( dataElement.selected ) ? 0 : 1;
            this._addSelectedSiblings( from );
            //Add to and remove from datatsources
            if ( !isInsert ) {
                to.data( "kendoListView" ).dataSource.add( dataElement );
            } else {
                this._insertElememt( to, dataElement );
            }
            this._removeSelectedSiblings( from, dataElement );
            this.siblingsArr = [];
            this._initDblClick();
            this._initSelect();
            this.element.trigger( "onDrop.doubleboxselect" );
        },
        _insertElememt: function ( container, el ) {
            var that = this,
                mX, mY,
                elOffset,
                insertPos;
            elOffset = $( container ).offset();
            mX = that.cursorX - elOffset.left;
            mY = that.cursorY - elOffset.top;
            insertPos = that._getInsertPosition( container, mX, mY );
            this._insertSelectedSiblings( container, el, insertPos );
        },
        _insertSelectedSiblings: function ( container, el, pos ) {
            if ( this.siblingsArr.length > 0 ) {
                this.siblingsArr.reverse();
                for ( var i = 0, len = this.siblingsArr.length; i < len; i++ ) {
                    container.data( "kendoListView" ).dataSource.insert( pos, this.siblingsArr[ i ].el );
                }
            } else {
                container.data( "kendoListView" ).dataSource.insert( pos, el );
            }
        },
        _removeSelectedSiblings: function ( container, el ) {
            if ( this.siblingsArr.length > 0 ) {
                for ( var i = 0, len = this.siblingsArr.length; i < len; i++ ) {
                    container.data( "kendoListView" ).dataSource.remove( this.siblingsArr[ i ].el );
                }
            } else {
                container.data( "kendoListView" ).dataSource.remove( el );
            }
        },
        _getInsertPosition: function ( container, x, y ) {
            var ret = 0,
                items = container.find( '.n-doubleboxselect-item' );
            if ( items.length ) {
                items.each( function ( idx ) {
                    var item = $( this ),
                        pos = item.position(),
                        iX = pos.left,
                        iY = pos.top,
                        iW = iX + item.width(),
                        iH = iY + item.height(),
                        iCenter = iY + ( item.height() / 2 );
                    if ( ( x > iX ) && ( x < iW ) && ( y > iY ) && ( y < iH ) ) {
                        ret = idx;
                        if ( ( y < iCenter ) && ( idx !== 0 ) ) {
                            ret = idx - 1;
                        } else if ( ( y < iCenter ) && ( idx === 0 ) ) {
                            ret = idx;
                        } else if ( y > iCenter ) {
                            ret = idx + 1;
                        }
                    }
                } );
            }
            return ret;
        },
        _getData: function ( isSelected, data ) {
            return $.map( data, function ( val ) {
                if ( val.selected === isSelected ) {
                    return val;
                }
            } );
        },
        _initBtns: function () {
            var that = this;
            // this.element.on('submit', function(e) {
            // 	e.preventDefault();
            // 	return that.element.val();
            // });
            this.element.on( 'click', '.btn', function () {
                if ( $( this ).attr( "type" ) === "submit" ) {
                    that.element.val();
                }
                if ( $( this ).attr( "type" ) === "reset" ) {
                    that._initListViews();
                }
            } );
        }
    } );
    window.nmsweb.registerComponent( 'Doubleboxselect', doubleboxselect );
    return doubleboxselect;
} );