define( [ 'jquery', 'core/data', 'core/nmsweb', 'core/popover' ], function ( $ ) {
    "use strict";
    var kendo = window.kendo,
        inlineelementselector = kendo.Observable.extend( {
            init: function ( selector, options ) {
                var that = this,
                    $selector = $( selector ).css( 'cursor', 'pointer' ),
                    $elementSelectorContainer = $selector.parent().find( '#element-selector' ),
                    $scripts = $elementSelectorContainer.find( 'script' ),
                    setUpInlineElementSelector;
                that.element = $selector;
                that.$doneBtn = $( '<button class=\'n-cnf-btn blue n-configurator-apply-change-button\'>Done</button>' );
                that.$elementSelector = $elementSelectorContainer.find( "div[name='Inline_Element_Selector']" ).css( {
                    'float': 'none'
                } )[ 0 ];
                setUpInlineElementSelector = function () {
                    that.elementSelector = $( that.$elementSelector ).find( '.n-elementselectorgrid:not(.n-elementselectorgrid-composite)' ).data( 'nmswebElementSelectorGrid' );
                    that.$doneBtn.wrap( $( '<div class=\'n-configurator-apply-change-button-holder\'></div>' ) );
                    that.$content = $( '<div class=\'n-configurator-section-form\'/>' ).html( that.$elementSelector ).append( that.$doneBtn );
                    that.elementSelector.selectable.options.multiple = !options.opts.singleSelect;
                    that.options = {};
                    window.nmsweb.extendOptions( that.options, options );
                    kendo.Observable.fn.init.apply( that, that.options );
                    $scripts.remove();
                    that.bindEvents();
                    return that;
                };
                if ( $( that.$elementSelector ).find( '.n-elementselectorgrid:not(.n-elementselectorgrid-composite)' ).length > 0 ) {
                    setUpInlineElementSelector();
                } else {
                    $( 'body' ).on( 'nmsweb:elementSelectorAvailable', function () {
                        setUpInlineElementSelector();
                    } );
                }
            },
            bindEvents: function () {
                var that = this;
                that.element.on( 'focus', that.showElemenentSelector.bind( this ) );
                that.$doneBtn.on( 'click', that.setElemetName.bind( this ) );
            },
            setElemetName: function () {
                var that = this,
                    dataSource = that.elementSelector.dataSource,
                    id = dataSource.getSelectedIds(),
                    model = dataSource.get( Number( id ) );
                if ( model ) {
                    that.element.val( model.obj_name )
                        .prop( 'readonly', 'readonly' )
                        .data( 'ObjectId', model.obj_id );
                }
                $( 'body' ).trigger( 'nmsweb:inlineselectclose', {
                    'type': 'close'
                } );
            },
            showElemenentSelector: function ( e ) {
                var that = this,
                    $target = $( e.target || e.srcElement ),
                    $container = $target.parents( 'form' ),
                    opts = {
                        listen: {
                            event: 'nmsweb:inlineselectclose',
                            container: $container
                        },
                        id: 'inline-elementselector',
                        exclusive: false,
                        nested: true,
                        closeBtn: false,
                        toggle: true,
                        manual: true,
                        placement: 'bottom',
                        content: that.$content
                    };
                $target.nmswebPopover( opts );
            }
        } );
    window.nmsweb.registerComponent( 'InlineElementSelector', inlineelementselector );
    return inlineelementselector;
} );