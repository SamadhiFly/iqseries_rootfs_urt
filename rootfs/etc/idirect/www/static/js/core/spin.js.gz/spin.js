define( [ 'jquery', 'spin' ], function ( $, Spinner ) {
    "use strict";
    $.fn.spin = function ( opts ) {
        this.each( function () {
            var $this = $( this ),
                data = $this.data(),
                presets = {
                    'small': {
                        lines: 8,
                        length: 2,
                        width: 2,
                        radius: 3,
                    },
                    'medium': {
                        lines: 10,
                        length: 6,
                        width: 4,
                        radius: 7,
                    },
                    'large': {
                        lines: 12,
                        length: 12,
                        width: 5,
                        radius: 12,
                    }
                },
                defaults = {
                    rotate: 0, // The rotation offset
                    color: [ '#1B8CC5', '#50C06E', '#154D5F' ], // #rgb or #rrggbb
                    speed: 1.4, // Rounds per second
                    trail: 44, // Afterglow percentage
                    shadow: false, // Whether to render a shadow
                    hwaccel: true, // Whether to use hardware acceleration
                    className: 'spinner', // The CSS class to assign to the spinner
                    zIndex: 2e9 // The z-index (defaults to 2000000000)
                };
            if ( typeof ( opts ) === 'undefined' ) {
                opts = "medium";
            }
            if ( typeof ( opts ) === 'string' ) {
                opts = presets[ opts ];
            }
            if ( data.spinner ) {
                data.spinner.stop();
                delete data.spinner;
            }
            if ( opts !== false ) {
                window.Spinner = Spinner;
                data.spinner = new window.Spinner( $.extend( defaults, opts ) ).spin( this );
            }
        } );
        return this;
    };
    return $.fn.spin;
} );