define( [ "jquery", "core/nmsweb", "core/input_validation" ], function ( $ ) {
    "use strict";
    var input = function ( selector, options ) {
        var _init = function () {
            var $that = $( selector ),
                additional_fields = ( $that.attr( 'additional_fields' ) !== undefined ? $that.attr( 'additional_fields' ).split( ',' ) : [] ),
                validationFunction = function () {
                    selector.validate_input( options, "#" + selector[ 0 ].id, additional_fields );
                };
            if ( $that.hasClass( 'validate' ) ) {
                //$that.change(validationFunction);
                $that.bind( 'blur', validationFunction );
            } else if ( $that.hasClass( 'multiple_validation' ) ) {
                //$that.change(validationFunction);
                $that.bind( 'blur', validationFunction );
                console.log( "MULTIPLE!!", options );
                console.log( "MULTIPLE!!", additional_fields );
            }
        };
        return _init();
    };
    window.nmsweb.registerComponent( 'Input', input );
    return input;
} );