define( [ "jquery", "core/data", "core/nmsweb" ], function ( $ ) {
    "use strict";
    var nmsweb = window.nmsweb,
        select = window.kendo.Observable.extend( {
            init: function ( selector, options ) {
                var that = this,
                    dataSource;
                that.options = {
                    multiple: true,
                    dataTextField: "text",
                    dataValueField: "value"
                };
                window.kendo.Observable.fn.init.call( that );
                that.element = $( selector );
                if ( options.opts ) {
                    nmsweb.extendOptions( that.options, options.opts );
                } else if ( options ) {
                    nmsweb.extendOptions( that.options, options );
                }
                dataSource = that.dataSource = that.options.dataSource;
                if ( $.isArray( dataSource ) ) {
                    that.options.dataSource = new window.nmsweb.DataSource( {
                        data: dataSource
                    } );
                    dataSource = that.options.dataSource;
                }
                if ( that.options.multiple ) {
                    that.element.attr( "multiple", "multiple" );
                }
                if ( dataSource !== undefined ) {
                    dataSource.bind( "change", $.proxy( that.refresh, that ) );
                    dataSource.read();
                }
                return that;
            },
            refresh: function () {
                var that = this,
                    options = that.options,
                    valId = options.dataValueField,
                    txtId = options.dataTextField,
                    data,
                    value,
                    text,
                    selector = $( that.element );
                if ( that.dataSource !== undefined ) {
                    data = that.dataSource.data();
                    selector.empty();
                    if ( data.length !== 0 ) {
                        $.each( data, function ( index, item ) {
                            value = item[ valId ] || item[ txtId ];
                            text = item[ txtId ];
                            if ( value !== undefined ) {
                                selector.append( $( "<option/>", {
                                    value: value,
                                    text: text
                                } ) );
                            }
                        } );
                    }
                    that.trigger( 'dataBound' );
                }
            }
        } );
    window.nmsweb.registerComponent( 'Select', select );
    return select;
} );