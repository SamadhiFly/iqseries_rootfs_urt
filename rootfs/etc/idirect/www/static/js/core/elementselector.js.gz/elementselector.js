define( [ "jquery", "jqueryConfirm", "core/notification", "core/popover", "core/utils", "core/lightdock", "core/elementselectorgrid", "module/core/directive/nmsweb-presets-load", 'module/core/service/nmsutils' ], function ( $ ) {
    'use strict';
    var $elementSelector,
        element,
        ElementSelector = window.kendo.Observable.extend( {
            element: element,
            globalpopoverwidth: 0,
            init: function ( element, options ) {
                var that = this;
                that.element = element;
                $elementSelector = $( this );
                if ( element.parent( '.n-configurator-section-form' ).length > 0 ) {
                    if ( options.levelClasses !== undefined && options.levelClasses !== null ) {
                        $.each( options.levelClasses, function () {
                            element.addClass( this );
                        } );
                    }
                }
                if ( options.global !== undefined && options.global === true ) {
                    $( document ).keyup( function ( e ) {
                        if ( e.keyCode !== undefined && e.keyCode === 27 ) {
                            if ( $( '#n-element-selector-global-search-popover' ).hasClass( 'advanced-query' ) ) {
                                $( '#n-element-selector-global-search-popover' )
                                    .find( '.k-pager-wrap button' )
                                    .toggleClass( 'hide' );
                                that.closeGlobalPopover();
                            } else {
                                $( '#n-element-selector-global-search-popover, #n-element-selector-directory-popover' ).addClass( 'hide' );
                                $( '.n-popover.input-large' ).prop( "disabled", false );
                                $( '.n-overlay .overlay, .n-overlay' ).removeAttr( 'style' );
                            }
                        }
                        var elem = angular.element( $( '#app' ) ),
                            injector = elem.injector(),
                            NMSUtils = injector.get( 'NMSUtils' );

                        $( '#n-element-selector-global-search-popover' ).css( 'z-index', NMSUtils.getPopoverIndex() );
                    } );
                    that.addGlobalDirectoryPopover();
                    that.addAdvancedGlobalDirectoryPopover();
                    that.addQuicklinksMenu();
                }
                $( 'body' ).trigger( 'nmsweb:elementSelectorAvailable' );
            },
            $actionPopover: $( '#n-element-selector-directory-popover' ),
            executeItemAction: function ( $actionButton, quicklink ) {
                var that = this,
                    action = $actionButton.attr( 'action' ),
                    $nameLink,
                    oldName,
                    $newNameInput;
                switch ( action ) {
                case 'rename':
                    $nameLink = $actionButton.parents( 'tr' ).first().find( 'a.n-type-link' );
                    oldName = $nameLink.text();
                    $newNameInput = $( '<input type=\'text\' class=\'renameInput\'></input>' )
                        .on( 'keyup', function ( e ) {
                            if ( e.keyCode === 13 ) {
                                that.bindQuicklinkClick();
                                var newName = $( this ).val(),
                                    inputParent = $( this ).parent();
                                if ( newName !== '' ) {
                                    inputParent.empty().append( "Please wait.." );
                                    $.ajax( {
                                        type: 'POST',
                                        url: '/core/presets/change',
                                        data: {
                                            id: quicklink.id,
                                            name: newName
                                        },
                                        complete: function ( xhr ) {
                                            var response = $.parseJSON( xhr.responseText );
                                            if ( response.error ) {
                                                if ( response.errorCode === "duplicateName" ) {
                                                    $( "#content" ).trigger( 'nmsweb:notify', {
                                                        "target": "content",
                                                        "type": "error",
                                                        "title": "Please correct the following before continuing",
                                                        "message": "'" + newName + "' is already in use. Please enter a unique Quicklink name."
                                                    } );
                                                }
                                                inputParent.empty().append( oldName );
                                            } else {
                                                $( "#content" ).trigger( 'nmsweb:notify', {
                                                    "target": "content",
                                                    "type": "success",
                                                    "title": "Successfully renamed Quicklink",
                                                    "message": "Quicklink has been successfully renamed to '" + newName + "'."
                                                } );
                                                inputParent.empty().append( newName );
                                            }
                                        }
                                    } );
                                }
                            }
                        } );
                    $( '#n-element-selector-directory-popover .n-type-grid' ).off( 'click', '.n-type-link' );
                    $nameLink.empty().append( $newNameInput );
                    $newNameInput.focus()
                        .val( oldName )
                        .select();
                    break;
                case 'delete':
                    $.confirm( {
                        title: "Remove Quicklink?",
                        content: "Are you sure you want to delete '" + quicklink.name + "'?",
                        confirmButton: 'Yes',
                        cancelButton: 'No',
                        confirm: function () {
                            $.ajax( {
                                type: 'DELETE',
                                url: '/core/presets/index',
                                data: {
                                    id: quicklink.id
                                },
                                success: function () {
                                    $( "#content" ).trigger( 'nmsweb:notify', {
                                        "target": "content",
                                        "type": "success",
                                        "title": "Successfully removed Quicklink",
                                        "message": "Quicklink '" + quicklink.name + "' has been successfully deleted."
                                    } );
                                }
                            } );
                        },
                        cancel: function () {}
                    } );
                    break;
                case 'load':
                    if ( quicklink.values.length > 0 ) {
                        window.nmsutils.preset.prepareToApplyPreset( quicklink.values );
                    }
                    $( "#content" ).trigger( 'nmsweb:notify', {
                        "target": "content",
                        "type": "success",
                        "title": "Successfully applied Quicklink",
                        "message": "Quicklink '" + quicklink.name + "' has been successfully applied."
                    } );
                    break;
                case 'preset':
                    if ( !quicklink.values.length ) {
                        $( "#content" ).trigger( 'nmsweb:notify', {
                            "target": "content",
                            "type": "error",
                            "title": "Please correct the following before continuing",
                            "message": "Quicklink '" + quicklink.name + "n-datasourcefilter-BIt2KHqRaO3G' contains no fields and so cannot be converted to a Preset."
                        } );
                        return;
                    }
                    $.ajax( {
                        type: 'POST',
                        url: '/core/presets/change',
                        data: {
                            id: quicklink.id,
                            quicklink: 0
                        },
                        success: function () {
                            $( "#content" ).trigger( 'nmsweb:notify', {
                                "target": "content",
                                "type": "success",
                                "title": "Successfully converted Quicklink to Preset",
                                "message": "Quicklink '" + quicklink.name + "' has been successfully converted to a Preset."
                            } );
                            $( '#n-element-selector-directory-popover' ).remove();
                        }
                    } );
                    break;
                }
            },
            val: function ( elements ) {
                var result,
                    that = this,
                    grid = that.element.find( '.n-elementselectorgrid:not(.n-elementselectorgrid-composite)' ),
                    gridData = that.element.find( '.n-elementselectorgrid:not(.n-elementselectorgrid-composite)' ).data( 'nmswebElementSelectorGrid' );
                if ( typeof elements === 'string' ) {
                    elements = JSON.parse( elements );
                }
                if ( elements && gridData.options.compositeSearch && elements.composite ) {
                    grid.find( '.n-element-selector-grid-composites-filter-link' ).removeClass( 'hide' );
                    result = grid.val( elements );
                } else if ( elements ) {
                    grid.val( elements );
                } else {
                    result = that.element.find( '.n-elementselectorgrid:not(.n-elementselectorgrid-composite)' ).val();
                }
                return result;
            },
            createSplitButton: function ( options ) {
                var i,
                    $selectButton,
                    $actionButton = $( '<button action=\'' + options[ 0 ].value + '\' class=\'btn\'>' + options[ 0 ].title + '</button>' ),
                    optionTitle,
                    optionValue,
                    $action,
                    $splitButtonContainer,
                    $actionList = $( '<ul class=\'n-action-list dropdown-menu hide\'></ul>' );
                for ( i = 0; i < options.length; i++ ) {
                    if ( options[ i ].title !== undefined && options[ i ].value !== undefined ) {
                        optionTitle = options[ i ].title;
                        optionValue = options[ i ].value;
                        //$selector.append( $option );
                        $action = $( '<li actionname=\'' + optionTitle + '\' actionvalue=\'' + optionValue + '\'><a>' + optionTitle + '</a></li>' );
                        $actionList.append( $action );
                    }
                }
                $selectButton = $( '<button class=\'n-splitbutton-choose n-splitbutton btn\'><span class=\'caret\'></span></button>' )
                    .on( 'click', function () {
                        $splitButtonContainer.toggleClass( 'open' );
                    } );
                $splitButtonContainer = $( '<div class=\'n-button-container btn-group\'></div>' ).append( $actionButton ).append( $selectButton ).append( $actionList );
                return $splitButtonContainer;
            },
            getContent: function ( items ) {
                var that = this,
                    $grid = $( '<div class="n-type-grid"></div>' ).nmswebGrid( {
                        pageable: true,
                        navigatable: false,
                        autoBind: true,
                        export: false,
                        dataSource: {
                            data: items,
                            pageSize: 5
                        },
                        columns: [
                            {
                                field: "name",
                                width: 400,
                                title: "Name"
                       }
                      ],
                        //in this case selectButton is little different and we can't use bootstrap "caret" style without modifying it. Needed to add white color style.
                        rowTemplate: '<tr ${ window.kendo.attr(\'uid\') + \'="\' + uid + \'"\' }> ' +
                            '<td><a class="n-type-link" data-item-id="#= id #">#= name #</a></td>' +
                            '<td>' +
                            '<div class="n-elementselectorgrid n-element-selector-toggle-holder">' +
                            '<div class="n-tree-builder-div">' +
                            '<div class="n-button-container btn-group">' +
                            '<button type="button" class="n-splitbutton-action btn default" data-item-id="#= id #" action="preset">Make Preset</button>' +
                            '<button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">' +
                            '<span class="caret"></span>' +
                            '</button>' +
                            '<ul class="n-action-list dropdown-menu hide">' +
                            '<li actionvalue="preset" actionname="Make Preset">' +
                            '<a>Make Preset</a>' +
                            '</li>' +
                            '<li actionvalue="rename" actionname="Rename">' +
                            '<a>Rename</a>' +
                            '</li>' +
                            '<li actionvalue="delete" actionname="Delete">' +
                            '<a>Delete</a>' +
                            '</li>' +
                            '</ul>' +
                            '</div>' +
                            '</div>' +
                            '</div>' +
                            '</td>' +
                            '</tr>'
                    } )
                    .on( 'click', '.n-splitbutton-choose', function () {
                        $( this ).parent( '.n-button-container' ).toggleClass( 'open' );
                    } )
                    .on( 'click', 'li[actionvalue]', function () {
                        var $listitem = $( this );
                        var $actionButton = $listitem.parents( '.n-button-container' ).find( 'button.n-splitbutton-action' );
                        var text = $actionButton.text();
                        var action_val = $actionButton.attr( 'action' );
                        $actionButton.text( $listitem.attr( 'actionname' ) )
                            .attr( 'action', $listitem.attr( 'actionvalue' ) );
                        $listitem.parents( '.n-button-container' ).removeClass( 'open' );
                        that.executeItemAction( $actionButton, $actionButton.parents( '.n-grid' ).data( 'nmswebGrid' ).dataSource.get( parseInt( $actionButton.attr( 'data-item-id' ), 10 ) ) );
                        $actionButton.text( text )
                            .attr( 'action', action_val );
                    } )
                    .on( 'click', '.n-splitbutton-action', function () {
                        var $actionButton = $( this );
                        that.executeItemAction( $actionButton, $actionButton.parents( '.n-grid' ).data( 'nmswebGrid' ).dataSource.get( parseInt( $actionButton.attr( 'data-item-id' ), 10 ) ) );
                    } );
                $grid.find( '.k-grid-content' ).removeAttr( 'style' );
                $grid.find( '.k-grouping-header, .k-grid-header, .k-scrollbar' ).addClass( 'hide' );
                return $( '<div></div>' ).append( $grid ).css( {
                    'width': '600px'
                } );
            },
            bindQuicklinkClick: function () {
                $( '#n-quicklinks-popover .n-type-grid' ).on( 'click', '.n-type-link', function () {
                    $( this ).parents( '.n-popover-content' ).spin();
                    var item = $( '#n-quicklinks-popover' ).find( '.n-type-grid' ).data( 'nmswebGrid' ).dataSource.get( parseInt( $( this ).attr( 'data-item-id' ), 10 ) );
                    var url = $.parseJSON( item.url );
                    $( '<form>', {
                        "html": '<input type="hidden" name="ql" value="' + url.ql + '" />',
                        "action": url.url,
                        "method": "POST"
                    } ).appendTo( $( this ) ).hide().submit();
                } );
            },
            closeGlobalPopover: function () {
                $( '.n-search .n-global-filter .n-datasourcefilter' ).removeAttr( 'disabled' );
                $( '#n-element-selector-global-search-popover .n-datasourcecomplexfilter, #n-element-selector-global-search-popover .n-popup-filter, #n-element-selector-global-search-popover' ).addClass( 'hide' ).find( '.close' ).removeClass( 'hide' );
                $( '#n-element-selector-global-search-popover' ).removeClass( 'advanced-query' )
                    .find( '.arrow, .overlayarrow' ).css( {
                        'left': '50%'
                    } );
                $( '.n-overlay .overlay, .n-overlay' ).removeAttr( 'style' );
                $( 'body' ).trigger( 'nmsweb:ClosePopover' );
            },
            openAdvancedDirectoryPopover: function ( searchData, nonGlobal ) {
                var that = this,
                    options = this.element.find( '.n-elementselectorgrid' ).data( 'nmswebElementSelectorGrid' ).options,
                    enumsArr = [ 'Beam', 'iNet', 'Inroute Group', 'Satellite', 'Terminal', 'SVN', 'Terminal Type', 'Object Type' ],
                    url = '/config-manager/advancedsearch/dropdowns?obj_type_ids=' + that.getEnumerableTypeIds( options.elementTypes, enumsArr ).join() + '&enums=configuration_state,obj_types';
                if ( typeof nonGlobal === "undefined" ) {
                    var advSearchGrid = $( '#n-element-selector-global-search-popover' ).find( '.k-grid' ).data( 'nmswebElementSelectorGrid' );
                    advSearchGrid._initialChangeRun = undefined;
                    advSearchGrid.isWaitingForUserInput = true;
                    advSearchGrid.trigger( 'nmsweb:notify', {
                        type: 'progress',
                        title: 'Status',
                        message: 'Waiting for user input',
                        isFadeable: false,
                        isPersistent: true
                    } );
                    //$('.n-overlay .overlay, .n-overlay').css({'visibility': 'visible'});
                    $( '#n-element-selector-global-search-popover' ).removeClass( 'hide' ).addClass( 'advanced-query' ).find( '.k-pager-wrap button' ).toggleClass( 'hide' );
                    $( '.n-search .n-global-filter .n-datasourcefilter' ).attr( 'disabled', 'true' );
                    $( '#n-element-selector-global-search-popover' ).find( '.n-datasourcecomplexfilter, .n-popup-filter' ).removeClass( 'hide' );
                    if ( !$( '#n-element-selector-global-search-popover .n-popover-content div .close:not(.n-element-selector-close)' ).length ) {
                        $( '#n-element-selector-global-search-popover' ).find( '.n-popover-content div' ).first()
                            .prepend( $( '<a class=\"close\">&times;</a>' )
                                .css( {
                                    'margin-right': '5px'
                                } )
                                .on( 'click', function () {
                                    $( '#n-element-selector-global-search-popover' )
                                        .find( '.k-pager-wrap button' )
                                        .toggleClass( 'hide' );
                                    that.closeGlobalPopover();
                                } )
                            );
                    }
                    $( '#n-element-selector-global-search-popover' ).find( '.n-datasourcecomplexfilter' ).data( 'nmswebDatasourceComplexFilter' ).displayQuery();
                    //remove all data from data source from grid before opening if global search has no value
                    $( '#n-element-selector-global-search-popover .n-elementselectorgrid' ).data( 'nmswebElementSelectorGrid' ).dataSource.data( [] );
                    var elem = angular.element( $( '#app' ) ),
                        injector = elem.injector(),
                        NMSUtils = injector.get( 'NMSUtils' );
                    $( '#n-element-selector-global-search-popover' ).css( 'z-index', NMSUtils.getPopoverIndex() );
                }
                $.ajax( url )
                    .done( function ( data ) {
                        var sendObj = {},
                            newObj = {};
                        $.each( that.getEnumerableTypeIds( options.elementTypes, enumsArr ), function ( idx, val ) {
                            newObj[ val ] = {};
                            newObj[ val ].label = data.enums.obj_types[ val ];
                            newObj[ val ].obj_list = data.obj_list[ val ];
                        } );
                        //Set Up Configuration State
                        newObj.configuration_state = {};
                        newObj.configuration_state.label = 'Configuration state';
                        newObj.configuration_state.obj_list = data.enums.configuration_state;
                        //Set Up Object Types
                        newObj.type = {};
                        newObj.type.label = 'Type';
                        newObj.type.obj_list = data.enums.obj_types;
                        sendObj.data = newObj;
                        sendObj.initialFilterList = $.map( data.enums.obj_types, function ( val, i ) {
                            return i;
                        } );
                        if ( searchData !== 'undefined' ) {
                            sendObj.searchData = searchData;
                        }
                        $( that.element ).trigger( 'nmsweb:poppedOver', sendObj );
                    } );
            },
            getEnumerableTypeIds: function ( typeArr, enumsArr ) {
                return $.map( typeArr, function ( val ) {
                    var i = 0,
                        len = enumsArr.length;
                    for ( ; i < len; i++ ) {
                        if ( enumsArr[ i ] === val.label ) {
                            return val.value;
                        }
                    }
                } );
            },
            getGlobalDirectoryContent: function () {
                var that = this;
                $( '.n-search .n-elementselectorgrid .k-pager-wrap' ).prepend( $( '<button class="btn btn-primary">Refine in Advanced Search</button>' )
                    .on( 'click', function () {
                        var val = $( '.n-global-filter .input-large' ).val();
                        that.closeGlobalPopover();
                        that.openAdvancedDirectoryPopover( {
                            'isRefinedSearch': true,
                            'value': val
                        } );
                    } ) );
                return $( '<div></div>' )
                    .css( {
                        'min-width': '900px',
                        'width': '100%',
                        'min-height': '200px'
                    } )
                    .append( $( '.n-search .n-datasourcecomplexfilter, .n-search .n-elementselectorgrid, .n-search .simple-filter, .n-search .data-elementselectorgrid-results-panel, .n-search .n-popup-filter' ).css( {} ) );
            },
            addQuicklinksMenu: function () {
                var $searchBox = $( '.quicklinks' );
                $searchBox.on( 'click', function () {
                    if ( $( '#n-quicklinks-popover:not("hidden")' ).length ) {
                        $( '#n-quicklinks-popover' ).remove();
                        // return;
                    }
                    $( '#n-quicklinks-popover' ).remove();

                    var elem = angular.element( $( '#app' ) ),
                        injector = elem.injector(),
                        $rootScope = injector.get( '$rootScope' ),
                        $compile = injector.get( '$compile' ),
                        $scope = $rootScope.$new(),
                        loadPresetsElement;

                    $scope.presetsOptions = {
                        quicklinks: true
                    };
                    loadPresetsElement = $compile( '<nmsweb-presets-load nmsweb-options="presetsOptions"></nmsweb-presets-load>' )( $scope );

                    var $content = loadPresetsElement,
                        actualWidth,
                        actualHeight,
                        tp,
                        $popover,
                        pos = $( '.quicklinks' ).getPosition();
                    $searchBox.nmswebPopover( {
                        'manual': false,
                        'exclusive': false,
                        'keypress': true,
                        'toggle': true,
                        'persistent': true,
                        'closeBtn': true, // show close 'X' in top-right
                        'showOnCreation': true, // don't hide immediately
                        'id': 'n-quicklinks-popover',
                        'hoverdelay': true,
                        'placement': 'bottom',
                        'content': $content
                    } );
                    $popover = $( '#n-quicklinks-popover' )
                        .css( {
                            top: 0,
                            left: 0,
                            display: 'block'
                        } )
                        .addClass( 'bottom' );
                    // $popover.find( '.n-popover-content div' ).spin();
                    actualHeight = $popover[ 0 ].offsetHeight;
                    actualWidth = $popover[ 0 ].offsetWidth;
                    tp = {
                        top: pos.top + pos.height,
                        left: pos.left - 450
                    };
                    $popover.removeAttr( 'style' )
                        .css( tp );
                    $popover.find( '.arrow, .overlayarrow' ).css( {
                        'left': '80%'
                    } );
                    $( '#n-quicklinks-popover' ).removeClass( 'hide' );
                    $( '#n-quicklinks-popover .k-virtual-scrollable-wrap' ).css( "position", "static" );
                    $( '#n-quicklinks-popover .k-grid-content' ).css( "position", "static" );
                } );
            },
            addGlobalDirectoryPopover: function () {
                var $searchBox = $( '.n-search > .n-global-filter > .input-large' )
                    .on( 'click', function () {
                        $( '#n-element-selector-directory-popover' ).remove();
                        $( '.n-overlay .overlay, .n-overlay' ).removeAttr( 'style' );
                        var elem = angular.element( $( '#app' ) ),
                            injector = elem.injector(),
                            NMSUtils = injector.get( 'NMSUtils' );
                        $( '#n-element-selector-global-search-popover' ).css( 'z-index', NMSUtils.getPopoverIndex() );
                        if ( $( '#n-element-selector-global-search-popover' ).hasClass( 'hide' ) ) {
                            NMSUtils.increasePopoverIndex();
                        }
                    } ),
                    that = this;
                // repositionToolbarControls = function () {
                // 	if ($('#n-element-selector-global-search-popover')[0].offsetWidth !== that.globalpopoverwidth) {
                // 		that.globalpopoverwidth = $('#n-element-selector-global-search-popover')[0].offsetWidth;
                // 		$('#n-element-selector-global-search-popover .n-elementselectorgrid .k-toolbar .n-element-selector-grid-toolbar-components-holder').css({'right': 0});
                // 	}
                // };
                $( '.n-search fieldset .close, .n-search .simple-filter .close, .n-search style' ).remove();
                $searchBox.nmswebPopover( {
                    'id': 'n-element-selector-global-search-popover',
                    'hoverdelay': false,
                    'placement': 'bottom',
                    'title': '',
                    'manual': false,
                    'cssoverride': true,
                    'modal': false,
                    'keypress': true,
                    'content': that.getGlobalDirectoryContent()
                } );
                $( '.n-overlay .overlay, .n-overlay' ).removeAttr( 'style' );
                // .on({'click': function () {
                // 	repositionToolbarControls();
                // },
                // 	'keypress': function () {
                // 		repositionToolbarControls();
                // 	}});
                $( '#n-element-selector-global-search-popover' ).removeClass( 'advanced-query' )
                    .find( '.n-popup-filter input' ).on( 'input', function () {
                        $( '.n-search .n-global-filter input' ).val( $( this ).val() );
                    } );
                $( '#js-eraser' ).prepend( $( '#n-element-selector-global-search-popover' ) );
            },
            addAdvancedGlobalDirectoryPopover: function () {
                var $popupFilter = $( '#n-element-selector-global-search-popover' ).find( '.n-popup-filter' ),
                    advancedSearchButton,
                    that = this;
                $popupFilter.prepend( $( '<div class="n-element-selector-advanced-query-title"></div>' )
                    .append( $( '<h3>Build Your Custom Query</h3>' ) ) );
                $( '#n-element-selector-global-search-popover' ).find( '.n-element-selector-advanced-query-title .close' ).remove();
                advancedSearchButton = $( '.n-search .advancedsearch' )
                    .on( 'click', function ( e ) {
                        if ( $( '#n-element-selector-global-search-popover' ).hasClass( 'advanced-query' ) && !$( '#n-element-selector-global-search-popover' ).hasClass( 'hide' ) ) {
                            $( '#n-element-selector-global-search-popover' )
                                .find( '.k-pager-wrap button' )
                                .toggleClass( 'hide' );
                            that.closeGlobalPopover();
                        } else {
                            //remove all data from data source from grid before opening if global search has no value
                            //$('#n-element-selector-global-search-popover .n-elementselectorgrid').data('nmswebElementSelectorGrid').datasource.data([]);
                            that.openAdvancedDirectoryPopover();
                            var $searchBox = $( '#n-element-selector-global-search-popover' ),
                                arrowPos = ( $( e.target ).offset().left + 55 ) - $searchBox.offset().left;
                            $searchBox.find( '.arrow' ).css( 'left', arrowPos );
                        }
                    } );
            }
        } );
    window.nmsweb.registerComponent( 'ElementSelector', ElementSelector );
    return ElementSelector;
} );