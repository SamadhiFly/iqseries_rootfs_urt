define( [ "core/nmsweb" ], function () {
    "use strict";
    window.nmsweb = window.nmsweb || {};
    window.nmsweb.logger = function () {
        var config = {
                0: {
                    name: 'off',
                    state: null,
                    binding: null
                },
                1: {
                    name: 'error',
                    state: null,
                    binding: console.error.bind( console )
                },
                2: {
                    name: 'warn',
                    state: null,
                    binding: console.warn.bind( console )
                },
                3: {
                    name: 'info',
                    state: null,
                    binding: console.info.bind( console )
                },
                4: {
                    name: 'log',
                    state: null,
                    binding: console.log.bind( console )
                }
            },
            pub = {},
            _enable,
            _disable,
            _maxLevel = 0;
        _enable = function ( level ) {
            if ( config[ level ].state === null ) {
                return;
            }
            window.console[ config[ level ].name ] = config[ level ].state;
        };
        _disable = function ( level ) {
            if ( console[ config[ level ].name ] ) {
                config[ level ].state = console[ config[ level ].name ];
                window.console[ config[ level ].name ] = function () {};
            }
        };
        Object.defineProperties( pub, {
            enabled: {
                get: function () {
                    return console.log.name === "log";
                },
                set: function ( value ) {
                    for ( var prop in config ) {
                        if ( config.hasOwnProperty( prop ) ) {
                            if ( value === true ) {
                                _enable( prop );
                            } else {
                                _disable( prop );
                            }
                        }
                    }
                }
            },
            action: {
                value: function () {
                    var apc = [].slice,
                        args = apc.call( arguments ),
                        levelNum = args[ 0 ];
                    if ( levelNum <= _maxLevel && levelNum !== 0 && _maxLevel !== 0 ) {
                        if ( typeof levelNum !== "number" ) {
                            this.enabled = false;
                            return;
                        }
                        if ( Object.keys( config ).indexOf( levelNum.toString() ) !== -1 ) {
                            args.splice( 0, 1 );
                            if ( config[ levelNum ].binding ) {
                                config[ levelNum ].binding.apply( null, args );
                            }
                        }
                    } else {
                        this.enabled = false;
                    }
                }
            },
            maxLevelAllowed: {
                get: function () {
                    return _maxLevel;
                },
                set: function ( value ) {
                    _maxLevel = value;
                }
            }
        } );
        return pub;
    }();
    // nmsweb.logger.disable();
    return window.nmsweb.logger;
} );