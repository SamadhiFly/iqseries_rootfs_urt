define( [ 'core/jmr', 'core/data' ], function ( $ ) { // jshint ignore:line
    "use strict";
    var jmrstreaming = function ( opts ) {
        console.log( opts );
        var that = this,
            url = opts.url,
            backend = opts.backend,
            request = opts.request,
            cid = opts.dataSource_id,
            jmr = window.nmsweb.jmr( url ),
            _init;
        _init = function () {
            jmr.bind( 'open', function () {
                jmr.send( {
                    backend: backend,
                    request: request,
                    cid: cid
                } );
                console.log( 'dammy', this );
            } );
            jmr.bind( cid, function ( response ) {
                if ( response !== undefined && response.data !== undefined ) {
                    console.log( response );
                    var dataSource = window.nmsweb.DataSources[ cid ];
                    dataSource.insert( 0, {
                        latency: response.data.latency,
                        element: response.data.element,
                        epoch: new Date( response.data.epoch * 1000 ),
                        string: 'Dammy being silly!'
                    } );
                    console.log( dataSource.data().length );
                }
            } );
            jmr.bind( cid + '-error', function ( response ) {
                console.log( response );
            } );
            return that;
        };
        return _init();
    };
    return jmrstreaming;
} );