define( [
    'core/nmsweb',
    'vendor/yworks/license',
    'vendor/yworks/yfiles-orgchart.min'
], function () {
    /* jshint ignore:start */
    var orgChartUI = demo.yfiles.graph.orgchart.OrgChartUI;
    window.nmsweb.registerComponent( 'orgChartUI', orgChartUI );
    return orgChartUI;
    /* jshint ignore:end */
} );