define( [ 'jquery', 'core/data', 'core/nmsweb' ], function ( $ ) {
    "use strict";
    var timer;

    function _generateFilterOptions( object ) {
        var len = object.length,
            i;
        for ( i = 0; i < len; i++ ) {
            object[ i ].value = null;
            if ( object[ i ].type === 'string' ) {
                object[ i ].operator = 'contains';
            } else if ( object[ i ].type === 'number' ) {
                object[ i ].operator = 'eq';
            }
        }
        return object.slice();
    }

    function _toArray( object ) {
        var newArray = [],
            prop;
        for ( prop in object ) {
            if ( object[ prop ] !== undefined ) {
                if ( object[ prop ].field === undefined ) {
                    object[ prop ].field = prop;
                }
                newArray.push( object[ prop ] );
            }
        }
        return newArray.slice();
    }

    function _process( options ) {
        var obj = {},
            c = [],
            i;
        if ( $.isArray( options ) ) {
            for ( i = 0; i < options.length; i++ ) {
                if ( typeof options[ i ] === 'string' ) {
                    obj = {};
                    obj[ options[ i ] ] = [];
                    c.push( obj );
                } else {
                    c.push( options[ i ] );
                }
            }
            return c;
        } else if ( typeof options === 'string' ) {
            obj[ options ] = [];
            return obj;
        } else {
            return options;
        }
    }
    var kendo = window.kendo,
        datasourcefilter = kendo.Observable.extend( {
            /**
             * datasource = options.dataSource,
             * fOptions = options.fOptions,
             * callBackObj = options.callback
             */
            init: function ( selector, options ) {
                var that = this,
                    isArray = $.isArray,
                    isPlainObject = $.isPlainObject,
                    extend = $.extend,
                    $selector = $( selector ),
                    $close_btn = $selector.next( 'a.close' ).hide(),
                    option = _process( options.dataSources ),
                    dataSource,
                    filters,
                    len,
                    i,
                    prop,
                    fFields,
                    temp = [],
                    fields,
                    defaultOptions;
                // default options object
                defaultOptions = {
                    fOptions: {
                        logic: "or",
                        filters: []
                    }
                };
                that.options = {};
                that.dataSources = extend( isPlainObject( option ) ? {} : [], option );
                len = that.dataSources.length;
                if ( isPlainObject( that.dataSources ) ) {
                    for ( prop in that.dataSources ) {
                        if ( that.dataSources.hasOwnProperty( prop ) ) {
                            if ( nmsweb.DataSources[ prop ] !== undefined && nmsweb.DataSources[ prop ].options.schema.model !== undefined ) {
                                fields = nmsweb.DataSources[ prop ].options.schema.model.fields;
                            }
                            if ( that.dataSources[ prop ] !== undefined ) {
                                dataSource = prop;
                                fFields = that.dataSources[ prop ] !== null && that.dataSources[ prop ].length ? that.dataSources[ prop ] : _toArray( fields );
                            }
                            filters = _generateFilterOptions( fFields );
                            that.dataSource = dataSource;
                            extend( defaultOptions.fOptions.filters, filters );
                            that.filterCfg = defaultOptions.fOptions;
                        }
                    }
                }
                if ( isArray( that.dataSources ) ) {
                    temp = that.dataSources.slice();
                    that.dataSources = [];
                    for ( i = 0; i < len; i++ ) {
                        for ( prop in temp[ i ] ) {
                            if ( temp[ i ][ prop ] !== undefined ) {
                                if ( nmsweb.DataSources[ prop ].options.schema.model !== undefined ) {
                                    fields = nmsweb.DataSources[ prop ].options.schema.model.fields;
                                }
                                fFields = temp[ i ][ prop ].length ? temp[ i ][ prop ] : _toArray( fields );
                                temp[ i ].fOptions = {
                                    'filters': [],
                                    'logic': 'or'
                                };
                                filters = _generateFilterOptions( fFields );
                                extend( defaultOptions.fOptions.filters, filters );
                                extend( temp[ i ].fOptions.filters, defaultOptions.fOptions.filters );
                                that.dataSources.push( {
                                    "dataSource": prop,
                                    "fOptions": temp[ i ].fOptions
                                } );
                                delete temp[ i ].fOptions;
                            }
                        }
                    }
                }
                window.nmsweb.extendOptions( that.options, defaultOptions, options );
                kendo.Observable.fn.init.apply( that, that.options );
                that.element = $selector;
                that.close_btn = $close_btn;
                that.bindEvents();
                return that;
            },
            bindEvents: function () {
                var that = this;
                that.element.on( 'input', that.filter.bind( that ) );
                that.element.on( 'keyup', function ( e ) {
                    if ( e.which === 13 && !$( this ).val() ) {
                        that.filter( e );
                    }
                } );
                that.close_btn.on( 'click', that.reset.bind( that ) );
            },
            mixin: function () {
                var that = this,
                    dataSources = that.dataSources,
                    len = dataSources.length,
                    i;
                if ( Array.isArray( dataSources ) ) {
                    for ( i = 0; i < len; i += 1 ) {
                        that.performFilter( dataSources[ i ].dataSource, dataSources[ i ].fOptions );
                    }
                } else {
                    that.performFilter();
                }
            },
            /**
             * Filter datasource(s)
             * @param {object} e jQuery event object
             */
            filter: function ( e ) {
                var that = this,
                    delay = that.options.delay || 500,
                    chck = function () {
                        var target = e.target || e.srcElement,
                            length,
                            characters = that.options.characters;
                        that.filterString = target.value.trim();
                        length = that.filterString.length;
                        if ( length >= characters ) {
                            that.mixin();
                        } else if ( that.options.initialFilter && that.options.initialFilterFireOnLoad && length === 0 ) {
                            that.mixin();
                        }
                    };
                clearTimeout( timer );
                timer = setTimeout( chck, delay );
            },
            /**
             * process dataSources filter object to pass in filter String
             * @param {object} (optional) o callback object
             */
            performFilter: function ( ds, fCfg ) {
                var that = this,
                    filterString = that.filterString,
                    dataSource = window.nmsweb.DataSources[ ds || that.dataSource ],
                    filterCfg = fCfg || that.filterCfg || {},
                    len = filterCfg.filters.length,
                    i;
                for ( i = 0; i < len; i += 1 ) {
                    if ( filterCfg.filters[ i ].operator === "eq" ) {
                        filterCfg.filters[ i ].value = Number( filterString );
                    } else {
                        filterCfg.filters[ i ].value = filterString;
                    }
                }
                if ( that.options.forceRemoteFiltering ) {
                    dataSource.options.serverFiltering = true;
                }
                if ( ( ( this.options.initialFilter ) && ( typeof this.options.initialFilter === 'object' ) && ( this.options.initialFilterPersistence ) ) || ( ( this.options.initialFilter ) && ( typeof this.options.initialFilter === 'object' ) && ( this.options.initialFilterFireOnLoad ) ) ) {
                    var newFilter = {};
                    newFilter.logic = "and";
                    newFilter.filters = [];
                    //add initial filter
                    if ( $.type( this.options.initialFilter ) === 'array' ) { //implicit AND logic
                        $.each( this.options.initialFilter, function () {
                            newFilter.filters.push( this );
                        } );
                    } else { //{"field": "...", "operator": "...", "value": "..."} OR {"logic": "...", "filters": [...]}
                        newFilter = this.options.initialFilter;
                    }
                    if ( filterCfg.filters && filterCfg.filters.length ) {
                        filterCfg = {
                            filters: [
                                newFilter,
                                filterCfg
                            ],
                            logic: "and"
                        };
                    } else {
                        filterCfg = newFilter;
                    }
                }
                dataSource.filter( filterCfg );
            },
            /**
             * Reset datasource(s)
             * to default/original state
             * @param {object} e jQuery event object
             */
            reset: function ( e ) {
                var that = this,
                    target = e.target || e.srcElement;
                that.filterString = "";
                $( target ).prev( 'input' ).val( '' );
                that.mixin();
                that.hide( target );
            }
        } );
    window.nmsweb.registerComponent( 'DatasourceFilter', datasourcefilter );
    return datasourcefilter;
} );