define( [ "jquery", "kendo", "core/nmsweb" ], function ( $ ) {
    "use strict";
    var Calendar = window.kendo.ui.Calendar.extend( {
        init: function ( element, options ) {
            var that = this,
                newDateFormat,
                newDate,
                defaults = {
                    format: "yyyy-MM-dd",
                    change: function ( e ) {
                        newDateFormat = e.sender.options.format;
                        newDate = new Date( e.sender.value() );
                        $( element.selector + "_value" ).val( window.kendo.toString( newDate, newDateFormat ) );
                    }
                };
            if ( options.opts ) {
                // forcing format (if developer (while creating form) put's additional options (tries to force it's own format)) because it has been decided that everywhere throughout nms time will be displayed in the following format HH:mm:ss
                if ( options.value ) {
                    options.opts.value = new Date( options.value );
                }
                options.opts.format = defaults.format;
                nmsweb.extendOptions( defaults, options.opts );
            } else if ( options ) {
                if ( options.value ) {
                    options.value = new Date( options.value );
                }
                options.format = defaults.format;
                nmsweb.extendOptions( defaults, options );
            }
            window.kendo.ui.Calendar.fn.init.call( that, element, defaults );
        }
    } );
    window.nmsweb.registerComponent( 'Calendar', Calendar );
    return Calendar;
} );