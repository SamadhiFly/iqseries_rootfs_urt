define( [ 'underscore', 'jquery', 'kendo', 'core/grid', 'core/nmsweb', 'core/lightdock', 'core/popover', 'core/spin', 'external/bootstrap/core', 'core/treeview', 'module/core', 'module/core/service/management-state-cache', 'module/core/directive/nmsweb-icon', 'module/core/directive/nmsweb-actionsbutton', 'module/core/service/nmsweb-notification', 'module/core/factory/api' ],
    function ( _, $, kendo, grid, nmsweb, lightdock, popover, spin, bscore, orgChartUI ) {
        "use strict";
        var ElementSelectorGrid = window.nmsweb.Grid.extend( {
            init: function ( element, options ) {
                var that = this,
                    filters = [],
                    typeID,
                    $compositeGrid = element.parent().find( '.n-elementselectorgrid-composite' ),
                    groupButtonDropdown,
                    groupAction,
                    selectedGridRows = [],
                    maximumNumberOfActions = 4,
                    groupRequestHandled = false,
                    toggleGroupActionButton = function ( dropdown, shouldEnable, selector, selectedType ) {
                        if ( dropdown !== undefined ) {
                            var listOfUrls;
                            if ( shouldEnable === true ) {
                                var typesToBlock = Object.keys( selector.options.disabled_group_actions );
                                dropdown
                                    .attr( 'aria-disabled', false )
                                    .attr( 'data-toggle', 'dropdown' );
                                // check also if some group actions should be blocked
                                var actionsToBlock;
                                if ( typesToBlock.indexOf( selectedType.toString() ) !== -1 ) {
                                    actionsToBlock = selector.options.disabled_group_actions[ selectedType ].actions;
                                    if ( actionsToBlock ) {
                                        listOfUrls = groupButtonDropdown.parent().find( 'li' );
                                        $.each( listOfUrls, function ( index, li ) {
                                            var aToCheck = $( li ).find( 'a' ),
                                                hrefToCheck = aToCheck.data( 'target' ),
                                                action = hrefToCheck.split( '/' )[ 3 ];
                                            if ( actionsToBlock.indexOf( action ) !== -1 ) {
                                                $( li ).css( 'display', 'none' );
                                            } else {
                                                $( li ).css( 'display', 'list-item' );
                                            }
                                        } );
                                    }
                                }
                            } else {
                                dropdown
                                    .attr( 'aria-disabled', true )
                                    .attr( 'data-toggle', 'false' )
                                    .parent()
                                    .removeClass( 'open' );
                                listOfUrls = dropdown.parent().find( 'li' );
                                // and display all <li> elements back
                                $.each( listOfUrls, function ( index, li ) {
                                    $( li ).css( 'display', 'list-item' );
                                } );
                            }
                        }
                    },
                    defaults = {
                        scrollable: {
                            virtual: true
                        },
                        sortable: {
                            mode: 'multiple',
                            allowUnsort: true
                        },
                        min_elements: options.min_elements,
                        pageable: false,
                        groupable: true,
                        selectable: 'multiple',
                        navigatable: true,
                        autoBind: true,
                        toolbar: $.proxy( window.kendo.template( that.getToolbar( element, options ) ), that ),
                        // called later
                        // rowTemplate: $.proxy( window.kendo.template( that.getRow() ), that ),
                        // altRowTemplate: $.proxy( window.kendo.template( that.getAltRow() ), that ),
                        change: function ( event ) {
                            groupButtonDropdown = ( groupButtonDropdown && groupButtonDropdown.length > 0 ) ? groupButtonDropdown : this.element
                                .find( '.n-group-actions-div' )
                                .find( '.n-element-selector-group-actions-drop' );
                            if ( this.dataSource.groupAction ) {
                                this.dataSource.groupAction( event, this );
                            }
                        }
                    },
                    clearComposite,
                    types = [],
                    selectedElements,
                    populateTypesAndFilter,
                    sortSelect,
                    doATypeFilter,
                    getFilters,
                    $powerQueryHolder,
                    $customHeader,
                    $section,
                    $nestedPopover,
                    i,
                    len,
                    _filterTimer,
                    hierarchyIndex,
                    numberOfDisplayedActions = 0,
                    $treeContainer,
                    typeIndex,
                    populateDropdown,
                    populateDropdownOnce,
                    populateActionsGroups,
                    $resultsPanel = $( '#' + element.attr( 'id' ) + '-results-panel' );
                if ( options ) {
                    if ( options.actions ) {
                        for ( i = 0, len = options.actions.length; i < len; i++ ) {
                            if ( !options.actions[ i ].width && !options.actions[ i ].celltemplate ) {
                                options.actions[ i ].celltemplate = 'action';
                            }
                            if ( options.actions[ i ].action === 'hierarchy' ) {
                                that.hierarchyIndex = hierarchyIndex = i;
                            }
                        }
                    }
                    if ( options.initialFilter === undefined || options.initialFilter === "" ) {
                        options.initialFilterFireOnLoad = false;
                    }
                    nmsweb.extendOptions( defaults, options );
                    if ( defaults.inForm !== undefined && defaults.inForm === false ) {
                        defaults.columns = $.merge( defaults.columns, defaults.actions );
                        for ( i = 0, len = defaults.columns.length; i < len; i++ ) {
                            if ( defaults.columns[ i ].celltemplate === 'type' ) {
                                that.typeIndex = typeIndex = i;
                            }
                        }
                        if ( defaults.actions.length < maximumNumberOfActions ) {
                            for ( i = 0; i < ( maximumNumberOfActions - defaults.actions.length ); i++ ) {
                                defaults.columns.push( {
                                    'celltemplate': 'action'
                                } );
                            }
                        }
                        if ( options.actions_url !== null ) {
                            defaults.columns.push( {
                                'celltemplate': 'allactions',
                                'title': 'allactions',
                                'field': 'allactions'
                            } );
                        }
                        // Need to swap the positions of obj_name and type so that the row templating is working better.
                        if ( that.typeIndex !== undefined ) {
                            defaults.columns.move( typeIndex, 0 );
                        }
                        $.each( defaults.columns, function () {
                            //TODO: Work out how to get this working properly with the templating. As it stands there is no value being passed through so what do I do?
                            // if (this.field === 'configuration_state') {
                            //  this.celltemplate = 'configuration_state';
                            // }
                            switch ( this.celltemplate ) {
                            case 'obj_name':
                                break;
                            case 'action':
                                if ( numberOfDisplayedActions >= maximumNumberOfActions ) {
                                    this.hidden = true;
                                }
                                this.width = '120px';
                                numberOfDisplayedActions = numberOfDisplayedActions + 1;
                                options.numberOfDisplayedActions = numberOfDisplayedActions;
                                break;
                            case 'allactions':
                                this.width = '200px';
                                break;
                                //TODO: Add the configuration state magic in here because it should work then. Doesn't seem to work when the above code is uncommented.
                            case 'configuration_state':
                                this.groupHeaderTemplate = '#= "Type: "+$("\\#' + element.attr( 'id' ) + '").data("nmswebElementSelectorGrid").getTypeName() #';
                                break;
                            case 'type':
                                this.width = "50px";
                                this.groupHeaderTemplate = '#= "Type: "+$("\\#' + element.attr( 'id' ) + '").data("nmswebElementSelectorGrid").getTypeName(value) #';
                                break;
                            default:
                                this.width = '120px';
                                break;
                            }
                        } );
                    }
                    groupAction = function ( event, selector ) {
                        var addSelectedGridRow = function ( objId, typeId, check ) {
                                var found = false;
                                if ( check !== undefined && check === true ) {
                                    // check if it's already in selectedGridRows because this.select() returns everything from current "page"
                                    $.each( selectedGridRows, function ( selecteRowIndex, selectedRow ) {
                                        if ( selectedRow.objId === objId ) {
                                            found = true;
                                            return false;
                                        }
                                    } );
                                }
                                if ( found === false ) {
                                    selectedGridRows.push( {
                                        typeId: typeId,
                                        objId: objId
                                    } );
                                }
                            },
                            removeGridRow = function ( objId ) {
                                $.each( selectedGridRows, function ( selecteRowIndex, selectedRow ) {
                                    if ( selectedRow.objId === objId ) {
                                        selectedGridRows.splice( selecteRowIndex, 1 );
                                        return false;
                                    }
                                } );
                            };
                        // in here we have two ways of handling this
                        // if elements are selected with shift groupAction is triggered twice (once from datasource and once from grid)
                        // in case of call via datasource we know that getSelectedIds already has data correct
                        // in case of call via grid that's still not updated
                        if ( event.sender instanceof window.nmsweb.Grid && selector !== undefined ) {
                            var selectedRows = element.find( 'tr.k-state-selected' );
                            if ( groupRequestHandled === false ) {
                                // simple click or range click on grid
                                // var selectedRows = element.find('tr.k-state-selected');
                                if ( event.sender.dataSource.getSelectedIds().length === 0 ) {
                                    // clear all data
                                    selectedGridRows.length = 0;
                                    // and these are new elements
                                    $.each( selectedRows, function ( index, row ) {
                                        var clickedId = parseInt( $( row ).attr( 'elementid' ), 10 ),
                                            clickedType = parseInt( $( row ).attr( 'elementtype' ), 10 );
                                        // no need to check, since we have emptied before
                                        addSelectedGridRow( clickedId, clickedType, false );
                                    } );
                                } else {
                                    // see what's now selected in view range, add those to selectedGridRows
                                    var notSelectedRows = element.find( 'tr:not(.k-state-selected)' );
                                    // see what's now deselected in view range and remove those from selectedGridRows
                                    $.each( selectedRows, function ( index, row ) {
                                        var rowId = parseInt( $( row ).attr( 'elementid' ), 10 ),
                                            rowType = parseInt( $( row ).attr( 'elementtype' ), 10 );
                                        addSelectedGridRow( rowId, rowType, true );
                                    } );
                                    $.each( notSelectedRows, function ( index, row ) {
                                        var rowId = parseInt( $( row ).attr( 'elementid' ), 10 ),
                                            rowType = parseInt( $( row ).attr( 'elementtype' ), 10 );
                                        removeGridRow( rowId, rowType );
                                    } );
                                }
                            }
                            groupRequestHandled = false;
                        } else {
                            if ( event.sender && event.sender.getSelectedIds ) {
                                var selectedIds = event.sender.getSelectedIds();
                                groupRequestHandled = true;
                                // clear selected rows and add all what's in data source
                                selectedGridRows.length = 0;
                                $.each( selectedIds, function ( index, id ) {
                                    var dataSourceObject = event.sender.get( id );
                                    // no need to check, since we have emptied before
                                    if ( dataSourceObject !== undefined ) {
                                        addSelectedGridRow( dataSourceObject.obj_id, dataSourceObject.type, false );
                                    }
                                } );
                            }
                        }
                        if ( selector !== undefined ) {
                            if ( selectedGridRows.length > 1 ) {
                                var selectedType = selectedGridRows[ 0 ].typeId,
                                    disableDropdown = false;
                                $.each( selectedGridRows, function ( index, row ) {
                                    var rowType = row.typeId;
                                    if ( rowType !== selectedType ) {
                                        disableDropdown = true;
                                    }
                                } );
                                toggleGroupActionButton( groupButtonDropdown, !disableDropdown, selector, selectedGridRows[ 0 ].typeId );
                            } else {
                                toggleGroupActionButton( groupButtonDropdown, false );
                            }
                        }
                    };
                    defaults.dataSource.groupAction = groupAction;
                    populateDropdown = function () {
                        var seen = {},
                            newOption = element.data( 'nmswebElementSelectorGrid' ).getElementTypes(),
                            $dropDown = element.find( '.n-element-selector-element-type-drop' );
                        $dropDown.find( 'option' ).remove();
                        $dropDown
                            .append( newOption )
                            .children().each( function () {
                                var txt = $( this ).val();
                                if ( seen[ txt ] ) {
                                    $( this ).remove();
                                } else {
                                    seen[ txt ] = true;
                                }
                            } );
                        sortSelect( $dropDown );
                    };
                    populateDropdownOnce = function ( e ) {
                        populateDropdown( e );
                        if ( defaults.dataSource._data.length > 0 ) {
                            defaults.dataSource.unbind( 'change', populateDropdownOnce );
                        }
                    };
                    populateActionsGroups = function () {
                        if ( undefined !== this.dataSource.id ) {
                            $.proxy( that.reattachFilter(), this );
                            $.proxy( that.getActionsGroup(), this );
                            $.proxy( that.updateToolbarDropDowns(), this );
                            that.unbind( 'dataBound', populateActionsGroups );
                        }
                    };
                    defaults.dataSource.bind( 'change', populateDropdownOnce );
                    defaults.dataSource.bind( 'requestEnd', function ( e ) {
                        if ( e.type ) {
                            //Only fire if it's an XHR request and not for virtual scrolling
                            defaults.dataSource.eventRequestEndFired = true;
                        }
                    } );
                    defaults.dataSource.bind( 'change', function ( e ) {
                        defaults.dataSource.groupAction( e );
                        if ( !defaults.dataSource.eventRequestEndFired ) {
                            return;
                        }
                        defaults.dataSource.eventRequestEndFired = false;
                        var elem = angular.element( $( '#app' ) );
                        var injector = elem.injector();
                        var managementStateCache = injector.get( 'ManagementStateCache' );
                        managementStateCache.elementSelectorDsUpdate( defaults.dataSource.id );
                    } );
                    defaults.dataSource.bind( 'filter', populateDropdown );
                }
                // we have to call these (getRow/getAltRow) later, because we need first number of actions columns calculated
                if ( options.rowTemplate === undefined ) {
                    defaults.rowTemplate = $.proxy( window.kendo.template( that.getRow( options ) ), that );
                }
                if ( options.altRowTemplate === undefined ) {
                    defaults.altRowTemplate = $.proxy( window.kendo.template( that.getAltRow( options ) ), that );
                }
                window.nmsweb.Grid.fn.init.call( that, element, defaults );
                that.bind( 'dataBound', populateActionsGroups );
                sortSelect = function ( selElem ) {
                    var my_options = selElem.find( 'option' );
                    my_options.sort( function ( a, b ) {
                        if ( a.text.toLowerCase() > b.text.toLowerCase() ) {
                            return 1;
                        } else if ( a.text.toLowerCase() < b.text.toLowerCase() ) {
                            return -1;
                        } else {
                            return 0;
                        }
                    } );
                    selElem.empty().append( my_options );
                };
                if ( options.actions && hierarchyIndex !== undefined && hierarchyIndex !== null && options.actions[ hierarchyIndex ].url && options.actions[ hierarchyIndex ].url !== null ) {
                    $treeContainer = $( '<div class=\'tree-content\'></div>' )
                        .css( {
                            'width': 'auto'
                        } )
                        .addClass( 'hide' );
                    element.append( $treeContainer );
                }
                if ( options.advancedSearch !== undefined && options.advancedSearch === true ) {
                    $nestedPopover = $( '<a class=\'n-popover-icon\' style=\'margin-left: 10px\'></a>' );
                    $customHeader = $( '<span class="advanced-filter-header">Build Your Custom Query</span>' )
                        .append( $nestedPopover )
                        .css( {
                            'display': 'none'
                        } );
                    $powerQueryHolder = $( '<div class=\'n-element-selector-grid-power-query-holder hide\'></div>' );
                    if ( element.parents( '.n-configurator-section-form' ).length > 0 ) {
                        element.parents( '.n-configurator-section-form' ).find( '.data-elementselectorgrid-results-panel' ).addClass( 'hide' );
                        element.parents( '.n-configurator-section-form' ).first()
                            .append( $customHeader )
                            .prepend( $powerQueryHolder
                                .append( element.parent()
                                    .find( '.n-datasourcecomplexfilter' ) ) );
                        element.append( $( '<span class="arrow hide"></span><span class="overlayarrow hide"></span>' ) );
                        $section = element.parents( '.n-configurator-section-form' )
                            .find( '.close' ).remove();
                        element.find( '.close' ).remove();
                        $nestedPopover.nmswebPopover( {
                            'placement': 'right',
                            'title': 'Build a Custom Query',
                            'nested': true,
                            'exclusive': false,
                            'content': '<div>Define a custom query to filter your datasource.</div>'
                        } );
                        element.find( '.k-pager-wrap' )
                            .append( $( '<a class=\'n-element-selector-grid-advanced-search-link\'>Advanced Search</a>' )
                                .on( 'click', function () {
                                    var that = $( this ),
                                        $form = element.parents( '.n-configurator-section-form' ),
                                        $filter = $form.find( '.n-datasourcefilter' ),
                                        $filterLabel = $form.find( '.n-datasourcefilter-label' ),
                                        $advancedHeader = $form.find( '.advanced-filter-header' ),
                                        $title = element.parents( '.n-popover-inner' ).first().find( '.n-popover-title' ),
                                        $queryHolder = $form.find( '.n-element-selector-grid-power-query-holder' ),
                                        $resultsPanel = $form.find( '.data-elementselectorgrid-results-panel' );
                                    element.parent( '.n-elementselector' ).data( 'nmswebElementSelector' ).openAdvancedDirectoryPopover( {
                                        'isRefinedSearch': true,
                                        'value': $filter.val()
                                    }, true );
                                    $queryHolder.toggleClass( 'hide' );
                                    $resultsPanel.toggleClass( 'hide' );
                                    $title.prepend( $advancedHeader );
                                    if ( element.parents( '.n-popover-content' ).first().find( '.n-element-selector-grid-power-query-holder' ).hasClass( 'hide' ) ) {
                                        that.text( 'Advanced Search' );
                                        $filter.removeClass( 'advancedquery' );
                                        $filterLabel.removeClass( 'advancedquery' );
                                        $title.addClass( 'n-popover-no-title' )
                                            .find( 'span' ).addClass( 'hide' );
                                        element.parents( '.n-configurator-section-form' ).find( '.n-elementselector' ).removeClass( 'advancedquery' );
                                        $form.find( '.n-datasourcefilter, .n-datasourcefilter-label' ).removeClass( 'hide' );
                                    } else {
                                        element.parents( '.n-configurator-section-form' ).find( '.n-elementselector' ).addClass( 'advancedquery' );
                                        element.parent().find( '.n-elementselectorgrid-composite' ).addClass( 'hide' );
                                        $( '.n-element-selector-grid-composites-filter-link' ).text( 'Show Composites Filter' );
                                        $filter.addClass( 'advancedquery' );
                                        $filterLabel.addClass( 'advancedquery' );
                                        that.text( 'Hide Advanced Search' );
                                        $title.removeClass( 'n-popover-no-title' )
                                            .find( 'span' ).removeAttr( 'style' ).removeClass( 'hide' );
                                        $form.find( '.n-datasourcefilter, .n-datasourcefilter-label' ).addClass( 'hide' );
                                    }
                                } ) );
                    }
                } else {
                    element.parent().find( '.n-datasourcecomplexfilter' ).addClass( 'hide' );
                }
                if ( options.compositeSearch !== undefined && options.compositeSearch === true ) {
                    element.find( '.k-pager-wrap' ).append( $( '<a class=\'n-element-selector-grid-composites-filter-link hide\'>Show Composites Filter</a>' ) );
                    element.on( 'click', 'tr[elementid]', function ( event ) {
                        if ( !$compositeGrid.hasClass( 'hide' ) ) {
                            if ( typeID !== parseInt( $( this ).attr( 'elementtype' ), 10 ) ) {
                                clearComposite = confirm( "Are you sure you want to select this element of different type. NOTE: doing so will clear your current composite selection." );
                                if ( clearComposite ) {
                                    element.parent().find( '.n-elementselectorgrid-composite' ).data( 'nmswebElementSelectorGrid' ).dataSource.deselectAll();
                                    element.parent().find( '.n-elementselectorgrid-composite' ).data( 'nmswebElementSelectorGrid' ).refresh();
                                    element.parent().find( '.n-elementselectorgrid-composite' ).addClass( 'hide' );
                                    element.data( 'nmswebElementSelectorGrid' ).dataSource.deselectAll();
                                    element.data( 'nmswebElementSelectorGrid' ).refresh();
                                    element.data( 'nmswebElementSelectorGrid' ).dataSource.selectMem( parseInt( $( this ).attr( 'elementid' ), 10 ) );
                                    element.data( 'nmswebElementSelectorGrid' ).refresh();
                                    element.find( '.n-element-selector-grid-composites-filter-link' ).text( 'Show Composites Filter' );
                                } else {
                                    event.preventDefault();
                                    element.data( 'nmswebElementSelectorGrid' ).dataSource.unselectMem( parseInt( $( this ).attr( 'elementid' ), 10 ) );
                                    element.data( 'nmswebElementSelectorGrid' ).refresh();
                                }
                            }
                        }
                        populateTypesAndFilter( element );
                    } );
                }
                populateTypesAndFilter = function ( grid ) {
                    types = [];
                    filters = [];
                    selectedElements = grid.data( 'nmswebElementSelectorGrid' ).dataSource.getSelectedIds();
                    $.each( selectedElements, function () {
                        typeID = grid.data( 'nmswebElementSelectorGrid' ).dataSource.get( this ).type;
                        if ( $.inArray( typeID, types ) === -1 ) {
                            types.push( typeID );
                        }
                    } );
                    if ( types.length === 1 ) {
                        $.each( types, function ( key, value ) {
                            typeID = value;
                            $.each( grid.data( 'nmswebElementSelectorGrid' ).options.elementMappings, function () {
                                if ( grid.data( 'nmswebElementSelectorGrid' ).options.elementMappings[ typeID ] && grid.data( 'nmswebElementSelectorGrid' ).options.elementMappings[ typeID ].length > 0 ) {
                                    $.each( grid.data( 'nmswebElementSelectorGrid' ).options.elementMappings[ typeID ], function () {
                                        filters.push( this );
                                    } );
                                    return false;
                                }
                            } );
                        } );
                        if ( filters.length > 0 ) {
                            grid.find( '.n-element-selector-grid-composites-filter-link' ).removeClass( 'hide' );
                        } else {
                            grid.find( '.n-element-selector-grid-composites-filter-link' ).addClass( 'hide' );
                        }
                    } else {
                        grid.find( '.n-element-selector-grid-composites-filter-link' ).addClass( 'hide' );
                    }
                };
                element.on( 'click', '.n-element-selector-grid-composites-filter-link', function () {
                    var that = $( this ),
                        $form = element.parents( '.n-configurator-section-form' ),
                        $compositeGrid = element.parent().find( '.n-elementselectorgrid-composite' ),
                        query = {};
                    query.logic = "and";
                    query.filters = [];
                    if ( $compositeGrid.data( 'nmswebElementSelectorGrid' ).options.dbQueryType ) {
                        query.filters.push( {
                            field: 'db_query_type',
                            operator: 'eq',
                            value: $compositeGrid.data( 'nmswebElementSelectorGrid' ).options.dbQueryType
                        } );
                    }
                    query.filters.push( {
                        logic: "or",
                        filters: []
                    } );
                    if ( filters === undefined || filters.length === 0 ) {
                        populateTypesAndFilter( element );
                    }
                    $.each( filters, function ( key ) {
                        query.filters[ query.filters.length - 1 ].filters.push( {
                            field: 'type',
                            operator: 'eq',
                            value: parseInt( filters[ key ], 10 )
                        } );
                    } );
                    $compositeGrid.data( 'nmswebElementSelectorGrid' ).dataSource.filter( query );
                    $compositeGrid.find( '.n-element-selector-element-type-drop' ).remove();
                    $compositeGrid.find( 'nmsweb-management-state-filter' ).hide();
                    $compositeGrid.toggleClass( 'hide' );
                    if ( element.parents( '.n-popover-content' ).first().find( '.n-elementselectorgrid-composite' ).hasClass( 'hide' ) ) {
                        that.text( 'Show Composites Filter' );
                    } else {
                        that.text( 'Hide Composites Filter' );
                        $( '.n-element-selector-grid-advanced-search-link' ).text( 'Advanced Search' );
                        $form.find( '.n-element-selector-grid-power-query-holder, .data-elementselectorgrid-results-panel' ).addClass( 'hide' );
                        element.find( '.overlayarrow, .arrow' ).removeAttr( 'style' ).addClass( 'hide' );
                        $form.find( '.n-datasourcefilter, .n-datasourcefilter-label' ).removeClass( 'advanced' );
                        element.parents( '.n-popover-inner' ).first().
                        find( '.n-popover-title' ).addClass( 'n-popover-no-title' )
                            .find( 'span' )
                            .addClass( 'hide' );
                        element.parents( '.n-configurator-section-form' ).find( '.n-elementselector' )
                            .removeClass( 'advanced' );
                    }
                } );
                element.find( '.k-grid-content' ).css( {
                    'overflow': 'visible'
                } );
                if ( options.actions_url !== null ) {
                    element.on( 'click', '*', function ( e ) {
                        if ( !$( e.target ).hasClass( 'n-splitbutton-choose' ) && !$( e.target ).hasClass( 'caret' ) && !$( e.target ).parent().hasClass( 'disabled' ) ) {
                            $( '.n-element-selector-actions' ).removeClass( 'open' );
                        }
                    } );
                }
                // Grouping ablility has been switched off for 1.0
                // element.on('change', '.n-element-selector-group-drop', function () {
                //  var dataSource = element.data('nmswebElementSelectorGrid').dataSource,
                //      oldFiltering = dataSource.options.serverFiltering;
                //  if (dataSource._data.length > 0) {
                //      dataSource.options.serverFiltering = false;
                //      switch (this.value) {
                //      case 'none':
                //          dataSource.group('');
                //          break;
                //      case 'configuration_state':
                //          dataSource.group('configuration_state');
                //          break;
                //      case 'type':
                //          dataSource.group('type');
                //          break;
                //      }
                //  }
                //  dataSource.options.serverFiltering = oldFiltering;
                // });
                getFilters = function ( value, filterType ) {
                    return $.map( new Array( 3 ), function ( val, i ) {
                        var type = [ 'string', 'ip', 'did' ],
                            field = [ 'obj_name', 'ip', 'did' ],
                            operator = ( filterType === 'DS' ) ? [ 'contains', 'startswith', 'startswith' ] : [ 'contains', 'is', 'eq' ];
                        if ( filterType === 'DS' ) {
                            return {
                                type: type[ i ],
                                field: field[ i ],
                                operator: operator[ i ],
                                value: value
                            };
                        } else {
                            return {
                                field: field[ i ],
                                operator: operator[ i ],
                                value: value
                            };
                        }
                    } );
                };
                var generateFilterJson = function ( $parent, level ) {
                    var logic = $( 'select[name=logic]', $parent ).val(),
                        filters = [];
                    $( '.fields:first', $parent ).children().each( function () {
                        var $this = $( this ),
                            field,
                            operator,
                            value,
                            value2;
                        if ( $this.hasClass( 'field' ) ) {
                            field = $( 'select[name=field]', $this ).val();
                            operator = $( 'select[name=operator]', $this ).val();
                            value = $( 'input[name=value]', $this ).val();
                            value2 = $( 'input[name=value2]', $this ).val();
                            if ( value2 !== '' ) {
                                value = value + ', ' + value2;
                            }
                            filters.push( {
                                'field': field,
                                'operator': operator,
                                'value': value
                            } );
                        } else if ( $this.hasClass( 'group' ) ) {
                            filters.push( generateFilterJson( $this, level + 1 ) );
                        }
                    } );
                    if ( filters.length === 1 ) {
                        return filters;
                    } else {
                        return {
                            'logic': logic,
                            'filters': filters
                        };
                    }
                };
                doATypeFilter = function ( typeFilter, outsideCall ) {
                    if ( typeFilter ) {
                        var eleSelGrid = element.data( 'nmswebElementSelectorGrid' ),
                            dataSource = eleSelGrid.dataSource,
                            dsOpts = dataSource.options,
                            initialFilter = dsOpts.initialFilter,
                            isInPopOver = ( element.parents( '.n-popover-content' ).length > 0 ),
                            dataSrcFilterVal = element.parent().find( '.input-large' ).val(),
                            eleSelVal = $( '.n-search.n-elementselector' ).find( '.input-large' ).val(),
                            globalAdvancedSearchOpen = false,
                            advancedSearchOpen = ( element.parent().prev( '.n-element-selector-grid-power-query-holder' ).length > 0 && !element.parent().prev( '.n-element-selector-grid-power-query-holder' ).hasClass( 'hide' ) ),
                            elType = "",
                            filters = [],
                            subFilters = [],
                            query,
                            val;
                        dataSource.typeFilterInProgress = true;
                        if ( isInPopOver && eleSelVal !== '' ) {
                            elType = "GS";
                            val = eleSelVal;
                        } else {
                            elType = "DS";
                            val = dataSrcFilterVal;
                        }
                        if ( initialFilter ) {
                            filters.push( {
                                logic: "and",
                                filters: initialFilter
                            } );
                        }

                        if ( advancedSearchOpen || globalAdvancedSearchOpen ) {
                            var $parent = element.parent().prev( '.n-element-selector-grid-power-query-holder' );
                            if ( globalAdvancedSearchOpen ) {
                                $parent = $( '#n-element-selector-global-search-popover' );
                            }
                            console.log( $parent );
                            $.each( $( '.group', $parent ), function ( key, index ) {
                                var thisFilter = generateFilterJson( $( index ) );
                                if ( $( '.group', $parent ).length === 1 ) {
                                    subFilters = thisFilter;
                                } else {
                                    subFilters.push( thisFilter );
                                }
                            } );
                        } else {
                            subFilters = {
                                logic: "or",
                                filters: getFilters( val, elType )
                            };
                        }
                        if ( filters.length ) {
                            filters.push( subFilters );
                            query = {
                                logic: "and",
                                filters: filters
                            };
                        } else {
                            query = subFilters;
                        }

                        if ( dsOpts.serverFilteringOrg === undefined ) {
                            dsOpts.serverFilteringOrg = dsOpts.serverFiltering;
                        }
                        if ( dataSource._dataCached === undefined ) {
                            dataSource._dataCached = dataSource._data;
                        } else {
                            dataSource.data( dataSource._dataCached );
                            if ( !( dataSource._ranges && dataSource._ranges[ 0 ] ) ) {
                                dataSource._ranges = [];
                            }
                            dataSource._ranges[ 0 ].data = dataSource._data;
                            dataSource._ranges[ 0 ].end = dataSource._data.length;
                        };

                        dsOpts.serverFiltering = false;
                        if ( typeFilter === 'all' && dataSource._dataCached ) {
                            dataSource.filter( [] );
                            dataSource._filter = query;
                            window.nmsweb.DataSources[ dataSource.id ]._cached = undefined;
                        } else {
                            var query = new window.kendo.data.Query( dataSource.data() ),
                                filters = {
                                    logic: "and",
                                    filters: [ {
                                        logic: "or",
                                        filters: [ {
                                            field: 'type',
                                            operator: 'eq',
                                            value: parseInt( typeFilter, 10 )
                                    } ]
                                } ]
                                },
                                cached = query.filter( filters ).data;
                            window.nmsweb.DataSources[ that.dataSource.id ]._cached = cached;
                            dataSource.filter( filters );
                            dataSource.data( dataSource.filterData() );
                            if ( !( dataSource._ranges && dataSource._ranges[ 0 ] ) ) {
                                dataSource._ranges = [];
                            }
                            dataSource._ranges[ 0 ].data = dataSource._data.slice();
                            dataSource._ranges[ 0 ].end = dataSource._data.length;
                        }
                        dsOpts.serverFiltering = dsOpts.serverFilteringOrg;
                        $( '.k-scrollbar-vertical', element ).scrollTop( 0 );
                        dataSource.typeFilterInProgress = false;
                        if ( outsideCall === undefined || outsideCall === false ) {
                            that.element.find( 'nmsweb-management-state-filter select' ).change();
                        }
                        dataSource.trigger( "typeFilterDone" );
                    }
                };
                sortSelect = function ( selElem ) {
                    var myOptions = selElem.find( 'option:not([value="all"])' ),
                        allOption = selElem.find( 'option[value="all"]' );
                    myOptions.sort( function ( a, b ) {
                        if ( a.text.toLowerCase() > b.text.toLowerCase() ) {
                            return 1;
                        } else if ( a.text.toLowerCase() < b.text.toLowerCase() ) {
                            return -1;
                        } else {
                            return 0;
                        }
                    } );
                    selElem.empty().append( allOption ).append( myOptions );
                    selElem.val( 'all' );
                };
                element.on( 'change', '.n-element-selector-element-type-drop', function ( event, outsideCall ) {
                    var that = $( this ),
                        val = that.val();
                    doATypeFilter( val, outsideCall );
                } );
                element.parent().find( '.input-large' ).on( 'input', function () {
                    var $dropDown = element.find( '.n-element-selector-element-type-drop' ),
                        eleSelGrid = element.data( 'nmswebElementSelectorGrid' ),
                        dataSource = eleSelGrid.dataSource;
                    dataSource.deselectAll();
                    eleSelGrid.clearSelection();
                    //$dropDown.val('all');
                    // $dropDown.find('option[value="all"]').trigger('click');
                    dataSource._dataCached = undefined;
                    dataSource._cached = undefined;
                    $dropDown.find( 'option:selected' ).removeAttr( 'selected' );
                    $dropDown.find( 'option[value="all"]' ).attr( 'selected', true );
                    //$dropDown.find('option:eq(0)').prop('selected', true);
                    $dropDown.val( 'all' );
                    that.element.change();
                    // console.log('inputting');
                } );
                element.on( 'mousedown', '.n-element-selector-monitor,.n-element-selector-report', function ( e ) {
                    e.preventDefault();
                    var $tr = $( this ).parents( 'tr' );
                    $( this ).attr( 'href', $( this ).attr( 'href' ) + "?shared=1&Element_Selector=" + $tr.attr( 'elementid' ) );
                    if ( e.button === 0 ) {
                        window.location = $( this ).attr( 'href' );
                    }
                } );
                // element.on( 'change', 'nmsweb-management-state-filter select', function () {
                //     // when changed, let's see if we disable/enable group actions dropdown
                //     if ( this.type === 'select-one' && selectedGridRows.length > 1 ) {
                //         var deferred = $.Deferred();
                //         deferred.done( function ( value ) {
                //             toggleGroupActionButton( groupButtonDropdown, value, element.data( 'nmswebElementSelectorGrid' ), selectedGridRows[ 0 ].typeId );
                //         } );
                //         setTimeout( function () {
                //             // http://www.telerik.com/forums/get-filtered-data-from-paged-grid#5W_6Z_pBmkOmuEV3ZVd8jw
                //             var data = element.data( 'nmswebElementSelectorGrid' ).dataSource.data(),
                //                 query = new kendo.data.Query( data );
                //             data = query.filter( element.data( 'nmswebElementSelectorGrid' ).dataSource.filter() ).data;
                //             if ( selectedGridRows.length < 2 ) {
                //                 deferred.resolve( false );
                //             } else {
                //                 // first check if all selected objects are the same type at all
                //                 // if they are, check if at least two of them is displayed
                //                 var firstType = selectedGridRows[ 0 ].typeId,
                //                     countDisplayed = 0,
                //                     deferedResolved = false;
                //                 $.each( selectedGridRows, function ( index, selectedRow ) {
                //                     if ( selectedRow.typeId !== firstType ) {
                //                         deferred.resolve( false );
                //                         deferedResolved = true;
                //                         return false;
                //                     } else if ( deferedResolved === false ) {
                //                         $.each( data, function ( index, displayedRow ) {
                //                             if ( displayedRow.id === selectedRow.objId ) {
                //                                 countDisplayed++;
                //                                 return false;
                //                             }
                //                         } );
                //                     }
                //                 } );
                //                 if ( deferedResolved === false ) {
                //                     if ( countDisplayed > 1 ) {
                //                         deferred.resolve( true );
                //                     } else {
                //                         deferred.resolve( false );
                //                     }
                //                 }
                //             }
                //         }, 10 );
                //     }
                // } );
                if ( options.actions && hierarchyIndex !== undefined && hierarchyIndex !== null && options.actions[ hierarchyIndex ].url && options.actions[ hierarchyIndex ].url !== null ) {
                    element.on( 'click', '.n-element-selector-hierarchy, .n-hierarchy-builder-div ul.dropdown-menu span.tree-builder-tree-option', function ( e ) {
                        // if clicked on one of the span while disabled, we shouldn't do anyting
                        if ( $( e.target ).attr( 'disabled' ) ) {
                            e.preventDefault();
                            return;
                        }
                        var $tree,
                            $parentHierarchyBuilderDiv = $( e.target ).parents( '.n-hierarchy-builder-div' ),
                            $hierarchyButton = $parentHierarchyBuilderDiv.find( 'button.n-element-selector-hierarchy' ),
                            $spans = $parentHierarchyBuilderDiv.find( '.tree-builder-options span' ),
                            $popover,
                            $tr = $hierarchyButton.parents( 'tr' ),
                            obj_id = $tr.attr( 'elementid' ),
                            mimic = function () {
                                if ( $( '.n-popoverbody[data-hierarchy-popover=' + obj_id + '] .n-elementselector-hierarchy-popover .k-treeview' ).data() === null ) {
                                    setTimeout( mimic, 300 );
                                } else {
                                    $( '.n-popoverbody[data-hierarchy-popover=' + obj_id + '] .n-elementselector-hierarchy-popover .k-treeview' ).data( "kendoTreeView" ).bind( "expand", function () {
                                        setTimeout( function () {
                                            $( '.n-popoverbody[data-hierarchy-popover=' + obj_id + '] .n-elementselector-hierarchy-popover' ).spin( false );
                                        }, 100 );
                                    } );
                                    $( '.n-popoverbody[data-hierarchy-popover=' + obj_id + '] .n-elementselector-hierarchy-popover .k-treeview' ).data( "kendoTreeView" ).expand( '.k-item' );
                                }
                            },
                            hierarchyUrl;
                        var $popoverBodyFound = $( '.n-popoverbody[data-hierarchy-popover=' + obj_id + ']' );
                        if ( $popoverBodyFound.length === 1 ) {
                            var $treeViewBodyPart = $popoverBodyFound.find( '.k-treeview' );
                            if ( $popoverBodyFound.hasClass( 'hide' ) && $treeViewBodyPart.data( 'kendoTreeView' ) !== null ) {
                                $treeViewBodyPart.data( 'kendoTreeView' ).collapse( '.k-item' );
                            } else if ( $treeViewBodyPart.data( 'kendoTreeView' ) !== null ) {
                                $treeViewBodyPart.data( 'kendoTreeView' ).expand( '.k-item' );
                                $.each( $( '.n-popoverbody[data-hierarchy-popover]' ), function () {
                                    if ( $( this ).attr( 'data-hierarchy-popover' ) !== obj_id ) {
                                        $( this ).addClass( 'hide' );
                                    }
                                } );
                            }
                        }
                        hierarchyUrl = options.actions[ hierarchyIndex ].url + '?obj_id=' + obj_id + '&children=2';
                        $popover = $parentHierarchyBuilderDiv.nmswebPopover( {
                            'data': {
                                'hierarchy-popover': obj_id
                            },
                            'placement': 'right',
                            'title': 'Element Hierarchy',
                            'exclusive': false,
                            'nested': true,
                            'persistent': true,
                            'toggle': false,
                            'manual': true,
                            'content': $( '<div class="n-elementselector-hierarchy-popover"></div>' )
                        } );
                        if ( options.dbQueryType !== undefined ) {
                            hierarchyUrl += '&db_query_type=' + options.dbQueryType;
                        }
                        // part for enabling/disabling buttons/spans based on clicked item
                        if ( $( e.target ).data() !== undefined && $( e.target ).data().treeType !== undefined ) {
                            var treeType = $( e.target ).data().treeType;
                            hierarchyUrl += '&type=' + treeType;
                            if ( $( e.target ).attr( 'disabled' ) === undefined ) {
                                $( e.target ).attr( 'disabled', 'disabled' );
                                if ( e.target.type !== 'button' ) {
                                    // enable rest of the dropdown items
                                    $.each( $spans, function ( index, span ) {
                                        if ( $( span ).data() !== undefined && $( span ).data().treeType !== treeType ) {
                                            $( span ).removeAttr( 'disabled' );
                                        }
                                    } );
                                    // enable button if clicked tree type is different than it's one
                                    if ( $hierarchyButton.data().treeType !== treeType ) {
                                        $hierarchyButton.removeAttr( 'disabled' );
                                    } else {
                                        $hierarchyButton.attr( 'disabled', 'disabled' );
                                    }
                                } else {
                                    // if clicked on button, enable all spans (except the one which has same tree type as button)
                                    $.each( $spans, function ( index, span ) {
                                        if ( $( span ).data() !== undefined && $( span ).data().treeType === $hierarchyButton.data().treeType ) {
                                            $( span ).attr( 'disabled', 'disabled' );
                                        } else {
                                            $( span ).removeAttr( 'disabled' );
                                        }
                                    } );
                                }
                            }
                            $parentHierarchyBuilderDiv.data().currentTreeType = treeType;
                        }
                        $( '.n-popoverbody[data-hierarchy-popover=' + obj_id + ']' ).removeClass( "hide" );
                        $( '.n-popoverbody[data-hierarchy-popover=' + obj_id + '] .n-elementselector-hierarchy-popover' ).spin();
                        $.ajax( {
                            'type': 'GET',
                            'url': hierarchyUrl,
                            'success': function ( data ) {
                                if ( data[ 0 ].subordinates !== undefined && data[ 0 ].subordinates.length > 0 ) {
                                    $( '.double-nested' ).remove();
                                    $tree = that.getTree( that._getHierarchyTreeData( data[ 0 ], obj_id ) );
                                    $( '.n-popoverbody[data-hierarchy-popover=' + obj_id + '] .n-elementselector-hierarchy-popover' ).append( $tree );
                                    mimic();
                                } else {
                                    $tree = $( '<h4>Element has no children.</h4>' );
                                    $( '.n-popoverbody[data-hierarchy-popover=' + obj_id + '] .n-elementselector-hierarchy-popover' ).append( $tree );
                                }
                                $popover = $( '.n-popoverbody[data-hierarchy-popover=' + obj_id + ']' ).addClass( 'right' );
                                $.each( $( '.n-popoverbody[data-hierarchy-popover]' ), function () {
                                    if ( $( this ).attr( 'data-hierarchy-popover' ) !== obj_id ) {
                                        $( this ).addClass( 'hide' );
                                    } else {
                                        $( this ).removeClass( 'hide' );
                                    }
                                } );
                                that.addConfigPopover( $popover );
                                // add listener if clicked outside of popover
                                $( document ).on( 'click.popover', function ( e ) {
                                    if ( e.isDefaultPrevented() === true ) {
                                        return;
                                    }
                                    var button = $( '.n-element-selector-hierarchy[element=' + $popover.data().hierarchyPopover + ']' ),
                                        parentDivHolder = button.parents( '.n-hierarchy-builder-div' ),
                                        targetParentDivHolder = $( e.target ).parents( '.n-hierarchy-builder-div' ),
                                        dropdownOptions = button.siblings( 'ul' ).find( 'span' );
                                    // if clicked close of popover, enable all
                                    if ( $( e.target ).closest( 'div[data-hierarchy-popover="' + obj_id + '"]' ).find( 'a.close' )[ 0 ] === e.target ) {
                                        $popover.remove();
                                        $.each( dropdownOptions, function ( index, span ) {
                                            $( span ).removeAttr( 'disabled' );
                                        } );
                                        button.removeAttr( 'disabled' );
                                    } else if ( !$( e.target ).closest( 'div[data-hierarchy-popover="' + obj_id + '"]' ).length ) {
                                        $popover.remove();
                                        $.each( dropdownOptions, function ( index, span ) {
                                            // if clicked item has same type don't disable it (or some other hierarchy button is clicked)
                                            if ( targetParentDivHolder[ 0 ] !== parentDivHolder[ 0 ] ||
                                                ( $( e.target ).data === undefined || $( span ).data().treeType !== $( e.target ).data().treeType ) ) {
                                                $( span ).removeAttr( 'disabled' );
                                            }
                                        } );
                                        if ( $( e.target ).data !== undefined && $( e.target ).data().treeType !== button.data().treeType ) {
                                            button.removeAttr( 'disabled' );
                                        } else if ( $( e.target ).data === undefined || $( e.target ).data().treeType === undefined ) {
                                            button.removeAttr( 'disabled' );
                                        } else if ( targetParentDivHolder[ 0 ] === parentDivHolder[ 0 ] ) {
                                            button.attr( 'disabled', 'disabled' );
                                        } else {
                                            button.removeAttr( 'disabled' );
                                        }
                                        $( document ).off( 'click.popover' );
                                        parentDivHolder.data().currentTreeType = undefined;
                                    }
                                } );
                            }
                        } );
                    } );
                }
                element.on( 'click', '.n-element-selector-tree-toggle-button-tree', function () {
                    var $treeContainer = $( this ).parents( '.n-element-selector-toggle-holder' ).find( '.n-tree-builder-div .btn-group.orgchart' ),
                        treeBuilderOptions = $treeContainer.parent().find( '.tree-builder-options' );
                    $( this ).parents( '.n-element-selector-toggle-holder' ).find( '.n-element-selector-tree-toggle-button-orgchart-tree' ).removeAttr( 'disabled' );
                    $treeContainer.find( 'button.default' ).removeAttr( 'disabled' );
                    if ( treeBuilderOptions && treeBuilderOptions.length > 0 ) {
                        var options = treeBuilderOptions.find( 'span' ),
                            optionLength = options.length,
                            i;
                        for ( i = 0; i < optionLength; i++ ) {
                            $( options[ i ] ).removeAttr( 'disabled' );
                        }
                    }
                    $( '.n-popoverbody:not("#n-element-selector-global-search-popover")' ).addClass( 'hide' );
                    element.data( 'nmswebElementSelectorGrid' )._displayTree( this );
                } );
                element.on( 'click', '.n-element-selector-tree-toggle-button-orgchart-tree', function () {
                    var $treeContainer = $( this ).parents( '.n-element-selector-toggle-holder' ).find( '.n-tree-builder-div .btn-group:not(.orgchart)' ),
                        treeBuilderOptions = $treeContainer.parent().find( '.tree-builder-options' );
                    $( this ).parents( '.n-element-selector-toggle-holder' ).find( '.n-element-selector-tree-toggle-button-tree' ).removeAttr( 'disabled' );
                    $treeContainer.find( 'button.default' ).removeAttr( 'disabled' );
                    if ( treeBuilderOptions && treeBuilderOptions.length > 0 ) {
                        var options = treeBuilderOptions.find( 'span' ),
                            optionLength = options.length,
                            i;
                        for ( i = 0; i < optionLength; i++ ) {
                            $( options[ i ] ).removeAttr( 'disabled' );
                        }
                    }
                    $( '.n-popoverbody:not("#n-element-selector-global-search-popover")' ).addClass( 'hide' );
                    element.data( 'nmswebElementSelectorGrid' )._displayTree( this, true );
                } );
                element.on( 'click', '.n-element-selector-tree-toggle-button-list', function () {
                    $( '.n-popoverbody:not("#n-element-selector-global-search-popover")' ).addClass( 'hide' );
                    $( this ).prop( 'disabled', true );
                    var $treeContainer = $( this ).parents( '.n-element-selector-toggle-holder' ).find( '.n-tree-builder-div' ),
                        treeBuilderOptions = $treeContainer.parent().find( '.tree-builder-options' );
                    $( this ).parents( '.n-element-selector-toggle-holder' ).find( '.n-element-selector-tree-toggle-button-orgchart-tree' ).removeAttr( 'disabled' );
                    $treeContainer.find( 'button.default' ).removeAttr( 'disabled' );
                    if ( treeBuilderOptions && treeBuilderOptions.length > 0 ) {
                        var options = treeBuilderOptions.find( 'span' ),
                            optionLength = options.length,
                            i;
                        for ( i = 0; i < optionLength; i++ ) {
                            $( options[ i ] ).removeAttr( 'disabled' );
                        }
                    }
                    element.find( '.tree-content' ).addClass( 'hide' );
                    element.find( '.k-grid-content' ).removeAttr( 'style' ).removeClass( 'hide' )
                        .attr( 'style', "width: auto; padding-right: 22px; overflow: visible;" );
                    element.find( '.k-pager-wrap' ).removeAttr( 'style' ).removeClass( 'hide' );
                    element.find( ':contains("There is currently no data available to generate tree view.")' ).closest( '.n-warning-notification' ).trigger( 'click' );
                } );
                if ( $resultsPanel.length > 0 ) {
                    that.dataSource.bind( 'change', function () {
                        var total = this.total(),
                            pluralSuffix = ( total === 1 ) ? '' : 's';
                        $( '.results-total', $resultsPanel ).text( total );
                        $( '.results-plural-suffix', $resultsPanel ).text( pluralSuffix );
                    } );
                    $( '.save-query-action', $resultsPanel ).on( 'click', function ( e ) {
                        e.preventDefault();
                    } ).nmswebPopover( {
                        'hoverdelay': true,
                        'titletextbackgroundcolor': '#C3C3C3',
                        'placement': 'right',
                        'exclusive': false,
                        'title': 'Save As Preset',
                        'manual': true,
                        'nested': true,
                        'tooltiptitle': 'Help',
                        'tooltip': $( '<p>Define a preset name for the Query.</p>' ),
                        'content': that._generateSavePresetContent( function () {
                            var filter = that.dataSource.filter();
                            return filter;
                        }, 'query' )
                    } );
                    var setUpSaveResultsAction = function () {
                        $( '.save-results-action', $resultsPanel ).on( 'click', function ( e ) {
                            e.preventDefault();
                            that.dataSource.selectAll();
                        } ).nmswebPopover( {
                            'hoverdelay': true,
                            'titletextbackgroundcolor': '#C3C3C3',
                            'placement': 'right',
                            'title': 'Save As Preset',
                            'manual': true,
                            'exclusive': false,
                            'nested': true,
                            'tooltiptitle': 'Help',
                            'tooltip': $( '<p>Define a preset name for the Search Results.</p>' ),
                            'content': that._generateSavePresetContent( function () {
                                var allRows = that.dataSource.data(),
                                    filter = {
                                        logic: 'or',
                                        filters: []
                                    };
                                $.each( allRows, function () {
                                    filter.filters.push( {
                                        field: this.idField,
                                        operator: 'eq',
                                        value: this[ this.idField ]
                                    } );
                                } );
                                return filter;
                            }, 'results' )
                        } );
                    };
                    setUpSaveResultsAction();
                    $( 'body' ).one( 'ElementSelector:submit', function () {
                        setUpSaveResultsAction();
                    } );
                }
                this.bind( 'dataBound', function () {
                    $( element ).find( '.k-grid-content tr' ).trigger( 'angularCompile' );
                } );
                this.bind( 'dataBinding', function () {
                    if ( !$( element ).find( '.k-grid-toolbar .ng-isolate-scope' ).length ) {
                        $( element ).find( '.k-grid-toolbar' ).trigger( 'angularCompile' );
                    }
                } );
                if ( this.dataSource ) {
                    this.dataSource.bind( 'change', function () {
                        that.element.find( 'nmsweb-management-state-filter' ).show();
                        if ( element.data( 'nmswebElementSelectorGrid' )._data && element.data( 'nmswebElementSelectorGrid' )._data.length > 0 ) {
                            that.element.find( '.n-select.n-element-selector-element-type-drop' ).removeClass( "hide" );
                        }
                        if ( this.typeFilterInProgress ) {
                            return;
                        }
                        element.removeAttr( 'data-treeUpdated' );
                        element.removeAttr( 'data-currentTree' );
                        if ( _filterTimer ) {
                            clearTimeout( _filterTimer );
                        }
                        var treeType = element.attr( 'data-currenttree' );
                        // that.dataSource.options.serverFiltering is false for mangement states update interval
                        if ( //that.dataSource.options.serverFiltering &&
                            element.find( '.n-element-selector-toggle-holder .btn-group.orgchart span[disabled="disabled"]' ).length ) {
                            element.data( 'nmswebElementSelectorGrid' )._displayTree( element.find( '.n-element-selector-tree-toggle-button-tree' ), treeType, true );
                            element.attr( 'data-currentTree', treeType );
                            element.attr( 'data-treeUpdated', true );
                        } else if ( //that.dataSource.options.serverFiltering &&
                            element.find( '.n-element-selector-toggle-holder .btn-group span[disabled="disabled"]' ).length ) {
                            var span = element.find( '.n-element-selector-tree-toggle-button-tree' ).parent().find( "span[disabled='disabled']" );
                            element.data( 'nmswebElementSelectorGrid' )._displayTree( span, treeType );
                            element.attr( 'data-currentTree', treeType );
                            element.attr( 'data-treeUpdated', true );
                        }
                    } );
                }
                this.dataSource.bind( 'doATypeFilter', function ( outsideCall ) {
                    element.find( '.n-element-selector-element-type-drop' ).trigger( 'change', outsideCall );
                } );
                this.dataSource.bind( 'typeFilterDone', function () {
                    if ( element.find( '.n-element-selector-tree-toggle-button-tree' ).not( ':disabled' ).length &&
                        element.find( '.n-element-selector-tree-toggle-button-orgchart-tree' ).not( ':disabled' ).length ) {
                        return;
                    }
                    element.removeAttr( 'data-treeUpdated' );
                    element.removeAttr( 'data-currentTree' );
                    if ( _filterTimer ) {
                        clearTimeout( _filterTimer );
                    }
                    if ( element.find( '.n-element-selector-tree-toggle-button-orgchart-tree' ).is( ':disabled' ) || element.find( '.n-element-selector-tree-toggle-button-tree' ).is( ':disabled' ) ) {
                        element.data( 'nmswebElementSelectorGrid' )._displayTree( element.find( '.n-element-selector-tree-toggle-button-tree' ), undefined, element.find( '.n-element-selector-tree-toggle-button-orgchart-tree' ).is( ':disabled' ) );
                    }
                } );
                if ( options.initialFilter && options.initialFilterFireOnLoad ) {
                    if ( window._presetDefined === undefined ) {
                        if ( options.selectResult ) {
                            that.dataSource.one( 'change', function () {
                                that.dataSource.selectAll();
                                var submit_button = that.element
                                    .closest( '.n-configurator-section-form' )
                                    .find( '.n-configurator-apply-change-button' );
                                if ( !window.callbacksReady ) {
                                    $( document ).on( 'callbacksReady', function () {
                                        submit_button.trigger( 'click' );
                                    } );
                                } else {
                                    submit_button.trigger( 'click' );
                                }
                            } );
                        }
                    } else {
                        that.dataSource._initialFilter = options.initialFilter;
                    }
                }
                this._actionClickHandler( element );
                that.addConfigPopover( element );
                that.removePopOverClose( element );
            },
            _displayTree: function ( button, type, orgchart ) {
                var that = this,
                    element = that.element,
                    treeBuilderOptions = $( button ).parents( '.n-tree-builder-div' ).find( '.tree-builder-options' ),
                    $treeContainer = element.find( '.tree-content' ),
                    mimic = function () {
                        if ( $( '.n-element-selector-grid-element-hierarchy-holder .k-treeview' ).data() === null ) {
                            setTimeout( mimic, 300 );
                        } else {
                            $( '.n-element-selector-grid-element-hierarchy-holder .k-treeview' ).data( "kendoTreeView" ).bind( "change", function () {
                                $( '.n-element-selector-grid-hierarchy-holder' ).spin( false );
                            } );
                            $( '.n-element-selector-grid-element-hierarchy-holder .k-treeview' ).data( "kendoTreeView" ).select( $() );
                        }
                    };
                if ( treeBuilderOptions && treeBuilderOptions.length > 0 && element.data( 'nmswebElementSelectorGrid' )._data.length > 0 && type === undefined ) {
                    if ( treeBuilderOptions.attr( 'tree-builder-options-opened' ) && treeBuilderOptions.attr( 'tree-builder-options-opened' ) !== "false" ) {
                        treeBuilderOptions.hide();
                        treeBuilderOptions.attr( 'tree-builder-options-opened', false );
                    } else if ( !treeBuilderOptions.attr( 'tree-builder-options-opened' ) || treeBuilderOptions.attr( 'tree-builder-options-opened' ) === "false" ) {
                        treeBuilderOptions.show();
                        treeBuilderOptions.attr( 'tree-builder-options-opened', true );
                    }
                } else {
                    if ( element.data( 'nmswebElementSelectorGrid' )._data.length > 0 ) {
                        if ( button ) {
                            $( button ).prop( 'disabled', true )
                                .parents( '.n-element-selector-toggle-holder' )
                                .find( '.n-element-selector-tree-toggle-button-list' )
                                .removeAttr( 'disabled' );
                            // enable rest of the types
                            if ( treeBuilderOptions && treeBuilderOptions.length > 0 ) {
                                var options = $( button ).parents( 'ul' ).find( 'span' ),
                                    optionLength = options.length,
                                    i;
                                treeBuilderOptions.attr( 'tree-builder-options-opened', false );
                                for ( i = 0; i < optionLength; i++ ) {
                                    if ( $( options[ i ] ).data().treeType !== type ) {
                                        $( options[ i ] ).removeAttr( 'disabled' );
                                    }
                                }
                            }
                        }
                        element.find( '.k-grid-content' ).addClass( 'hide' );
                        $treeContainer.removeClass( 'hide' );
                        element.find( '.k-pager-wrap' ).addClass( 'hide' );
                        //if ( !element.attr( 'data-treeUpdated' ) ) {
                        //Disable condition to allow switching between tree and orgchart
                        if ( orgchart ) {
                            that.getTreeContent( element, type, orgchart );
                        } else {
                            $treeContainer.html( that.getTreeContent( element, type ) );
                            $( '.n-element-selector-grid-hierarchy-holder' ).spin();
                            element.attr( 'data-treeUpdated', true );
                            mimic( '.n-element-selector-grid-element-hierarchy-holder .k-treeview', '.n-element-selector-grid-hierarchy-holder' );
                        }
                        //}
                    } else {
                        element.trigger( 'nmsweb:notify', {
                            type: 'warning',
                            title: 'Not available at this time',
                            message: 'There is currently no data available to generate tree view.',
                            isFadeable: false
                        } );
                    }
                }
            },
            _showActionDrop: function ( $this ) {
                if ( $this.parents( '.n-element-selector-actions' ).hasClass( 'open' ) ) {
                    $( '.n-element-selector-actions' ).removeClass( 'open' );
                } else {
                    $( '.n-element-selector-actions' ).removeClass( 'open' );
                    $this.parents( '.n-element-selector-actions' ).addClass( 'open' );
                }
            },
            _configureTreeBehaviour: function ( $tree ) {
                var that = this;
                $tree.find( '.n-element-selector-grid-tree-node' ).on( 'click', function () {
                    var $node = $( this ),
                        $elementContent,
                        limit = 3,
                        count = 0,
                        action,
                        actionsToDisplay,
                        objectId = parseInt( $node.data( 'identity' ), 10 ),
                        objectModel = $node.data( 'model' ),
                        objectName = $node.data( 'name' ),
                        objectType = $node.data( 'type' ),
                        elemData = that.dataSource.get( parseInt( $node.data( 'identity' ), 10 ) );
                    if ( !elemData && objectId && objectName && objectModel ) {
                        elemData = {};
                        elemData.obj_id = objectId;
                        elemData.obj_name = objectName;
                        elemData.model = objectModel;
                        elemData.type = objectType;
                    }
                    if ( !$node.hasClass( 'n-popover' ) ) {
                        $elementContent = $( '<div class="n-element-selector-hierarchy-context-menu-holder"></div>' );
                        actionsToDisplay = that.options.actions.slice();
                        $.each( actionsToDisplay, function () {
                            if ( this && this.action && this.action === 'hierarchy' ) {
                                actionsToDisplay.splice( actionsToDisplay.indexOf( this ), 1 );
                            }
                        } );
                        if ( actionsToDisplay.length > 0 ) {
                            $.each( actionsToDisplay, function () {
                                action = this;
                                if ( count === limit ) {
                                    return false;
                                }
                                if ( action.action !== 'hierarchy' ) {
                                    if ( elemData ) {
                                        if ( action.url ) {
                                            if ( action.url.indexOf( '#= obj_id #' ) !== -1 ) {
                                                action.url.replace( '#= obj_id #', elemData.obj_id );
                                            }
                                            $elementContent.append( $( '<a element="' + elemData.obj_id + '" target="" href="' + action.url + ' " class="btn n-element-selector-' + action.field + ' n-element-selector-btn">' + action.title + '</a>' ) );
                                        } else {
                                            $elementContent.append( $( '<button element="' + elemData.obj_id + '" disabled="disabled" class="btn n-element-selector-' + action.field + ' n-element-selector-btn">' + action.title + '</button>' ) );
                                        }
                                    }
                                    count++;
                                }
                            } );
                        }
                        $elementContent.append( '<nmsweb-actionsbutton obj-id="' + elemData.obj_id + '" type-id="' + elemData.type + '"></nmsweb-actionsbutton>' );
                        $( '.n-element-selector-hierarchy-context-menu-holder' ).parents( '.n-popoverbody' ).remove();
                        $node.parents( '.k-treeview' ).find( '.n-popover' ).removeClass( '.n-popover' );
                        $node.nmswebPopover( {
                            'placement': 'right',
                            'manual': true,
                            'toggle': true,
                            'nested': true,
                            'cssclass': 'double-nested',
                            'exclusive': false,
                            'showOnCreation': true,
                            'persistent': false,
                            'content': $elementContent
                        } );
                        $elementContent.trigger( 'angularCompile' );
                        $( '.n-element-selector-hierarchy-context-menu-holder' ).parents( '.n-popover-inner' ).find( 'h3' ).remove();
                        $( '.n-element-selector-hierarchy-context-menu-holder .n-splitbutton-choose' ).on( 'click', function () {
                            var $this = $( this );
                            that._showActionDrop( $this );
                            if ( $this.data( 'actions-retrieved' ) === undefined || $this.data( 'actions-retrieved' ) === 0 ) {
                                that.retrieveActions( $this, elemData );
                            }
                        } );
                    }
                } );
            },
            val: function ( elements ) {
                var ret = {},
                    that = this,
                    comps,
                    a,
                    newComp,
                    compIDs;
                if ( typeof elements === 'string' ) {
                    elements = JSON.parse( elements );
                }
                //this becomes very hard setting a preset of composite IDs. Something very special needs to happen with the two grids.
                if ( typeof this.options.valCallback === 'function' ) {
                    ret = $.proxy( this, this.options.valCallback( elements ) );
                } else {
                    if ( elements && !elements.composite ) {
                        var dsFilter = {};
                        dsFilter.filters = [];
                        if ( elements.query ) {
                            dsFilter = elements.query;
                        } else {
                            dsFilter.logic = "or";
                            $.each( elements.elements, function () {
                                var elementID = this;
                                if ( elementID !== null ) {
                                    dsFilter.filters.push( {
                                        "operator": "eq",
                                        "field": "element_id",
                                        "value": elementID.toString()
                                    } );
                                }
                            } );
                        }
                        if ( dsFilter.filters.length > 0 ) {
                            var ds = this.element.data( 'nmswebElementSelectorGrid' ).dataSource,
                                requestEndEvent,
                                setPresetEsValue = function ( elementsCopy ) {
                                    var requestInProgressInterval = setInterval( function () {
                                        if ( !ds._requestInProgress ) {
                                            if ( !elementsCopy.query && elementsCopy.elements && elementsCopy.elements.length ) {
                                                that.forceSelect( elementsCopy.elements );
                                            }
                                            clearInterval( requestInProgressInterval );
                                        }
                                    }, 100 );
                                    ds.filter( dsFilter );
                                };
                            if ( ds.options.initialFilter !== undefined && ds.options.initialFilter !== '' ) {
                                var newFilters = [];
                                $( ds.options.initialFilter ).each( function () {
                                    newFilters.push( this );
                                } );
                                newFilters = {
                                    logic: 'and',
                                    filters: newFilters
                                };
                                newFilters = {
                                    logic: 'and',
                                    filters: [ newFilters, dsFilter ]
                                };
                                dsFilter = newFilters;
                            }
                            ds.options.serverFiltering = true;

                            var elementsCopy = $.extend( true, {}, elements );
                            if ( ds.options.initialFilter.length && !ds._data.length && ds._requestInProgress ) {
                                ds.one( 'requestEnd', function () {
                                    setPresetEsValue( elementsCopy );
                                } );
                            } else {
                                setPresetEsValue( elementsCopy )
                            }

                        }
                        if ( !elements.query && elements.elements && elements.elements.length ) {
                            this.forceSelect( elements.elements );
                        }
                    } else if ( this.options.compositeSearch && elements && elements.composite ) {
                        var that = this,
                            firstTypeID,
                            gridfilter = {},
                            compositefilter = {},
                            secondTypeID,
                            multiply = Math.pow( 2, 32 ),
                            firstTypes = [],
                            grid = that.element.parent().find( '.n-elementselectorgrid:not(.n-elementselectorgrid-composite)' ),
                            gridData = that.element.parent().find( '.n-elementselectorgrid:not(.n-elementselectorgrid-composite)' ).data( 'nmswebElementSelectorGrid' ),
                            compositeGridData = that.element.parent().find( '.n-elementselectorgrid-composite' ).data( 'nmswebElementSelectorGrid' ),
                            composites = [];
                        $.each( elements.elements, function ( key, value ) {
                            firstTypeID = value & ( multiply - 1 );
                            secondTypeID = Math.floor( value / multiply );
                            if ( $.inArray( firstTypeID, firstTypes ) === -1 ) {
                                firstTypes.push( firstTypeID );
                            }
                            if ( $.inArray( secondTypeID, composites ) === -1 ) {
                                composites.push( secondTypeID );
                            }
                        } );
                        compositefilter.logic = 'or';
                        compositefilter.filters = [];
                        $.each( composites, function ( key, value ) {
                            compositefilter.filters.push( {
                                field: 'element_id',
                                operator: 'eq',
                                value: value
                            } );
                        } );
                        compositeGridData.dataSource.filter( compositefilter );
                        compositeGridData.forceSelect( composites );
                        gridfilter.logic = 'or';
                        gridfilter.filters = [];
                        $.each( firstTypes, function ( key, value ) {
                            gridfilter.filters.push( {
                                field: 'element_id',
                                operator: 'eq',
                                value: value
                            } );
                        } );
                        gridData.dataSource.filter( gridfilter );
                        this.forceSelect( firstTypes );
                        grid.find( '.n-element-selector-grid-composites-filter-link' ).removeClass( 'hide' );
                    } else if ( this.options.compositeSearch && this.element.parent().find( '.n-elementselectorgrid-composite' ).data( 'nmswebElementSelectorGrid' ).dataSource.getSelectedIds().length > 0 ) {
                        //working out the composite IDS to return for the preset.
                        comps = this.element.parent().find( '.n-elementselectorgrid-composite' ).val();
                        ret.composite = true;
                        ret.elements = this.dataSource.getSelectedIds();
                        if ( ret.elements.length > 0 && comps.elements.length > 0 ) {
                            compIDs = [];
                            $.each( ret.elements, function ( key, value ) {
                                a = value;
                                $.each( comps.elements, function ( key, value ) {
                                    multiply = Math.pow( 2, 32 );
                                    newComp = ( value * multiply ) + a;
                                    compIDs.push( newComp );
                                } );
                            } );
                            ret.elements = compIDs;
                        }
                    } else {
                        ret.composite = false;
                        ret.elements = this.dataSource.getSelectedIds();
                    }
                }
                return ret;
            },
            _generateSavePresetContent: function ( onBeforeSave, type ) {
                var $content,
                    that = this,
                    filter,
                    $itemNameInput = $( '<div><label for=\'n-save-preset-' + type + '-name\'>Name:</label><input id=\'n-save-preset-' + type + '-name\' type=\'text\' class=\'preset-name\' /></div>' ),
                    address = '/core/presets/index/',
                    $saveItemButton = $( '<button class=\' n-cnf-btn blue n-configurator-save-preset-button\'>Save Preset</button>' )
                    .on( 'click', function () {
                        filter = onBeforeSave.call( this );
                        var item = {
                            'name': $( '#n-save-preset-' + type + '-name' ).val(),
                            'fields': [ {
                                'name': "Element_Selector",
                                'title': "Element_Selector",
                                'value': that.element.data( 'nmswebElementSelectorGrid' ).val()
                        } ]
                        };
                        console.log( 'value from element sel grid', that.element.data( 'nmswebElementSelectorGrid' ).val() );
                        $( this ).parents( '.n-popoverbody' ).addClass( 'hide' );
                        $.ajax( {
                            'type': 'PUT',
                            'url': address,
                            'data': {
                                preset: JSON.stringify( item )
                            },
                            success: function () {
                                $( "#content" ).trigger( 'nmsweb:notify', {
                                    "target": "content",
                                    "type": "success",
                                    "title": "Successfully saved Preset",
                                    "message": "'" + item.name + "' has been successfully saved."
                                } );
                            },
                            complete: function ( xhr ) {
                                var response = $.parseJSON( xhr.responseText );
                                if ( response.error === "duplicateName" ) {
                                    $( "#content" ).trigger( 'nmsweb:notify', {
                                        "target": "content",
                                        "type": "error",
                                        "title": "Please correct the following before continuing",
                                        "message": "'" + item.name + "' is already in use. Please enter a unique Preset name."
                                    } );
                                }
                            }
                        } );
                    } );
                $content = $( '<div></div>' )
                    .append( $itemNameInput )
                    .append( $saveItemButton );
                return $content;
            },
            reattachFilter: function () {
                var $search = this.element.parent().find( '.input-large' ),
                    $toolbar = this.element.find( '.k-grid-toolbar' );
                if ( !this.element.hasClass( 'n-elementselectorgrid-composite' ) && $search.length && $toolbar.children( '.input-large' ).length < 1 ) {
                    $search.prependTo( $toolbar );
                }
            },
            // getActionsGroup: function () {
            //  if (this.options.inForm !== true &&
            //      this.options.group_actions !== undefined &&
            //      this.options.group_actions.length > 0) {
            //      var $wrapper = this.element.closest('#wrapper'),
            //          $groupActions = $('<div>', {'class':'n-group-actions-div'}),
            //          $groupActionsDrop = $('<select>', {'class':'n-select n-element-selector-group-actions-drop'}),
            //          $groupActionsBtn = $('<button>', {'class':'n-element-selector-go-button btn', 'text': 'Go!'}),
            //          groupOptions = $.map(this.options.group_actions, function( val, i ){
            //              return $('<div>').append($('<option>', {
            //                  'value': [
            //                          val.module,
            //                          val.controller,
            //                          val.action
            //                      ].join('/'),
            //                  'text': 'Actions For Group: ' + val.title
            //              }).clone()).html();
            //          }).join("");
            //      if($wrapper.length > 0 && $wrapper.children('.n-group-actions-div').length < 1){
            //          $wrapper
            //              .prepend($groupActions.append($groupActionsBtn)
            //              .append($groupActionsDrop.append(groupOptions)));
            //          return true;
            //      } else if($wrapper.length > 0 && $wrapper.children('.n-group-actions-div').length > 0) {
            //          return true;
            //      } else {
            //          return false;
            //      }
            //  } else {
            //      return false;
            //  }
            // },
            updateToolbarDropDowns: function () {
                this.element
                    .find( '.k-grid-toolbar' )
                    .find( '.n-select-container' )
                    .each( function () {
                        if ( $( this ).find( 'select' ).length > 0 ) {
                            $( this ).removeClass( 'hide n-select-container' );
                        }
                    } ).addClass( 'n-select-container' );
            },
            onGroupActionsChange: function ( eventInfo ) {
                var that = this,
                    button_value,
                    obj_ids = [],
                    url,
                    selectedRows = that.dataSource.getSelectedIds(),
                    firstType,
                    firstModel,
                    dropDown,
                    action,
                    typesToBlock = Object.keys( this.options.disabled_group_actions ),
                    blockedAction,
                    csvExport;
                dropDown = this.element.find( '.n-group-actions-div > .dropdown-menu' );
                button_value = dropDown.find( '.selected' ).data( 'target' );
                csvExport = ( button_value === "config/csv/build_csv_data" );
                if ( selectedRows.length === 0 ) {
                    return;
                }
                firstType = that.dataSource.get( selectedRows[ 0 ] ).type;
                firstModel = that.dataSource.get( selectedRows[ 0 ] ).model;
                url = button_value.split( '/' );
                action = url[ 3 ];
                if ( url[ 0 ] !== "#" && ( url[ 0 ] === '' || url[ 1 ] === '' || url[ 2 ] === '' ) ) {
                    console.warn( 'Url not defined for this group action', url );
                    return;
                }
                var selectedType;
                $.each( selectedRows, function () {
                    selectedType = that.dataSource.get( this ).type;
                    if ( selectedType === firstType ) {
                        obj_ids.push( this );
                    }
                    if ( typesToBlock.indexOf( selectedType.toString() ) !== -1 ) {
                        // if found one of the types we need to block
                        // check if this is also action we need to block
                        var actionsToBlock = that.options.disabled_group_actions[ selectedType ].actions;
                        if ( actionsToBlock.indexOf( action ) !== -1 ) {
                            blockedAction = {
                                displayName: that.options.disabled_group_actions[ selectedType ].display_name,
                                action: action
                            };
                        }
                    }
                } );
                if ( csvExport || obj_ids.length === selectedRows.length ) {
                    if ( url[ 2 ] === '*' ) { //find controller based on type
                        url[ 2 ] = firstModel;
                    }

                    if ( action === 'applygroupchange' ) {
                        $( '#app' ).injector().invoke( [ 'nmswebAPI', 'NMSWebNotification', function ( nmswebAPI, NMSWebNotification ) {
                            var button = $( '.n-group-actions-div' ),
                                api = new nmswebAPI(),
                                elementApplyChange = api.resource( 'config/element/:id/apply_changes', {}, {
                                    applyChanges: {
                                        method: 'POST',
                                        headers: {
                                            'Use-Cookie': 'true',
                                            'Use-Sleep': 'false'
                                        },
                                        params: {
                                            id: '@id'
                                        },
                                    }
                                } );

                            function parseResponse( response ) {
                                var errors, data, message = 'For ',
                                    title = 'Apply changes';

                                data = ( response && response.data && !response.data.errors ) ? response.data : response.data.data;

                                //Notification for successfuly applied changes
                                if ( data.length ) {
                                    NMSWebNotification.add( {
                                        type: 'success',
                                        isFadeable: false,
                                        isPersistent: false,
                                        title: title,
                                        message: title + ' ' + message + data.length + ' elements succeeded'
                                    }, "body" );
                                }

                                //Notification for failed elements
                                if ( response && response.data && response.data.errors && response.data.errors.length ) {
                                    NMSWebNotification.add( {
                                        type: 'error',
                                        isFadeable: false,
                                        isPersistent: false,
                                        title: title,
                                        message: title + ' ' + message + response.data.errors.length + ' elements failed'
                                    }, "body" );
                                }

                                button.spin( false );
                                button.find( '.dropdown-toggle' ).attr( 'aria-disabled', 'false' );
                                that.trigger( 'dataBound' );
                            };

                            button.find( '.dropdown-toggle' ).attr( 'aria-disabled', 'true' );
                            button.removeClass( 'open' );
                            button.spin();
                            elementApplyChange.applyChanges( {
                                obj_id: obj_ids.join( ',' ),
                                id: 'group'
                            }, parseResponse, parseResponse );
                        } ] );
                    } else if ( url[ 0 ] !== "#" ) {
                        $( '#group_actions_form' ).remove();
                        $( 'body' ).append( '<form method="POST" action="/' + url.join( '/' ) + '" id="group_actions_form"><input type="hidden" name="obj_ids" value="' + obj_ids.join( ',' ) + '"/></form>' );
                        $( '#group_actions_form' ).submit();
                    } else {
                        // Change the element to model_name when action is activate/deactivate
                        if ( url[ 3 ] === 'activate' || url[ 3 ] === 'deactivate' ) {
                            button_value = button_value.replace( "element", firstModel );
                        } else if ( url[ 2 ] === '' ) {
                            url[ 2 ] = window.location.href.split( "/" )[ 4 ];
                            button_value = url.join( '/' );
                        } else {
                            button_value = url.join( '/' );
                        }
                        if ( eventInfo.which !== undefined && parseInt( eventInfo.which, 10 ) === 2 ) {
                            //Open link in new window
                            var win = window.open( "/" + button_value + "/" + selectedRows.join( ',' ) );
                            if ( win ) {
                                win.focus();
                            } else {
                                alert( "Please allow popups for this site" );
                            }
                        } else {
                            var urlStr = "/" + button_value + "/" + selectedRows.join( ',' );
                            window.location = urlStr.replace( '/#/', '/' );
                        }
                    }
                } else {
                    alert( 'Group actions can only be executed on elements of the same type.' );
                    dropDown.find( '.selected' ).removeClass( 'selected' );
                }
            },
            getActionsGroup: function () {
                var that = this,
                    $groupActions = $( '<div>', {
                        'class': 'btn-group n-group-actions-div'
                    } ),
                    $groupActionsDrop = $( '<a>', {
                        'class': 'btn btn-primary dropdown-toggle btn-lg n-element-selector-group-actions-drop n-splitbutton n-splitbutton-action',
                        'data-toggle': 'false', // initially should be disabled for dropdown
                        'text': 'Group Actions',
                        'aria-disabled': true
                    } ),
                    $groupActionsList = $( '<ul>', {
                        'class': 'dropdown-menu',
                        'role': 'menu'
                    } );
                if ( this.options.inForm !== true &&
                    this.options.group_actions !== undefined &&
                    this.options.group_actions.length > 0 &&
                    ( !this.element.find( '.k-grid-toolbar' ).find( '.n-group-actions-div' ).length ) ) {
                    $groupActionsList.append(
                        $.map( that.options.group_actions, function ( val ) {
                            var href = [
                            val.module,
                            val.controller,
                            val.action
                        ].join( '/' );
                            return '<li><a href="#" data-target="' + href + '">' + val.title + '</a></li>';
                        } ).join( '' )
                    );
                    this.element.find( '.k-grid-toolbar' )
                        .find( '.n-element-selector-grid-toolbar-components-holder' )
                        .append(
                            $groupActions
                            .append( $groupActionsDrop )
                            .append( $groupActionsList )
                        );
                    $groupActionsList.on( 'click', 'a', function ( e ) {
                        e.preventDefault();
                        $groupActionsList.find( 'a' ).removeClass( 'selected' );
                        $( e.target ).addClass( 'selected' );
                        that.onGroupActionsChange.call( that, {
                            'which': e.which
                        } );
                    } );
                }
            },
            getToolbar: function ( element, options ) {
                var optionsHtml, treeButtonHtml;
                if ( options.tree_types.length > 0 ) {
                    var treeTypesLength = options.tree_types.length;
                    optionsHtml = "<ul class='n-action-list dropdown-menu tree-builder-options' role='menu'>";
                    for ( var i = 0; i < treeTypesLength; i++ ) {
                        var displayName = options.tree_types[ i ].display;
                        displayName += options.tree_types[ i ].default ? ' (default)' : '';
                        optionsHtml += "<li><span class='tree-builder-tree-option' data-tree-type='" + options.tree_types[ i ].key + "'>" + displayName + "</span></li>";
                    }
                    optionsHtml += "</ul>";
                    // storing it in this so we can share it for each row (no need to create it each time when calling getRow and getAltRow)
                    treeButtonHtml = [
                    '<div class="n-tree-builder-div">',
                    '<div class="btn-group">',
                    '<button type="button" data-tree-type="' + options.tree_types[ 0 ].key + '" class="btn default">Tree</button>',
                    '<button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">',
                    '<span class="caret"></span>',
                    '</button>',
                    optionsHtml,
                    '</div>',
                    '<div class="btn-group orgchart">',
                    '<button type="button" data-tree-type="' + options.tree_types[ 0 ].key + '" class="btn default">Org Chart</button>',
                    '<button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">',
                    '<span class="caret"></span>',
                    '</button>',
                    optionsHtml,
                    '</div>',
                    '</div>'
                ].join( '' );
                    this.hierarchyButtonHtml =
                        '<div class="n-hierarchy-builder-div">' +
                        '<div class="btn-group">' +
                        '<button type="button" element="#= obj_id #" class="btn n-element-selector-btn n-element-selector-hierarchy" data-tree-type="' + options.tree_types[ 0 ].key + '" class="btn default">Hierarchy</button>' +
                        '<button type="button" element="#= obj_id #" class="btn n-element-selector-btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">' +
                        '<span class="caret"></span>' +
                        '</button>' +
                        optionsHtml +
                        '</div>' +
                        '</div>';
                    // hide options if clicked outside
                    $( document ).click( function ( e ) {
                        var container = element.find( ".n-tree-builder-div button" );
                        // if clicked on element that is not this one and one of it's children
                        if ( !container.is( e.target ) && container.has( e.target ).length === 0 ) {
                            var treeBuilderOptions = $( container ).parents( '.n-tree-builder-div' ).find( '.tree-builder-options' );
                            treeBuilderOptions.attr( 'tree-builder-options-opened', false );
                            container.parent().find( 'ul' ).hide();
                        }
                    } );
                    element.on( 'click', '.n-tree-builder-div button.dropdown-toggle', function () {
                        $( this ).siblings( '.tree-builder-options' ).toggle();
                    } );
                    element.on( 'click', '.n-tree-builder-div button.default, .n-tree-builder-div ul.dropdown-menu span.tree-builder-tree-option', function ( e ) {
                        var treeType = $( e.target ).data().treeType,
                            currentTreeType = element.attr( 'data-currentTree' );
                        if ( element.data( 'nmswebElementSelectorGrid' )._data.length < 1 ) {
                            if ( $( e.target ).parents( '.btn-group.orgchart' ).length ) {
                                $( e.target ).parents( ".data-elementselectorgrid" ).data( 'nmswebElementSelectorGrid' )._displayTree( this, currentTreeType, true );
                            } else {
                                $( e.target ).parents( ".data-elementselectorgrid" ).data( 'nmswebElementSelectorGrid' )._displayTree( this, currentTreeType );
                            }
                            return false;
                        }
                        if ( currentTreeType !== treeType ) {
                            element.removeAttr( 'data-treeUpdated' );
                        }
                        // $( e.target ).parents( '.n-tree-builder-div' ).find( 'button' ).text( treeTypeDisplay );
                        element.attr( 'data-currentTree', treeType );
                        $( this ).parents( '.n-tree-builder-div' ).find( '.tree-builder-tree-option' ).removeAttr( "disabled" );
                        $( this ).parents( '.n-tree-builder-div' ).find( 'button[data-tree-type="basic"]' ).removeAttr( "disabled" );
                        if ( $( this ).hasClass( 'tree-builder-tree-option' ) ) {
                            $( this ).siblings().removeAttr( "disabled" );
                            if ( treeType !== 'basic' ) {
                                $( this ).closest( '.btn-group' ).find( 'button.default' ).removeAttr( "disabled" );
                            } else if ( treeType === 'basic' ) {
                                $( this ).closest( '.btn-group' ).find( 'button.default' ).attr( "disabled", "disabled" );
                            }
                            $( this ).attr( "disabled", "disabled" );
                        } else {
                            $( e.target ).siblings( '.tree-builder-options' ).find( 'span' ).removeAttr( "disabled" );
                            $( this ).closest( '.btn-group' ).find( '.tree-builder-tree-option[data-tree-type="basic"]' ).attr( "disabled", "disabled" );
                        }
                        if ( $( e.target ).parents( '.btn-group.orgchart' ).length ) {
                            $( e.target ).parents( ".data-elementselectorgrid" ).data( 'nmswebElementSelectorGrid' )._displayTree( this, treeType, true );
                        } else {
                            $( e.target ).parents( ".data-elementselectorgrid" ).data( 'nmswebElementSelectorGrid' )._displayTree( this, treeType );
                        }
                    } );
                } else {
                    treeButtonHtml = '<button class=\'n-element-selector-tree-toggle-button-tree btn\'>Tree</button><button class=\'n-element-selector-tree-toggle-button-orgchart-tree btn\'>Org Chart</button>';
                }
                return '<span class="n-select-container hide"><select class="n-select n-element-selector-element-type-drop hide">' +
                    '</select></span>' +
                    '<nmsweb-management-state-filter datasourceid="#= this.dataSource.id #" type="po_state" enabled="#= this.options.managementStateFiltering #" default="#= this.options.managementPoStateDefault #"></nmsweb-management-state-filter>' +
                    '<nmsweb-management-state-filter datasourceid="#= this.dataSource.id #" type="cu_state" enabled="#= this.options.managementStateFiltering #" default="#= this.options.managementCuStateDefault #"></nmsweb-management-state-filter>' +
                    // Grouping ablility has been switched off for 1.0
                    // '<select class="n-select n-element-selector-group-drop">' +
                    //  '<option value="none">Group By: None</option>' +
                    // '<option value="configuration_state">Group By: Configuration State</option>' +
                    //  '<option value="type">Group By: Type</option>' +
                    // '</select>' +
                    '# if (this.options.inForm !== true) { #' +
                    '<div class="n-element-selector-grid-toolbar-components-holder">' +
                    '# if (this.element.parents(".n-configurator-section").length === 0) { #' +
                    '<a class="close n-element-selector-close">&times;</a>' +
                    '# } #' +
                    // '# if(this.options.group_actions !== undefined && this.options.group_actions.length > 0) { #' +
                    //  '<div class="n-group-actions-div hide"> <button class="n-element-selector-go-button btn" target="">Go!</button>' +
                    //  '<select class="n-select n-element-selector-group-actions-drop">' +
                    //  '# for (var i = 0, l = this.options.group_actions.length; i < l; i++) { #' +
                    //      '<option value="#= this.options.group_actions[i].module #/#= this.options.group_actions[i].controller #/#= this.options.group_actions[i].action #">Actions For Group: #= this.options.group_actions[i].title #</option>' +
                    //  '# } #' +
                    //  '</select></div>' +
                    // '# } #' +
                    '# if (this.options.treeView !== undefined && this.options.treeView === true) { #' +
                    '<div class=\'n-element-selector-toggle-holder\'>' +
                    '# if (this.options.actions && this.hierarchyIndex !== undefined && this.hierarchyIndex !== null && this.options.actions[this.hierarchyIndex].url && this.options.actions[this.hierarchyIndex].url !== null) { #' +
                    treeButtonHtml +
                    '<button disabled=\'disabled\' class=\'n-element-selector-tree-toggle-button-list btn\'>List</button>' +
                    '# } #' +
                    '</div>' +
                    '# } #' +
                    '</div>' +
                    '# } #';
            },
            getRow: function ( opts ) {
                return '<tr elementmodel="#= model #" elementname="#= obj_name #" elementid="#= obj_id #" elementtype="#= type #" class="" ${ window.kendo.attr(\'uid\') + \'=\' + uid }>' +
                    '# if (this.dataSource.group().length > 0) { #' +
                    '<td class="k-group-cell"></td>' +
                    '# } #' +
                    '<td class="n-element-selector-status-column">' +
                    '<nmsweb-icon is_element_selector="1" po_state="#= obj_states.performance_operational_state #" cu_state="#= obj_states.config_update_state #" update="#= this.options.shouldUpdate #" obj_type="#= type #" obj_name="#= obj_name #" obj_id="#= obj_id #"></nmsweb-icon>' +
                    '</td>' +
                    '<td>#= obj_name #</td>' +
                    '# if (this.options.inForm !== true && this.options.actions.length >= ' + ( opts.numberOfDisplayedActions ) + ') { #' +
                    '# for (var i = 0; i < ' + ( opts.numberOfDisplayedActions ) + '; i++) { #' +
                    '# if (this.options.actions && this.options.actions[i] && this.options.actions[i].action === "hierarchy") { #' +
                    '<td>' +
                    this.hierarchyButtonHtml +
                    '</td>' +
                    '# } else if (this.options.actions && this.options.actions[i] && this.options.actions[i].url.indexOf("%obj_id%") !== -1) { #' +
                    '<td>' +
                    '<a element="#= obj_id #" href="#= this.options.actions[i].url.replace("%obj_id%", "") ##= obj_id #" target="" class="btn n-element-selector-#= this.options.actions[i].field # n-element-selector-btn n-element-selector-row-btn">#= this.options.actions[i].title #</a>' +
                    '</td>' +
                    '# } else { #' +
                    '<td>' +
                    '<a element="#= obj_id #" href="#= this.options.actions[i].url #" target="" class="btn n-element-selector-#= this.options.actions[i].field # n-element-selector-btn n-element-selector-row-btn">#= this.options.actions[i].title #</a>' +
                    '</td>' +
                    '# } #' +
                    '# } #' +
                    '# } else if (this.options.inForm !== true) { #' +
                    '# for (var i = 0; i < (' + ( opts.numberOfDisplayedActions ) + ' - this.options.actions.length); i++) { #' +
                    '<td></td>' +
                    '# } #' +
                    '# for (var i = 0; i < this.options.actions.length; i++) { #' +
                    '# if (this.options.actions && this.options.actions[i] && this.options.actions[i].action === "hierarchy") { #' +
                    '<td>' +
                    this.hierarchyButtonHtml +
                    '</td>' +
                    '# } else if (this.options.actions && this.options.actions[i] && this.options.actions[i].url.indexOf("%obj_id%") !== -1) { #' +
                    '<td>' +
                    '<a element="#= obj_id #" href="#= this.options.actions[i].url.replace("%obj_id%", "") ##= obj_id #" target="" class="btn n-element-selector-#= this.options.actions[i].field # n-element-selector-btn n-element-selector-row-btn">#= this.options.actions[i].title #</a>' +
                    '</td>' +
                    '# } else { #' +
                    '<td>' +
                    '<a element="#= obj_id #" href="#= this.options.actions[i].url #" target="" class="btn n-element-selector-#= this.options.actions[i].field # n-element-selector-btn n-element-selector-row-btn">#= this.options.actions[i].title #</a>' +
                    '</td>' +
                    '# } #' +
                    '# } #' +
                    '# } #' +
                    '# if (this.options.inForm !== true) { #' +
                    '# if (this.options.actions_url !== null) { #' +
                    '<td>' +
                    '<nmsweb-actionsbutton obj-id="#= obj_id #" type-id="#= type #"></nmsweb-actionsbutton>' +
                    '</td>' +
                    '# } #' +
                    '# } #' +
                    '</tr>';
            },
            getAltRow: function ( opts ) {
                return '<tr elementmodel="#= model #" elementname="#= obj_name #" elementid="#= obj_id #" elementtype="#= type #" class="k-alt" ${ window.kendo.attr(\'uid\') + \'=\' + uid  }>' +
                    '# if (this.dataSource.group().length > 0) { #' +
                    '<td class="k-group-cell"></td>' +
                    '# } #' +
                    '<td class="n-element-selector-status-column">' +
                    '<nmsweb-icon is_element_selector="1" po_state="#= obj_states.performance_operational_state #" cu_state="#= obj_states.config_update_state #" update="#= this.options.shouldUpdate #" obj_type="#= type #" obj_name="#= obj_name #" obj_id="#= obj_id #"></nmsweb-icon>' +
                    '</td>' +
                    '<td>#= obj_name #</td>' +
                    '# if (this.options.inForm !== true && this.options.actions.length >= ' + ( opts.numberOfDisplayedActions ) + ') { #' +
                    '# for (var i = 0; i < ' + ( opts.numberOfDisplayedActions ) + '; i++) { #' +
                    '# if (this.options.actions && this.options.actions[i] && this.options.actions[i].action === "hierarchy") { #' +
                    '<td>' +
                    this.hierarchyButtonHtml +
                    '</td>' +
                    '# } else if (this.options.actions && this.options.actions[i] && this.options.actions[i].url.indexOf("%obj_id%") !== -1) { #' +
                    '<td>' +
                    '<a element="#= obj_id #" href="#= this.options.actions[i].url.replace("%obj_id%", "") ##= obj_id #" target="" class="btn n-element-selector-#= this.options.actions[i].field # n-element-selector-btn n-element-selector-row-btn">#= this.options.actions[i].title #</a>' +
                    '</td>' +
                    '# } else { #' +
                    '<td>' +
                    '<a element="#= obj_id #" href="#= this.options.actions[i].url #" target="" class="btn n-element-selector-#= this.options.actions[i].field # n-element-selector-btn n-element-selector-row-btn">#= this.options.actions[i].title #</a>' +
                    '</td>' +
                    '# } #' +
                    '# } #' +
                    '# } else if (this.options.inForm !== true) { #' +
                    '# for (var i = 0; i < (' + ( opts.numberOfDisplayedActions ) + ' - this.options.actions.length); i++) { #' +
                    '<td></td>' +
                    '# } #' +
                    '# for (var i = 0; i < this.options.actions.length; i++) { #' +
                    '# if (this.options.actions && this.options.actions[i] && this.options.actions[i].action === "hierarchy") { #' +
                    '<td>' +
                    this.hierarchyButtonHtml +
                    '</td>' +
                    '# } else if (this.options.actions && this.options.actions[i] && this.options.actions[i].url.indexOf("%obj_id%") !== -1) { #' +
                    '<td>' +
                    '<a element="#= obj_id #" href="#= this.options.actions[i].url.replace("%obj_id%", "") ##= obj_id #" target="" class="btn n-element-selector-#= this.options.actions[i].field # n-element-selector-btn n-element-selector-row-btn">#= this.options.actions[i].title #</a>' +
                    '</td>' +
                    '# } else { #' +
                    '<td>' +
                    '<a element="#= obj_id #" href="#= this.options.actions[i].url #" target="" class="btn n-element-selector-#= this.options.actions[i].field # n-element-selector-btn n-element-selector-row-btn">#= this.options.actions[i].title #</a>' +
                    '</td>' +
                    '# } #' +
                    '# } #' +
                    '# } #' +
                    '# if (this.options.inForm !== true) { #' +
                    '# if (this.options.actions_url !== null) { #' +
                    '<td>' +
                    '<nmsweb-actionsbutton obj-id="#= obj_id #" type-id="#= type #"></nmsweb-actionsbutton>' +
                    '</td>' +
                    '# } #' +
                    '# } #' +
                    '</tr>';
            },
            _getHierarchyTreeData: function ( data, boldID ) {
                var newTree = {},
                    that = this,
                    elementId = data.obj_id;
                if ( ( boldID !== undefined && typeof ( boldID ) === 'string' && boldID === elementId ) || ( boldID !== undefined && typeof ( boldID ) === 'object' && $.inArray( parseInt( elementId, 10 ), boldID ) !== -1 ) ) {
                    newTree.originNode = true;
                }
                newTree.text = data.obj_name;
                newTree.objectType = data.obj_type;
                newTree.identity = data.obj_id;
                newTree.model = data.model_name;
                newTree.obj_states = data.obj_states;
                if ( data.subordinates && data.subordinates.length > 0 ) {
                    newTree.items = [];
                    $.each( data.subordinates, function () {
                        newTree.items.push( that._getHierarchyTreeData( this, boldID ) );
                    } );
                }
                return newTree;
            },
            getTree: function ( treeObject ) {
                var newTreeData = [],
                    $elementHierarchyTree;
                newTreeData.push( treeObject );
                $elementHierarchyTree = $( '<div></div>' )
                    .kendoTreeView( {
                        template: "# if (item.originNode) { #" +
                            "<div data-identity='#= item.identity #' data-name='#= item.text #' data-type='#= item.objectType #' data-model='#= item.model #' class='n-element-selector-grid-tree-node origin n-element-selector-grid-tree-node-#= item.status_value #'><nmsweb-icon is_element_selector='1' po_state='#= item.obj_states.performance_operational_state #' cu_state='#= item.obj_states.config_update_state #' update='false' obj_type='#= item.objectType #' obj_name='#= item.text #' obj_id='#= item.identity #'></nmsweb-icon> #= item.text #</div>" +
                            "# } else { #" +
                            "<div data-identity='#= item.identity #' data-name='#= item.text #' data-type='#= item.objectType #' data-model='#= item.model #' class='n-element-selector-grid-tree-node n-element-selector-grid-tree-node-#= item.status_value #'><nmsweb-icon is_element_selector='1' po_state='#= item.obj_states.performance_operational_state #' cu_state='#= item.obj_states.config_update_state #' update='false' obj_type='#= item.objectType #' obj_name='#= item.text #' obj_id='#= item.identity #'></nmsweb-icon> #= item.text #</div>" +
                            "# } #",
                        dataSource: newTreeData,
                        animation: false
                    } );
                return $elementHierarchyTree;
            },
            getTreeContent: function ( el, type, orgchart ) {
                var that = this,
                    $elementList = $( '<div class=\'n-element-selector-grid-hierarchy-holder\'></div>' ),
                    obj_ids = [],
                    $tree,
                    filters,
                    query,
                    data = that.dataSource.data(),
                    globalElementSelector = $( '.n-elementselectorgrid[data-ds="globalElementSelectorDS"]' ).data( 'nmswebElementSelectorGrid' );
                if ( !that.dataSource.options.serverFiltering ) {
                    filters = that.dataSource.filter();
                    query = new kendo.data.Query( data );
                    data = query.filter( filters ).data;
                }
                $.each( data, function () {
                    obj_ids.push( this.obj_id );
                } );
                if ( obj_ids.length > 0 && that.options.actions && that.hierarchyIndex !== undefined && that.hierarchyIndex !== null && that.options.actions[ that.hierarchyIndex ].url && that.options.actions[ that.hierarchyIndex ].url !== null ) {
                    var hierarchyUrl = that.options.actions[ that.hierarchyIndex ].url;
                    if ( that.options.dbQueryType !== undefined ) {
                        hierarchyUrl += '?db_query_type=' + that.options.dbQueryType;
                    }
                    if ( type !== undefined ) {
                        hierarchyUrl += '&type=' + type;
                    }
                    if ( orgchart ) {
                        var orgchartObj = new orgChartUI( this ),
                            $orgchart = $( '<div class="orgchart" style="width: 100%; height: 100%; visibility:hidden;"></div>' );
                        this.element.removeAttr( 'data-treeUpdated' );
                        this.element.find( '.tree-content' ).html( $orgchart ).css( 'height', '500px' );
                        $orgchart.data( 'orgchart', orgchartObj );
                        $orgchart.css( 'visibility', 'visible' );
                        $orgchart.find( '.yfiles-canvascontrol' ).height( $orgchart.innerHeight() );
                        var miniToolbar = $( '<div class="y-toolbar mini-toolbar"></div>' );
                        miniToolbar.append( orgchartObj.makeButton( 'yIconZoomIn', function () {
                            orgchartObj.$graphControl.zoom = orgchartObj.$graphControl.zoom * 1.2;
                        } ) ).append( orgchartObj.makeButton( 'yIconZoomOut', function () {
                            orgchartObj.$graphControl.zoom = orgchartObj.$graphControl.zoom / 1.2;
                        } ) ).append( orgchartObj.makeButton( 'yIconZoomOriginal', function () {
                            orgchartObj.$graphControl.zoom = 1;
                        } ) ).append( orgchartObj.makeButton( 'yIconShowAll', function () {
                            orgchartObj.$showAllExecuted();
                            orgchartObj.$refreshLayout( -1, null );
                        } ) ).append( orgchartObj.makeButton( 'yIconZoomFit', function () {
                            orgchartObj.$graphControl.fitContent();
                        } ) );

                        $orgchart.html( orgchartObj.$graphControl.div ).prepend( miniToolbar );
                        $orgchart.append( '<div class="overview"></div>' );
                        $orgchart.find( '.overview' ).html( orgchartObj.$overviewControl.div );
                        $orgchart.spin();
                    }
                    $.ajax( {
                        'type': 'POST',
                        'url': hierarchyUrl,
                        'data': 'obj_id=' + obj_ids.join( '&obj_id=' ) + '&orgchart=' + orgchart,
                        'success': function ( data ) {
                            if ( orgchart ) {
                                var orgChartData = data[ 0 ];
                                orgchartObj.createGraph( [ orgChartData ] );
                                orgchartObj.fitContent();
                                orgchartObj.graphControl.maximumZoom = 1.6;
                                orgchartObj.graphControl.minimumZoom = 0.4;
                                orgchartObj._currentIds = {};
                                orgchartObj._iconsMapping = {};
                                orgchartObj.graphControl.addUpdatedVisualListener( function () {
                                    var images = $orgchart.find( 'image' );
                                    images.each( function ( index, image ) {
                                        var icon = orgchartObj._iconsMapping[ $( image ).attr( 'obj_id' ) ] ||
                                            globalElementSelector.getIcon( $( image ).attr( 'obj_type' ), JSON.parse( $( image ).attr( 'obj_states' ) ) ),
                                            randomId = 'orgchart_' + Math.random().toString( 36 ).substring( 7 ),
                                            tmpContainer,
                                            tmpContainerOverlay;

                                        if ( index % 2 === 0 ) {
                                            orgchartObj._currentIds[ $( image ).attr( 'obj_id' ) ] = true;

                                            tmpContainer = $( '<div>' ).css( 'visibility', 'hidden' ).attr( 'id', randomId );
                                            tmpContainer.addClass( 'n-element-selector-status-' + icon.big );
                                            $( 'body' ).append( tmpContainer );
                                            // not using jQuery's on('load') because of issues with IE
                                            $( image ).attr( 'onload', function () {
                                                var href = tmpContainer.css( 'background-image' ).replace( 'url(', '' ).replace( ')', '' ).replace( /"/g, '' );
                                                if ( href && href !== '' && href !== 'none' ) {
                                                    image.setAttribute( 'href', href );
                                                } else {
                                                    // reset to spacer
                                                    image.removeAttribute( 'href' );
                                                    image.setAttribute( 'xlink:href', '/static/images/spacer.svg' );
                                                }
                                                $( '#' + randomId ).detach();
                                            } );
                                        } else {
                                            tmpContainerOverlay = $( '<div>' ).css( 'visibility', 'hidden' ).attr( 'id', randomId + '_overlay' );
                                            tmpContainerOverlay.addClass( 'n-element-selector-status-configuration-icon ' + icon.config );
                                            $( 'body' ).append( tmpContainerOverlay );
                                            // not using jQuery's on('load') because of issues with IE
                                            $( image ).attr( 'onload', function () {
                                                var href = tmpContainerOverlay.css( 'background-image' ).replace( 'url(', '' ).replace( ')', '' ).replace( /"/g, '' );
                                                if ( href && href !== '' && href !== 'none' ) {
                                                    image.setAttribute( 'href', href );
                                                } else {
                                                    image.removeAttribute( 'href' );
                                                    image.setAttribute( 'xlink:href', '/static/images/spacer.svg' );
                                                }

                                                $( '#' + randomId + '_overlay' ).detach();
                                            } );
                                        }
                                    } );
                                } );
                                $orgchart.find( '.yfiles-svgpanel' ).height( '500' );
                                $orgchart.spin( false );
                                var iconInterval = setInterval( function () {
                                    if ( $orgchart.css( 'display' ) === '' ) {
                                        // orgchart is hidden
                                        // update no needed -> cancel interval
                                        clearInterval( iconInterval );
                                        return;
                                    }
                                    var url = '/api/1.0/config/element/query?obj_id__in=' + Object.keys( orgchartObj._currentIds ).join( ',' ) + '&calculate_states=true';
                                    $.ajax( {
                                        type: 'GET',
                                        url: url,
                                        headers: {
                                            'Use-Cookie': true
                                        },
                                        success: function ( response ) {
                                            var data = response.data,
                                                images,
                                                icon,
                                                tmpContainer,
                                                tmpContainerOverlay;
                                            for ( var i = 0, dataLength = data.length; i < dataLength; i++ ) {
                                                var randomId = 'orgchart_' + Math.random().toString( 36 ).substring( 7 ),
                                                    href;
                                                icon = globalElementSelector.getIcon( data[ i ].obj_type, data[ i ].obj_states );
                                                orgchartObj._iconsMapping[ data[ i ].obj_id ] = icon;
                                                images = $orgchart.find( 'image[obj_id="' + data[ i ].obj_id + '"]' );
                                                // it will find 2 images per obj_id
                                                // one for big icon, one for triangle
                                                images.each( function ( index, image ) {
                                                    $( image ).attr( 'obj_states', data[ i ].obj_states_json );

                                                    if ( index % 2 === 0 ) {
                                                        tmpContainer = $( '<div>' ).css( 'visibility', 'hidden' ).attr( 'id', randomId );
                                                        tmpContainer.addClass( 'n-element-selector-status-' + icon.big );
                                                        $( 'body' ).append( tmpContainer );
                                                        href = tmpContainer.css( 'background-image' ).replace( 'url(', '' ).replace( ')', '' ).replace( /"/g, '' );
                                                        if ( href && href !== '' && href !== 'none' ) {
                                                            image.setAttribute( 'href', href );
                                                        } else {
                                                            // reset to spacer
                                                            image.removeAttribute( 'href' );
                                                            image.setAttribute( 'xlink:href', '/static/images/spacer.svg' );
                                                        }
                                                        $( '#' + randomId ).detach();
                                                    } else {
                                                        tmpContainerOverlay = $( '<div>' ).css( 'visibility', 'hidden' ).attr( 'id', randomId + '_overlay' );
                                                        tmpContainerOverlay.addClass( 'n-element-selector-status-configuration-icon ' + icon.config );
                                                        $( 'body' ).append( tmpContainerOverlay );
                                                        // not using jQuery's on('load') because of issues with IE
                                                        href = tmpContainerOverlay.css( 'background-image' ).replace( 'url(', '' ).replace( ')', '' ).replace( /"/g, '' );
                                                        if ( href && href !== '' && href !== 'none' ) {
                                                            image.setAttribute( 'href', href );
                                                        } else {
                                                            image.removeAttribute( 'href' );
                                                            image.setAttribute( 'xlink:href', '/static/images/spacer.svg' );
                                                        }

                                                        $( '#' + randomId + '_overlay' ).detach();
                                                    }
                                                } );
                                            }
                                        }
                                    } );
                                }, 15000 );
                            } else {
                                if ( data.length > 0 ) {
                                    $.each( data, function () {
                                        $tree = that.getTree( that._getHierarchyTreeData( this, obj_ids ) );
                                        that._configureTreeBehaviour( $tree, this );
                                        $tree.data( 'kendoTreeView' ).bind( 'collapse', function () {
                                            var $closePopover = $( '.n-element-selector-hierarchy-context-menu-holder' ).closest( '.n-popoverbody' ).find( 'a.close' );
                                            $closePopover.trigger( 'click' );
                                        } );
                                        $elementList.append( $( '<div class=\'n-element-selector-grid-element-hierarchy-holder\'></div>' ).append( $tree ) );
                                        $elementList.trigger( 'angularCompile' );
                                    } );
                                } else {
                                    $elementList.removeAttr( 'class' )
                                        .attr( 'data-notreetoshow', true )
                                        .html( $( '<div>No hierarchy data available at this time.</div>' ) );
                                }
                            }
                        }
                    } );
                }
                return $elementList;
            },
            getElementTypes: function () {
                var that = this;
                var elementTypes = [];
                var ds = window.nmsweb.DataSources[ that.options.dataSource.id ]._dataCached || window.nmsweb.DataSources[ that.options.dataSource.id ].data();
                $.each( ds, function () {
                    var chosenelement = this;
                    if ( $.inArray( chosenelement.type, elementTypes ) === -1 ) {
                        elementTypes.push( this.type );
                    }
                } );
                var options = '<option value="all">Element Type: All</option>';
                $.each( elementTypes, function () {
                    var elementType = this;
                    if ( that.options.icon_mappings && that.options.icon_mappings[ elementType ] !== undefined ) {
                        options = options + '<option value="' + elementType + '">Element Type: ' + that.options.icon_mappings[ elementType ].type_display_name + '</option>';
                    } else {
                        options = options + '<option value="' + elementType + '">Element Type: ' + elementType + '</option>';
                    }
                } );
                return options;
            },
            getIcon: function ( type, obj_states ) {
                var shape, // big icon shape
                    color = "", // big icon colour
                    config = "", // mini triangle icon (bottom-right)
                    small = ""; // mini circle icon (top-left)
                //type_name = this.getTypeName(type);
                if ( typeof obj_states === "undefined" || !obj_states ) {
                    return {
                        'big': 'placecard_light_grey',
                        'small': 'none',
                        'config': ''
                    };
                }
                if ( this.options.icon_mappings !== undefined &&
                    this.options.icon_mappings[ type ] !== undefined ) {
                    shape = this.options.icon_mappings[ type ].icon_shape;
                } else {
                    type = type << 3;
                    type = ( type > ( this.options.shape_names.length - 1 ) ) ?
                        ( this.options.shape_names.length - 1 ) : type;
                    shape = this.options.shape_names[ type ];
                }
                if ( obj_states !== undefined ) {
                    if ( obj_states.performance_operational_state !== undefined ) {
                        switch ( obj_states.performance_operational_state ) {
                        case 'deactivated':
                            color = 'dark_grey';
                            break;
                        case 'offline':
                            color = 'red';
                            break;
                        case 'online':
                            color = 'green';
                            break;
                        case 'unknown':
                            break;
                        default:
                            color = 'light_grey';
                            break;
                        }
                        // color = obj_states.performance_operation_state.replace("_","-");
                    }
                    if ( obj_states.config_update_state !== undefined ) {
                        config = obj_states.config_update_state; //.replace("_", "-");
                    }
                }
                return {
                    'big': ( [ shape, color ] ).join( '_' ),
                    'small': small,
                    'config': config
                };
            },
            getTypeName: function ( value ) {
                if ( this.options.icon_mappings && this.options.icon_mappings[ value ] ) {
                    value = this.options.icon_mappings[ value ].type_display_name;
                }
                return value;
            },
            retrieveActions: function ( $button, elemData ) {
                var that = this;
                $button.next().spin( 'small' );
                $button.attr( 'disabled', true );
                $.ajax( {
                    'type': 'GET',
                    'url': that.options.actions_url + '?obj_id=' + elemData.obj_id + '&obj_type=' + elemData.type,
                    'success': function ( data ) {
                        if ( data !== undefined && data.obj_id !== undefined ) {
                            $button.data( 'actions-retrieved', 1 );
                            if ( data.actions.length > 0 ) {
                                that.addActions( data.actions, elemData, $button );
                            } else {
                                that.addActions( data.actions, elemData, $button );
                                $button.next().spin( false );
                            }
                        }
                        $button.removeAttr( 'disabled' ); //We need to add that line in error handler as well
                        $button.trigger( 'retrievedActions' );
                    }
                } );
            },
            addActions: function ( actions, elemData, $button ) {
                var $actionList = $button.parent().find( '.n-action-list' ),
                    i,
                    len,
                    $action,
                    numberOfActions = $button.parents( '.n-splitbutton-container' ).find( 'li' ).length,
                    stopLoading = function () {
                        if ( ( numberOfActions + actions.length ) === $button.parents( '.n-splitbutton-container' ).find( 'li' ).length ) {
                            $button.next().spin( false );
                        } else {
                            setTimeout( stopLoading, 300 );
                        }
                    };
                stopLoading();
                if ( actions.length === 0 ) {
                    $action = $( '<li><span>No actions available</span></li>' );
                    $actionList.append( $action );
                } else {
                    for ( i = 0, len = actions.length; i < len; i++ ) {
                        $action = $( '<li actionvalue="' + actions[ i ].action_id + '" actionname="' + actions[ i ].action_name + '"></li>' );
                        if ( actions[ i ].is_enable === 0 ) {
                            $action.addClass( 'disabled' );
                            $action.append( '<a>' + actions[ i ].action_name + '</a>' );
                        } else {
                            if ( actions[ i ].url !== undefined ) {
                                $action.append( $( '<a href="' + actions[ i ].url + '">' + actions[ i ].action_name + '</a>' ) );
                            }
                        }
                        $actionList.append( $action );
                    }
                }
            },
            _actionClickHandler: function ( element ) {
                $( element ).on( 'mousedown', '.n-action-list a', function ( e ) {
                    var content, eleSel, $this;
                    if ( e.which === 1 ) {
                        $this = $( this );
                        if ( $this.parent().hasClass( "disabled" ) ) {
                            return false;
                        }
                        content = $( '#content' );
                        content.empty();
                        content.spin();
                        eleSel = $( '.n-search.n-elementselector' ).data( 'nmswebElementSelector' );
                        if ( eleSel ) {
                            eleSel.closeGlobalPopover();
                        }
                        window.location = $this.attr( 'href' );
                    }
                } );
            },
            removePopOverClose: function ( element ) {
                if ( element.closest( '.n-popover-content' ).length === 0 &&
                    undefined !== this.dataSource.id &&
                    this.dataSource.id !== 'globalElementSelectorDS' ) {
                    element.find( '.n-element-selector-grid-toolbar-components-holder a.n-element-selector-close' ).remove();
                }
            },
            addConfigPopover: function ( element ) {
                var types = {};
                for ( var i in this.options.icon_mappings ) {
                    if ( this.options.icon_mappings.hasOwnProperty( i ) ) {
                        types[ i ] = this.options.icon_mappings[ i ].type_display_name;
                    }
                }
                element.on( 'click', '.n-element-selector-status.big-icon', function () {
                    var $this = $( this ),
                        id, url, popover, title, type;
                    //Avoid conflicts with angular implementation - this code will be obsolute soon
                    if ( $this.attr( 'obj_id' ) ) {
                        return;
                    }
                    $( '.n-elementselectoractions-popover' ).remove();
                    id = $this.data( 'element-id' );
                    type = $this.data( 'element-type' );
                    url = '/config-manager/elementselectoractions/popover_data?obj_id=' +
                        id + '&obj_type=' + type;
                    title = $( '<div/>' );
                    title.append( $this.closest( '.big-icon' ).clone() );
                    title.append( $this.data( 'element-name' ) );
                    popover = $this.nmswebPopover( {
                        'cssclass': 'n-elementselectoractions-popover',
                        'manual': false,
                        'exclusive': false,
                        'keypress': true,
                        'toggle': true,
                        'persistent': true,
                        'closeBtn': true, // show close 'X' in top-right
                        'showOnCreation': true, // don't hide immediately
                        'url': url, // URL for ajax
                        'spin': true, // show spin widget while getting content w/ajax
                        'cache': true, // cache ajax response for performance
                        'title': title,
                        'content': ''
                    } );
                } );
            }
        } );
        window.nmsweb.registerComponent( 'ElementSelectorGrid', ElementSelectorGrid );
        return ElementSelectorGrid;
    } );