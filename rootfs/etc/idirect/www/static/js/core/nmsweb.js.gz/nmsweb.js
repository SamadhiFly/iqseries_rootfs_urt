define( [ "jquery", "kendo", "core/date", "core/data" ], function ( $ ) {
    //template, month.content, footer
    "use strict";
    var kendo = window.kendo;
    window.nmsweb = window.nmsweb || {};
    window.nmsweb.templates = window.nmsweb.templates || {};
    window.nmsweb.callbacks = window.nmsweb.callbacks || {};

    window.nmsweb.applyCallbacks = function ( element, dataSource ) {
        dataSource.bind( 'sort', function () {
            element.trigger( 'datasource:sort' );
        } );
        dataSource.bind( 'filter', function () {
            element.trigger( 'datasource:filter' );
        } );
        dataSource.bind( 'page', function () {
            element.trigger( 'datasource:page' );
        } );
        dataSource.bind( 'group', function () {
            element.trigger( 'datasource:group' );
        } );
        dataSource.bind( 'delete', function () {
            element.trigger( 'datasource:delete' );
        } );
        dataSource.bind( 'update', function () {
            element.trigger( 'datasource:update' );
        } );
        dataSource.bind( 'create', function () {
            element.trigger( 'datasource:create' );
        } );
        dataSource.bind( 'selected', function () {
            element.trigger( 'datasource:selected' );
        } );
    };
    window.nmsweb.registerComponent = function ( name, constr ) {
        var componentName = 'nmsweb' + name;
        if ( typeof constr !== 'undefined' && typeof constr === "function" ) {
            window.nmsweb[ name ] = constr;
        }
        $.fn[ componentName ] = function ( options ) {
            var that = $( this ),
                className = 'n-' + name.toLowerCase(),
                component;
            options = options || {};
            component = new window.nmsweb[ name ]( that, options );
            component.componentName = componentName;
            that.trigger( 'ready', [ component ] );
            if ( component.dataSource && component.dataSource.id ) {
                that.attr( 'data-ds', component.dataSource.id );
                component.bind( 'dataBound', function () {
                    that.trigger( 'dataBound', [ component ] );
                } );
            }
            if ( typeof component.val === 'function' ) {
                that.attr( 'data-val', true );
            }
            this.data( componentName, component );
            that.addClass( className );
            if ( componentName === 'nmswebElementSelectorGrid' ) {
                that.trigger( 'nmswebClassApplied' );
            }

            if ( typeof component.dataSource === 'object' && component.dataSource !== null ) {
                window.nmsweb.applyCallbacks( component, component.dataSource );
            }
            return that;
        };
    };
    return window.nmsweb;
} );