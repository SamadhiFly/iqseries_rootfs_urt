define( [ 'kendo', 'core/nmsweb' ], function () {
    "use strict";
    var defaults = {},
        Rangeslider = window.kendo.ui.RangeSlider.extend( {
            init: function ( element, options ) {
                var that = this;
                if ( options ) {
                    nmsweb.extendOptions( defaults, options );
                }
                window.kendo.ui.RangeSlider.fn.init.call( that, element, defaults );
            }
        } );
    window.nmsweb.registerComponent( 'Rangeslider', Rangeslider );
    return Rangeslider;
} );