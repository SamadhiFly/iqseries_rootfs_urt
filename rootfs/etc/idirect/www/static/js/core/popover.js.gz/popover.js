define( [ 'jquery', 'angular', 'core/nmsweb', 'module/core/service/nmsutils' ], function ( $ ) {
    "use strict";
    var that = this,
        options,
        optionContent,
        placement,
        pos,
        actualWidth,
        actualHeight,
        tp,
        popoverHtml = '<div class=\"n-popoverbody\">' +
        '<div class=\"arrow\"></div>' +
        '<div class=\"overlayarrow\"></div>' +
        '<div class=\"n-popover-inner\">' +
        '<h2 class=\"n-popover-title\">' +
        '</h2>' +
        '<div class=\"n-popover-content\">' +
        '</div>' +
        '</div>' +
        '</div>',
        modalPopoverHtml = '<div class=\"n-popoverbody modal\">' +
        '<div class=\"n-popover-inner\">' +
        '<h2 class=\"n-popover-title\">' +
        '</h2>' +
        '<div class=\"n-popover-content\">' +
        '</div>' +
        '</div>' +
        '</div>',
        $body = $( 'body' ),
        Popover = window.kendo.Observable.extend( {
            that: that,
            options: options,
            init: function ( element, options ) {
                var $defaults = {
                        placement: 'right',
                        manual: false,
                        exclusive: true,
                        closeBtn: true,
                        spin: true,
                        cache: false,
                        content: '<div>Some Content</div>'
                    },
                    that = this,
                    $selector = $( element );
                if ( options.forceCreate || options.manual || $selector.is( ':visible' ) ) {
                    if ( options ) {
                        options = $.extend( true, $defaults, options );
                    }
                    if ( options.url !== undefined && !options.spin ) {
                        $.ajax( {
                            url: options.url,
                            async: false,
                            success: function ( data ) {
                                options.content = $( data.contents );
                            }
                        } );
                    }
                    window.kendo.Observable.fn.init.call( that, element, options );
                    $selector.each( function () {
                        that._createPopover( this, options );
                    } );
                }
            },
            _closePopover: function () {
                this.that.addClass( 'hide' );
            },
            _movePopover: function ( newelement ) {
                this.setPopoverPosition( this.that, newelement, this.options );
            },
            _createPopover: function ( selector, options ) {
                var $selected = $( selector ),
                    $popover,
                    freeze = false,
                    uniqueId,
                    that = this;
                if ( options.modalCentral ) {
                    $popover = $( modalPopoverHtml );
                } else {
                    $popover = $( popoverHtml );
                }
                if ( options.height ) {
                    $popover.find( '.n-popover-content' ).css( 'height', options.height + 'px' );
                }
                if ( options.width ) {
                    $popover.find( '.n-popover-content' ).css( 'width', options.width + 'px' );
                }
                if ( options.unique && ( undefined !== options.cssclass ||
                        undefined !== $selected.attr( 'id' ) ||
                        undefined !== $selected.attr( 'rel' ) ) ) {
                    //remove extra popups from dom
                    uniqueId = options.cssclass || $selected.attr( 'id' ) || $selected.attr( 'rel' );
                    $( '.n-popoverbody[data-unique="' + uniqueId + '"]' ).remove();
                    $popover.attr( 'data-unique', uniqueId );
                }
                this.that = $popover;
                this.options = options;
                if ( options.after !== undefined ) {
                    $( options.after ).after( $popover );
                } else if ( options.modal || options.modalCentral ) {
                    $( '.n-overlay' ).append( $popover );
                } else {
                    $body.append( $popover );
                }
                if ( options.id !== undefined ) {
                    $popover.attr( 'id', options.id );
                }
                if ( options.hoverdelay === true ) {
                    that._addHoverDelay( $popover, options );
                }
                if ( options.listen !== undefined ) {
                    that._addCloseListener( $popover, options );
                }
                if ( options.content !== undefined ) {
                    optionContent = that._getContent( options );
                }
                if ( $selected.data( 'content' ) ) {
                    options.content = $selected.data( 'content' );
                    optionContent = that._getContent( options );
                }
                if ( options.cssclass !== undefined ) {
                    $popover.addClass( options.cssclass );
                }
                if ( options.data ) {
                    $.each( options.data, function ( key, value ) {
                        $popover.attr( 'data-' + key, value );
                    } );
                }
                that._populateTitle( $popover, options );
                that._populateContent( $popover, options, $selected );
                $popover.find( '.close' ).on( 'click', function () {
                    $popover.addClass( 'hide' );
                    freeze = false;
                    if ( options.persistent !== undefined && options.persistent === false ) {
                        $popover.remove();
                        $selected.removeClass( 'n-popover' );
                    }
                    if ( options.modal || options.modalCentral ) {
                        $( '.n-overlay, .n-overlay .overlay' ).removeAttr( 'style' );
                    }
                } );
                if ( options.nested !== undefined && options.nested === true ) {
                    $popover.addClass( 'n-nested-popover' );
                }
                $popover.addClass( 'hide' );
                if ( ( options.persistent !== undefined && options.persistent === false ) || ( options.showOnCreation !== undefined && options.showOnCreation === true ) ) {
                    $popover.removeClass( 'hide' );
                    if ( !options.modalCentral ) {
                        that.setPopoverPosition( $popover, $selected, options );
                    } else {
                        $( '.n-overlay, .n-overlay .overlay' ).css( {
                            'visibility': 'visible'
                        } );
                    }
                }
                that._configureBehaviour( $selected, $popover, options );
                if ( !options.modalCentral ) {
                    that.setPopoverPosition( $popover, $selected, options );
                }
            },
            _configureBehaviour: function ( $selected, $popover, options ) {
                var freeze = false,
                    that = this;
                if ( ( ( options.manual !== undefined ) && ( options.manual === true ) ) || ( ( options.persistent !== undefined ) && ( options.persistent === false ) ) ) {
                    $selected.on( {
                        'click': function () {
                            // if element is disabled nothing should happen with popover (e.g. be hidden)
                            if ( $selected.attr( 'disabled' ) ) {
                                return;
                            }
                            var closed = $popover.hasClass( 'hide' ),
                                grid;
                            freeze = freeze ? false : true;
                            if ( !options.cssoverride && !options.modalCentral ) {
                                that.setPopoverPosition( $popover, $selected, options );
                            } else {
                                $popover.removeAttr( 'style' );
                            }
                            if ( options.exclusive !== undefined && options.exclusive === true ) {
                                $( '.n-popoverbody' ).addClass( 'hide' );
                            }
                            $popover.toggleClass( 'hide' );
                            if ( options.toggle && !closed ) {
                                $popover.addClass( 'hide' );
                            }
                            if ( $popover.hasClass( 'hide' ) && options.persistent !== undefined && options.persistent === false ) {
                                $popover.remove();
                                $selected.removeClass( 'n-popover' );
                            }
                            if ( closed ) {
                                grid = $popover.find( '.k-grid' );
                                if ( grid.length ) {
                                    grid = $( grid[ 0 ] );
                                    grid = grid.data( 'nmswebGrid' ) || grid.data( 'nmswebElementSelectorGrid' );
                                    if ( grid ) {
                                        grid.dataSource.trigger( 'change' );
                                    }
                                }
                            }
                            if ( options.modal || options.modalCentral ) {
                                $( '.n-overlay, .n-overlay .overlay' ).css( {
                                    'visibility': 'visible'
                                } );
                            }
                        }
                    } );
                } else if ( ( options.keypress !== undefined ) && ( options.keypress === true ) ) {
                    $selected.on( {
                        'keypress': function () {
                            if ( !options.cssoverride && !options.modalCentral ) {
                                that.setPopoverPosition( $popover, $selected, options );
                            } else {
                                $popover.removeAttr( 'style' );
                            }
                            if ( options.exclusive !== undefined && options.exclusive === true ) {
                                $( '.n-popoverbody' ).addClass( 'hide' );
                            }
                            $popover.removeClass( 'hide' );
                        },
                        'click': function () {
                            if ( $selected.val() !== '' ) {
                                if ( !options.cssoverride && !options.modalCentral ) {
                                    that.setPopoverPosition( $popover, $selected, options );
                                } else {
                                    $popover.removeAttr( 'style' );
                                }
                                if ( options.exclusive !== undefined && options.exclusive === true ) {
                                    $( '.n-popoverbody' ).addClass( 'hide' );
                                }
                                var elem = angular.element( $( '#app' ) ),
                                    injector = elem.injector(),
                                    NMSUtils = injector.get( 'NMSUtils' );
                                $popover.css( 'z-index', NMSUtils.getPopoverIndex( false ) );
                                if ( $popover.hasClass( 'hide' ) ) {
                                    NMSUtils.increasePopoverIndex();
                                }
                                $popover.removeClass( 'hide' );
                                if ( options.modal || options.modalCentral ) {
                                    $( '.n-overlay, .n-overlay .overlay' ).css( {
                                        'visibility': 'visible'
                                    } );
                                }
                            }
                        }
                    } );
                } else {
                    $selected.on( {
                        'click': function () {
                            if ( options.toggle ) {
                                $popover.toggleClass( 'hide' );
                            }
                            if ( options.modal || options.modalCentral ) {
                                $( '.n-overlay, .n-overlay .overlay' ).css( {
                                    'visibility': 'visible'
                                } );
                            }
                            freeze = freeze ? false : true;
                        },
                        'mouseenter focus': function () {
                            if ( !options.cssoverride && !options.modalCentral ) {
                                that.setPopoverPosition( $popover, $selected, options );
                            } else {
                                $popover.removeAttr( 'style' );
                            }
                            if ( options.exclusive !== undefined && options.exclusive === true ) {
                                $( '.n-popoverbody' ).addClass( 'hide' );
                            }
                            $popover.removeClass( 'hide' );
                        },
                        'mouseleave blur': function () {
                            if ( !freeze ) {
                                $popover.addClass( 'hide' );
                                if ( options.persistent !== undefined && options.persistent === false ) {
                                    $popover.remove();
                                }
                            }
                        }
                    } );
                }
            },
            _populateTitle: function ( $popover, options ) {
                var $title = $popover.find( '.n-popover-title' ),
                    tooltipTitle,
                    $nestedPopover;
                if ( options.title ) {
                    if ( typeof ( options.title ) === 'object' ) {
                        $title.append( options.title );
                    } else if ( typeof ( options.title ) === 'string' ) {
                        $title[ 0 ].innerHTML = options.title;
                    }
                } else {
                    $title.remove();
                }
                if ( options.closeBtn && !$title.find( '.close' ).length ) {
                    $title.append( $( '<a class=\"close\">&times;</a>' ) );
                }
                if ( options.titletextbackgroundcolor !== undefined ) {
                    $title.css( 'background-color', options.titletextbackgroundcolor );
                }
                if ( options.tooltip !== undefined && options.tooltip === true ) {
                    tooltipTitle = 'A Title';
                    if ( options.tooltiptitle !== undefined ) {
                        tooltipTitle = options.tooltiptitle;
                    }
                    $nestedPopover = $( '<a class=\'n-popover-icon\' style=\'margin-left: 10px\'></a>' );
                    $title.append( $nestedPopover );
                    $nestedPopover.nmswebPopover( {
                        'placement': 'right',
                        'title': tooltipTitle,
                        'content': options.tooltip
                    } );
                }
                if ( options.formtooltip !== undefined && options.formtooltip === true ) {
                    $title.remove();
                    $popover.addClass( 'n-form-popover' );
                }
                if ( options.titletextcolor !== undefined ) {
                    $title.css( 'color', options.titletextcolor );
                }
            },
            _populateContent: function ( $popover, options, $selected ) {
                var $content = $popover.find( '.n-popover-content' );
                if ( options.url === undefined || !options.spin ) {
                    $content.append( optionContent );
                    if ( options.formtooltip !== undefined && options.formtooltip === true ) {
                        $popover.find( '.n-popover-content' ).append( $( '<a class=\"close\">&times;</a>' ) );
                    }
                } else {
                    if ( options.cache && $selected.data( 'popover-cache' ) !== undefined ) {
                        // use cached content
                        $content.html( $selected.data( 'popover-cache' ) );
                    } else {
                        // set up a spinner while waiting for ajax
                        $content.spin( 'medium' );
                        // fetch content
                        $.ajax( {
                            url: options.url,
                            async: 'true',
                            success: function ( data ) {
                                if ( typeof data.contents === "undefined" ) {
                                    $content.html( "No content available&hellip;" );
                                } else {
                                    // replace content with ajax response
                                    $content.html( data.contents );
                                    // cache the ajax for next time
                                    if ( options.cache ) {
                                        $selected.data( 'popover-cache', data.contents );
                                    }
                                }
                            }
                        } );
                    }
                }
            },
            _addHoverDelay: function ( $popover, options ) {
                var popovertimer;
                $popover.on( {
                    'mouseenter focus': function () {
                        clearTimeout( popovertimer );
                    },
                    'mouseleave blur': function () {
                        popovertimer = setTimeout( function () {
                            $popover.addClass( 'hide' );
                        }, 500 );
                        if ( options.persistent !== undefined && options.persistent === false ) {
                            $popover.remove();
                        }
                    }
                } );
            },
            _getContent: function ( options ) {
                var content;
                if ( typeof ( options.content ) === 'object' ) {
                    if ( options.formtooltip !== undefined && options.formtooltip === true ) {
                        content = options.content;
                    } else {
                        content = options.content;
                    }
                } else if ( typeof ( options.content ) === 'string' ) {
                    if ( options.formtooltip !== undefined && options.formtooltip === true ) {
                        content = $( $.parseHTML( options.content ) );
                    } else {
                        content = $( $.parseHTML( options.content ) );
                    }
                }
                return content;
            },
            _addCloseListener: function ( $popover, options ) {
                if ( options.listen.container && options.listen.container.data( 'kendoTabStrip' ) ) {
                    if ( options.listen.container.length > 1 ) {
                        options.listen.container.each( function ( key, value ) {
                            $( value ).data( 'kendoTabStrip' ).bind( "activate", function () {
                                if ( options.persistent ) {
                                    $popover.addClass( "hide" );
                                } else {
                                    $popover.remove();
                                }
                            } );
                        } );
                    } else {
                        $( options.listen.container[ 0 ] ).data( 'kendoTabStrip' ).bind( "activate", function () {
                            if ( options.persistent ) {
                                $popover.addClass( "hide" );
                            } else {
                                $popover.remove();
                            }
                        } );
                    }
                }
                $body.on( options.listen.event, function () {
                    $popover.addClass( 'hide' );
                } );
            },
            resetArrows: function ( popover, height ) {
                popover.find( '.arrow' ).css( {
                    'top': height / 2 - 12.5
                } );
                popover.find( '.overlayarrow' ).css( {
                    'top': height / 2 - 12.5
                } );
            },
            resetArrowsWidthPos: function ( popover, left ) {
                popover.find( '.arrow' ).css( {
                    'left': left
                } );
                popover.find( '.overlayarrow' ).css( {
                    'left': left
                } );
            },
            setPopoverPosition: function ( popover, owner, options ) {
                var self = this;
                popover.css( {
                    top: 0,
                    left: 0,
                    display: 'block'
                } );
                placement = options.placement;
                pos = owner.getPosition();
                actualWidth = popover[ 0 ].offsetWidth;
                actualHeight = popover[ 0 ].offsetHeight;
                popover.removeAttr( 'style' );
                switch ( placement ) {
                case 'bottom':
                    tp = {
                        top: pos.top + pos.height,
                        left: pos.left + pos.width / 2 - actualWidth / 2
                    };
                    break;
                case 'top':
                    tp = {
                        top: pos.top - actualHeight,
                        left: pos.left + pos.width / 2 - actualWidth / 2
                    };
                    break;
                case 'left':
                    this.resetArrows( popover, actualHeight );
                    tp = {
                        top: pos.top + pos.height / 2 - actualHeight / 2,
                        left: pos.left - actualWidth
                    };
                    break;
                case 'right':
                    this.resetArrows( popover, actualHeight );
                    tp = {
                        top: pos.top + pos.height / 2 - actualHeight / 2,
                        left: pos.left + pos.width
                    };
                    break;
                }
                popover.css( tp ).addClass( placement );
                ( function ( popover, placement ) {
                    setTimeout( function () {
                        var visibleHeight = document.documentElement.clientHeight,
                            scrollHeight = document.body.scrollHeight,
                            top = scrollHeight - visibleHeight - document.body.scrollTop,
                            arrowPosition;
                        if ( tp.top < document.body.scrollTop ) {
                            tp.top = document.body.scrollTop;
                            popover.css( tp ).addClass( placement );
                            if ( placement === 'right' || placement === 'left' ) {
                                actualHeight = popover[ 0 ].offsetHeight + top;
                                arrowPosition = $( owner ).offset().top + ( $( owner ).height() / 2 ) - tp.top;
                                if ( $( owner ).offset().top + ( $( owner ).height() / 2 ) - $( popover ).offset().top < 20 ) {
                                    arrowPosition = $( popover ).offset().top - tp.top + 20;
                                }
                                self.resetArrows( popover, arrowPosition * 2 );
                            }
                        }
                        if ( scrollHeight > visibleHeight ) {
                            if ( tp.top + popover[ 0 ].offsetHeight - document.body.scrollTop > visibleHeight ) {
                                tp.top -= tp.top + popover[ 0 ].offsetHeight - document.body.scrollTop - visibleHeight;
                                if ( placement === 'right' || placement === 'left' ) {
                                    actualHeight = popover[ 0 ].offsetHeight + top;
                                    arrowPosition = $( owner ).offset().top + ( $( owner ).height() / 2 ) - tp.top;
                                    if ( popover[ 0 ].offsetHeight + tp.top - ( $( owner ).offset().top + ( $( owner ).height() / 2 ) ) < 45 ) {
                                        arrowPosition = popover[ 0 ].offsetHeight + tp.top - tp.top - 45;
                                    }
                                    self.resetArrows( popover, arrowPosition * 2 );
                                }
                                popover.css( tp ).addClass( placement );
                            }
                        }
                        var visibleWidth = document.documentElement.clientWidth,
                            scrollWidth = document.body.scrollWidth,
                            left = scrollWidth - visibleWidth - document.body.scrollLeft;
                        if ( tp.left < document.body.scrollLeft ) {
                            tp.left = document.body.scrollLeft;
                            popover.css( tp ).addClass( placement );
                            if ( placement === 'bottom' || placement === 'top' ) {
                                actualWidth = popover[ 0 ].offsetWidth + left;
                                arrowPosition = $( owner ).offset().left + ( $( owner ).width() / 2 ) - tp.left;
                                if ( $( owner ).offset().left + ( $( owner ).width() / 2 ) - $( popover ).offset().left < 20 ) {
                                    arrowPosition = $( popover ).offset().left - tp.left + 20;
                                }
                                self.resetArrowsWidthPos( popover, arrowPosition );
                            }
                        }
                        if ( scrollWidth > visibleWidth ) {
                            if ( tp.left + popover[ 0 ].offsetWidth - document.body.scrollLeft > visibleWidth ) {
                                tp.left -= tp.left + popover[ 0 ].offsetWidth - document.body.scrollLeft - visibleWidth;
                                if ( placement === 'bottom' || placement === 'top' ) {
                                    actualWidth = popover[ 0 ].offsetWidth + left;
                                    arrowPosition = $( owner ).offset().left + ( $( owner ).width() / 2 ) - tp.left;
                                    if ( popover[ 0 ].offsetWidth + tp.left - ( $( owner ).offset().left + ( $( owner ).width() / 2 ) ) < 45 ) {
                                        arrowPosition = popover[ 0 ].offsetWidth + tp.left - tp.left - 45;
                                    }
                                    self.resetArrowsWidthPos( popover, arrowPosition );
                                }
                                popover.css( tp ).addClass( placement );
                            }
                        }
                        var elem = angular.element( $( '#app' ) ),
                            injector = elem.injector(),
                            NMSUtils = injector.get( 'NMSUtils' );
                        popover.css( 'z-index', NMSUtils.getPopoverIndex() );
                    }, 100 );
                } )( popover, placement );
            }
        } );
    window.nmsweb.registerComponent( 'Popover', Popover );
    return Popover;
} );