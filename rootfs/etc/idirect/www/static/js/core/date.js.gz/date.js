define( [ "kendo" ], function () {
    //template, month.content, footer
    'use strict';
    var kendo = window.kendo,
        oldDate = window.Date,
        oldParse = window.Date.parse;

    function getTime() {
        /*jshint -W040 */
        return parseInt( oldDate.prototype.getTime.call( this ) / 1000, 10 );
    }

    function Date() {
        var that = this,
            ret,
            args,
            regex = /\D+/,
            code = '',
            i,
            len;
        if ( that === undefined ) {
            return oldDate.apply( oldDate, arguments );
        }
        if ( arguments.length === 2 ) {
            if ( arguments[ 0 ] === 'milliseconds' && typeof arguments[ 1 ] === 'number' ) {
                ret = new oldDate( arguments[ 1 ] );
            }
        } else if ( arguments.length === 1 && typeof arguments[ 0 ] === 'number' && arguments[ 0 ] < 99999999999 && arguments[ 0 ] > 0 ) {
            ret = new oldDate( arguments[ 0 ] * 1000 );
            ret.getTime = getTime;
            ret.getTimeMilliseconds = new oldDate().getTime;
            ret.getTimeInSec = getTime;
        } else if ( arguments.length === 1 && typeof arguments[ 0 ] === 'string' ) {
            if ( !regex.test( arguments[ 0 ] ) ) {
                ret = new Date( parseInt( arguments[ 0 ], 10 ) );
            } else {
                ret = kendo.parseDate( arguments[ 0 ] );
                if ( ret === null ) {
                    ret = new Date( NaN );
                }
            }
        } else {
            if ( arguments[ 0 ] instanceof oldDate ) {
                ret = new Date( arguments[ 0 ].getTime() );
            } else {
                args = Array.prototype.slice.call( arguments );
                if ( Function.prototype.constructor.bind ) {
                    args.unshift( oldDate );
                    ret = new( Function.prototype.constructor.bind.apply( oldDate, args ) )();
                } else {
                    code = 'return new oldDate( ';
                    for ( i = 0, len = args.length; i < len; i++ ) {
                        code = code + 'args[' + i + '],';
                    }
                    code = code.slice( 0, code.length - 1 );
                    code = code + ');';
                    /*jshint -W054 */
                    return ( new Function( "args", code ) )( args );
                }
            }
        }
        ret.setTime = function ( val ) {
            if ( typeof val === 'number' && val < 99999999999 && val > 0 ) {
                return oldDate.prototype.setTime.call( this, val * 1000 );
            } else if ( typeof val === 'string' && !regex.test( val ) ) {
                return oldDate.prototype.setTime.call( this, parseInt( val, 10 ) * 1000 );
            } else {
                return oldDate.prototype.setTime.call( this, val );
            }
        };
        ret.toString = function () {
            if ( this.toJSON() === null ) {
                return oldDate.prototype.toString.call( this );
            }
            if ( this.getTime() === 0 ) {
                return "n/a";
            }
            var convertedDate;
            if ( ret.getTimeMilliseconds ) {
                convertedDate = ret.getTimeMilliseconds() + this.getTimezoneOffset() * 60000;
            } else {
                convertedDate = ret.getTime() + this.getTimezoneOffset() * 60000;
            }
            return window.kendo.toString( new Date( convertedDate ), 'yyyy-MM-dd HH:mm:ss' );
        };
        return ret;
    }
    Date.UTC = function () {
        var milli = arguments[ 0 ];
        if ( milli === 'milliseconds' ) {
            delete arguments[ 0 ];
            return oldDate.UTC.apply( null, arguments );
        }
        return oldDate.UTC.apply( null, arguments ) / 1000;
    };
    Date.parse = function () {
        if ( arguments.length === 2 && arguments[ 0 ] === 'milliseconds' ) {
            if ( arguments[ 1 ] instanceof oldDate ) {
                return arguments[ 1 ].getTime();
            }
            return oldParse.call( this, arguments[ 1 ] );
        } else {
            if ( arguments[ 0 ] instanceof oldDate ) {
                if ( typeof arguments[ 0 ].getTimeInSec === 'function' ) {
                    return arguments[ 0 ].getTimeInSec();
                } else {
                    return arguments[ 0 ].getTime() / 1000;
                }
            }
            return ( Math.round( oldParse.call( this, arguments[ 0 ] ) / 1000 ) );
        }
    };
    window.kendo.toStringOld = window.kendo.toString;
    window.kendo.toString = function () {
        return window.kendo.toStringOld.apply( this, arguments );
    };
    if ( navigator.appVersion.search('PhantomJS') === -1 ) { // This should be removed once the UTC changes are completed
     window.Date = Date;
     window.Date.prototype = oldDate.prototype;
     window.Date.prototype.toJSON = function () {
         return window.kendo.toString( this, 'yyyy-MM-dd HH:mm:ss' );
     }
    }
    Date.now = oldDate.now;
    window.oldDate = oldDate;
    return Date;
} );
