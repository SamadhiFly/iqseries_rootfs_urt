define( [ 'kendo', 'kendo', 'core/nmsweb' ], function () {
    "use strict";
    var PanelBar = window.kendo.ui.PanelBar.extend( {
        init: function ( element, options ) {
            var that = this,
                defaults = {
                    animation: false
                };
            if ( options ) {
                nmsweb.extendOptions( defaults, options );
            }
            window.kendo.ui.PanelBar.fn.init.call( that, element, defaults );
        }
    } );
    window.nmsweb.registerComponent( 'PanelBar', PanelBar );
    return PanelBar;
} );