define( [ "kendo", "core/nmsweb", "external/bootstrap/multiselector" ], function () {
    "use strict";
    var Bookmarks,
        kendo = window.kendo,
        Observable = kendo.Observable,
        address,
        FIELDSSELECTOR = ':enabled:visible:not([type="password"]):not([type="submit"]):not(button)';
    Bookmarks = Observable.extend( {
        init: function ( selector, options ) {
            var that = this,
                addButton,
                bookmarks = options.bookmarks,
                bookmark;
            Observable.fn.init.call( that );
            address = options.address;
            that._form = $( options.formId );
            that._selector = selector;
            that._bookmarksContainer = $( selector.find( 'dl' ) );
            that._template = kendo.template( $( "#bookmark-template" ).html() );
            that._fieldTemplate = kendo.template( $( "#bookmark-field-template" ).html() );
            for ( bookmark in bookmarks ) {
                if ( bookmarks.hasOwnProperty( bookmark ) ) {
                    that.prepend( bookmarks[ bookmark ] );
                }
            }
            addButton = selector.find( '#bookmark-add button' );
            addButton.on( 'click', $.proxy( that, 'add' ) ); //Need to change context for Bookmark object
            that._bookmarksContainer.on( 'click', '.bookmark-delete', that.deleteB ); //Have to keep button context
            that._bookmarksContainer.on( 'click', '.bookmark-quicklink', that.update ); //Have to keep checkbox context
            that._bookmarksContainer.on( 'click', '.bookmark-load', that.load ); //Have to keep button context
            $( that._form ).on( 'change', FIELDSSELECTOR, function () {
                var serialized = $( that._form ).serialize(),
                    newPath = window.location.pathname + '?' + serialized,
                    state = window.history.state;
                window.history.replaceState( state, '', newPath );
            } );
            $( that._selector ).data( 'nmswebBookmark', that );
            return that;
        },
        add: function () {
            var that = this,
                addInput = that._selector.find( '#bookmark-add input' ),
                values = that._form.find( FIELDSSELECTOR ).serializeArray(),
                value,
                name,
                bookmark = {
                    values: {},
                    labels: {},
                    name: addInput.val(),
                    serialized: ''
                };
            for ( value in values ) {
                if ( values.hasOwnProperty( value ) ) {
                    name = values[ value ].name;
                    if ( values[ value ].value !== '' ) {
                        bookmark.values[ name ] = {};
                        bookmark.values[ name ].value = values[ value ].value;
                        bookmark.values[ name ].label = that._form.find( 'label[for="' + name + '"]' ).text();
                        bookmark.values[ name ].name = name;
                    }
                }
            }
            bookmark.serialized = that._form.serialize();
            if ( bookmark.name !== '' ) {
                $.ajax( {
                    type: 'PUT',
                    url: address,
                    data: bookmark,
                    success: function ( data ) {
                        bookmark.id = data.id;
                        that.prepend( bookmark );
                    }
                } );
            }
        },
        prepend: function ( bookmark ) {
            var that = this,
                newBookmark,
                value,
                dropdownContainer,
                field;
            bookmark.quicklink = bookmark.quicklink === 1 || bookmark.quicklink === true ? 'active' : '';
            that._bookmarksContainer.prepend( that._template( {
                name: bookmark.name,
                id: bookmark.id,
                quicklink: bookmark.quicklink
            } ) );
            newBookmark = that._bookmarksContainer.children( 'dt:first' );
            newBookmark.data( 'values', bookmark.values );
            dropdownContainer = newBookmark.find( '.dropdown-menu:first' );
            for ( value in bookmark.values ) {
                if ( bookmark.values.hasOwnProperty( value ) ) {
                    field = bookmark.values[ value ];
                    dropdownContainer.append( that._fieldTemplate( {
                        name: field.name,
                        value: field.value,
                        label: field.label
                    } ) );
                }
            }
        },
        deleteB: function () {
            var that = $( this ),
                item = that.closest( 'dt' ),
                id = item.data( 'bookmark' ),
                deleteItem = function () {
                    item.remove();
                };
            if ( id === undefined ) {
                deleteItem();
            } else {
                $.ajax( {
                    type: 'DELETE',
                    url: address,
                    data: {
                        id: id
                    },
                    success: function () {
                        deleteItem();
                    }
                } );
            }
        },
        update: function () {
            var that = $( this ),
                item = that.closest( 'dt' ),
                id = item.data( 'bookmark' );
            if ( id !== undefined ) {
                $.ajax( {
                    type: 'POST',
                    url: address,
                    data: {
                        id: id
                    },
                    success: function () {
                        that.toggleClass( 'active' );
                    }
                } );
            }
            return false;
        },
        load: function () {
            var that = $( this ),
                item = that.closest( 'dt' ),
                list = item.find( 'input.bookmark-field:checked' ),
                field,
                formField,
                last,
                name,
                value,
                obj = that.closest( '.bookmark-engine' ).data( 'nmswebBookmark' );
            list.each( function ( i ) {
                field = $( list[ i ] );
                name = field.attr( 'name' );
                value = field.attr( 'value' );
                formField = obj._form.find( '[name="' + name + '"]' );
                if ( formField !== undefined ) {
                    formField.val( value );
                    last = formField;
                }
            } );
            if ( last !== undefined ) {
                last.trigger( 'change' );
            }
        }
    } );
    window.nmsweb.registerComponent( 'Bookmarks', Bookmarks );
    return Bookmarks;
} );