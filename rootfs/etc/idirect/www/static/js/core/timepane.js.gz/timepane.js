define( [ 'core/date' ], function () {
    "use strict";
    window.nmsweb = window.nmsweb || {};
    window.nmsweb.timepane = function ( $localDateTimeContainer, $systemTimeDateContainer, refreshInterval ) {
        var localTimeBefore,
            $localTimeContainer = $( '.time', $localDateTimeContainer ),
            $systemTimeContainer = $( '.time', $systemTimeDateContainer ),
            serverOffset,
            updateTimers = function () {
                var date = new Date();
                //display local time
                $localTimeContainer.html( window.kendo.toString( date, 'HH:mm:ss' ) );
                //display server time
                date.setMilliseconds( date.getMilliseconds() - serverOffset );
                window.nmsweb.__systemTime = date;
                $systemTimeContainer.html( window.kendo.toString( date, 'HH:mm:ss' ) );
            };
        refreshInterval = refreshInterval || 1000;
        localTimeBefore = new Date().getTime();
        //get server time
        $.ajax( {
            type: 'GET',
            url: '/core/time',
            data: {
                'local_timestamp': localTimeBefore / 1000
            },
            dataType: 'json',
            success: function ( data ) {
                var localTimeAfter = new Date(),
                    serverTime;
                if ( data !== undefined && data.server_time !== undefined ) {
                    serverTime = new Date(
                        data.server_time.year,
                        data.server_time.month,
                        data.server_time.day,
                        data.server_time.hours,
                        data.server_time.minutes,
                        data.server_time.seconds,
                        data.server_time.miliseconds
                    );
                    serverOffset = localTimeAfter - serverTime; //assumption: server response time is neglectable
                    $( '.time-zone', $systemTimeDateContainer ).html( data.server_time.time_zone );
                }
                updateTimers();
                setInterval( function () {
                    updateTimers();
                }, refreshInterval );
            }
        } );
    };
    return window.nmsweb.timepane;
} );