define( [ "kendo", "core/utils" ], function ( kendo ) {
    "use strict";
    window.WebSocket = window.WebSocket || window.MozWebSocket;
    var Jmr,
        kendo = window.kendo,
        Observable = kendo.Observable,
        heartbeat = 1000,
        heartbeatTimer,
        singleton,
        getSid = window.nmsutils.getSid,
        attempts = 0, //number of performed attempts 
        notifyFrom = 4, //notify user after n attempts
        timeoutTimer,
        timeArray = [ 1, 1, 1, 5, 5, 10, 10, 30, 30 ],
        timer;
    /**
     * Function to renew connection
     **/
    function renew() {
        var jmr = singleton;
        $( '#n-time-notifier-text:visible' ).html( 'Reconnecting...' );
        singleton = new Jmr( jmr.__address );
        attempts += 1;
        console.info( 'Attempting to reconnect WebSocket' );
        singleton.open();
    }

    function jmrBack() {
        $( 'body' ).trigger( 'nmsweb:jmrClose' );
        $( 'body' ).trigger( 'nmsweb:jmrBack' );
        if ( attempts > notifyFrom ) {
            console.info( 'JMR connected back to server' );
            $( 'body' ).nmswebNotification( {
                title: 'WebSocket connected',
                message: 'Streaming is available',
                type: 'success'
            } );
        }
        attempts = 0;
    }

    function counter() {
        var ele = $( '.n-time-notifier:visible' ),
            second;
        if ( ele.length ) {
            second = parseInt( ele.text(), 10 ) || 1;
            ele.text( ( second - 1 ) );
        }
    }

    function notifyAttempt( seconds ) {
        var ele = $( '#n-time-notifier-text:visible' ),
            text = "Trying to reconnect in <span class=\"n-time-notifier\">" + seconds + "</span> seconds. <a class=\"n-fire-now-notification\" href=\"#\">Try now</a>";
        clearInterval( timer );
        if ( ele.length ) {
            ele.html( text );
        } else {
            $( 'body' ).nmswebNotification( {
                "type": "majorwarning",
                "title": "WebSocket connection lost",
                "message": "<span>Any streaming information cannot<br>be relied upon.</span><br><span id=\"n-time-notifier-text\">" + text + "</span>",
                'progress': true,
                'listenfor': 'nmsweb:jmrClose'
            } );
            $( '#n-time-notifier-text:visible' ).html( text );
        }
        $( '.n-fire-now-notification:visible' ).on( 'click', function () {
            clearTimeout( timeoutTimer );
            renew();
            return false;
        } );
        timer = setInterval( counter, 1000 );
    }

    function onError() {
        var num,
            len = timeArray.length,
            renewTimeouted = function () {
                clearTimeout( timeoutTimer );
                renew();
            };
        clearInterval( heartbeatTimer );
        if ( attempts > ( len - 1 ) ) {
            clearTimeout( timeoutTimer );
            $( 'body' ).trigger( 'nmsweb:jmrClose' );
            $( 'body' ).nmswebNotification( {
                "type": "error",
                "title": "WebSocket connection lost",
                "message": "<span>Any streaming information cannot<br>be relied upon.</span><br><span id=\"n-time-notifier-text\">Refresh to try again.</span>",
                'progress': false,
                'listenfor': 'nmsweb:jmrClose'
            } );
        } else {
            num = timeArray[ attempts ];
            if ( attempts > notifyFrom ) {
                $( 'body' ).trigger( 'nmsweb:jmrDown' );
                notifyAttempt( num );
            }
            timeoutTimer = setTimeout( renewTimeouted, ( num * 999 ) );
        }
    }
    Jmr = Observable.extend( {
        init: function ( address ) {
            var that = this,
                protocol = 'ws://';
            Observable.fn.init.call( that );
            if ( location.protocol === 'https:' ) {
                protocol = 'wss://';
            }
            address = address || that._address || '';
            address = address.replace( /^(http|https){0,1}:{0,1}\/\//, '' );
            that.__address = address;
            that._address = protocol + address;
            that._protocol = protocol;
            that._opened = false;
        },
        open: function () {
            var that = this;
            if ( that._address === undefined ) {
                that.trigger( 'error' );
            } else {
                that._address = that._protocol + that.__address;
                that._ws = new window.WebSocket( that._address );
                that._ws.onopen = function () {
                    that._wserror = false;
                    var sid = getSid();
                    that._ws.send( JSON.stringify( {
                        request: 'handshake',
                        sid: sid
                    } ) );
                    clearInterval( heartbeatTimer );
                    heartbeatTimer = setInterval( function () {
                        that._ws.send( JSON.stringify( {
                            request: 'heartbeat',
                            sid: sid
                        } ) );
                    }, heartbeat );
                    that.trigger( 'open' );
                    that._opened = true;
                    jmrBack();
                    console.info( 'WebSocket connected' );
                };
                that._ws.onmessage = function ( message ) {
                    var response = JSON.parse( message.data );
                    console.info( 'Response:', response );
                    if ( response.result === 200 ) {
                        that.trigger( 'message', response );
                        try {
                            console.info( 'Data:', response.payload.data );
                        } catch ( e ) {
                            console.error( e );
                        }
                        if ( response.cid !== undefined ) {
                            if ( response.async ) {
                                that.trigger( response.cid + ':async', response );
                            } else {
                                that.trigger( response.cid, response );
                            }
                        }
                    } else if ( response.result === 278 ) {
                        window.location = window.location;
                    } else if ( response.result === 207 ) {
                        //Notifications
                        response.status = response.status || 'info';
                        $( 'body' ).nmswebNotification( response );
                    } else if ( response.result >= 400 && response.result < 600 ) { //Error
                        that.trigger( 'error', response );
                        that.trigger( response.cid + ':error', response );
                        that.trigger( response.cid + ':async:error', response );
                        if ( !response.silent ) {
                            $( 'body' ).nmswebNotification( {
                                title: "Streaming error",
                                type: "error",
                                message: response.message + '<br>Error code: <strong>' + response.result + '</strong>'
                            } );
                        }
                    }
                };
                that._ws.onerror = function () {
                    console.warn( 'Error occured while trying to connect WebSocket' );
                    that.trigger( 'error' );
                    that._wserror = true;
                    onError();
                };
                that._ws.onclose = function () {
                    console.warn( 'WebSocket disconnected' );
                    that.trigger( 'close' );
                    if ( !that._wserror ) {
                        onError();
                    }
                };
            }
        },
        //Request object should have: request, cid, backend
        send: function ( request ) {
            var that = this;
            if ( typeof request !== 'object' ) {
                throw 'request has to be an object';
            } else {
                request.sid = getSid();
            }
            if ( that._opened ) {
                if ( that._ws === undefined ) {
                    that.trigger( 'error' );
                } else {
                    console.info( 'Sending request', request );
                    that._ws.send( JSON.stringify( request ) );
                }
            } else {
                that.one( 'open', function () {
                    if ( that._ws === undefined ) {
                        that.trigger( 'error' );
                    } else {
                        console.info( 'Sending request', request );
                        that._ws.send( JSON.stringify( request ) );
                    }
                } );
            }
        }
    } );
    window.nmsweb = window.nmsweb || {};
    window.nmsweb.jmr = function ( address ) {
        if ( singleton === undefined ) {
            singleton = new Jmr( address );
            if ( address !== undefined ) {
                singleton.open();
            }
        } else if ( address !== undefined ) {
            singleton._address = address;
            singleton.open();
        }
        return singleton;
    };
    $( 'body' ).on( 'nmsweb:jmrClose', function () {
        clearInterval( timer );
    } );
    require( [ "core/notification" ] );
    return window.nmsweb.jmr;
} );