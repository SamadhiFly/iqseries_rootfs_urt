define( [
    'jquery',
    'core/input',
    'core/datepicker',
    'core/datetimepicker',
    'core/timepicker',
    'core/select'
 ], function ( $ ) {
    "use strict";
    var form = function ( selector, options ) {
        var module = options.module,
            lib = options.lib,
            source = options.source,
            verticalrendering = options.verticalrendering,
            action = $( selector ).attr( 'action' ),
            method = $( selector ).attr( 'method' ),
            i,
            _validate = function ( data ) {
                var errors,
                    error_name,
                    $error_box,
                    error_string,
                    contents = JSON.parse( data.contents );
                if ( data.error ) {
                    return false;
                }
                if ( contents.payload.url ) {
                    window.location.href = contents.payload.url;
                }
                if ( contents.payload.html ) {
                    $( selector ).slideUp(
                        'slow',
                        function () {
                            $( selector ).html( contents.payload.html );
                            $( selector ).slideDown( 'fast' );
                        }
                    );
                }
                if ( contents.payload.errors ) {
                    $( selector + ':input' ).each( function () {
                        error_name = $( this ).attr( 'id' );
                        $error_box = $( 'div[id="' + error_name + '_errors"]' );
                        errors = contents.payload.errors[ error_name ];
                        if ( errors ) {
                            error_string = '';
                            for ( i = 0; i < errors.length; i++ ) {
                                error_string += errors[ i ] + '<br />';
                            }
                            $error_box.html( error_string );
                            $error_box.addClass( 'alert alert-error' );
                        } else {
                            $error_box.text( '' );
                            $error_box.removeClass( 'alert alert-error' );
                        }
                    } );
                }
            },
            _init = function () {
                $( selector ).find( 'input' ).each( function () {
                    if ( !( $( this ).attr( "complex" ) ) ) {
                        $( this ).nmswebInput( {
                            "module": module,
                            "lib": lib,
                            "source": source,
                            "form_id": selector.selector,
                            "verticalrendering": verticalrendering
                        } );
                    }
                } );
                // AJAX submit
                if ( method.toLowerCase() === 'ajax' ) {
                    $( selector ).submit( function () {
                        $.post(
                            action,
                            $( selector ).serialize(),
                            function ( data ) {
                                _validate( data );
                            }
                        );
                        return false;
                    } );
                }
                return $( selector );
            };
        return _init();
    };
    window.nmsweb.registerComponent( 'Form', form );
    return form;
} );