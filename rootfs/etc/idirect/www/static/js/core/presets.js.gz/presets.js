define( [ "kendo", "core/nmsweb", "external/bootstrap/multiselector" ], function () {
    "use strict";
    var Presets,
        kendo = window.kendo,
        Observable = kendo.Observable,
        address,
        FIELDSSELECTOR = ':enabled:visible:not([type="password"]):not([type="submit"]):not(button)';
    Presets = Observable.extend( {
        init: function ( selector, options ) {
            var that = this,
                addButton,
                presets = options.presets,
                preset;
            Observable.fn.init.call( that );
            address = options.address;
            that._form = $( options.formId );
            that._selector = selector;
            that._presetsContainer = $( selector.find( 'dl' ) );
            that._template = kendo.template( $( "#preset-template" ).html() );
            that._fieldTemplate = kendo.template( $( "#preset-field-template" ).html() );
            for ( preset in presets ) {
                if ( presets.hasOwnProperty( preset ) ) {
                    that.prepend( presets[ preset ] );
                }
            }
            addButton = selector.find( '#preset-add button' );
            addButton.on( 'click', $.proxy( that, 'add' ) ); //Need to change context for Preset object
            that._presetsContainer.on( 'click', '.preset-delete', that.deleteB ); //Have to keep button context
            that._presetsContainer.on( 'click', '.preset-quicklink', that.update ); //Have to keep checkbox context
            that._presetsContainer.on( 'click', '.preset-load', that.load ); //Have to keep button context
            $( that._form ).on( 'change', FIELDSSELECTOR, function () {
                var serialized = $( that._form ).serialize(),
                    newPath = window.location.pathname + '?' + serialized,
                    state = window.history.state;
                window.history.replaceState( state, '', newPath );
            } );
            $( that._selector ).data( 'nmswebPreset', that );
            return that;
        },
        add: function () {
            var that = this,
                addInput = that._selector.find( '#preset-add input' ),
                values = that._form.find( FIELDSSELECTOR ).serializeArray(),
                value,
                name,
                preset = {
                    values: {},
                    labels: {},
                    name: addInput.val(),
                    serialized: ''
                };
            for ( value in values ) {
                if ( values.hasOwnProperty( value ) ) {
                    name = values[ value ].name;
                    if ( values[ value ].value !== '' ) {
                        preset.values[ name ] = {};
                        preset.values[ name ].value = values[ value ].value;
                        preset.values[ name ].label = that._form.find( 'label[for="' + name + '"]' ).text();
                        preset.values[ name ].name = name;
                    }
                }
            }
            preset.serialized = that._form.serialize();
            if ( preset.name !== '' ) {
                $.ajax( {
                    type: 'PUT',
                    url: address,
                    data: preset,
                    success: function ( data ) {
                        preset.id = data.id;
                        that.prepend( preset );
                    }
                } );
            }
        },
        prepend: function ( preset ) {
            var that = this,
                newPreset,
                value,
                dropdownContainer,
                field;
            preset.quicklink = preset.quicklink === 1 || preset.quicklink === true ? 'active' : '';
            that._presetsContainer.prepend( that._template( {
                name: preset.name,
                id: preset.id,
                quicklink: preset.quicklink
            } ) );
            newPreset = that._presetsContainer.children( 'dt:first' );
            newPreset.data( 'values', preset.values );
            dropdownContainer = newPreset.find( '.dropdown-menu:first' );
            for ( value in preset.values ) {
                if ( preset.values.hasOwnProperty( value ) ) {
                    field = preset.values[ value ];
                    dropdownContainer.append( that._fieldTemplate( {
                        name: field.name,
                        value: field.value,
                        label: field.label
                    } ) );
                }
            }
        },
        deleteB: function () {
            var that = $( this ),
                item = that.closest( 'dt' ),
                id = item.data( 'preset' ),
                deleteItem = function () {
                    item.remove();
                };
            if ( id === undefined ) {
                deleteItem();
            } else {
                $.ajax( {
                    type: 'DELETE',
                    url: address,
                    data: {
                        id: id
                    },
                    success: function () {
                        deleteItem();
                    }
                } );
            }
        },
        update: function () {
            var that = $( this ),
                item = that.closest( 'dt' ),
                id = item.data( 'preset' );
            if ( id !== undefined ) {
                $.ajax( {
                    type: 'POST',
                    url: address,
                    data: {
                        id: id
                    },
                    success: function () {
                        that.toggleClass( 'active' );
                    }
                } );
            }
            return false;
        },
        load: function () {
            var that = $( this ),
                item = that.closest( 'dt' ),
                list = item.find( 'input.preset-field:checked' ),
                field,
                formField,
                last,
                name,
                value,
                obj = that.closest( '.preset-engine' ).data( 'nmswebPreset' );
            list.each( function ( i ) {
                field = $( list[ i ] );
                name = field.attr( 'name' );
                value = field.attr( 'value' );
                formField = obj._form.find( '[name="' + name + '"]' );
                if ( formField !== undefined ) {
                    formField.val( value );
                    last = formField;
                }
            } );
            if ( last !== undefined ) {
                last.trigger( 'change' );
            }
        }
    } );
    window.nmsweb.registerComponent( 'Presets', Presets );
    return Presets;
} );