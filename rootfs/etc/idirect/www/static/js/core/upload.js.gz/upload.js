define( [ "jquery", "kendo", "core/nmsweb" ], function ( $ ) {
    'use strict';

    function onStartUpload( e ) {
        var submit = e.sender.wrapper.eq( 0 ).parents( 'form' ).find( 'button[type="submit"]' ),
            uploadButton = e.sender.wrapper.eq( 0 ).parents( 'form' ).find( 'button.uploadButton' );
        if ( !uploadButton.length ) {
            submit.prop( 'disabled', 'disabled' ).css( 'visibility', 'hidden' );
            uploadButton = $( '<button class="btn uploadButton">Uploading...</button>' );
            submit.before( uploadButton );
            uploadButton.click( function ( e ) {
                e.preventDefault();
                var initSubmit = submit.prop( 'initSubmit' );
                if ( initSubmit ) {
                    initSubmit = 0;
                    uploadButton.html( "Uploading..." );
                } else {
                    initSubmit = 1;
                    uploadButton.html( "Submit requested, click here to cancel" );
                }
                submit.prop( 'initSubmit', initSubmit );
                return false;
            } );
            uploadButton.html( "Uploading..." );
        }
        if ( uploadButton.prop( 'disabled' ) === "disabled" ) {
            uploadButton.off( 'click' );
        }
        if ( !e.sender.options.submitmode || e.sender.options.submitmode === "disabled" ) {
            uploadButton.prop( 'disabled', 'disabled' );
        }
        if ( submit.prop( 'uploadCount' ) ) {
            submit.prop( 'uploadCount', submit.prop( 'uploadCount' ) + 1 );
        } else {
            submit.prop( 'uploadCount', 1 );
        }
    }

    function checkForComplete( e ) {
        var submit = e.sender.wrapper.eq( 0 ).parents( 'form' ).find( 'button[type="submit"]' ),
            uploadButton = e.sender.wrapper.eq( 0 ).parents( 'form' ).find( 'button.uploadButton' ),
            currUploadCount = submit.prop( 'uploadCount' );
        submit.prop( 'uploadCount', currUploadCount - 1 );
        if ( currUploadCount === 1 ) {
            submit.prop( 'disabled', '' ).css( 'visibility', 'visible' );
            uploadButton.remove();
            if ( submit.prop( 'initSubmit' ) ) {
                submit.click();
            }
        }
    }
    var defaults = {
            // method for updating file list which will be later submitted in form
            error: function ( e ) {
                checkForComplete( e );
            },
            cancel: function ( e ) {
                checkForComplete( e );
            },
            success: function ( e ) {
                if ( e.operation === "upload" ) {
                    checkForComplete( e );
                }
                // id of component's container
                var containerId = e.response.container_id,
                    filename = e.response.filename,
                    folderToken = e.response.folder_token,
                    tokenMapping = [],
                    tokenMappingLength,
                    i;
                if ( $( "#" + containerId + "_files" ).val() !== "" ) {
                    // array of JSON mappings
                    tokenMapping = JSON.parse( $( "#" + containerId + "_files" ).val() );
                }
                if ( e.operation === 'upload' ) {
                    tokenMapping.push( {
                        'filename': filename,
                        'token': folderToken
                    } );
                } else if ( e.operation === 'remove' ) {
                    tokenMappingLength = tokenMapping.length;
                    for ( i = 0; i < tokenMappingLength; i += 1 ) {
                        if ( tokenMapping[ i ].filename === filename && tokenMapping[ i ].token === folderToken ) {
                            tokenMapping.splice( i, 1 );
                            break;
                        }
                    }
                }
                $( "#" + containerId + " .k-file" ).each( function () {
                    var fileEntry = $( this );
                    // if it doesn't have token defined it's newly uploaded
                    if ( fileEntry.find( ".k-icon" ).is( ".k-success" ) && fileEntry.data( "fileNames" )[ 0 ].token === undefined ) {
                        fileEntry.data( "fileNames" )[ 0 ].token = folderToken;
                    }
                } );
                // set value of hidden input
                $( "#" + containerId + "_files" ).val( JSON.stringify( tokenMapping ) );
            },
            async: {
                autoUpload: true,
                saveField: 'filename',
                removeField: 'filename',
                saveUrl: '/core/uploadhandler/save',
                removeUrl: '/core/uploadhandler/remove'
            },
            localization: {
                cancel: 'Cancel',
                dropFilesHere: 'Drop files here',
                remove: 'Remove',
                retry: 'Retry',
                select: 'Select files...',
                statusFailed: 'Upload failed',
                statusUploaded: 'Files uploaded',
                statusUploading: 'Uploading files',
                uploadSelectedFiles: 'Upload selected files'
            },
            enabled: true,
            multiple: true,
            showFileList: true
        },
        Upload = window.kendo.ui.Upload.extend( {
            init: function ( element, options ) {
                var that = this,
                    id = element.attr( 'id' ),
                    containerId = options.in_form === true && !$( "#" + id ).parents( 'form.n-tabstrip' ) ? $( "#" + id ).parents( 'form' ).attr( 'id' ) : $( "#" + id ).parent().attr( 'id' ),
                    // extented options to always (when uploading/removing) send container's id and where file is stored to server
                    uploadRemoveFunctions = {
                        upload: function ( e ) {
                            e.data = {
                                'containerId': containerId
                            };
                            onStartUpload( e );
                        },
                        remove: function ( e ) {
                            e.data = {
                                'containerId': containerId,
                                'folderToken': e.files[ 0 ].token
                            };
                        }
                    };
                nmsweb.extendOptions( defaults, uploadRemoveFunctions );
                if ( options.opts ) {
                    nmsweb.extendOptions( defaults, options.opts );
                } else if ( options ) {
                    nmsweb.extendOptions( defaults, options );
                }
                // adding hidden input which will contain uploaded filenames/tokens
                element.before( "<input id='" + containerId + "_files' type='hidden' name='" + element.attr( 'name' ) + "'/>" );
                // and change original name to now have two inputs with same name
                element.attr( 'name', element.attr( 'name' ) + "_" );
                window.kendo.ui.Upload.fn.init.call( that, element, defaults );
            }
        } );
    window.nmsweb.registerComponent( 'Upload', Upload );
    return Upload;
} );