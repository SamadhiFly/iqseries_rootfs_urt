define( [ "jquery", "kendo", "core/nmsweb", "core/input_validation" ], function ( $ ) {
    "use strict";
    var AutoComplete = window.kendo.ui.AutoComplete.extend( {
        init: function ( element, options ) {
            var that = this,
                $element = $( element ),
                defaults = {
                    delay: 200,
                    enable: true,
                    minLength: 1,
                    suggest: true,
                    change: function () {
                        this.search();
                    }
                },
                validationFunction = function () {
                    $( element.selector ).validate_input( options.opts, element.selector );
                };
            if ( options.opts ) {
                nmsweb.extendOptions( defaults, options.opts );
            } else if ( options ) {
                nmsweb.extendOptions( defaults, options );
            }
            if ( $( element.selector ).hasClass( 'validate' ) ) {
                $( element.selector ).change( validationFunction );
                $( element.selector ).bind( 'blur', validationFunction );
            }
            window.kendo.ui.AutoComplete.fn.init.call( that, element, defaults );
            $element.bind( 'keyup', function () {
                var autoComplete = $element.data( 'kendoAutoComplete' );
                if ( $element.val() === '' ) {
                    that.close();
                    autoComplete.dataSource.filter( null );
                }
            } );
        }
    } );
    window.nmsweb.registerComponent( 'AutoComplete', AutoComplete );
    return AutoComplete;
} );