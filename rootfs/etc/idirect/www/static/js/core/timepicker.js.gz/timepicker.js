define( [ "jquery", "kendo", "core/nmsweb", "core/input_validation" ], function ( $ ) {
    "use strict";
    var TimePicker = window.kendo.ui.TimePicker.extend( {
        init: function ( element, options ) {
            var that = this,
                defaults = {
                    animation: false,
                    format: "HH:mm:ss",
                    timeFormat: "HH:mm"
                },
                validationFunction = function () {
                    $( element.selector ).validate_input( options.opts, element.selector );
                };
            if ( options.opts ) {
                // forcing format (if developer (while creating form) put's additional options (tries to force it's own format)) because it has been decided that everywhere throughout nms time will be displayed in the following format HH:mm:ss
                options.opts.format = defaults.format;
                nmsweb.extendOptions( defaults, options.opts );
            } else if ( options ) {
                options.format = defaults.format;
                nmsweb.extendOptions( defaults, options );
            }
            if ( $( element.selector ).hasClass( 'validate' ) ) {
                $( element.selector ).change( validationFunction );
                $( element.selector ).bind( 'blur', validationFunction );
            }
            window.kendo.ui.TimePicker.fn.init.call( that, element, defaults );
        }
    } );
    window.nmsweb.registerComponent( 'TimePicker', TimePicker );
    return TimePicker;
} );