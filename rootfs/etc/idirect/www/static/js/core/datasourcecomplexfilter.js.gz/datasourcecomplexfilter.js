define( [ 'jquery', 'kendo', 'core/data', 'core/nmsweb', 'core/multiselectdropdownlist' ], function ( $ ) {
    "use strict";
    var kendo = window.kendo,
        datasourcecomplexfilter = kendo.Observable.extend( {
            init: function ( selector, options ) {
                var that = this,
                    dsObject,
                    fieldLabel,
                    filterFields,
                    fieldOptions,
                    EQ = "Is equal to",
                    NEQ = "Is not equal to",
                    defaults = {
                        margin_offset: 20
                    },
                    dsId,
                    i,
                    len;
                that.selector = $( selector );
                that.operators = {
                    string: {
                        is: 'Is',
                        isnot: 'Is not',
                        contains: "Contains",
                        doesnotcontain: "Does not contain",
                        startswith: "Starts with",
                        endswith: "Ends with"
                    },
                    number: {
                        gt: "Is greater than",
                        lt: "Is less than",
                        gte: "Is greater than or equal to",
                        lte: "Is less than or equal to",
                        eq: EQ,
                        neq: NEQ,
                        isbetween: 'Is between',
                        isnotbetween: 'Is not between'
                    },
                    ip: {
                        is: 'Is',
                        isnot: 'Is not',
                        isbetween: 'Is between',
                        isnotbetween: 'Is not between',
                        gt: "Is greater than",
                        lt: "Is less than"
                    },
                    date: {
                        eq: EQ,
                        neq: NEQ,
                        gte: "Is after or equal to",
                        gt: "Is after",
                        lte: "Is before or equal to",
                        lt: "Is before"
                    },
                    enums: {
                        eq: EQ,
                        neq: NEQ
                    }
                };
                options = $.extend( true, defaults, options );
                that.options = options;
                //get FIRST data source and filter fields
                for ( dsId in options.dataSources ) {
                    if ( options.dataSources.hasOwnProperty( dsId ) ) {
                        dsObject = nmsweb.DataSources[ dsId ];
                        filterFields = options.dataSources[ dsId ];
                        break;
                    }
                }
                that.dsObject = dsObject;
                //prepare filterFields string
                fieldOptions = '';
                if ( filterFields !== undefined && filterFields !== null ) {
                    filterFields = that.initLabels( filterFields );
                    for ( i = 0, len = filterFields.length; i < len; i++ ) {
                        fieldLabel = filterFields[ i ].field.charAt( 0 ).toUpperCase() + filterFields[ i ].field.slice( 1 ).replace( /_/g, ' ' );
                        fieldOptions += '<option value="' + filterFields[ i ].field + '" data-enumerable-key="' + filterFields[ i ].field + '">' + that.generateLabel( filterFields[ i ].label_type, filterFields[ i ].label ) + '</option>';
                    }
                }
                that.fieldOptions = fieldOptions;
                that.filterFields = filterFields;
                that.generateGroup( $( '.filters', that.selector ) ); //initial group
                that.bindEvents();
                return that;
            },
            initLabels: function ( objArr ) {
                var textMapObj = {
                    'beam': 'Beam',
                    'cir': 'CIR',
                    'configuration_state': 'Configuration State',
                    'did': 'DID',
                    'element_id': 'Element ID',
                    'inet': 'iNet',
                    'inroute_group': 'Inroute Group',
                    'ip': 'Management IP',
                    'mir': 'MIR',
                    'obj_name': 'Name',
                    'satellite': 'Satellite',
                    'svn_number': 'SVN name',
                    'terminal': 'Terminal',
                    'terminal_type': 'Terminal Type name',
                    'type': 'Element Type'
                };
                return $.map( objArr, function ( val ) {
                    var id = val.field;
                    val.label = textMapObj[ id ];
                    if ( id === 'beam' || id === 'inet' || id === 'inroute_group' || id === 'satellite' ) {
                        val.label_type = 'in';
                    } else if ( id === 'terminal' ) {
                        val.label_type = 'linked to';
                    } else {
                        val.label_type = 'where';
                    }
                    return val;
                } );
            },
            generateLabel: function ( type, label ) {
                switch ( type ) {
                case 'in':
                    return type + " " + label + " where " + label + " name";
                case 'linked to':
                    return type + " " + label + " where " + label + " name";
                default:
                    return "where " + label;
                }
            },
            generateGroup: function ( $parent, level ) {
                var that = this,
                    $group,
                    $groupActions;
                if ( level === undefined ) {
                    level = 1;
                }
                $group = $( '<div class="group">' + '<div class="actions">' + '<span class="logic-label">Group Operator</span><select name="logic">' + '<option value="or">Or</option>' + '<option value="and">And</option>' + '</select>' + '</div>' + '<div class="fields">' + '</div>' + '</div>' );
                $groupActions = $( '<div class="group-actions">' + '<button name="add-group" class="btn btn-primary">Add Group</button>' + ( ( level !== 1 ) ? '<button name="remove-group" class="btn btn-primary">Remove Group</button>' : '' ) + '</div>' );
                $group.attr( 'group-level', level );
                $group.find( '.actions' ).find( 'select' ).wrap( "<span class='n-select-container' />" );
                $parent.append( $group.append( $groupActions ) );
                that.generateField( $group.find( '.fields' ), true );
            },
            generateField: function ( $parent, firstField ) {
                var that = this,
                    $field = $( '<div class="field">' + '<span class="field-items">' + '<span class="prefix">Find Elements</span>' + '<select name="field">' + that.fieldOptions + '</select>' + '<select name="operator"> </select>' + '<input class="hide" name="value" value="" />' + '<input name="value2" value="" class="hide dblInput" />' + '</span>' + '<span class="actions">' +
                        ( ( firstField !== true ) ? '<button name="remove-field" class="btn btn-primary field-action">&minus;</button>' : '<button name="remove-field" class="btn btn-primary hide field-action">&minus;</button>' ) +
                        '<button name="add-field" class="btn btn-primary field-action hide">&plus;</button>' + '</span>' + '</div>' );
                $field.find( '.field-items' ).find( 'select' ).wrap( "<span class='n-select-container' />" );
                $parent.append( $field );
            },
            removeGroup: function ( $parent, $group ) {
                $group.remove();
                $parent.find( '.group:last button[name=add-group]' ).removeClass( 'hide' );
            },
            removeField: function ( $parent ) {
                $parent.remove();
            },
            generateFilterJson: function ( $parent, level ) {
                var that = this,
                    logic = $( 'select[name=logic]', $parent ).val(),
                    filters = [];
                $( '.fields:first', $parent ).children().each( function () {
                    var $this = $( this ),
                        field,
                        operator,
                        value,
                        value2;
                    if ( $this.hasClass( 'field' ) ) {
                        field = $( 'select[name=field]', $this ).val();
                        operator = $( 'select[name=operator]', $this ).val();
                        value = $( 'input[name=value]', $this ).val();
                        value2 = $( 'input[name=value2]', $this ).val();
                        if ( value2 !== '' ) {
                            value = value + ', ' + value2;
                        }
                        filters.push( {
                            'field': field,
                            'operator': operator,
                            'value': value
                        } );
                    } else if ( $this.hasClass( 'group' ) ) {
                        filters.push( that.generateFilterJson( $this, level + 1 ) );
                    }
                } );
                return {
                    'logic': logic,
                    'filters': filters
                };
            },
            generateInitialFilterJson: function () {
                var that = this,
                    filters = [],
                    $this = $( '.group[group-level="1"] .fields:first .field:first', that.selector ),
                    field,
                    operator,
                    value,
                    value2;
                if ( $this.hasClass( 'field' ) ) {
                    field = $( 'select[name=field]', $this ).val();
                    operator = $( 'select[name=operator]', $this ).val();
                    value = $( 'input[name=value]', $this ).val();
                    value2 = $( 'input[name=value2]', $this ).val();
                    $.each( that.initialFilterList, function ( idx, val ) {
                        filters.push( {
                            'field': 'type',
                            'operator': 'eq',
                            'value': val
                        } );
                    } );
                }
                return {
                    'logic': 'or',
                    'filters': filters
                };
            },
            displayQuery: function () {
                var that = this,
                    stringforfiltering = '',
                    $queryPreview = $( '.querypreview', that.selector );
                $.each( $( '.group', that.selector ), function ( key, index ) {
                    var thisFilter = that.buildDisplayQuery( that.generateFilterJson( $( index ) ) );
                    if ( key !== 0 ) {
                        stringforfiltering = stringforfiltering + ' and ' + '(' + thisFilter + ')';
                    } else {
                        stringforfiltering = stringforfiltering + '(' + thisFilter + ')';
                    }
                } );
                $queryPreview.html( stringforfiltering );
            },
            buildGroupsFromQuery: function ( value ) {
                var that = this,
                    i = 0,
                    $group = $( '.filters .group:last', that.selector ),
                    $field,
                    $fields = $group.find( '.fields' ),
                    $operator,
                    $value,
                    objArr = [ {
                        'field': 'obj_name',
                        'operator': 'contains',
                        'type': 'string',
                        'value': value
                    }, {
                        'field': 'ip',
                        'operator': 'is',
                        'type': 'ip',
                        'value': value
                    }, {
                        'field': 'did',
                        'operator': 'eq',
                        'type': 'string',
                        'value': value
                    } ],
                    len = objArr.length;
                //instead of click functionality being triggered refactor out the behaviour into a function so both can call it.
                //that.addNewGroup($group.find('button[name=add-group]'));
                for ( i = 0; i < len; i++ ) {
                    $field = $group.find( '.fields .field' ).eq( i ).find( 'select[name=field]' );
                    $operator = $group.find( '.fields .field' ).eq( i ).find( 'select[name=operator]' );
                    $value = $group.find( '.fields .field' ).eq( i ).find( 'input[name=value]' );
                    $field.val( objArr[ i ].field );
                    that.upDateField( $field );
                    $operator.val( objArr[ i ].operator );
                    $value.val( value );
                    if ( i !== 2 ) {
                        $group.find( '.fields .field' ).find( 'button[name=add-field]' ).addClass( 'hide' );
                        that.generateField( $fields );
                    }
                    that.displayQuery();
                }
                //allow all initial field rows to removed
                $fields.find( 'button[name="remove-field"]' ).removeClass( 'hide' );
            },
            buildDisplayQuery: function ( filter ) {
                var that = this,
                    parts = [];
                if ( filter.filters !== undefined ) {
                    $.each( filter.filters, function () {
                        parts.push( that.buildDisplayQuery( this ) );
                    } );
                    return ' (' + parts.join( ') ' + filter.logic + ' (' ) + ') ';
                } else {
                    if ( filter.value2 === '' ) {
                        return filter.field + ' ' + filter.operator + ' \'' + filter.value + '\'';
                    } else {
                        return filter.field + ' ' + filter.operator + ' \'' + filter.value + ', ' + filter.value2 + '\'';
                    }
                }
            },
            addNewField: function ( $el ) {
                var that = this,
                    $fields = $el.closest( '.fields' );
                that.generateField( $fields );
                that.displayQuery();
                that.upDateField( $fields.find( '.field:last select[name=field]' ) );
                $fields.find( '.field:not(:last-child) button[name=add-field]' ).addClass( 'hide' );
                $fields.find( '.field:last button[name=add-field]' ).removeClass( 'hide' );
            },
            addNewGroup: function ( $el ) {
                var that = this,
                    $filters = $el.closest( '.filters' ),
                    $group = $el.closest( '.group' );
                that.generateGroup( $filters, parseInt( $group.attr( 'group-level' ), 10 ) + 1 );
                that.displayQuery();
                that.upDateField( $filters.find( '.field:last select[name=field]' ) );
                $group.find( 'button[name=add-group]' ).addClass( 'hide' );
            },
            upDateField: function ( $el ) {
                var that = this,
                    $this = $el,
                    i,
                    len,
                    type,
                    operator,
                    specificOperators,
                    operatorOptions = '',
                    $parent = $this.closest( '.field-items' );
                //find type of field
                if ( that.filterFields !== undefined && that.filterFields !== null ) {
                    for ( i = 0, len = that.filterFields.length; i < len; i++ ) {
                        if ( that.filterFields[ i ].field === $this.val() ) {
                            type = that.filterFields[ i ].type;
                            break;
                        }
                    }
                }
                specificOperators = that.operators[ type ];
                if ( type && specificOperators ) {
                    for ( operator in specificOperators ) {
                        if ( specificOperators.hasOwnProperty( operator ) ) {
                            operatorOptions += '<option value="' + operator + '">' + specificOperators[ operator ] + '</option>';
                        }
                    }
                }
                $( 'select[name=operator]', $this.closest( '.field-items' ) ).html( operatorOptions );
                that.upDateOperator( $parent.find( 'select[name=operator]' ) );
                // $fields.find('select').each(function(){
                // 	that.sortSelect($(this));
                // });
            },
            upDateOperator: function ( $operator ) {
                var that = this,
                    $parent = $operator.closest( '.field-items' ),
                    $field = $parent.find( 'select[name=field]' ),
                    $selectedData = $field.find( ':selected' ).data(),
                    closestGroup = $operator.closest( '.group' ),
                    wholeClosestGroup = closestGroup.find( 'button[name=add-field]' );
                if ( closestGroup.find( '.fields .field' ).size() < 2 ) {
                    wholeClosestGroup.removeClass( 'hide' );
                }
                if ( $operator.val() === 'isbetween' || $operator.val() === 'isnotbetween' ) {
                    $parent.find( 'input[name=value]' ).removeClass( 'hide' ).val( '' ).addClass( 'dblInput' );
                    $parent.find( 'input[name=value2]' ).removeClass( 'hide' ).val( '' );
                    $parent.find( '.filtercombo' ).remove();
                } else if ( ( $operator.val() === 'is' || $operator.val() === 'isnot' ) && ( that.enumData[ $selectedData.enumerableKey ] ) ) {
                    that.addDropDownOptions( $parent, $field.find( ':selected' ).data() );
                } else {
                    $parent.find( 'input[name=value]' ).removeClass( 'hide' ).removeClass( 'dblInput' ).val( '' );
                    $parent.find( 'input[name=value2]' ).addClass( 'hide' ).val( '' );
                    $parent.find( '.filtercombo' ).remove();
                }
            },
            addDropDownOptions: function ( $parent, $selectedData ) {
                var that = this,
                    comboData = [];
                $.each( that.enumData[ $selectedData.enumerableKey ], function ( key, value ) {
                    comboData.push( {
                        'text': value,
                        'value': key
                    } );
                } );
                comboData.sort( that.compare );
                $parent.find( '.filtercombo' ).remove();
                $parent.find( 'input[name=value]' ).addClass( 'hide' ).removeClass( 'dblInput' );
                $parent.find( 'input[name=value2]' ).addClass( 'hide' );
                $parent.append( '<select class="filtercombo" multiple="multiple" />' );
                $parent.find( '.filtercombo' ).kendoMultiSelect( {
                    dataTextField: "text",
                    dataValueField: "value",
                    dataSource: comboData,
                    filter: 'contains',
                    change: function () {
                        var value = this.value();
                        $parent.find( 'input[name=value]' ).val( value );
                        that.displayQuery();
                    }
                } );
            },
            addMultiSelectfilterBox: function ( $parent, options ) {
                var $msfb = $( '<div class="multi-select-filter filtercombo" />' ),
                    $autoCompleteBox = $( '<input class="multi-select-filter-autocomplete"/>' ),
                    $selectBox = $( '<select class="multi-select-filter-select"/>' ),
                    $footer = $( '<div class="multi-select-footer" />' ),
                    $button = $( '<a class="btn" href="#"><i class="icon-remove"></i></a>' ),
                    opts = options,
                    selectedItemsNo = function () {
                        if ( $selectBox.val() ) {
                            return $selectBox.val().length;
                        } else {
                            return 0;
                        }
                    };
                opts.open = function ( e ) {
                    e.preventDefault();
                };
                opts.height = 0;
                opts.suggest = false;
                opts.filter = 'contains';
                $autoCompleteBox.nmswebAutoComplete( opts );
                $autoCompleteBox.bind( 'keyup', function () {
                    $selectBox.scrollTop( 0 );
                } );
                $selectBox.nmswebSelect( options );
                $selectBox.change( function () {
                    $footer.html( 'Number of selected items ' + selectedItemsNo() );
                } );
                $parent.append( $msfb );
                $msfb.append( $autoCompleteBox )
                    .append( $button )
                    .append( $selectBox )
                    .append( $footer );
                $msfb.on( 'click', function () {
                    $selectBox.children( 'option:selected' ).removeAttr( "selected" );
                    $footer.html( 'Number of selected items ' + selectedItemsNo() );
                    $autoCompleteBox.data( "nmswebAutoComplete" ).value( '' );
                    $autoCompleteBox.data( "nmswebAutoComplete" ).dataSource.filter( null );
                    $selectBox.data( 'nmswebSelect' ).refresh();
                } );
            },
            bindEvents: function () {
                var that = this,
                    isFirstTimePoppedOver = true;
                $( 'body' ).on( 'nmsweb:poppedOver', that.selector, function ( e, response ) {
                    if ( $( that.selector ).parent().next().attr( 'id' ) !== $( e.target ).attr( 'id' ) && !( $( that.selector ).parents( '#n-element-selector-global-search-popover' ).length && $( e.target ).parents( '.global' ).length ) ) {
                        //Callback only gets executed for the element selector which fired the event
                        return;
                    }
                    var data = response.data,
                        searchData = typeof response.searchData !== 'undefined' ? response.searchData : false,
                        $group = $( '.filters .group', that.selector ).first();
                    that.enumData = {};
                    that.refineSearchData = {};
                    that.initialFilterList = response.initialFilterList;
                    for ( var key in data ) {
                        if ( data.hasOwnProperty( key ) ) {
                            var obj = data[ key ];
                            if ( obj.hasOwnProperty( 'label' ) ) {
                                //Correct inconsistent naming issue
                                if ( obj.label === 'SVN' ) {
                                    obj.label = 'SVN Number';
                                }
                                that.enumData[ obj.label.replace( / /g, "_" ).toLowerCase() ] = obj.obj_list;
                            }
                        }
                    }
                    if ( searchData ) {
                        //remove all and start again
                        $( that.selector ).find( '.filters' ).empty();
                        that.generateGroup( $( '.filters', that.selector ) ); //initial group
                        that.buildGroupsFromQuery( searchData.value );
                        isFirstTimePoppedOver = false;
                    } else if ( isFirstTimePoppedOver ) {
                        that.upDateField( $group.find( '.field:last select[name=field]' ) );
                        isFirstTimePoppedOver = false;
                    }
                } );
                $( 'body' ).on( 'nmsweb:ClosePopover', function () {
                    $( '.n-elementselector.n-search .n-datasourcefilter' ).val( '' );
                } );
                $( that.selector ).on( 'click', 'button[name=add-field]', function () {
                    var $fields = $( this ).closest( '.fields' ),
                        $firstField = $fields.find( '.field:first' );
                    that.addNewField( $( this ) );
                    //that.upDateField( $field.find('select[name=field]') );
                    if ( $fields.find( '.field' ).length > 1 ) {
                        $firstField.find( 'button[name="remove-field"]' ).removeClass( 'hide' );
                    }
                    $fields.find( '.field:not(:last-child) button[name=add-field]' ).addClass( 'hide' );
                    $fields.find( '.field:last button[name=add-field]' ).removeClass( 'hide' );
                } );
                $( that.selector ).on( 'click', 'button[name=add-group]', function () {
                    that.addNewGroup( $( this ) );
                } );
                $( that.selector ).on( 'click', 'button[name=remove-group]', function () {
                    var $filters = $( this ).parents( '.filters:first' ),
                        $group = $( this ).parents( '.group:first' );
                    that.removeGroup( $filters, $group );
                    that.displayQuery();
                } );
                $( that.selector ).on( 'click', 'button[name=remove-field]', function () {
                    var $parent = $( this ).parents( '.field:first' ),
                        $fields = $( this ).closest( '.fields' );
                    that.removeField( $parent );
                    that.displayQuery();
                    $fields.find( '.field:not(:last-child) button[name=add-field]' ).addClass( 'hide' );
                    $fields.find( '.field:last button[name=add-field]' ).removeClass( 'hide' );
                    if ( $fields.find( '.field' ).length < 2 ) {
                        var $firstField = $fields.find( '.field:first' );
                        $firstField.find( 'button[name="remove-field"]' ).addClass( 'hide' );
                    }
                } );
                $( that.selector ).on( 'click', 'button[name=apply-filter]', function () {
                    var filters = [],
                        serverFiltering;
                    if ( that.options.forceRemoteFiltering ) {
                        serverFiltering = that.dsObject.options.serverFiltering;
                        that.dsObject.options.serverFiltering = true;
                    }
                    //Filter will include restricted types list (we only need to send thi back once)
                    // var thisFilter = that.generateInitialFilterJson();
                    // 	filters.push(thisFilter);
                    $.each( $( '.group', that.selector ), function ( key, index ) {
                        var thisFilter = that.generateFilterJson( $( index ) );
                        filters.push( thisFilter );
                    } );
                    var initialFilters;
                    if ( that.options.initialFilter !== undefined &&
                        $.isArray( that.options.initialFilter ) ) {
                        initialFilters = [];
                        $.each( that.options.initialFilter, function ( index, value ) {
                            initialFilters.push( value );
                        } );
                    }
                    if ( initialFilters !== undefined ) {
                        filters.push( {
                            'filters': initialFilters,
                            'logic': 'and'
                        } );
                    }
                    // special field that will be handled by ME
                    // we indicate if it is adv. search or not because different conditions have to be met in those two,
                    // but both are targeting same logic (_fetch in el. selector (_pre_fetch in mutator will strip it out))
                    filters.push( {
                        'filters': [ {
                            'field': 'is_advanced_search',
                            'operator': 'eq',
                            'value': true
                        } ],
                        'logic': 'and'
                    } );
                    that.dsObject._dataCached = undefined;
                    that.dsObject.filter( filters );
                    if ( that.options.forceRemoteFiltering ) {
                        that.dsObject.options.serverFiltering = serverFiltering;
                    }
                    var requestEndHandler = function () {
                        angular.element( '#app' ).injector().get( 'ManagementStateCache' ).update( true );
                        that.dsObject.unbind( "requestEnd", requestEndHandler );
                    };
                    that.dsObject.bind( "requestEnd", requestEndHandler );
                } );
                $( that.selector ).on( 'change', 'select[name=field]', function () {
                    that.upDateField( $( this ) );
                } );
                $( that.selector ).on( 'change', 'select[name=operator]', function () {
                    that.upDateOperator( $( this ) );
                } );
                $( that.selector ).on( 'change', 'select[name=logic], select[name=field], select[name=operator], input[name=value], input[name=value2]', function () {
                    that.displayQuery();
                } );
            },
            sortSelect: function ( selElem ) {
                var my_options = selElem.find( 'option' );
                my_options.sort( function ( a, b ) {
                    if ( a.text.toLowerCase() > b.text.toLowerCase() ) {
                        return 1;
                    } else if ( a.text.toLowerCase() < b.text.toLowerCase() ) {
                        return -1;
                    } else {
                        return 0;
                    }
                } );
                selElem.empty().append( my_options );
                //TODO: Ensure first option is currently selected
            },
            compare: function ( a, b ) {
                var reA = /[^a-zA-Z]/g;
                var reN = /[^0-9]/g;
                var aA = a.text.toLowerCase().replace( reA, "" );
                var bA = b.text.toLowerCase().replace( reA, "" );
                if ( aA === bA ) {
                    var aN = parseInt( a.text.toLowerCase().replace( reN, "" ), 10 );
                    var bN = parseInt( b.text.toLowerCase().replace( reN, "" ), 10 );
                    return aN === bN ? 0 : aN > bN ? 1 : -1;
                } else {
                    return aA > bA ? 1 : -1;
                }
            }
        } );
    window.nmsweb.registerComponent( 'DatasourceComplexFilter', datasourcecomplexfilter );
} );