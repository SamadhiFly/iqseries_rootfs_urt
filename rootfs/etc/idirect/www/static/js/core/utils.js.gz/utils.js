define( [ "jquery" ], function ( $ ) {
    'use strict';
    $.fn.getPosition = function () {
        var position = $.extend( {}, $( this ).offset(), {
            width: $( this )[ 0 ].offsetWidth,
            height: $( this )[ 0 ].offsetHeight
        } );
        return position;
    };
    Array.prototype.move = function ( old_index, new_index ) {
        while ( old_index < 0 ) {
            old_index += this.length;
        }
        while ( new_index < 0 ) {
            new_index += this.length;
        }
        if ( new_index >= this.length ) {
            var k = new_index - this.length;
            while ( ( k-- ) + 1 ) {
                this.push( undefined );
            }
        }
        this.splice( new_index, 0, this.splice( old_index, 1 )[ 0 ] );
        return this; // for testing purposes
    };
    ( function ( $ ) {
        var currentVal = $.fn.val;
        $.fn.val = function ( value ) {
            var that = this,
                data = $( that ).data(),
                ret = currentVal.apply( this, arguments );
            //This should ideally live somewhere else but for now will do.
            // jQuery val will always return value attribute of element or "on"
            // but we do not have a checkbox.js file where val is being extended.
            if ( this.hasClass( 'n-doubleboxselect' ) ) {
                var itemsArr = $.makeArray( data.nmswebDoubleboxselect.selectedView.find( ".n-doubleboxselect-item" ) );
                return $.map( itemsArr, function ( item ) {
                    return $( item ).find( 'input' ).val();
                } );
            } else if ( $( that ).attr( 'type' ) === 'checkbox' && $( that ).parent( '.n-configurator-section-field' ).length > 0 ) {
                if ( value !== undefined ) {
                    if ( parseInt( value, 10 ) === 1 ) {
                        $( that ).attr( 'checked', 'true' );
                    } else {
                        $( that ).removeAttr( 'checked' );
                    }
                } else {
                    if ( $( that ).is( ':checked' ) ) {
                        ret = 1;
                    } else {
                        ret = 0;
                    }
                }
            } else if ( data !== null ) {
                $.each( data, function ( key ) {
                    if ( key.indexOf( 'nms' ) !== -1 ) {
                        if ( typeof ( data[ key ].val ) === 'function' ) {
                            if ( value !== undefined ) {
                                ret = data[ key ].val( value );
                            } else {
                                ret = data[ key ].val();
                            }
                        }
                    }
                } );
            }
            return ret;
        };
    }( $ ) );
    var nmsutils = window.nmsutils = [];
    nmsutils.preset = ( function () {
        var applyPreset = function ( preset, additional ) {
                window.presetDefined = undefined;
                $( document ).trigger( 'applyPreset' );
                var sectionsAsync = false,
                    executeAdditionals = function () {
                        if ( additional !== undefined ) {
                            if ( additional.shouldSubmit ) {
                                if( $('fieldset[data-configurator-name="MetricSelector"]').length > 0 ) {
                                    nmsutils.preset.generateReportReady = true;
                                } else {
                                    $( '.n-configurator-generate-button' ).click();
                                }
                            }
                            if ( additional.configuratorState === "closed" ) {
                                $( '.n-configurator-minimize' )[ 0 ].click();
                            }
                        }
                        $( document ).trigger( 'presetApplied' );
                    },
                    presetFeedback = {
                        isValid: true
                    };
                $.each( preset, function () {
                    var name = this.name,
                        $section,
                        $configurator,
                        $form,
                        $popover,
                        dateRangeValue,
                        value = this.value,
                        section = this.section,
                        $input = $( '[data-configurator-name=' + name + ']' ),
                        submitSectionsForConfigurator = function () {
                            $section = $( '.n-configurator-section[data-configurator-name=' + section + ']' );
                            $configurator = $section.parents( '.n-configurator-form' );
                            var sectionElement = $configurator.data( 'nmswebConfigurator' ).options.sections[ section ];
                            $form = $input.parents( '.n-configurator-section-form' );
                            $popover = $section.find( '.n-configurator-expand-section' ).parent();
                            $configurator.data( 'nmswebConfigurator' )._updateConfiguratorValues( preset );
                            $configurator.data( 'nmswebConfigurator' )._submitSectionTrigger( sectionElement, $configurator, $form, $popover, preset );
                        };
                    if ( $input.length > 0 ) {
                        if ( $input.attr( 'name' ) === 'Metric_Selector' ) {
                            $( 'body' ).one( 'stats.metricselector.ready', function () {
                                //var metrics = { composite: false, elements: value.split(',') };
                                $input.val( value );
                                submitSectionsForConfigurator();

                                if( nmsutils.preset.generateReportReady !== undefined && nmsutils.preset.generateReportReady === true ){
                                    $( '.n-configurator-generate-button' ).click();
                                }
                            } );
                        } else if ( $input.hasClass( 'n-elementselector' ) ) {
                            try {
                                //Check for shared link
                                JSON.parse( value );
                                if ( !isNaN( parseFloat( value ) ) && isFinite( value ) ) {
                                    //single element id - need to generate proper element selector object
                                    throw "singleElement";
                                }
                            } catch ( e ) {
                                var elementSelector = '{"composite": false, "elements": ' + JSON.stringify( $.map( value.split( "," ), Number ) ) + '}';
                                value = elementSelector;
                            }
                            var populateEs = function () {
                                var es = $input.find( '.n-elementselectorgrid:not(.n-elementselectorgrid-composite)' ).data( 'nmswebElementSelectorGrid' ),
                                    changeHandler = function ( e ) {
                                        $( 'fieldset[data-configurator-name="' + section + '"] .n-configurator-section-template' ).spin( false );
                                        $( 'fieldset[data-configurator-name="' + section + '"] .n-configurator-section-template' ).children().show();
                                        es.dataSource.selectAll();
                                        es.element
                                            .closest( '.n-configurator-section-form' )
                                            .find( '.n-configurator-apply-change-button' )
                                            .trigger( 'click' );
                                    };
                                $( 'fieldset[data-configurator-name="' + section + '"] .n-configurator-section-template' ).children().hide();
                                $( 'fieldset[data-configurator-name="' + section + '"] .n-configurator-section-template' ).spin( 'small' );
                                $input.val( value );
                                var requestInProgressInterval = setInterval( function () {
                                    if ( !es.dataSource._requestInProgress ) {
                                        clearInterval( requestInProgressInterval );
                                        changeHandler();
                                        executeAdditionals();
                                    }
                                }, 100 );
                            };
                            //Will have to wait for ES to complete query
                            sectionsAsync = true;
                            if ( !$input.find( '.n-elementselectorgrid:not(.n-elementselectorgrid-composite)' ).length ) {

                                $( 'body' ).on( 'nmsweb:elementSelectorAvailable', function () {
                                    var dataPopulated = false,
                                        $elementSelectorObj = $input.find( '.n-elementselectorgrid:not(.n-elementselectorgrid-composite)' );
                                    if ( !dataPopulated && $elementSelectorObj.length ) {
                                        if ( $elementSelectorObj.data( 'nmswebElementSelectorGrid' ).options.initialFilter ) {
                                            $input.one( 'dataBound', function () {
                                                populateEs();
                                            } );
                                        } else {
                                            populateEs();
                                        }
                                        dataPopulated = true;
                                    }

                                } );
                            } else {
                                populateEs();
                            }
                        } else if ( $input.hasClass( 'n-datetimerangepicker' ) ) {
                            try {
                                //Check for shared link
                                value = JSON.parse( value );
                            } catch ( e ) {
                                var valueArray = value.split( "_" );
                                dateRangeValue = {
                                    stream: false,
                                    value: [ "", "" ],
                                    template: [ "", "" ],
                                    relativ: false
                                };
                                for ( var i = 0; i < valueArray.length; i++ ) {
                                    var item = valueArray[ i ],
                                        tmpItemArray = item.split( "," );
                                    if ( tmpItemArray[ 0 ] === "start" ) {
                                        dateRangeValue.value[ 0 ] = tmpItemArray[ 1 ];
                                    } else if ( tmpItemArray[ 0 ] === "end" ) {
                                        dateRangeValue.value[ 1 ] = tmpItemArray[ 1 ];
                                    } else if ( tmpItemArray[ 0 ] === "relative" ) {
                                        dateRangeValue.resolution = tmpItemArray[ 1 ];
                                    } else if ( tmpItemArray[ 0 ] === "templateStart" ) {
                                        dateRangeValue.template[ 0 ] = tmpItemArray[ 1 ];
                                    } else if ( tmpItemArray[ 0 ] === "templateEnd" ) {
                                        dateRangeValue.template[ 1 ] = tmpItemArray[ 1 ];
                                    } else if ( tmpItemArray[ 0 ] === "stream" ) {
                                        dateRangeValue.stream = ( tmpItemArray[ 1 ] === "1" ) ? true : false;
                                    } else {
                                        dateRangeValue[ tmpItemArray[ 0 ] ] = tmpItemArray[ 1 ];
                                    }
                                }
                                value = dateRangeValue;
                            }
                            //Compensate datetimepicker's UTC conversion as quicklinks/presets already store UT
                            if ( value.value[ 0 ] !== "" ) {
                                value.value[ 0 ] = parseInt( value.value[ 0 ], null ) + ( 60 * ( new Date( value.value[ 0 ] ) ).getTimezoneOffset() );
                            }
                            if ( value.value[ 1 ] !== "" ) {
                                value.value[ 1 ] = parseInt( value.value[ 1 ], null ) + ( 60 * ( new Date( value.value[ 1 ] ) ).getTimezoneOffset() );
                            }
                            $input.val( value );
                            if ( value.resolution !== undefined ) {
                                presetFeedback.isValid = window.nmsweb.resolutionBuilder.isValid( parseInt( value.resolution, 10 ) );
                                if( !presetFeedback.isValid ) {
                                    presetFeedback.message = "The resolution defined in your query is no longer valid. Please re-enter and try your query again or use another.";
                                    return false;
                                }
                            }

                            submitSectionsForConfigurator();
                        } else if ( $input.hasClass( 'configurator-combo' ) ) {
                            try {
                                //Check for shared link
                                value = JSON.parse( value );
                            } catch ( e ) {
                                value = typeof value === 'string' ? value.split( ',' ) : value;
                            }
                            $input.val( value );
                            submitSectionsForConfigurator();
                        } else {
                            $input.val( value );
                            submitSectionsForConfigurator();
                        }
                    }
                } );
                if ( !sectionsAsync ) {
                    executeAdditionals();
                }

                return presetFeedback;
            },
            getSectionValues = function ( presetValues, $forms ) {
                var specifyData = {},
                    sections;
                specifyData.fields = [];
                $.each( presetValues, function () {
                    var presetName = this.name,
                        presetValue = this.value,
                        fieldObject = {};
                    fieldObject.name = presetName;
                    fieldObject.value = presetValue;
                    $.each( $forms, function () {
                        sections = $( this ).data( 'nmswebConfigurator' ).configurator_values;
                        $.each( sections, function () {
                            var section = this;
                            $.each( section.items, function () {
                                var fieldName = this.text;
                                if ( presetName === fieldName ) {
                                    fieldObject.section = section.templatename;
                                }
                            } );
                        } );
                    } );
                    specifyData.fields.push( fieldObject );
                } );
                return specifyData;
            },
            preApplyPreset = function ( presetValues, additional ) {
                if ( $( '.n-configurator-form' ) !== undefined && $( '.n-configurator-form' ).length > 0 ) {
                    //need to iterate through any configurators that exist and apply section values if need be to each.
                    var specNew = getSectionValues( presetValues, $( '.n-configurator-form' ) );
                    applyPreset( specNew.fields, additional );
                } else {
                    applyPreset( presetValues, additional );
                }
            };
        return {
            applyPreset: applyPreset,
            prepareToApplyPreset: preApplyPreset,
            getSectionValues: getSectionValues
        };
    }( $ ) );
    nmsutils.getSid = function () {
        var cookie = document.cookie,
            sid;
        cookie = cookie.substr( cookie.indexOf( "sid=" ) + 4 );
        if ( cookie.indexOf( ';' ) !== -1 ) {
            sid = cookie.substr( 0, cookie.indexOf( ';' ) );
        } else {
            sid = cookie;
        }
        return sid;
    };
    nmsutils.fib = function ( n ) {
        var i, fib1, fib2, fib;
        fib = 0;
        for ( fib1 = 0, fib2 = 1, i = 1; i < n; i++ ) {
            fib = fib1 + fib2;
            fib1 = fib2;
            fib2 = fib;
        }
        return fib;
    };
    //escapes value used in jQuery selector
    nmsutils.escapeSelectorValue = function ( value ) {
        return value.replace( /[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&" );
    };
    //sets or unsets disabled attribute with hidden fields based on readonly attribute
    nmsutils.fixReadonly = function ( $elements ) {
        var refreshReadonly = function ( $el ) {
            var name = $el.attr( 'name' ),
                $input,
                $container,
                val = $el.val();
            if ( name !== undefined ) {
                $container = $( '.' + nmsutils.escapeSelectorValue( name ) + '-readonly-fix', $el.parent() );
                if ( $container.length > 0 ) {
                    $el.prop( 'disabled', $container.data( 'disabled' ) ); //revert initial state
                    $container.remove();
                }
                if ( !$el.prop( 'disabled' ) && $el.attr( 'readonly' ) !== undefined && val !== null ) {
                    $container = $( '<span class="' + name + '-readonly-fix" style="display:none"></span>' );
                    val = ( $.type( val ) === 'array' ) ? val : [ val ];
                    $.each( val, function () {
                        $input = $( '<input name="' + name + '" value="' + this + '" type="hidden" />' );
                        $container.append( $input );
                    } );
                    $el.after( $container );
                    $container.data( 'disabled', $el.prop( 'disabled' ) );
                    $el.prop( 'disabled', true );
                }
            }
        };
        $elements.each( function () {
            refreshReadonly.call( this, $( this ) );
        } );
        //TODO: call refreshReadonly on "readonly" attribute change
    };
    nmsutils.exportCsv = function ( gridData, columns ) {
        var csv = '',
            kendo = window.kendo;
        $.each( gridData, function ( key, row ) {
            $.each( columns, function ( colindex, colobject ) {
                var col = ( typeof ( colobject.title ) !== "undefined" ) ? colobject.title : colobject.field;
                if ( typeof col !== "undefined" ) {
                    col = col.replace( /"/g, '""' );
                    csv += '"' + col + '"';
                    if ( col !== row.length - 1 ) {
                        csv += ",";
                    }
                }
            } );
            csv += "\n";
            return false;
        } );
        $.each( gridData, function ( key, row ) {
            $.each( columns, function ( colindex, colobject ) {
                var col = colobject.field;
                var value = row[ col ];
                if ( value === null || typeof ( value ) === "undefined" ) {
                    value = "";
                } else if ( value instanceof Date ) {
                    value = kendo.toString( kendo.parseDate( value ), "yyyy-MM-dd HH:mm:ss" );
                } else {
                    value = value.toString();
                }
                value = value.replace( /"/g, '""' );
                csv += '"' + value + '"';
                if ( col !== row.length - 1 ) {
                    csv += ",";
                }
            } );
            csv += "\n";
        } );
        return csv;
    };
    nmsutils.triggerPostRequest = function ( url, data ) {
        var form = $( '<form></form>' ).attr( 'action', url ).attr( 'method', 'post' );
        $.each( data, function ( key, value ) {
            form.append( $( "<input></input>" ).attr( 'type', 'hidden' ).attr( 'name', key ).attr( 'value', value ) );
        } );
        form.appendTo( 'body' ).submit().remove();
    };
    return nmsutils;
} );