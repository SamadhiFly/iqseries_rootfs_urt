<style>
.nmsweb-input-error {
	margin-left: 100px;
	background-color: white;
	border-radius: 20px;
	color:red;
	width:200px;
	text-align: center;
	opacity: 0.4;
}

</style>
<h4>Demo of NMSWeb Input components</h4>
<form ng-submit="submitForm()" name="idirectTestForm" class="n-form-horizontal-rendering n-form">
	<div>
		<label for={{inputOptionsText.id}}>{{inputOptionsText.label}}:<span ng-show={{inputOptionsText.required}} class='required'>*</span></label>
		<nmsweb-input nmsweb-options="inputOptionsText" ng-model="form.name"></nmsweb-input>
		<span>{{inputOptionsText.additionalContent}}</span>
	</div>
	<div>
		<label for={{inputOptionsInteger.id}}>{{inputOptionsInteger.label}}:<span ng-show={{inputOptionsInteger.required}} class='required'>*</span></label>
		<nmsweb-input nmsweb-options="inputOptionsInteger" ng-model="form.age"></nmsweb-input>
		<span>{{inputOptionsInteger.additionalContent}}</span>
	</div>
	<div>
		<label for={{inputOptionsFloat.id}}>{{inputOptionsFloat.label}}:<span ng-show={{inputOptionsFloat.required}} class='required'>*</span></label>
		<nmsweb-input nmsweb-options="inputOptionsFloat" ng-model="form.averageGrade"></nmsweb-input>
		<span>{{inputOptionsFloat.additionalContent}}</span>
	</div>
	<div>
		<label for={{inputOptionsFloatCustomStep.id}}>{{inputOptionsFloatCustomStep.label}}:<span ng-show={{inputOptionsFloatCustomStep.required}} class='required'>*</span></label>
		<nmsweb-input nmsweb-options="inputOptionsFloatCustomStep" ng-model="form.threshold"></nmsweb-input>
		<span>{{inputOptionsFloatCustomStep.additionalContent}}</span>
	</div>
	<div>
		<label for={{inputOptionsEmail.id}}>{{inputOptionsEmail.label}}:<span ng-show={{inputOptionsEmail.required}} class='required'>*</span></label>
		<nmsweb-input nmsweb-options="inputOptionsEmail" ng-model="form.email"></nmsweb-input>
		<span>{{inputOptionsEmail.additionalContent}}</span>
	</div>
	<div>
		<label for={{inputOptionsUrl.id}}>{{inputOptionsUrl.label}}:<span ng-show={{inputOptionsUrl.required}} class='required'>*</span></label>
		<nmsweb-input nmsweb-options="inputOptionsUrl" ng-model="form.url"></nmsweb-input>
		<span>{{inputOptionsUrl.additionalContent}}</span>
	</div>
	<div>
		<label for={{inputOptionsPassword.id}}>{{inputOptionsPassword.label}}:<span ng-show={{inputOptionsPassword.required}} class='required'>*</span></label>
		<nmsweb-input nmsweb-options="inputOptionsPassword" ng-model="form.password"></nmsweb-input>
		<span>{{inputOptionsPassword.additionalContent}}</span>
	</div>
	<div>
		<label for={{inputOptionsPasswordWithToggle.id}}>{{inputOptionsPasswordWithToggle.label}}:<span ng-show={{inputOptionsPasswordWithToggle.required}} class='required'>*</span></label>
		<nmsweb-input nmsweb-options="inputOptionsPasswordWithToggle" ng-model="form.passwordToggle"></nmsweb-input>
		<span>{{inputOptionsPasswordWithToggle.additionalContent}}</span>
	</div>
	<div>
		<label for={{inputOptionsCheckbox.id}}>{{inputOptionsCheckbox.label}}:<span ng-show={{inputOptionsCheckbox.required}} class='required'>*</span></label>
		<nmsweb-input nmsweb-options="inputOptionsCheckbox" ng-model="form.admin"></nmsweb-input>
		<span>{{inputOptionsCheckbox.additionalContent}}</span>
	</div>
	<div>
		<label for={{inputOptionsIpv4.id}}>{{inputOptionsIpv4.label}}:<span ng-show={{inputOptionsIpv4.required}} class='required'>*</span></label>
		<nmsweb-input nmsweb-options="inputOptionsIpv4" ng-model="form.address4"></nmsweb-input>
		<span>{{inputOptionsIpv4.additionalContent}}</span>
	</div>

	<input ng-disabled="idirectTestForm.$valid === false" type="submit" value="Submit" /> Button will be disabled until entire form is valid (based on idirectTestForm.$valid === false)
</form>

<h4>Form errors</h4>
{{ idirectTestForm.$error }}
<br />

<h4>Demo of behavior of model in controller</h4>
<i>By changing values here you are changing model directly</i>
<form name="modelDisplayForm" class="n-form-horizontal-rendering n-form">
	<label for="form.name">form.name</label> <input id="form.name" ng-model="form.name"></input><br />
	<label for="form.age">form.age</label> <input ng-model="form.age"></input><br />
	<label for="form.averageGrade">form.averageGrade</label> <input ng-model="form.averageGrade"></input><br />
	<label for="form.threshold">form.threshold</label> <input ng-model="form.threshold"></input><br />
	<label for="form.email">form.email</label> <input ng-model="form.email"></input><br />
	<label for="form.url">form.url</label> <input ng-model="form.url"></input><br />
	<label for="form.password">form.password</label> <input ng-model="form.password"></input><br />
	<label for="form.admin">form.admin</label> <input type="checkbox" ng-model="form.admin"></input><br />
	<label for="form.address4">form.admin</label> <input type="text" ng-model="form.address4"></input><br />
</form>


<h4>Model fields</h4>
<i>See how they behave when changing them in controller</i>


<h4>Model state</h4>
<i>See current state of model</i>
{{ form | json }}