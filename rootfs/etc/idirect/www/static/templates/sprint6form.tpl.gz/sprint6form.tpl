<style>
	.ng-invalid-ipv6 {
		border: 1px solid red;
	}
</style>
<nmsweb-form schema="form"></nmsweb-form>
<br><br>
SCHEMA: <br>
<pre>{{schema | json}}</pre>