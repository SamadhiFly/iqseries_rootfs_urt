
<h2>NMSWeb Dropdownlist</h2>
<h4>All options in nmsweb-options</h4>
<nmsweb-drop-down-list
        nmsweb-options="dropDownOptions"
        ng-model="dropDownModel.value">
</nmsweb-drop-down-list>
<br />
Selected value: {{ dropDownModel.value }}
<br />

<h4>Separate options</h4>
<nmsweb-drop-down-list
        nmsweb-option-label="'Select A Thing 2'"
        nmsweb-data-text-field="'name'"
        nmsweb-data-value-field="'id'"
        nmsweb-data-source="things"
        ng-model="dropDownModelSecond.value">
</nmsweb-drop-down-list>
<br />
Selected value: {{ dropDownModelSecond.value }}
<br />

<i>Used data</i>
<div>{{dropDownOptions | json}}</div>

<h2>NMSWeb Date Picker</h2>
<nmsweb-date-picker nmsweb-options="datePickerOptions" ng-model="datePickerModel.value"></nmsweb-date-picker>
<br />
DatePickerModel : {{ datePickerModel.value | date }}
<br />

<i>Used data</i>
<div>{{datePickerOptions | json}}</div>

<br />

<h2>NMSWeb DateTime Picker</h2>

<nmsweb-date-time-picker nmsweb-options="dateTimePickerOptions" ng-model="dateTimePickerModel.value"></nmsweb-date-time-picker>
<br />
<br />
DateTimePickerModel: {{ dateTimePickerModel.value | date:'MM/dd/yyyy @ h:mma' }}
<br />

<i>Used data</i>
<div>{{dateTimePickerOptions | json}}</div>

<h2>NMSWeb Time Picker</h2>

<nmsweb-time-picker nmsweb-options="timePickerOptions" ng-model="timePickerModel.value"></nmsweb-time-picker>
<br />
<br />
<!-- <i>Used data</i> -->
TimePickerModel: {{ timePickerModel.value | date:'h:mma' }}
<br />

<i>Used data</i>
<div>{{timePickerOptions | json}}</div>

<nmsweb-textarea ng-model='textareaModel'></nmsweb-textarea>
<br />
<!-- <i>Used data</i> -->
textareaModel: {{ textareaModel }}
<br />