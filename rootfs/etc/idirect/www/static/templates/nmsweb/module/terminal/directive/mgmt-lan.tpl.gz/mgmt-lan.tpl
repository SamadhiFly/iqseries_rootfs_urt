<div>
    <div class="span12">
        <fieldset class="table-fieldset">
            <legend>
                {{translation.language.configuration}}
            </legend>
            <div class="directive-contents">
                <div class="ng-scope interval" id="manual-downstream-interval-container">
                    <label style="font-weight: bold;" style="display: inline-block;">
                            {{translation.language.lan_ip}}
							</label>
                    <span style="margin-left: 20px;" class="k-widget k-numerictextbox">
									<span class="k-numeric-wrap k-state-default">
										<input type="text" class="k-formatted-value k-input" tabindex="0" style="display: inline-block;" aria-disabled="false" aria-readonly="false" ng-model="mgmt_lan.model.lan_ip">
										<input k-options="nmswebOptions" nmsweb-options="field.options" additional-options="field.additionalOptions" id="mgmt-lan-interval" ng-model="mgmt_lan.model.lan_ip" ng-change="checkDependencies(field.name)" class="k-input" data-role="numerictextbox" role="spinbutton" style="display: none;" type="text" aria-valuemin="1" aria-valuemax="30" aria-valuenow="" aria-disabled="false" aria-readonly="false">
									</span>
                    </span>
                </div>
                <div class="ng-scope activity_threshold" id="manual-downstream-activity_threshold-container">
                    <label style="font-weight: bold;" style="display: inline-block;">
                            {{translation.language.subnet_ip}}
								</label>
                    <span style="margin-left: 20px;" class="k-widget k-numerictextbox">
									<span class="k-numeric-wrap k-state-default">
										<input type="text" class="k-formatted-value k-input" tabindex="0" style="display: inline-block;" aria-disabled="false" aria-readonly="false" ng-model="mgmt_lan.model.lan_subnet_ip">
										<input k-options="nmswebOptions" nmsweb-options="field.options" additional-options="field.additionalOptions" id="mgmt-lan-interval" ng-model="mgmt_lan.model.lan_subnet_ip" ng-change="checkDependencies(field.name)" class="k-input" data-role="numerictextbox" role="spinbutton" style="display: none;" type="text" aria-valuemin="1" aria-valuemax="30" aria-valuenow="" aria-disabled="false" aria-readonly="false">
									</span>
                    </span>
                </div>
                <div class="ng-scope inactivity_threshold" id="manual-downstream-inactivity_threshold-container">
                    <label style="font-weight: bold;" style="display: inline-block;">
                            {{translation.language.gateway_ip}}
							</label>
                    <span style="margin-left: 20px;" class="k-widget k-numerictextbox">
								<span class="k-numeric-wrap k-state-default">
									<input type="text" class="k-formatted-value k-input" tabindex="0" style="display: inline-block;" aria-disabled="false" aria-readonly="false" ng-model="mgmt_lan.model.lan_gateway_ip">
									<input k-options="nmswebOptions" nmsweb-options="field.options" additional-options="field.additionalOptions" id="mgmt-lan-inactivity-threshold" ng-model="mgmt_lan.model.lan_gateway_ip" ng-change="checkDependencies(field.name)" class="k-input" data-role="numerictextbox" role="spinbutton" style="display: none;" type="text" aria-valuemin="1" aria-valuemax="30" aria-valuenow="" aria-disabled="false" aria-readonly="false">
								</span>
                    </span>
                </div>
            </div>
        </fieldset>
    </div>
    <nmsweb-form schema="mgmt_lan" ng-attr-name="{{mgmt_lan.name}}"></nmsweb-form>
    <div class="span12">
        <button ng-click="mgmtsave()" style="margin-top:10px;float:right">
			{{translation.language.save}}
		</button>
    </div>
</div>