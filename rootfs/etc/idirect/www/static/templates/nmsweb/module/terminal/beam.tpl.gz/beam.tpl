<h1>{{translation.language.satellite_interface}} - {{translation.language.beam}}</h1>
<div class="commissioning-info" ng-show="beamEmpty">
  <p>{{translation.language.beam_not_available}}</p>
</div>
<div class="beam_row" ng-repeat="i in beamList">
  <div class="beam_row_title" ng-click="open($index)">
    {{ i.beam_name }} (ID: {{ i.beam_id }})
    <div class="n-light small" ng-class="{'green':i.visible, 'red':!i.visible}"></div>
    <div class="beam_arrow" ng-class="{'beam_open':!isCollapsed[$index] , 'beam_closed':isCollapsed[$index] }"></div>
  </div>
  <table style="width:1000px;" class="beam-table" ng-show="!isCollapsed[$index]">
    <tbody>
      <tr><td>{{translation.language.id}}</td><td>{{ i.beam_id }}</td><td>{{translation.language.rx_quality}}</td><td>{{ i.rx_quality }} dB</td></tr>
      <tr><td>{{translation.language.active}}</td><td>{{ i.active }}</td><td>{{translation.language.visible}}</td><td>{{ i.visible }}</td></tr>
      <tr><td>{{translation.language.rx_ok}}</td><td>{{ i.rx_ok }}</td><td>{{translation.language.tx_ok}}</td><td>{{ i.tx_ok }}</td></tr>
      <tr><td>{{translation.language.tx_gain}}</td><td>{{ i.tx_gain }}</td><td>{{translation.language.elevation}}</td><td>{{ i.elevation }}</td></tr>
      <tr><td>{{translation.language.elevation_gain}}</td><td>{{ i.elevation_gain }}</td><td>{{translation.language.init_tx_power_offset}}</td><td>{{ i.init_tx_power_offset }}</td></tr>
      <tr><td>{{translation.language.map_tx_init_power}}</td><td>{{ i.map_tx_init_power }}</td><td>{{translation.language.tx_max_psd}}</td><td>{{ i.tx_max_psd }}</td></tr>
      <tr class="beam_trow_title"><td>{{translation.language.downstream}}</td><td></td>
        <td ng-hide="!beam[$index]">{{translation.language.upstream}}</td><td ng-hide="!beam[$index]"></td>
      </tr>
      <tr class="beam_trow_downup"><td>{{translation.language.satellite_transponder_name}}</td><td>{{ i.downstream.sat_xponder_name }}</td>
        <td ng-hide="!beam[$index]">{{translation.language.satellite_transponder_name}}</td><td ng-hide="!beam[$index]">{{ i.upstream.sat_xponder_name }}</td>
      </tr>
      <tr class="beam_trow_downup"><td>{{translation.language.longitude}}</td><td>{{ i.downstream.longitude }} °E</td>
        <td ng-hide="!beam[$index]">{{translation.language.longitude}}</td><td ng-hide="!beam[$index]">{{ i.upstream.longitude }} °E</td>
      </tr>
      <tr class="beam_trow_downup"><td>{{translation.language.latitude_variance}}</td><td>{{ i.downstream.latitude_variance }} °</td>
        <td ng-hide="!beam[$index]">{{translation.language.latitude_variance}}</td><td ng-hide="!beam[$index]">{{ i.upstream.latitude_variance }} °</td>
      </tr>
      <tr class="beam_trow_downup"><td>{{translation.language.polarization}}</td><td>{{ i.downstream.polarization }}</td>
        <td ng-hide="!beam[$index]">{{translation.language.polarization}}</td><td ng-hide="!beam[$index]">{{ i.upstream.polarization }}</td>
      </tr>
      <tr class="beam_trow_downup"><td>{{translation.language.polarization_skew}}</td><td>{{ i.downstream.polarization_skew }} °</td>
        <td ng-hide="!beam[$index]">{{translation.language.polarization_skew}}</td><td ng-hide="!beam[$index]">{{ i.upstream.polarization_skew }} °</td>
      </tr>
      <tr class="beam_trow_downup"><td>{{translation.language.if_frequency}}</td><td>{{ i.downstream.if_frequency }} MHz</td>
      </tr>
      <tr class="beam_trow_downup"><td>{{translation.language.rf_frequency}}</td><td>{{ i.downstream.rf_frequency }} Mhz</td>
      </tr>
      <tr class="beam_trow_downup"><td>{{translation.language.symbol_rate}}</td><td>{{ i.downstream.symbol_rate }} Ksps</td></tr>
      <tr class="beam_trow_downup"><td>{{translation.language.rolloff}}</td><td>{{ i.downstream.rolloff }}</td></tr>
    <tbody>
  </table>
</div>
