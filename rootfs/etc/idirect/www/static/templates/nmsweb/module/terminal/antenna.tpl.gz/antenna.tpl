<h1>{{translation.language.external_equipment}} - {{translation.language.antenna}}</h1>
<nmsweb-form schema="form" ng-attr-name="{{form.name}}" ng-hide="$root.noAntenna"></nmsweb-form>
<div class="commissioning-info" ng-show="noAntenna">
  <p>{{translation.language.no_antenna_connected}}</p>
</div>
