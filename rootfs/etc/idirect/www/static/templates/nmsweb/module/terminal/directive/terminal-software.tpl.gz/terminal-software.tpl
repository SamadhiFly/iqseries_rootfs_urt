<fieldset class="ng-scope ng-isolate-scope release-status">
  <legend class="ng-binding">
    <span
      ng-show="system_type === 'EVOLUTION' || ( terminalModel !== '950mp' && terminalModel !== '9350')"
      >{{ $root.translation.language.manage_software_packages }}</span
    >
    <span
      ng-show="system_type !== 'EVOLUTION' && (terminalModel === '950mp' || terminalModel === '9350')"
      >{{ $root.translation.language.software_packages }}</span
    >
    <button ng-click="reboot()" class="confirm terminal-btn reboot-btn">
      {{ $root.translation.language.reboot_terminal }}
    </button>
  </legend>
  <div class="main-upload-wrapper" ng-if="terminalModelChecked">
    <p class="label-upload-package">
      {{ $root.translation.language.upload_software_package }}:
    </p>

    <div class="upload_wrapper">
      <input
        id="upload-release-component"
        kendo-upload
        k-options="upload_release"
        type="file"
        name="{{ name }}"
      />
    </div>
    <div
      class="upload_progress"
      ng-show="showProgress && system_type === 'EVOLUTION'"
    >
      {{ progress }}%
    </div>
    <div class="installation_status">
      <span class="installation_status_label" />
    </div>
    <div ng-if="langLoaded" class="upload_tooltip">
      <nmsweb-tooltip tooltip="upload_release_tooltip"></nmsweb-tooltip>
    </div>
  </div>
  <div class="table_wrapper">
    <table style="width:1200px" class="terminal-table">
      <thead>
        <tr>
          <th ng-show="system_type === 'EVOLUTION'">
            {{ $root.translation.language.partition }}
          </th>
          <th ng-show="system_type !== 'EVOLUTION'">
            {{ $root.translation.language.software }}
          </th>
          <th ng-show="system_type === 'EVOLUTION'">
            {{ $root.translation.language.type }}
          </th>
          <th ng-show="system_type !== 'EVOLUTION'">
            {{ $root.translation.language.package_name }}
          </th>
          <th
            ng-show="system_type === 'EVOLUTION' || terminalModel === '950mp' || terminalModel === '9350'"
          >
            {{ $root.translation.language.description }}
          </th>
          <th
            ng-show="system_type !== 'EVOLUTION' && terminalModel !== '950mp' && terminalModel !== '9350'"
          >
            {{ $root.translation.language.creation_date }}
          </th>
          <th>{{ $root.translation.language.version }}</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr
          ng-repeat="x in releases"
          ng-if="x.name"
          ng-class="{'evolution-partition': x.partition_number == '1' || x.partition_number == '2', 'velocity-partition': x.partition_number == '3' || x.partition_number == '4'}"
        >
          <td>{{ x.partition_id }}</td>
          <td>{{ x.name }}</td>
          <td
            ng-show="system_type === 'EVOLUTION' || terminalModel === '950mp' || terminalModel === '9350'"
          >
            {{ x.description }}
          </td>
          <td
            ng-show="system_type !== 'EVOLUTION' && terminalModel !== '950mp' && terminalModel !== '9350'"
          >
            {{ x.timestamp | date: "MM/dd/yyyy" }}
          </td>
          <td>{{ x.version }}</td>
          <td>
            <button
              ng-hide="x.active"
              ng-click="activate_release(x.url, x.partition_id)"
              class="terminal-btn"
            >
              {{ $root.translation.language.activate_software_package }}
            </button>
            <div ng-show="x.active" class="not-activated-row">
              {{
                $root.translation.language.software_package_is_currently_active
              }}
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</fieldset>
