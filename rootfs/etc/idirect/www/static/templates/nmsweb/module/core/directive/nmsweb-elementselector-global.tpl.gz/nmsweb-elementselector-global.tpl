<div class="n-search n-elementselector" nmsweb-spin="spin">
        <fieldset class="n-global-filter" nmsweb-popover="globalSearch" nmsweb-popover-options="globalSearchPopover">
                <nmsweb-elementselector-search ng-click="hideAdvancedSearch(true, true)" ng-if="elSelectorOptions.searchOptions" class="nmsweb-grid-searchbox-holder" nmsweb-options="elSelectorOptions" widget="elSelectorOptions.nmswebElementselectorSearch"></nmsweb-elementselector-search>
        </fieldset>
        <div class="advancedsearch">
                <button class="n-cnf-btn blue" ng-click="hideAdvancedSearch(false, true)" nmsweb-popover="advGlobalSearch" nmsweb-popover-options="advGlobalSearchPopover">Advanced</button>
        </div>
</div>
nmswebOptions.