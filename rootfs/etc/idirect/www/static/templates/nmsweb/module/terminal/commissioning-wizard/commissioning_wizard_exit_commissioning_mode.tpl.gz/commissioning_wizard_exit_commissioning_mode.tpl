<h2>{{$root.translation.language.commissioning_wizard_exit_commissioning_mode}}</h2>

<div class="commissioning-info">
        <p>{{$root.translation.language.exiting_commissioning_mode_will_enable_the_terminal_to_acquire_network}}</p>
</div>
