<div class='passwordToggle'>
    <input type='checkbox' ng-checked='passwordToggle'"></input>
    <label ng-click="passwordToggleFunction()" ng-hide="passwordToggle">Show password</label>
    <label ng-click="passwordToggleFunction()" ng-show="passwordToggle">Hide password</label>
</div>
