<div ng-if="formReady">
  <nmsweb-form schema="form" ng-attr-name="{{form.name}}"></nmsweb-form>
</div>
