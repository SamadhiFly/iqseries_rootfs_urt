<nmsweb-tooltip ng-repeat="tooltip in tooltips" tooltip="tooltip"></nmsweb-tooltip>
