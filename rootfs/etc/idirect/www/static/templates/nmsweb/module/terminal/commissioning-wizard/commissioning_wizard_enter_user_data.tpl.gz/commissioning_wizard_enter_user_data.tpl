<h2>{{$root.translation.language.commissioning_wizard_enter_transmit_power_parameters}}</h2>
<commissioning-user-data user-data-configuration="stepData['commissioning_wizard_enter_user_data']" valid="config.steps['commissioning_wizard_enter_user_data'].buttons[0].enabled"></commissioning-user-data>
