<div class="dashboard-label-holder">
<led color="systemStatusLed" size="large"></led>
<h1>{{translation.language.system_status}}</h1>
<button ng-show="$root.system_type==='EVOLUTION' && onlineStatus" ng-click="switchStatus(onlineStatus.status)" class="terminal-btn switch-status-btn">{{buttonTitle}}</button>
</div>
<div class="inCommissioningInfo commissioning-info dashboard-commissioning-info" ng-if="inCommissioning && isAdmin && commissioningAvailable">
        <p>{{translation.language.the_terminal_is_currently_being_commissioned}} <button type="submit" ng-click="changePath('commissioning-wizard')">{{translation.language.continue_with_wizard}}</button></p>
</div>

<div class="outOfNetworkInfo commissioning-info dashboard-commissioning-info" ng-if="!inNetwork && !inCommissioning && isAdmin && commissioningAvailable">
        <p>{{translation.language.the_terminal_is_currently_not_in_network_please_start_the_commissioning_wizard_if_the_terminal_hasnt_been_commissioned_yet}} <button type="submit" ng-click="changePath('commissioning-wizard')">{{translation.language.start_wizard}}</button></p>
</div>

<nmsweb-form schema="form" ng-attr-name="{{form.name}}" class="dashboard-wrapper"></nmsweb-form>
