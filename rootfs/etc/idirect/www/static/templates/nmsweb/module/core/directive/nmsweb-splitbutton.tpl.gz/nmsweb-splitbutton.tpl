<div class="n-hierarchy-builder-div">
    <div class="btn-group">
        <button type="button" ng-click="nmswebOptions.queryActions.handler(nmswebOptions.queryActions.actions[0].action, name)" class="btn n-element-selector-btn n-element-selector-hierarchy" >{{nmswebOptions.queryActions.actions[0].label}}</button>
        <button type="button" class="btn n-element-selector-btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
            <span class="caret"></span>
        </button>
        <ul class="n-action-list dropdown-menu tree-builder-options" role="menu">
            <li ng-repeat="element in nmswebOptions.queryActions.actions">
                <span ng-click="nmswebOptions.queryActions.handler(element.action, name)" class="tree-builder-tree-option">
                {{element.label}}
                </span>
            </li>
        </ul>
    </div>
</div>
