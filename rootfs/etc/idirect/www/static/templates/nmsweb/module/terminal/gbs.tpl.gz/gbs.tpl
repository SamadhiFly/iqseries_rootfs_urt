<h1>{{translation.language.satellite_interface}} - {{ ($root.system_type === 'EVOLUTION') ? translation.language.multi_protocol_encapsulation : translation.language.global_broadcasting_system}}</h1>
<div class="commissioning-info" ng-show="!mpe && mpeChecked">
  <p>{{translation.language.your_remote_is_not_configured_for_this_tool_yet}}</p>

  <p>{{ ($root.system_type === 'EVOLUTION') ? translation.language.mpe_required_fields : translation.language.gbs_required_fields}}</p>
  <br />
  <p>{{translation.language.gbs_configure_fields}}</p>
  <p><a href="/#/software_and_configuration">Administration - Software and Configuration</a></p>
</div>
<div ng-if="mpe && gotMpeReceivers">
<div><nmsweb-form schema="form" ng-attr-name="{{form.name}}"></nmsweb-form></div>
</div>
