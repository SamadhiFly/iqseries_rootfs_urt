<div><nmsweb-tree-view widget="treeView" nmsweb-options="nmswebOptions"></nmsweb-tree-view></div>
