<h1>{{translation.language.terminal_device}} - {{translation.language.reporting_configuration}}</h1>
<nmsweb-form schema="form" ng-attr-name="{{form.name}}"></nmsweb-form>
