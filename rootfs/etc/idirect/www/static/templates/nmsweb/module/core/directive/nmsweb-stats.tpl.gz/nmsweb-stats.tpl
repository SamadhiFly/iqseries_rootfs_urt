<h2>Stats</h2>
{{objId}}
{{type}}
{{metricId}}
{{startTime}}
{{endTime}}
{{resolutions}}