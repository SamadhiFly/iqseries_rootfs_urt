<div class='nmsweb-elementselector-icon-popover'>
<nmsweb-key-information-panel obj-id='objId' obj-type-id='objType' obj-name="objName" detail-level='1' nmsweb-spin='spin'></nmsweb-key-information-panel>
</div>
