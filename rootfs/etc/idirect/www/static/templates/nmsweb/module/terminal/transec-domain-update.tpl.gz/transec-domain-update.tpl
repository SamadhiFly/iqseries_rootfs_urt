<h1>{{translation.language.administration}} - {{translation.language.transec_modify_domain}}</h1>
<div>
    <label>{{translation.language.certs_validity}}</label> <led color="ledOptions.color" size="ledOptions.size"></led>{{translation.language[ ledOptions.value ]}}
</div>
<div class="commissioning-info">{{translation.language.modify_domain_notice}}</div>
<nmsweb-form schema="form" ng-attr-name="{{form.name}}"></nmsweb-form>
