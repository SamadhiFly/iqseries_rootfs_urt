<div ng-mouseleave="delayHideOptions()" ng-mouseenter="showOptions()" class="n-splitbutton-container btn-group n-element-selector-actions ng-scope" >
	<a ng-click="clickDropdown($event)" class="n-splitbutton-action n-splitbutton btn" ng-class="{inverted: inverted, 'n-splitbutton-action-small': displayType == 'small'}">{{displayType == "small" ? "" : "Actions"}}</a>
	<ul ng-show="actionsOpen" ng-style="dropdownMenuStyle" nmsweb-spin="spin" class="n-action-list dropdown-menu" ng-class="{inverted: inverted, horizontalOverflow: horizontalOverflow}">
		<li ng-hide="errorMessage" ng-repeat="action in actions">
			<a class="" ng-href="{{action.url}}" ng-show="{{action.is_enable}}">{{action.action_name}}</a>
			<span ng-hide="{{action.is_enable}}">{{action.action_name}}</span>
		</li>
		<span class="no-actions" ng-show="errorMessage">
			{{errorMessage}}
		</span>
	</ul>
</div>
