<select class='n-select n-element-selector-element-type-drop' ng-model='nmswebOptions.toolbar.filteredType' data-ng-change='nmswebOptions.toolbar.filterType()'>
	<option ng-repeat='(type_id, type_name) in nmswebOptions.toolbar.filteredTypes' value='{{type_id}}'>
		{{type_name}}
	</option>
</select>
