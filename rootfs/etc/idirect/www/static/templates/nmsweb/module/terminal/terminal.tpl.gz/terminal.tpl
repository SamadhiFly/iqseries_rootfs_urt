<h1>{{translation.language.administration}} - {{translation.language.software_configuration}}</h1>
<div ng-cloak class="row-fluid" ng-if="$root.system_type == 'EVOLUTION' && model == 'iQDesktop'">
    <receiver-configuration ng-if="!noRx0" receiver="1"></receiver-configuration>
    <receiver-configuration ng-if="!noRx1" receiver="2"></receiver-configuration>
    <div id="combineReceiversHolder">
      <combine-receivers ng-if="combineReceiversEnabled && $root.noRx1 != true"></combine-receivers>
    </div>
</div>
<terminal-software ng-cloak></terminal-software>
<terminal-configuration ng-cloak></terminal-configuration>
