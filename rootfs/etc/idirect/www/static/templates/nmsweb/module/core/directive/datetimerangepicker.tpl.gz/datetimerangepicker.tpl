<div class="n-datetimerangepicker">
	<div class="n-datetimerangepicker-range-holder">
		<div ng-repeat="dateTimePicker in nmswebOptions.dateTimePickers track by $index" class="n-datetimerangepicker-date-holder">
			<label>{{dateTimePicker.label}}</label>
			<nmsweb-date-time-picker widget="dateTimePicker.widget" ng-disabled="$index !== 0 && model[streamFieldName]" ng-class="n-datetimerangepicker-{{dateTimePicker.name}}" nmsweb-options="dateTimePicker.options" nmsweb-model="model[dateTimePicker.name]" />
		</div>
		<div class="n-datetimerangepicker-checks-holder">
			<div class="n-datetimerangepicker-stream-check-holder n-check-holder" ng-if="streamFieldName" style="float:none; background: none">
				<label>{{nmswebOptions.streamField.label}}</label>
				<input type="checkbox" ng-model="model[streamFieldName]" />
			<span class="help-icon" nmsweb-popover="streamTooltip" nmsweb-popover-options="streamTooltipOptions"></div>
		</div>
	</div>
	<div class="n-datetimerangepicker-intervals n-interval-holder" ng-if="nmswebOptions.intervals && nmswebOptions.intervals.length">
		<ul>
			<li ng-repeat="interval in nmswebOptions.intervals"><a href ng-click="updateInterval(interval)">{{ interval.label }}</a></li>
		</ul>
	</div>
	<div class="n-datetimerangepicker-resolution" ng-show="enableResolution">
		<span class="n-datetimerangepicker-resolution">Resolution: </span>
		<span class="n-select-container">
            <select class="resolution" ng-disabled="!resolutionEnabled" ng-init="model[resolutionFieldName] = model[resolutionFieldName] || nmswebOptions.resolutions.labels[0].value" class="n-select" ng-model="model[resolutionFieldName]" ng-options="item.value as item.label for item in nmswebOptions.resolutions.labels">
            </select>
            <div class="n-cnf-btn blue label label-info" ng-show="enableTooltip" nmsweb-popover="widgetPopover" nmsweb-popover-options="nmswebOptions.popoverOptions">?</div>
        </span>
	</div>
</div>
