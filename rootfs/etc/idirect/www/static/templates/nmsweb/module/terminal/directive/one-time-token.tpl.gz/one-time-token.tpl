<div>
  <nmsweb-form schema="form" ng-attr-name="{{form.name}}"></nmsweb-form>
  <button ng-click="uploadToken()" type="submit">{{$root.translation.language.submit_token}}</button>
</div>
