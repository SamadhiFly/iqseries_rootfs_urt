<tr data-uid="#: uid #" obj_name="{{dataItem.obj_name}}" obj_id="{{dataItem.obj_id}}" obj_type="{{dataItem.type}}">
	<td class="n-element-selector-status-column">
		<nmsweb-element-icon po-state="dataItem.obj_states.performance_operational_state" cu-state="dataItem.obj_states.config_update_state" no-popover="true" obj-type="dataItem.type" obj-name="dataItem.obj_name" update="nmswebOptions.iconOptions.shouldUpdate" no-popover="nmswebOptions.iconOptions.noPopover" obj-id="dataItem.obj_id" is-element-selector="true">
		</nmsweb-element-icon>
	</td>
	<td>{{dataItem.obj_name}}</td>
</tr>
