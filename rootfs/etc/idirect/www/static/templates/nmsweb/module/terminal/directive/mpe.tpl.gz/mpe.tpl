<div>
    <div id="mpe-container" ng-show="mpeEnabled">
        <nmsweb-form schema="mpe" ng-attr-name="{{mpe.name}}"></nmsweb-form>
        <div class="span12">
            <button ng-click="saveMPE()" style="margin-top:10px;float:right">
                {{translation.language.save}}
            </button>
        </div>
    </div>
    <div ng-show="!mpeEnabled">
        <div class="commissioning-info">
            <p>{{translation.language.your_remote_is_not_configured_for_this_tool_yet}}</p>
            <p>{{translation.language.mpe_required_fields}}</p>
            <p>{{translation.language.mpe_update_receiver_configuration}}</p>
        </div>
    </div>
</div>