<div class="n-hierarchy-builder-div">
    <div class="btn-group">
        <button type="button" ng-click="hierarchicalButtonHandler(objId, dbQueryType, defaultType)" class="btn n-element-selector-btn n-element-selector-hierarchy" data-tree-type="{{defaultType}}">Hierarchy</button>
        <button type="button" class="btn n-element-selector-btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
            <span class="caret"></span>
        </button>
        <ul class="n-action-list dropdown-menu tree-builder-options" role="menu">
            <li ng-repeat="(key, element) in treeTypes">
                <span ng-click="hierarchicalButtonHandler(objId, dbQueryType, key)" class="tree-builder-tree-option">
                {{element.options.ui_label}}
                </span>
            </li>
        </ul>
    </div>
</div>

