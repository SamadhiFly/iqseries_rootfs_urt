<div class="wizard">
        <div class="wizard-progress">
                <div ng-repeat="step in config.order" ng-class="{'active': currentStep == $index, 'valid': $index < currentStep || $index <= maxStep}">
                        <a ng-click="setCurrentStep($index, true)" class="number"></a><p ng-click="setCurrentStep($index, true)">{{$root.translation.language[config.steps[step].title] || config.steps[step].title}}</p>
                </div>
        </div>
        <div class="wizard-content"></div>
        <div class="wizard-buttons-wrapper">
          <div class="wizard-buttons {{config.steps[config.order[currentStep]].buttonClass || ''}}">
                  <button ng-repeat="button in config.steps[config.order[currentStep]].buttons" ng-click="executeButtonAction($index)" class="{{button.class || ''}}" ng-class="{'disabled': !button.enabled}">
                          {{$root.translation.language[button.title] || button.title}}
                  </button>
          </div>
        </div>
</div>
