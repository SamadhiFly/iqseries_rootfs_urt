<h1>{{translation.language.commissioning}} - {{translation.language.bim_configuration}}</h1>
<p id="antenna_config_link"> <a href="{{protocol}}://{{host}}:{{port}}" target="_blank">{{translation.language.bim_configuration_page_open_in_a_new_window}}</a> </p>
