<div class="notification-warning">
    <b ng-if="warningMsgs.length === 1">{{ warningMsgs.length }}  Warning was found </b> <br/>
    <b ng-if="warningMsgs.length !== 1">{{ warningMsgs.length }} Warnings were found </b> <br/>
    <ul>
        <li ng-repeat="notificationItem in warningMsgs track by $index">{{notificationItem}}</li>
    </ul>
</div>