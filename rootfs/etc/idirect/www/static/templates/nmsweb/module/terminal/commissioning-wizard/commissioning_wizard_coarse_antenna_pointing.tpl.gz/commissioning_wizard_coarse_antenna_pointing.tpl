<h2>{{$root.translation.language.commissioning_wizard_coarse_antenna_pointing}}</h2>
<div class="commissioning-info info">{{$root.translation.language.angleCalculator_instruction}}</div>
<angle-calculator angle-calculator-configuration="stepData['commissioning_wizard_coarse_antenna_pointing']" valid="config.steps['commissioning_wizard_coarse_antenna_pointing'].buttons[0].enabled"></angle-calculator>
