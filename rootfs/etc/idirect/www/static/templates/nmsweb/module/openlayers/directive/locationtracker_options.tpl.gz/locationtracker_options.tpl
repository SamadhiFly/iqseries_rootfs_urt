<form class="new-fe optionsOverlay">
    <label for="showLabels">
        <span class="checkbox-label" ng-class="{'checked': showNameLabels}"></span>Show labels
    </label>
    <input type="checkbox" id="showLabels" ng-model="showNameLabels" />
    <h3>Show Overlays</h3>
    <div class="showLocationTrackerBorder lcOverlaysBorder">
        <div class="showLocatioTrackerBorderDistance">
            <p class="lcElementsDisplayed">
              <label for="selectedAllOverlays">
                <span class="checkbox-label" ng-class="{'checked': selectedAllOverlays}"></span>All</label>
                <input id="selectedAllOverlays" type="checkbox" ng-model="selectedAllOverlays" ng-change="checkAllOverlays()" />
            </p>
            <p ng-repeat="(key, overlay) in availableOverlays" class="lcElementsDisplayed">
                <label for="overlay_{{key}}" class="lcHideLongText">
                        <span class="checkbox-label" ng-class="{'checked': overlay.visible}"></span><span title="{{overlay.name}}">{{overlay.name}}</span>
                </label>
                <input type="checkbox" id="overlay_{{key}}" ng-model="availableOverlays[key].visible" ng-change="updateOverlays()"/>
            </p>
        </div>
    </div>
    <h3>Show Historical Paths</h3>
    <div class="showLocationTrackerBorder lcHistorycalPathsBorder">
        <div class="showLocatioTrackerBorderDistance">
            <p class="lcElementsDisplayed">
              <label for="selectedAllHistoricalPaths">
                <span class="checkbox-label" ng-class="{'checked': selectedAllHistoricalPaths}"></span>All</label>
                <input id="selectedAllHistoricalPaths" type="checkbox" ng-model="selectedAllHistoricalPaths" ng-change="checkAllHistoricalPaths()" />
            </p>
            <p ng-repeat="(key, element) in elements" class="lcElementsDisplayed">
                <label for="trail_{{element.obj_id}}" class="lcHideLongText">
                    <span class="checkbox-label" ng-class="{'checked': element.historicalTrail}"></span><span title="{{element.obj_name}}">{{element.obj_name}}</span>
                </label>
                <input type="checkbox" id="trail_{{element.obj_id}}" ng-model="elements[key].historicalTrail"  ng-change="updateMarkers()" />
            </p>
        </div>
    </div>
</form>
