<div nmsweb-popover="specifyPopoverWidget" nmsweb-popover-options="specifyPopover" class="n-configurator-apply-preset-popover n-popover-content">
    <div class="n-configurator-presets-grid">
        <h2>Load Query</h2>
        <nmsweb-grid nmsweb-options="presetsGridOptions" widget="grid"></nmsweb-grid>
        <form class="n-quicklinks-load-form" ng-show="specifyPopover.quicklinks"> </form>
    </div>
</div>