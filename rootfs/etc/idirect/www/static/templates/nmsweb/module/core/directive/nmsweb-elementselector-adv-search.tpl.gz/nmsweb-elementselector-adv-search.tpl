<div class="advanced-query" nmsweb-spin="spin" ng-keypress="suppressEnter($event)">
	<div class='advanced-search-group-wrap' ng-repeat="group in groups track by $index">
		<nmsweb-elementselector-adv-search-group widget="groupWidgets[$index]" condition-options="nmswebOptions.conditionOptions" ng-model="group"></nmsweb-elementselector-adv-search-group>
		<div class="group-actions">
			<button ng-show="$last" ng-click="addGroup()" class="adv-search-add-group btn btn-primary">Add Group</button>
			<button ng-show="$last && groups.length > 1" ng-click="removeGroup($index)" class="adv-search-remove-group btn btn-primary">Remove Group</button>
		</div>
	</div>
	<div class="complexfilter-actions-holder">
		<button class="btn btn-primary run-query" ng-click="runQuery()">Run Query</button>
	</div>
</div>
