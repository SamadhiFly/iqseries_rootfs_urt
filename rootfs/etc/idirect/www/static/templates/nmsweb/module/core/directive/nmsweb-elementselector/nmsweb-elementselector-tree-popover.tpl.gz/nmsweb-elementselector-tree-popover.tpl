<span class='treeview-popover'>
	<span ng-repeat="tool in nmswebOptions.toolButtons.slice()" class="n-element-selector-row-btn-holder">
		<a ng-href="{{tool.obj_attributes.module}}/{{tool.obj_attributes.controller}}/{{tool.obj_attributes.action}}?shared=1&Element_Selector={{objId}}" class="btn n-element-selector-btn n-element-selector-row-btn" ng-if="tool.obj_attributes.type === 'elementselector_row_action'">{{tool.obj_name}}</a>
	</span>
	<span class="n-element-selector-row-btn-holder">
			<nmsweb-actionsbutton class="n-element-selector-row-btn" obj-id="objId" type-id="type"></nmsweb-actionsbutton>
	</span>
</span>