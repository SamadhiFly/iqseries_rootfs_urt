<h2>Management States Summary</h2>

<div class="details">
    <table class="simple">
    	<tbody>
    		<tr ng-repeat="state in states">
    			<th>{{state.key}}</th>
    			<td>{{state.value ? state.value:"n/a"}}</td>
    		</tr>
    	</tbody>
    </table>

    <div><a ng-if="!boolShowMessages && messages" ng-click="showMessages(true)">Show messages</a></div>
    <div><a ng-if="boolShowMessages && messages" ng-click="showMessages(false)">Hide messages</a></div>
    <h3 ng-if="messages[0]" ng-hide="!boolShowMessages">{{capitalize(messages[0][0])}}</h3>
    <ul ng-hide="!boolShowMessages">
    	<li ng-repeat="message in messages">
    		<p>{{message[1]}}</p>
    	</li>
    </ul>

    <table class="complex">

    <tr ng-if="components.length > 0">
    <th>Element</th>
    <th>Item Type</th>
    <th>Configuration State</th>
    <th>Operational State</th>
    <th>Activation State</th>
    </tr>

    <tr ng-repeat="component in components">
    <td><nmsweb-element-icon obj-id="component.obj_id" obj-show-name="true"></nmsweb-element-icon></td>
    <td>{{component.item_type}}</td>
    <td>{{component.configuration_state.value ? component.configuration_state.value:"n/a"}}</td>
    <td>{{component.operational_state.value ? component.operational_state.value:"n/a"}}</td>
    <td>{{component.activation_state.value ? component.activation_state.value:"n/a"}}</td>
    </tr>

    </table>
</div>