<div class="center">
    <h2 class="commissioningCompleted success">{{$root.translation.language.remote_location_successfully_set}}</h2>
    <div class="bigActiveHolder" style="margin-top:100px">
            <button class="bigActive" ng-click="changePath('/');completeWizard()">{{$root.translation.language.return_to_dashboard}}</button>
    </div>
</div>
