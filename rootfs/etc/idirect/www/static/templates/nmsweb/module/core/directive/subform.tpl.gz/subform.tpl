<div class="n-subform">
	<nmsweb-form-element ng-repeat="element in schema.layout" schema="element" form="schema"></nmsweb-form-element>
	<div class="remaining-fields"></div>
</div>
