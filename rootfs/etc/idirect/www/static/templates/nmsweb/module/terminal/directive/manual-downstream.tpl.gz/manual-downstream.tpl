<div>
    <div class="span12">
        <fieldset class="table-fieldset">
            <legend>
                {{translation.language.general}}
            </legend>
            <div class="directive-contents">
                <div class=".k-state-disabled combine-receivers" id="manual-downstream-combine-receivers-container">
                    <label ng-style="model == '950mp' && {'cursor':'not-allowed'}" ng-click="toggleCombineReceiver()">Combine Receivers
								<span ng-style="model == '950mp' && {'background-color':'#e3e3e3','cursor':'not-allowed'} " ng-class="{'checked' : combineReceiverEnable}" style="float: right; position: inherit;" class=".k-input checkbox-label"></span>
							</label>
                </div>
            </div>
        </fieldset>
        <button ng-disabled="model == '950mp'" ng-click="saveCombineReceivers()" style="margin-top:10px;float:right">
			{{translation.language.save_and_reboot}}
		</button>
    </div>
    <div class="span6">
        <fieldset class="table-fieldset">
            <legend>
                {{translation.language.receiver_1}}
            </legend>
            <div class="directive-contents">
                <div class="combine-receivers" id="manual-configuration-enabeld-container1">
                    <label style="width: 220px" ng-click="toggleManualConfiguration(1)">{{translation.language.enable_manual_configuration}}
                                        <span ng-class="{'checked' : manualConfigurationEnabled1}" style="float: right; position: inherit;" class="checkbox-label"></span>
                                    </label>
                </div>
                <nmsweb-form schema="manualDownstream_1" receiver="1" ng-attr-name="{{manualDownstream_1.name}}"></nmsweb-form>
            </div>
        </fieldset>
        <button ng-click="saveManualDownstream(1)" style="margin-top:10px;float:right">
					{{translation.language.save}}
				</button>
    </div>
    <div class="span6" ng-show="manualDownstream_2.receiver2">
        <fieldset class="table-fieldset">
            <legend>
                {{translation.language.receiver_2}}
            </legend>
            <div class="directive-contents">
                <div class="combine-receivers" id="manual-configuration-enabeld-container2">
                    <label style="width: 220px" ng-click="toggleManualConfiguration(2)">{{translation.language.enable_manual_configuration}}
                                        <span ng-class="{'checked' : manualConfigurationEnabled2}" style="float: right; position: inherit;" class="checkbox-label"></span>
                                    </label>
                </div>
                <nmsweb-form schema="manualDownstream_2" receiver="2" ng-attr-name="{{manualDownstream_2.name}}"></nmsweb-form>
            </div>
        </fieldset>
        <button ng-click="saveManualDownstream(2)" style="margin-top:10px;float:right">
						{{translation.language.save}}
				</button>
    </div>
    <div class="span12">
        <button ng-click="reboot()" style="margin-top:10px;float:right">
				{{translation.language.reboot_terminal}}
        </button>
    </div>
</div>