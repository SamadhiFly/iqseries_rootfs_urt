<div>
	<nmsweb-elementselector-search ng-if="nmswebOptions.searchOptions && nmswebOptions.showSearch !== false" nmsweb-options="nmswebOptions.searchOptions" ng-hide="widget.advSearchShown || widget.advancedSearch && widget.advancedSearch.alwaysOpened"></nmsweb-elementselector-search>
	<nmsweb-elementselector-filters ng-if="nmswebOptions.filterOptions" nmsweb-options="nmswebOptions.filterOptions.nmswebOptions" datasource="nmswebOptions.filterOptions.datasource" models="nmswebOptions.filterOptionsModel"></nmsweb-elementselector-filters>
	<span class='n-element-selector-grid-toolbar-components-holder'>
		<span ng-if="nmswebOptions.treeOptions && nmswebOptions.treeOptions.length > 0" class='n-element-selector-toggle-holder'>
			<button ng-disabled="widget.listViewButtonDisabled" ng-click="nmswebOptions.enableListView()" aria-disabled="{{widget.listViewButtonDisabled === 'disabled' ? true : false}}" class='n-element-selector-tree-toggle-button-list btn'>List</button>
		</span>
		<span class='n-element-selector-toggle-holder' ng-repeat="treeOption in nmswebOptions.treeOptions.slice().reverse()">
			<div ng-if="treeOption === 'treeview'" class="n-tree-builder-div">
				<div class="btn-group">
					<button type="button" class="btn default n-element-selector-btn n-element-selector-treeview" ng-click="nmswebOptions.buildTree(nmswebOptions.treeviewOptions.defaultType)" data-tree-type="{{nmswebOptions.treeviewOptions.defaultType}}" ng-disabled="widget.treeDisplayed && widget.activeTree===nmswebOptions.treeviewOptions.defaultType">Tree</button>
					<button type="button" class="btn n-element-selector-btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
						<span class="caret"></span>
					</button>
					<ul class="n-action-list dropdown-menu tree-builder-options" role="menu">
						<li ng-repeat="(key, element) in nmswebOptions.treeviewOptions.treeTypes">
							<span class="tree-builder-tree-option" ng-click="nmswebOptions.buildTree(key)" ng-disabled="widget.treeDisplayed && widget.activeTree===key">
							{{element.options.ui_label}}
							</span>
						</li>
					</ul>
				</div>
			</div>
			<div ng-if="treeOption === 'orgchart'" class="n-tree-builder-div">
				<div class="btn-group">
					<button type="button" class="btn default n-element-selector-btn n-element-selector-treeview" ng-click="nmswebOptions.buildOrgchart(nmswebOptions.treeviewOptions.defaultType)" data-tree-type="{{nmswebOptions.treeviewOptions.defaultType}}" ng-disabled="widget.orgchartDisplayed && widget.activeOrgchart===nmswebOptions.treeviewOptions.defaultType">Org Chart</button>
					<button type="button" class="btn n-element-selector-btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
						<span class="caret"></span>
					</button>
					<ul class="n-action-list dropdown-menu tree-builder-options" role="menu">
						<li ng-repeat="(key, element) in nmswebOptions.treeviewOptions.treeTypes">
							<span class="tree-builder-tree-option" ng-click="nmswebOptions.buildOrgchart(key)" ng-disabled="widget.orgchartDisplayed && widget.activeOrgchart===key">
							{{element.options.ui_label}}
							</span>
						</li>
					</ul>
				</div>
			</div>
		</span>
<!-- 		<span class='n-element-selector-toggle-holder'>

		</span> -->
		<!-- options will come from elementselector directive -->
		<nmsweb-groupactions-button ng-if="nmswebOptions.showGroupActions" nmsweb-options="nmswebOptions.groupactions" ng-model="widget.selectedData"></nmsweb-groupactions-button>
	</span>
</div>
