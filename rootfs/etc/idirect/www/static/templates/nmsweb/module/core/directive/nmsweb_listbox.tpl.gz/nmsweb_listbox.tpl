<select multiple="multiple" widget="widget">
    <option
        name = {{nmswebOptions.name}}
        ng-repeat = "item in nmswebOptions.options"
        ng-disabled = "additionalOptions.viewMode || item.disabled"
        value = "{{item.value}}">{{item.display}}</option>
</select>

