<h1>{{translation.language.external_equipment}} - {{translation.language.lnb}}</h1>
<div ng-if="ready">
    <nmsweb-form schema="form" ng-attr-name="{{form.name}}" ng-hide="$root.noLnb"></nmsweb-form>
    <div class="commissioning-info" ng-show="noLnb">
        <p>{{translation.language.no_lnb_attached}}</p>
    </div>
</div>