<div>
	<div ng-hide="start" class="center">
		<div class="commissioning-info info" ng-if="$root.system_type != 'EVOLUTION'">{{$root.translation.language.downstreamConfig_description}}</div>
		<div class="commissioning-info info" ng-if="$root.system_type == 'EVOLUTION'">{{$root.translation.language.downstreamConfig_description_evo}}<br /><a href="/#/software_and_configuration">Administration -> Software and Configuration</a></div>

		<div ng-hide="!form.isRendered" ng-if="formReady">
		    <nmsweb-form schema="form" ng-attr-name=""></nmsweb-form>
		</div>
	</div>
</div>
