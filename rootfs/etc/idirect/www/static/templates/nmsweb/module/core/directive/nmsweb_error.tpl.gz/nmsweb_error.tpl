<div class="nmsweb-input-error" >
	<div ng-repeat="error in errors">
		{{error}}
	</div>
</div>