<span id="megamenuToggler"></span>
<ul id="megamenuHolder" class="n-megamenu">
        <li ng-repeat="menuitem in menuitems" ng-hide="menuitem.admin_only && !adminUser">
                <span> <a ng-if="menuitem.url !== ''" href="{{menuitem.url}}" data-path="{{menuitem.title}}" data-name="{{menuitem.title}}">{{menuitem.title}}</a> <a ng-if="menuitem.url === ''" data-path="{{menuitem.title}}" data-name="{{menuitem.title}}" class="caret-item">{{menuitem.title}}</a>                        </span>
        </li>
        <div ng-repeat="menuitem in menuitems" class="n-megamenu-category hide" data-name="{{menuitem.title}}" ng-if="menuitem.children.length !== 0">
                <ul>
                        <li ng-repeat="childitem in menuitem.children">
                                <span ng-if="childitem.url"><a data-path="child{{childitem.title}}" data-name="child{{childitem.title}}" href="{{childitem.url}}">{{childitem.title}}</a></span>
                                <span ng-if="!childitem.url"><a data-path="child{{childitem.title}}" data-name="child{{childitem.title}}">{{childitem.title}}</a></span>
                        </li>
                        <div ng-repeat="childitem in menuitem.children" class="n-megamenu-category hide" data-name="child{{childitem.title}}">
                                <ul>
                                        <li ng-repeat="childchilditem in childitem.children">
                                                <span><a href="{{childchilditem.url}}">{{childchilditem.title}}</a></span>
                                        </li>
                                </ul>
                        </div>
                </ul>
        </div>
        <li class="n-megamenu-actions-tab">
                <a>
                        <span class="username">{{username}}</span>
                        <span class="avatar"></span>
                </a>
        </li>
        <li class="n-megamenu-tab i18n">
                <input id="i18nPicker" class="hide"></input>
        </li>
</ul>
