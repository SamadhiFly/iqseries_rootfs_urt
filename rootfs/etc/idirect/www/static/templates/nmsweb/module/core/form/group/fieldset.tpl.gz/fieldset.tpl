<legend>{{schema.label}} <a href="#" class="self-disclose" ng-show="schema.disclosedBy === 'self'">{{schema._discloseText}}</a></legend>
<div class="directive-contents" nmsweb-spin="loading">
	<nmsweb-form-element ng-repeat="element in schema.contents" schema="element" form="form"></nmsweb-form-element>
</div>
