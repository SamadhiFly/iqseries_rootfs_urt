<fieldset class="colored-rows">
	<nmsweb-form schema="form" ng-attr-name="{{form.name}}"></nmsweb-form>
</fieldset>