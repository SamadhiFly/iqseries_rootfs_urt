<div>
	<input kendo-upload="widget" k-options="nmswebOptions" type="file" name="{{name}}"/>
</div>
