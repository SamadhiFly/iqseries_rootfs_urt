<div class='nmsweb-globaldashboard' ng-show="showSplashscreen">
	<button class="refresh-button" ng-click="refresh()" ng-disabled="loadedWidgets < neededWidgets">Refresh</button> <!-- it will be pulled right by css -->
	<nmsweb-dashboard layout='layout' width='width' height='height' layout-parameters='layoutParameters' widget="nmswebGlobalDashboard"></nmsweb-dashboard>
</div>