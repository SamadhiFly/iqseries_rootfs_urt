<div>
	<div kendo-window="widget" k-options="nmswebOptions"></div>
</div>