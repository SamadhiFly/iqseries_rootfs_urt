<div>
        <!-- <h1>{{translation.language.commissioning}} - {{translation.language.one_touch_commissioning}}</h1> -->
        <div ng-hide="!smartBuc">
          <!-- <div ng-hide="validDownstream">
            <nmsweb-form schema="form" ng-attr-name=""></nmsweb-form>
          </div> -->
          <div class="commissioning-info" ng-hide="!start || success">
                  <p>{{$root.translation.language.tx_cable_is_attached_to_buc}}</p>
          </div>
          <div class="commissioning-info" ng-class="{red:'warning', green:'success'}[message_color]" ng-hide="!display_status">
            <b>{{display_message_head}}</b>{{display_message}}
          </div>
          <div class="commissioning-info success" ng-hide="!completed || lastTimeCompleted">
            {{$root.translation.language.the_remote_is_now_rebooting}}
          </div>
          <div class="progress-container meter" ng-class="progress_color">
            <div>{{bar_width}}</div>
            <span ng-style="{ 'width': bar_width }"></span>
          </div>
          <div class="details-link hide">
            <a href="#" id="show-details" ng-click="show_details()">{{$root.translation.language.show_details}}</a>
          </div>
          <div id="details-container">
          </div>
          <div class="one-touch-commissioning-button-holder">
            <button id="start-comm" ng-class="{'disabled':!start}" ng-click="one_touch_start()" ng-disabled="!start">{{start_btn_text}}</button>
            <button id="stop-comm" ng-class="{'disabled':start || completed}" ng-click="one_touch_stop()" ng-disabled="start || completed">{{stop_btn_text}}</button>
          </div>
        </div>
        <div class="commissioning-info" ng-hide="smartBuc">
          <p>{{$root.translation.language.one_touch_commissioning_is_not_available}}</p>
        </div>
</div>
