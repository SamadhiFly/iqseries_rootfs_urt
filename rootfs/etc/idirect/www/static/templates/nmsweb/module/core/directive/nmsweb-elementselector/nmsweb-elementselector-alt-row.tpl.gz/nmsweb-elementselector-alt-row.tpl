<tr data-uid="#: uid #" class="k-alt" obj_name="{{dataItem.obj_name}}" obj_id="{{dataItem.obj_id}}" obj_type="{{dataItem.type}}">
    <td class="n-element-selector-status-column">
        <nmsweb-element-icon po-state="dataItem.obj_states.performance_operational_state" cu-state="dataItem.obj_states.config_update_state" no-popover="true" obj-type="dataItem.type" obj-name="dataItem.obj_name" update="nmswebOptions.iconOptions.shouldUpdate" obj-id="dataItem.obj_id" is-element-selector="true">
        </nmsweb-element-icon>
    </td>
    <td>{{dataItem.obj_name}}</td>
    <td class="row-actions" ng-if="nmswebOptions.rowActions">
        <span class="n-element-selector-row-btn-holder"><nmsweb-actionsbutton class="n-element-selector-row-btn" obj-id="dataItem.obj_id" type-id="dataItem.type"></nmsweb-actionsbutton></span>
        <span ng-repeat="tool in nmswebOptions.toolButtons" class="n-element-selector-row-btn-holder">
            <a ng-href="/{{tool.obj_attributes.module}}/{{tool.obj_attributes.controller}}/{{tool.obj_attributes.action}}?shared=1&Element_Selector={{dataItem.obj_id}}" class="btn n-element-selector-btn n-element-selector-row-btn" ng-if="tool.obj_attributes.type === 'elementselector_row_action'">{{tool.obj_name}}</a>
            <nmsweb-hierarchy-button class="n-element-selector-row-btn n-element-selector-row-hierarchy" ng-if="tool.obj_attributes.action === 'hierarchy'" obj-id="dataItem.obj_id" obj-type="dataItem.type" db-query-type="nmswebOptions.dbQueryType"></nmsweb-hierarchy-button>
        </span>
    </td>
</tr>
