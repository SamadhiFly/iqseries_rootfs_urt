<nmsweb-form-element ng-repeat='element in layout' schema='element' form='{}' widget="{{$index}}"></nmsweb-form-element>
