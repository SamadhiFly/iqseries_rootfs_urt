<div>
	<nmsweb-grid id={{nmswebOptions.id}} ng-model="ngModel" nmsweb-options="nmswebOptions" nmsweb-model="nmswebModel" widget="widget" nmsweb-spin="spin"></nmsweb-grid>
</div>