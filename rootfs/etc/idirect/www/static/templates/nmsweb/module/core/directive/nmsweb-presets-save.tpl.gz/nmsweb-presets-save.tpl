<div nmsweb-spin="spin">
<h2 class="n-popover-title">Save Query</h2>
    <div>
        <p>
            <label><input type="radio" name="query_type" value="preset" ng-model="queryType" />Save Query Only</label>
            <span nmsweb-popover="queryOnlyTooltipObj" nmsweb-popover-options="queryOnlyTooltip" id="presets_tooltip" class="label label-info n-popover" style="float:right;">?</span>
        </p>
        <p>
            <label><input type="radio" name="query_type" value="quicklink" ng-model="queryType" />Save Query and Tool</label>
            <span nmsweb-popover="queryTooltipObj" nmsweb-popover-options="queryTooltip" id="ql_tooltip" class="label label-info n-popover" style="float:right;">?</span>
        </p>
    </div>
    <div>
        <label for='n-save-query-name'>Query Name:</label><br />
        <input type='text' ng-model='queryName'></input>
    </div>
    
    
    <h4>Include:</h4>
    <nmsweb-tree-view widget="treeView" nmsweb-options="treeViewOptions"> </nmsweb-tree-view>
    
    <!--  This part below is dynamically based on sections of the configurator. -->
    <h4>Additional:</h4>
    <p>
        <span class="daterange-relative">Relative Daterange:</span>
        <input type="checkbox" class="n-configurator-relative-daterange" checked="checked" ng-model="additional_daterange">
    </p>
    <p>
        <span class="elements-relative">Relative Elements:</span>
        <input type="checkbox" class="n-configurator-relative-elements" ng-model="additional_elements">
    </p>
    
    <!-- This part below is hard-coded  -->
    <div ng-show="queryType == 'quicklink'">
        <p>
            <span class="quicklink-should-submit">Submit configurator:</span>
            <input type="checkbox" checked="checked" value="true" class="n-configurator-should-submit" ng-model="shouldSubmit">
        </p>
        <p>
            <span class="quicklink-configurator-state">Configurator state:</span>
            <select class="n-configurator-state quicklink-select" ng-model="configuratorState">
                <option value="open" selected="selected">Open</option>
                <option value="closed">Closed</option>
            </select>
        </p>
    </div>
    <button class='flat-buttons' ng-click="savePresets()">Save Query</button>
</div>
