<hr>
<nmsweb-drop-down-list nmsweb-options="nmswebOptions" name="{{formOptions[0].attr_name}}" id="{{formOptions[0].attr_name}}" ng-model="rx0_beam.dropDownModel.value" type={{formOptions[0].attr_type}}>
<nmsweb-tooltip tooltip="nmswebOptions.fieldDetails.tooltip"></nmsweb-tooltip>
<hr>
