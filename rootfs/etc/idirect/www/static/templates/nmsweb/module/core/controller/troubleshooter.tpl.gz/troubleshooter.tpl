<nmsweb-configurator ng-model="model" nmsweb-options="options" widget="configurator"></nmsweb-configurator>
<div id="troubleshooterContent"></div>
