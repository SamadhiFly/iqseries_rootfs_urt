<input kendo-drop-down-list="widget" ng-required={{field.options.required}} ng-disabled={{field.additionalOptions.viewMode}}></input>
