<div ng-if="terminalModelChecked">
        <fieldset class="ng-scope ng-isolate-scope">
                <legend class="ng-binding">{{$root.translation.language.configuration_files}}</legend>
                <div class="table_wrapper">
                <table style="width:1200px" class="terminal-table configuration-table">
                        <thead>
                                <tr>
                                        <th>{{$root.translation.language.description}}</th>
                                        <th>{{$root.translation.language.filename}}</th>
                                        <th>{{$root.translation.language.version}}</th>
                                        <th>{{$root.translation.language.date}}</th>
                                        <th>{{$root.translation.language.size}}</th>
                                        <th></th>
                                        <th></th>
                                </tr>
                        </thead>
                        <tbody>
                                <tr ng-repeat="i in configFiles">
                                        <td>{{ i.description }}</td>
                                        <td>{{ i.filename }}</td>
                                        <td>{{ i.version }}</td>
                                        <td>{{ i.timestamp | date:'MM/dd/yyyy' }}</td>
                                        <td>{{ i.size }}</td>
                                        <td>
                                                <input kendo-upload="" k-options="upload_config" type="file" name="{{i.filename}}"/>
                                                <!-- <nmsweb-fileupload nmsweb-options="upload_config" name="i.filename" ng-model="upload_config"></nmsweb-fileupload> -->
                                        </td>
                                        <td>
                                                <button ng-click="downloadFile(i.filename)" ng-class="{disabled: !i.size}" ng-disabled="!i.size" class="terminal-btn">{{$root.translation.language.download_configuration_file}}</button>
                                        </td>
                                </tr>
                                <tbody>
                </table>
                </div>
        </fieldset>
</div>
