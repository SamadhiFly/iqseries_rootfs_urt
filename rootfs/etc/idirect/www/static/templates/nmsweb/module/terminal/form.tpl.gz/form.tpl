<led></led><h1>{{translation.language.system_status}}</h1>
<nmsweb-form schema="form" ng-attr-name="{{form.name}}"></nmsweb-form>
