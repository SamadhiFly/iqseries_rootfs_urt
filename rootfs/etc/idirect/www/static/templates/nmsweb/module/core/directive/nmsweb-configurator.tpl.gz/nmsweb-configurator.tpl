<div class='n-configurator-wrapper'>
        <div ng-show="nmswebOptions.opened" class="n-configurator-container  n-configurator-container-mover n-configurator-absolute">
                <div class="n-configurator-controls-top">
                        <div class="n-configurator-controls-top-title">
                                <h1 class="n-configurator-controls-top-title-header"> {{nmswebOptions.title}} </h1>
                                <a href ng-click="toggleMethod()" class="n-configurator-minimize"></a>
                                <div class="clear"></div>
                        </div>
                        <span class="n-select-container">
                                <select class="n-select" ng-model="nmswebOptions.mode" ng-options="value for value in availableModes"></select>
                        </span>
                        <div class="clear"></div>
                </div>
                <div class="n-configurator-sections" nmsweb-spin="spin">
                        <!-- presets directive goes here --><a nmsweb-popover="loadPopover" nmsweb-popover-options="loadPresetsPopover" class="white n-apply-preset-btn">Load Query</a>
                        <form class="n-configurator-form ng-pristine ng-valid n-configurator" ng-submit="nmswebOptions.submit.callback(ngModel, widget)">
                                <nmsweb-configurator-section ng-repeat-start="section in nmswebOptions.sections" widget="sections[section.name]" nmsweb-options="section" ng-model="ngModel" nmsweb-model="nmswebModel" mode="nmswebOptions.mode"></nmsweb-configurator-section>
                                <div ng-repeat-end class="clear"></div>
                                <div class="n-configurator-controls-bottom">
                                        <button nmsweb-popover="savePopover" nmsweb-popover-options="popoverOptions" class="n-cnf-btn white n-configurator-preset-button n-configurator-save-button n-popover"> Save Query
                                                <span class="buttonicon"></span>
                                        </button>
                                        <button type="submit" class=" n-cnf-btn blue n-configurator-generate-button" value="{{nmswebOptions.submit.value}}"> {{nmswebOptions.submit.label}} </button>
                                </div>
                        </form>
                </div>
        </div>
        <div ng-hide="nmswebOptions.opened" class="n-configurator-hidden-configurator">
                <div class="n-configurator-hidden-tab n-configurator-absolute">
                        <span class="n-configurator-hidden-text">
                                <a href ng-click="toggleMethod()" class="n-configurator-minimize-active"></a>
                        </span>
                </div>
        </div>
</div>