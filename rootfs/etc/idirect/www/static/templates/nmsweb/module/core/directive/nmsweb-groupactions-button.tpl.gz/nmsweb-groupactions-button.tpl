<div class="dropdown nmsweb-elementselector-groupactions" nmsweb-spin="spin">
	<a ng-if="!nmswebOptions.disabled" href="#" class='btn btn-primary btn-lg n-element-selector-group-actions-drop n-splitbutton n-splitbutton-action dropdown-toggle' role='button' data-toggle="dropdown" id='{{generatedId}}'>{{nmswebOptions.display}}</a>
	<a ng-if="nmswebOptions.disabled" class='btn btn-primary btn-lg n-element-selector-group-actions-drop n-splitbutton n-splitbutton-action dropdown-toggle' role='button' id='{{generatedId}}' aria-disabled='true'>{{nmswebOptions.display}}</a>
	<ul id='{{generatedId}}_menu' class='dropdown-menu' role='menu' aria-labelledby={{generatedId}}>
		<li ng-repeat="action in nmswebOptions.actions" ng-hide="ngModel && nmswebOptions.blockedActions[ngModel.typename] && nmswebOptions.blockedActions[ngModel.typename][action.action]">
			<a ng-if='action.generatedUrl' href='{{action.generatedUrl || "#"}}' ng-click='clickaction(action, $event)' data-target='{{action.url}}'>{{action.display}}</a>
			<a ng-if='action.wsUrl' ng-click="wsAction(action.wsUrl)">{{action.display}}</a>
		</li>
		<li>
	</ul>
	<yes-no-dialog initialize-dialog='nmswebOptions.initializeDialog' yes-callback='nmswebOptions.yesCallback()' no-callback='nmswebOptions.noCallback()' window-options='nmswebOptions.windowOptions'></yes-no-dialog>
</div>