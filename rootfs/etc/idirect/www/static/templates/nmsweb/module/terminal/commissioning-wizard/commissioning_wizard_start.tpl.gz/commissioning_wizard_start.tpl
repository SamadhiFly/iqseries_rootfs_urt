<div class="commissioning-info">{{$root.translation.language.during_commissioning_mode_the_terminal_will_not_attempt_to_acquire_the_network}}</div>
