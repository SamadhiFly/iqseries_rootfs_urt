<div class="advanced-search-group" nmsweb-spin="spin">
	<span class="group-operator-text">Group Operator</span><nmsweb-drop-down-list class="advanced-search-group-operator" widget="groupOperatorWidget" nmsweb-options="operatorOptions" ng-model='logicValue'></nmsweb-drop-down-list>
	<div class="advanced-search-group-condition" ng-repeat="condition in filters">
			<span class="find-elements-text">Find Elements</span> <nmsweb-elementselector-adv-search-cond widget="widgets[$index]" condition-options="conditionOptions" ng-model="condition"></nmsweb-elementselector-adv-search-cond>
			<span class="actions n-datasourcecomplexfilter"><button class="remove-condition-field" ng-hide="$first && filters.length === 1" class="btn btn-primary field-action" ng-click="removeCondition($index)">−</button><button class="add-condition-field" ng-click="addEmptyCondition()" ng-show="$last && !$first || filters.length === 1" class="btn btn-primary field-action">+</button></span>
	</div>
</div>