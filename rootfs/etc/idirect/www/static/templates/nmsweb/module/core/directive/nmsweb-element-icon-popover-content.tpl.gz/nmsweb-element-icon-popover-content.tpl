<nmsweb-key-information-panel obj_id='objId' obj_type_id='objType' detail_level='1' nmsweb-spin='spin'></nmsweb-key-information-panel>
