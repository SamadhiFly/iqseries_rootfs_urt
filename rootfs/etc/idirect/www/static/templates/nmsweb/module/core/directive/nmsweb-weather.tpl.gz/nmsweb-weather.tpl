<h2>Weather</h2>
<div class="spin" ng-if="objTypeId && weather.temp.current">
	<div style="float:left"><img ng-src="{{ imgurl }}"></div>   
	<h3>Current: {{ weather.temp.current | number:2 }}&deg;C</h3>
	<p>min: {{ weather.temp.min | number }}&deg;C, max: {{ weather.temp.max | number }}&deg;C</p>
	<p>Humidity: {{ weather.main.humidity | number }}%</p>
	<p>Wind: {{ weather.wind.speed | number }} mps</p>
	<p>Condition: {{ weather.weather.description }}</p>
</div>
<div ng-if="!objTypeId">
	<p>No location information available.</p>
</div>