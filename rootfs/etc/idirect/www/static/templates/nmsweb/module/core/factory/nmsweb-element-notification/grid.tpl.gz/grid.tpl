<div class="nmsweb-element-grid-notification">
	<div class="n-progress-notification-container group">
		<div class="n-progress-notification">
			<div class="n-notification-text-container">
				<span class="n-notification-title">Status</span>
				<span class="n-notification-text">{{message}}</span>
			</div>
		</div>
	</div>
</div>