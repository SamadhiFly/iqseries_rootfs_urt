<form novalidate class="n-form-horizontal-rendering n-form new-fe">
	<nmsweb-form-element ng-repeat="element in schema.layout" schema="element" form="schema"></nmsweb-form-element>
	<div class="remaining-fields"></div>
	<div class="n-actions">
		<input type="submit" ng-disabled="schema.renderingChildren.length > 0" ng-repeat="action in schema.actions" ng-click="schema.submit(action)" ng-show="(schema.mode === action.mode && !schema.viewMode) || (schema.viewMode && action.mode === 'view')" value="{{action.label}}"></input>
	</div>
</form>
