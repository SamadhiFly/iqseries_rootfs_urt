<ul>
        <li> <a href="/#/satellite-interface">{{$root.translation.language.view_satellite_details}}</a> </li>
        <li> <a href="/#/remote-device">{{$root.translation.language.view_terminal_details}}</a> </li>
        <li> <a href="/#/reporting-ports">{{$root.translation.language.view_current_traffic_throughput}}</a> </li>
</ul>
