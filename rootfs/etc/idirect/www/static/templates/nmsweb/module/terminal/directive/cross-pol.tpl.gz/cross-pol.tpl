<div ng-if="formReady">
<div ng-show="isCircular && mode == 'crosspol' && !standAloneTool" class="commissioning-info">
        <p >{{$root.translation.language.circular_crosspol}}</p>
</div>
<nmsweb-form schema="_isolate.form" ng-attr-name="{{_isolate.form.name}}"></nmsweb-form>
<div class="cross-pol-controls">
  <!-- <div class="cross-pol-status" ng-hide="$parent.currentStep == 7">{{$root.translation.language.cross_polarization}} is {{cross_pol_status}}</div>
  <div class="cross-pol-status" ng-show="$parent.currentStep == 7">{{$root.translation.language.p1db}} is {{cross_pol_status}}</div> -->

  <div class="cross-pol-status">
    <span ng-if="$parent.currentStep == '6'">{{$root.translation.language.cross_polarization}} is {{cross_pol_status}}</span>
    <span ng-if="$parent.currentStep == '7'">{{$root.translation.language.p1db}} is {{cross_pol_status}}</span>
  </div>
  <div class="commissioning-info warning" ng-show="outOfBoundsFrequency">
    <span ng-if="rfLo">{{$root.translation.language.invalidRfFrequency}}</span>
    <span ng-if="loRf">{{$root.translation.language.invalidLoFrequency}}</span>
  </div>

  <div class="commissioning-info warning" ng-show="inputError">
    {{$root.translation.language.please_fill_in_every_required_field}}
  </div>
  <div class="commissioning-info warning">
    {{$root.translation.language.do_not_click_the_start_button_until_instructed_to_do_so_by_the_satellite_provider}}
    <!-- <br/> {{$root.translation.language.when_you_do_click_start_this_satellite_modem_will_start_as_configured_above}} -->
    <br/> {{$root.translation.language.obtain_this_test_frequency_from_the_satellite_provider}}
    <br/> {{$root.translation.language.verify_the_l_band_tx_frequency_with_the_network_help_desk_operator}}
    <br/> {{$root.translation.language.downstream_lock_needed_for_crosspol_test}}
  </div>
  <div class="commissioning-info info">
          <p ng-if="!start">{{$root.translation.language.when_you_do_click_start_this_satellite_modem_will_start_as_configured_above}}</p>
          <p ng-if="start">{{$root.translation.language.please_use_the_apply_changes_button_after_adjusting_the_configuration_above_in_order_to_take_effect}}</p>
  </div>
  <button ng-click="cross_pol_start()" type="submit" ng-disabled="requestPending || !allowStart">
    <span ng-if="!start">{{$root.translation.language.turn_on_signal}}</span>
    <span ng-if="start">{{$root.translation.language.apply_changes}}</span>
  </button>
  <button ng-click="cross_pol_stop()" type="submit" ng-disabled="stop">{{$root.translation.language.turn_off_signal_and_complete}}</button>

</div>
</div>
