<div class="top-spinner-holder" nmsweb-spin="spin">
<form ng-if="layout.length && layoutLoadingComplete" class='new-fe flex-grid'>
        <div class="kipTitle">
                <h1><span><nmsweb-element-icon obj-id="objId" obj-show-name="true" no-popover='true' widget="nmswebOptions.nmswebElementIcon"></nmsweb-element-icon></span>
                        <nmsweb-actionsbutton obj-id='actionsbutton' display-type='small' widget="nmswebOptions.nmswebActionsbutton"></nmsweb-actionsbutton></h1>
        	<div class="detailLevels">
				<!--
					<span ng-show="detailLevel === 1"><a ng-click="showDetailLevel2()">expand window</a></span>
        	        <span ng-show="detailLevel === 1 || detailLevel === 2"><a ng-click="showDetailLevel3()">view as fullpage</a></span>
				-->
        	</div>
        </div>
        <nmsweb-dashboard layout='layout' width='width' height='height' layoutParameters='layoutParameters' widget="nmswebOptions.nmswebDashboard"></nmsweb-dashboard>
        </div>
</form>
<div id="{{$id}}"></div>
<div class="noData" ng-if="!layout.length && layoutLoadingComplete">No data available</div>
</div>
