<h1>{{translation.language.lan_interface}} - {{translation.language.ip_configuration_vlans}}</h1>
<span ng-if="formReady">
    <nmsweb-form schema="form" ng-attr-name="{{form.name}}"></nmsweb-form>
</span>