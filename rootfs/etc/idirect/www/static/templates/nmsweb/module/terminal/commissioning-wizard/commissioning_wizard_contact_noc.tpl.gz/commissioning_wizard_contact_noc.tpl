<h2>{{$root.translation.language.commissioning_wizard_contact_noc}}</h2>

<div class="commissioning-info">
        <p>{{$root.translation.language.please_verify_that_tx_cable_is_attached_to_buc}}</p>
        <p ng-if="stepData['commissioning_wizard_p1db_test']">{{$root.translation.language.please_contact_your_noc_before_proceeding_to_the_cross_polarization_and_p1db_tests}}</p>
        <p ng-if="!stepData['commissioning_wizard_p1db_test']">{{$root.translation.language.please_contact_your_noc_before_proceeding_to_the_cross_polarization}}</p>
</div>
