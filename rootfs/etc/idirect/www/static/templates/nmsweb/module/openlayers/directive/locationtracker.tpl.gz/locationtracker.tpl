<div>
    <script type="text/javascript">
    //openlayers-directive can't take ID directly from scope attribute as it's using attrs.id instead of scope.id internally
    $("openlayers").attr('id',"{{id}}");
    </script>
    <nmsweb-tooltip tooltip="optionsDropdown" ng-hide="widget" uniqueid="locationtrackerOptionsDropdown" actionsbutton="true" style="float: right; margin: 10px;"></nmsweb-tooltip>
    <input ng-model="filter" class="locationFilter" ng-hide="widget" placeholder="Filter ..." />
    <div id="map"></div>
    <openlayers ng-hide="mapLoadError" id={{id}} ol-events="events" ol-markers="markers" ol-layers="olLayers" ol-controls="controls" ol-defaults="defaults" ol-center="center"></openlayers>
    <div class="mapLoadError" ng-show="mapLoadError">Map cannot be loaded.<br />You have currently got no access to the map server.</div>
</div>
