<div class="n-splash" ng-show="showSplashscreen">
    <!-- Duplicate code of /static/templates/nmsweb/module/core/controller/index.tpl -->
    <img class="pulse-small" src="/static/images/Small%20Pulse%20Logo.png" width="118" height="64">
    <h1>Welcome to iDirect Pulse</h1>
    <p>To get started you can access tasks and functions via the main menu options or find an Element using the search box above.</p>
	<img class="pulse-watermark" src="/static/images/Pulse%20Logo%20Watermark%20png.png" width="905" height="406">
</div>