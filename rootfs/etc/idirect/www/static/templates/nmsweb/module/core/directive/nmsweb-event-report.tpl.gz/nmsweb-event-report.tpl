<h2>Event Report</h2>
{{objId}}
{{severity}}
{{startTime}}
{{stream}}