<div kendo-tree-view="widget" k-options="nmswebOptions">
</div>
