<div class='nmsweb-configurator-report' ng-class='{"configurator-shown":configuratorShown}'>
	<nmsweb-configurator ng-model="ngModel" nmsweb-options="nmswebOptions" nmsweb-model="nmswebModel" widget="nmswebConfigurator"></nmsweb-configurator>
	<div class='report'>
	</div>
</div>
