<div class="row-fluid">
	<div class="span6">
		<txrx-configuration configuration="config" type="'tx'"></txrx-configuration>
		<button ng-click="apply('tx')">Apply</button>
	</div>
	<div class ="span12">
		<div class="span6">
			<txrx-configuration configuration="config" type="'rx1'" ></txrx-configuration>
			<button ng-click="apply('rx1')">Apply</button>
		</div>
		<div class="span6">
			<txrx-configuration configuration="config" type="'rx2'" ng-show="rx2" ></txrx-configuration>
			<button ng-click="apply('rx2')" ng-show="rx2">Apply</button>
		</div>
	</div>
</div>
