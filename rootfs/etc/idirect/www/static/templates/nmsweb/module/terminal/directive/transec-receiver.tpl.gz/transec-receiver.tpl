<div ng-if="_completed">
    <nmsweb-form schema="form" ng-attr-name="{{form.name}}" id="{{receiverForm}}"></nmsweb-form>
</div>
