<div>
    <input ng-model='userSearch' placeholder='Search...' type='text' class='nmsweb-elementselector-search-input' ng-keypress='searchKeyPressed($event)'></input>
</div>
