<div>
	<span class='n-select-container nmsweb-elementselector-filter-{{dropdown.name}}' ng-repeat='dropdown in nmswebOptions.dropdowns track by $index'>
		<select class='n-select' ng-model='models[$index]'>
			<option ng-repeat='option in dropdown.options' value='{{option.value}}'>
				{{option.display}}
			</option>
		</select>
	</span>
</div>
