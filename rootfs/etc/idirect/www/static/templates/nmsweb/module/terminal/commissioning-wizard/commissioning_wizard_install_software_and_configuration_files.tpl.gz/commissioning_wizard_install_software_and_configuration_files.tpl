<h2>{{$root.translation.language[config.steps['commissioning_wizard_install_software_and_configuration_files'].title]}}</h2>

<terminal-software modified="config.steps['commissioning_wizard_install_software_and_configuration_files'].modified"></terminal-software>
<terminal-configuration modified="config.steps['commissioning_wizard_install_software_and_configuration_files'].modified"></terminal-configuration>
