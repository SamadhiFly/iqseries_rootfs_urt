<h2>{{$root.translation.language.commissioning_wizard_cross_polarization_test}}</h2>
<cross-pol rx-id="stepData['commissioning_wizard_configure_downstream'].rx_clear" cross-pol-configuration="stepData['commissioning_wizard_cross_polarization_test']" valid="config.steps['commissioning_wizard_cross_polarization_test'].buttons[1].enabled"></cross-pol>
