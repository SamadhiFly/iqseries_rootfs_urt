<h2>{{$root.translation.language.commissioning_wizard_configure_downstream}}</h2>
<configure-downstream wizard="true" downstream-configuration="stepData['commissioning_wizard_configure_downstream']" valid="config.steps['commissioning_wizard_configure_downstream'].buttons[0].enabled"></configure-downstream>
