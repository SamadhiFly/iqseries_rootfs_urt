<div>
        <nmsweb-elementselector class="n-metricselector" widget="widget" ng-model="ngModel" nmsweb-model="nmswebModel" nmsweb-options="metricSelectorOptions"></nmsweb-elementselector>
</div>
