<input kendo-time-picker='widget' k-options="nmswebOptions" ng-disabled={{additionalOptions.viewMode}}></input>
