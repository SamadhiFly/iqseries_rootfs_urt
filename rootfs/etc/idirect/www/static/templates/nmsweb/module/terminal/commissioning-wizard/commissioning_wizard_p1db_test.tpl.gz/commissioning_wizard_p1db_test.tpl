<h2>{{$root.translation.language.commissioning_wizard_p1db_test}}</h2>
<cross-pol mode="'p1db'" rx-id="stepData['commissioning_wizard_configure_downstream'].rx_clear" cross-pol-configuration="stepData['commissioning_wizard_p1db_test']" valid="config.steps['commissioning_wizard_p1db_test'].buttons[0].enabled"></cross-pol>
