<h1 ng-show="activeTab != 3">{{translation.language.administration}} - {{translation.language.manual_downstream}}</h1>
<h1 ng-show="activeTab == 3">{{translation.language.administration}} - {{translation.language.management_lan_configuration}}</h1>
<form ng-if="model != '980' && ready" class="new-fe">
    <div class="k-tabstrip-wrapper">
        <div class="n-tabstrip k-widget k-header k-tabstrip k-floatwrap k-tabstrip-top">

            <span class="mobile-tabs-holder">
                <select ng-model="activeTab" ng-init="activeTab = 0" ng-change="changeTab(activeTab)" class="ng-pristine ng-valid">
                    <option value="0">{{translation.language.manual_downstream}}</option>
                    <option value="1">Multicast</option>
                    <option value="2">{{translation.language.mpe}}</option>
                    <option value="3">MGMT LAN</option>
                </select>
            </span>

            <ul class=" k-tabstrip-items k-reset">
                <li ng-click="changeTab(0)" ng-class="{'k-state-active': activeTab == 0}" class="k-item k-state-default k-first k-tab-on-top" role="tab">
                    <span class="k-link">{{translation.language.manual_downstream}}</span>
                </li>
                <li ng-click="changeTab(1)" ng-class="{'k-state-active': activeTab == 1}" class="k-item k-state-default k-tab-on-top" role="tab">
                    <span class="k-link">Multicast</span>
                </li>
                <li ng-click="changeTab(2)" ng-class="{'k-state-active': activeTab == 2}" class="k-item k-state-default k-tab-on-top" role="tab">
                    <span class="k-link">{{translation.language.mpe}}</span>
                </li>
                <li ng-click="changeTab(3)" ng-class="{'k-state-active': activeTab == 3}" class="k-item k-state-default k-last k-tab-on-top" role="tab">
                    <span class="k-link">MGMT LAN</span>
                </li>
            </ul>
            <div class="k-content" ng-style="tabStyle0" ng-class="{'k-state-active': activeTab == 0}">
                <manual-downstream></manual-downstream>
            </div>
            <div class="k-content" ng-style="tabStyle1" ng-class="{'k-state-active': activeTab == 1}">
                <multicast></multicast>
            </div>
            <div class="k-content" ng-style="tabStyle2" ng-class="{'k-state-active': activeTab == 2}">
                <mpe></mpe>
            </div>
            <div class="k-content" ng-style="tabStyle3" ng-class="{'k-state-active': activeTab == 3}">
                <mgmt-lan></mgmt-lan>
            </div>
        </div>
    </div>
</form>
<div class="commissioning-info" ng-if="model == '980'">
        {{translation.language.manual_downstream_is_not_available}}
</div>