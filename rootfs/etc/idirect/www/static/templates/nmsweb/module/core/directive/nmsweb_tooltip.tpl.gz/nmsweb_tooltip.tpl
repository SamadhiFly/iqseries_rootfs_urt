<div ng-show="actionsbutton" class="actionsbutton-container">
        <div class="n-splitbutton-action-small n-splitbutton btn"></div>
</div>
<span ng-show="!actionsbutton" class="tooltip-icon {{tooltip.type}}"></span>
