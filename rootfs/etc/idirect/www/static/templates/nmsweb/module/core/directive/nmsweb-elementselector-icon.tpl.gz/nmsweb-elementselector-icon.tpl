<div class="ng-scope n-element-selector-status big-icon nmsweb-elementselector-icon" ng-class="model.shape">
	<div class="n-element-selector-status-configuration-icon" ng-class="model.config"></div>
</div>
