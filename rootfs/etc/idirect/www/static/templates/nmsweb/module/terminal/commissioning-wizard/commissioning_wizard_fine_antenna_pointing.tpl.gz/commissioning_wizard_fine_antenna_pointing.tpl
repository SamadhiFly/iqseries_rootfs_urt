<h2>{{$root.translation.language.commissioning_wizard_fine_antenna_pointing}}</h2>
<antenna-pointing downstream-configuration="stepData['commissioning_wizard_configure_downstream']" valid="config.steps['commissioning_wizard_fine_antenna_pointing'].buttons[0].enabled"></antenna-pointing>
