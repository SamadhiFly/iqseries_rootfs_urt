<nmsweb-input nmsweb-options='nmswebOptions' ng-model='model'></nmsweb-input>
<!-- <nmsweb-tooltip tooltip="nmswebOptions.fieldDetails.tooltip"></nmsweb-tooltip> -->
