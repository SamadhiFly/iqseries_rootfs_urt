<span class="row-label">{{schema.label}}</span>
<div class="row-fluid">
	<nmsweb-form-element ng-repeat="element in schema.contents" schema="element" form="form"></nmsweb-form-element>
</div>
