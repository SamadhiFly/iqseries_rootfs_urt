<div class="k-content">

    <form novalidate="" class="n-form-horizontal-rendering n-form new-fe ng-isolate-scope ng-scope ng-pristine ng-valid" ng-hide="$root.noBuc"  ng-attr-name="{{form.name}}">
        <div class="span6 ng-scope ng-isolate-scope"><span class="cell-label"></span>
            <fieldset ng-hide="schema.hide" class="ng-scope ng-isolate-scope">
                <legend>BUC Information <a href="#" class="self-disclose  ng-hide"></a></legend>
                <div class="directive-contents" nmsweb-spin="loading">
                    <div class="part-number ng-scope" id="buc-part-number-container">
                        <label for="buc-part-number">
                            {{$root.translation.language.part_number}}
        </label>
                        <div class="ng-scope ng-isolate-scope ng-pristine ng-valid value-wrapper" id="buc-part-number"> <span>
        {{form.model.part_number}}
      </span>
                        </div>

                        <div class="wrapper-icon ng-scope">
                            <nmsweb-field-tooltip tooltips="field.options.tooltips" class="ng-isolate-scope">
                            </nmsweb-field-tooltip>
                        </div>
                    </div>
                    <div class="serial-number ng-scope" id="buc-serial-number-container">
                        <label for="buc-serial-number">{{$root.translation.language.serial_number}}
        </label>
                        <div class="ng-scope ng-isolate-scope ng-pristine ng-valid value-wrapper" id="buc-serial-number"> <span>
                                {{form.model.serial_number}}
      </span>
                        </div>

                        <div class="wrapper-icon ng-scope">
                            <nmsweb-field-tooltip tooltips="field.options.tooltips" class="ng-isolate-scope">
                            </nmsweb-field-tooltip>
                        </div>
                    </div>
                    <div class="manufacturer-id ng-scope" id="buc-manufacturer-id-container">
                        <label for="buc-manufacturer-id">
                            {{$root.translation.language.manufacturer_id}}
        </label>
                        <div class="ng-scope ng-isolate-scope ng-pristine ng-valid value-wrapper" id="buc-manufacturer-id"> <span>
                                    {{form.model.manufacturer_id}}
      </span>
                        </div>

                        <div class="wrapper-icon ng-scope">
                            <nmsweb-field-tooltip tooltips="field.options.tooltips" class="ng-isolate-scope">
                            </nmsweb-field-tooltip>
                        </div>
                    </div>
                    <div class="functional-id ng-scope" id="buc-functional-id-container">
                        <label for="buc-functional-id">
                                {{$root.translation.language.functional_id}}
        </label>
                        <div class="ng-scope ng-isolate-scope ng-pristine ng-valid value-wrapper" id="buc-functional-id"> <span>
                                {{form.model.functional_id}}
      </span>
                        </div>

                        <div class="wrapper-icon ng-scope">
                            <nmsweb-field-tooltip tooltips="field.options.tooltips" class="ng-isolate-scope">
                            </nmsweb-field-tooltip>
                        </div>
                    </div>
                    <div ng-if="$root.system_type != 'VELOCITY'" class="buc-lo-frequency ng-scope" id="buc-buc-lo-frequency-container">
                        <label for="buc-buc-lo-frequency">
                                {{$root.translation.language.buc_lo_frequency}}
        </label>
                        <div class="ng-scope ng-isolate-scope ng-pristine ng-valid value-wrapper" id="buc-buc-lo-frequency"> <span>
                                {{form.model.buc_lo_frequency}}
      </span>
                        </div>

                        <div class="wrapper-icon ng-scope">
                            <nmsweb-field-tooltip tooltips="field.options.tooltips" class="ng-isolate-scope">
                            </nmsweb-field-tooltip>
                        </div>
                    </div>
                    <div class="software-version ng-scope" id="buc-software-version-container">
                        <label for="buc-software-version">
                                {{$root.translation.language.software_version}}
        </label>
                        <div class="ng-scope ng-isolate-scope ng-pristine ng-valid value-wrapper" id="buc-software-version"> <span>
                                {{form.model.software_version}}
      </span>
                        </div>

                        <div class="wrapper-icon ng-scope">
                            <nmsweb-field-tooltip tooltips="field.options.tooltips" class="ng-isolate-scope">
                            </nmsweb-field-tooltip>
                        </div>
                    </div>
                    <div class="band-selection ng-scope" id="buc-band-selection-container">
                        <label for="buc-band-selection">
                                {{$root.translation.language.band_selection}}
        </label>
                        <div class="ng-scope ng-isolate-scope ng-pristine ng-valid value-wrapper" id="buc-band-selection"> <span>
                                {{form.model.band_selection}}
      </span>
                        </div>

                        <div class="wrapper-icon ng-scope">
                            <nmsweb-field-tooltip tooltips="field.options.tooltips" class="ng-isolate-scope">
                            </nmsweb-field-tooltip>
                        </div>
                    </div>
                </div>
            </fieldset>
        </div>
        <div class="span6 ng-scope ng-isolate-scope"><span class="cell-label"></span>
            <fieldset ng-hide="schema.hide" class="ng-scope ng-isolate-scope">
                <legend>BUC Status <a href="#" class="self-disclose  ng-hide"></a></legend>
                <div class="directive-contents" nmsweb-spin="loading">
                    <div class="local-oscillator ng-scope" id="buc-local-oscillator-container">
                        <label for="buc-local-oscillator">
                                    {{$root.translation.language.local_oscillator}}
        </label>
                        <div class="ng-scope ng-isolate-scope ng-pristine ng-valid value-wrapper" id="buc-local-oscillator"> <span>
                                        {{form.model.local_oscillator}}
      </span>
                        </div>
                        <div class="wrapper-icon ng-scope">
                            <nmsweb-field-tooltip tooltips="field.options.tooltips" class="ng-isolate-scope">
                            </nmsweb-field-tooltip>
                        </div>
                    </div>
                    <div class="fan ng-scope" id="buc-fan-container">
                        <label for="buc-fan">
                                    {{$root.translation.language.fan}}
        </label>

                        <led-field-wrapper nmsweb-options="form.fields.fan.options" ng-attr-id="{{field.id}}" ng-model="form.model.fan" class="ng-scope ng-isolate-scope ng-pristine ng-valid" id="buc-fan">

                        </led-field-wrapper>

                        <div class="wrapper-icon ng-scope">
                            <nmsweb-field-tooltip tooltips="field.options.tooltips" class="ng-isolate-scope">
                            </nmsweb-field-tooltip>
                        </div>
                    </div>
                    <div class="output ng-scope" id="buc-output-container">
                        <label for="buc-output">
                                    {{$root.translation.language.output}}
        </label>
                        <div class="ng-scope ng-isolate-scope ng-pristine ng-valid value-wrapper" id="buc-output"> <span>
                                    {{form.model.output}}
      </span>
                        </div>
                        <div class="wrapper-icon ng-scope">
                            <nmsweb-field-tooltip tooltips="field.options.tooltips" class="ng-isolate-scope">
                            </nmsweb-field-tooltip>
                        </div>
                    </div>
                    <div class="temperature ng-scope" id="buc-temperature-container">
                        <label for="buc-temperature">
                                    {{$root.translation.language.temperature}}
        </label>
                        <div class="ng-scope ng-isolate-scope ng-pristine ng-valid value-wrapper" id="buc-temperature"> <span>
                                    {{form.model.temperature}} °C
      </span> </div>
                        <div class="wrapper-icon ng-scope" ng-if="field.options.fieldDetails.chart_options.type !== 'fieldset'">
                            <nmsweb-field-tooltip tooltips="field.options.tooltips" class="ng-isolate-scope">

                            </nmsweb-field-tooltip>

                            <chart resource=" 'terminal/odu/buc/'+ form.id " resolutionlive="5000" resolutionbuffer="30000" buffer="false" field="['temperature']" unit="'°C'" type="'popover'" tooltipoptions="{placement: 'left',title: 'Temperature'}" maxpoints="150" class="ng-scope ng-isolate-scope">

                            </chart>

                        </div>
                    </div>
                </div>
            </fieldset>
        </div>
    </form>
    <div ng-if="$root.system_type == 'VELOCITY'">
        <fieldset class="ng-scope ng-isolate-scope">
            <legend class="ng-binding">{{$root.translation.language.translation.language.configuration_files}}</legend>
            <div class="table_wrapper">
                <table style="width:1200px" class="terminal-table configuration-table">
                    <thead>
                        <tr>
                            <th>{{$root.translation.language.start_frequency}}</th>
                            <th>{{$root.translation.language.stop_frequency}}</th>
                            <th>{{$root.translation.language.translation}}</th>
                            <th>{{$root.translation.language.commissioning_status}}</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr ng-repeat="i in form.band_config" ng-style="{ 'background-color': i.active == true ? '#3b93e9' : ''}">
                            <td>{{ i.start_rf_frequency }}<span></span></td>
                            <td>{{ i.stop_rf_frequency }}</td>
                            <td>{{ i.translation }}</td>
                            <td><span ng-if="i.state != 'emulate'">{{ i.commissiond }} |</span>


                            <span ng-if="i.state == 'serial' || i.state == 'ethernet'">
                                <a class="attr-link" style="color:#2e2e2e; text-decoration: underline;" href="/#/one-touch-calibration">One Touch Calibration</a>
                            </span>
                            <span ng-if="i.state == 'standard'">
                                    <a class="attr-link" style="color:#2e2e2e; text-decoration: underline;" href="/#/commissioning-wizard">Commissioning Wizard</a>
                            </span>
                            <span ng-if="i.state == 'emulate'">
                                    BUC emulation mode
                            </span>
                            <span ng-if="i.state == 'details'">
                                <a class="attr-link" style="color:#2e2e2e; text-decoration: underline;" href="/#/commissioning-details#{{i.start_rf_frequency}}">Band Details</a>
                            </span>
                            </td>
                        </tr>
                        <tbody>
                </table>
            </div>
        </fieldset>
    </div>
</div>