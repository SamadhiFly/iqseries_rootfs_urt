<div class="span6">
    <div ng-if="formReady">
        <nmsweb-form schema="form" ng-attr-name=""></nmsweb-form>
    </div>
</div>
