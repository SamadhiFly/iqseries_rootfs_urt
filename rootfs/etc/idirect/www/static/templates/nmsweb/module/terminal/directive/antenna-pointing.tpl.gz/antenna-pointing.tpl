<div>
  <div class="antennaPointing">
        <div ng-show="!validDownstream || showDownstream">
                <configure-downstream downstream-configuration="downstreamConfiguration"></configure-downstream>
        </div>
        <div class="commissioning-info info" ng-show="!openamip && openamipChecked">
          <p ng-hide="!info_box_text_step_1"><strong>1. {{$root.translation.language.point_to_empty_sky}} ({{$root.translation.language.current_step}})</strong><br/>2. {{$root.translation.language.point_until_locked_onto_the_downstream_carrier}}</p>
          <p ng-hide="info_box_text_step_1">1. {{$root.translation.language.point_to_empty_sky}} <br/><strong>2. {{$root.translation.language.point_until_locked_onto_the_downstream_carrier}} ({{$root.translation.language.current_step}})</strong></p>
        </div>
        <div class="commissioning-info info" ng-show="openamip && openamipChecked && start">
          <p><strong>{{$root.translation.language.satellite_search_in_progress}}</p>
        </div>
        <div ng-if="error" class="commissioning-info warning">{{error}}</div>
        <p ng-class="{ 'antennaPointingInfoText': openamip, 'topToolbar': !openamip }"><span ng-show="!openamip && openamipChecked">{{$root.translation.language.voltage}} <nmsweb-tooltip tooltip="voltage_tooltip"></nmsweb-tooltip></span><span> {{$root.translation.language.demod_lock_status}}: {{state || '-'}}</span><span ng-show="openamip && openamipChecked"> {{$root.translation.language.antenna_status}}: {{func || '-'}}, {{transmit || '-'}}</span></p>
        <highchart ng-show="!openamip && openamipChecked" id="chart1" config="chartConfig" class="antenna_pointing_chart" width="100%"></highchart>
        <div class="antenna_pointing_control">
                <div class="control-buttons">
                        <span class="btn-holder">
                                <button type="submit" ng-if="!start" ng-class="{'disabled': start || !validDownstream}" ng-click="antenna_pointing_start(pwm)" ng-disabled="start || !validDownstream">{{$root.translation.language.start_antenna_pointing}}</button>
                                <button type="submit" ng-if="start" ng-class="{'disabled': stop}" ng-click="antenna_pointing_stop()" ng-disabled="stop">{{$root.translation.language.stop_antenna_pointing}}</button>
                        </span>
                        <!-- <span class="antenna_pointing_status">{{$root.translation.language.the_output_voltage_is}}
                                <span class="antenna_pointing_status2">{{antenna_pointing_status}}</span>
                        </span> -->
                        <span class="options-holder" ng-show="!openamip && openamipChecked">
                                <p ng-show="pwmEnabled">{{$root.translation.language.use_pwm_signal}}:
                                        <input type="checkbox" ng-disabled="start" ng-model="pwm" ng-change="pwmConfirm()"/>
                                        <nmsweb-tooltip tooltip="pwm_tooltip"></nmsweb-tooltip>
                                </p>
                                <p>{{$root.translation.language.use_audio_feedback}}:
                                <input type="checkbox" ng-show="webaudio" ng-model="audiofeedback" />
                                        <span ng-hide="webaudio">{{$root.translation.language.the_browser_you_are_using_doesnt_support_this_feature_we_recommend_firefox_chrome}}</span>
                                        <nmsweb-tooltip tooltip="audio_feedback_tooltip"></nmsweb-tooltip>
                                </p>
                        </span>
                        <br/>
                </div>
                <div class="table_wrapper" ng-show="!openamip && openamipChecked">
                  <table class="antenna_pointing_info_table">
                          <thead>
                                  <td>{{$root.translation.language.volts_dc}}</td>
                                  <td>{{$root.translation.language.antenna_status}}</td>
                          </thead>
                          <tbody>
                                  <tr class="antenna_pointing_info_table_row1">
                                          <td>{{ranges[0].range}}</td>
                                          <td>{{ranges[0].description}}</td>
                                  </tr>
                                  <tr class="antenna_pointing_info_table_row2">
                                          <td>{{ranges[1].range}}</td>
                                          <td>{{ranges[1].description}}</td>
                                  </tr>
                                  <tr class="antenna_pointing_info_table_row3">
                                          <td>{{ranges[2].range}}</td>
                                          <td>{{ranges[2].description}}</td>
                                  </tr>
                          </tbody>
                  </table>
                </div>
        </div>
   </div>
</div>
