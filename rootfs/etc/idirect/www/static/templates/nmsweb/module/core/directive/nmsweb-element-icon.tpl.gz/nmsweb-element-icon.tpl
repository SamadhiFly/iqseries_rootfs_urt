<div class="nmsweb-element-icon-wrapper" nmsweb-elementselector-icon-popover="mainPopoverWidget">
	<div class="ng-scope n-element-selector-status big-icon nmsweb-element-icon" ng-class="model.shape" ng-click="openPopover($event)">
		<div class="n-element-selector-status-configuration-icon" ng-class="model.config"></div>
	</div>
	<span ng-show="objShowName">{{objName}}</span>
</div>
