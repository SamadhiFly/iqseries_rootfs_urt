<h1>{{translation.language.commissioning}} - {{translation.language.commissioning_details}}</h1>
<nmsweb-form schema="form" ng-attr-name="{{form.name}}" ng-if="$root.commissioningAvailable"></nmsweb-form>
<div class="commissioning-info" ng-if="$root.commissioningAvailable">
  <p>{{translation.language.this_page_contains_the_commissioning_details_currently_in_use}}</p>
</div>
<div class="commissioning-info" ng-if="!$root.commissioningAvailable">
  <p>{{translation.language.commissioning_not_available}}</p>
</div>
