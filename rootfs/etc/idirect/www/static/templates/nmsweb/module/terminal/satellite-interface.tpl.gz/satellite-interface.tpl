<h1>{{translation.language.satellite_interface}} - {{translation.language.reporting_configuration}}</h1>
<div ng-if="ready">
<nmsweb-form schema="form" ng-attr-name="{{form.name}}"></nmsweb-form>
</div>