<div>
	<div kendo-tab-strip="widget" class="n-tabstrip" k-options="nmswebOptions" ng-transclude></div>
</div>