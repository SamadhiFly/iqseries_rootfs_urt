<div>
    <div id="{{nmswebOptions.id}}" class='n-grid' kendo-grid="widget" nmsweb-spin="widget.spin" k-options="nmswebOptions"></div>
    <span class="n-selection-info" ng-show="_showSelectionInfo">
        {{selected}} of {{widget.dataSource._total || 0}} selected
        <span class="n-selection-actions">
            (<a class="k-label n-select-all" href="" ng-click="selectAll()">select all</a> | 
            <a class="k-label n-deselect-all" href="" ng-click="deselectAll()">deselect all</a>)
    </span>
</div>