<div class='notification-tray' ng-show="show">
    <img class="close-notification-tray" ng-src="/static/images/notification-tray/blue_close_icon.png" ng-click="closeNotificationTray()">
	<nmsweb-tab-strip widget="tabstrip" nmsweb-options="opts"></nmsweb-tab-strip> 
</div>