<div widget='widget'>
	<nmsweb-grid nmsweb-spin='spin' widget='nmswebOptions.grid' nmsweb-options='nmswebOptions' class="n-grid foo"></nmsweb-grid>
</div>