<tr data-uid="#: uid #" elementname="#: obj_name #" elementid="#: obj_id #" elementtype="#: type #">
	<td class="n-element-selector-status-column">
		#: obj_name #
	</td>
</tr>
