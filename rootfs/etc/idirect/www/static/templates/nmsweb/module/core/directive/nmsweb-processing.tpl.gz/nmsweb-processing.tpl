<div ng-show='processing'>
	{{content}}
	<img ng-show='processing' class='pull-right' ng-src='/static/images/external/Kendo/Default/loading-image.gif'/><br/>
</div>