<h1 class="ng-binding ng-scope">{{translation.language.commissioning}} - {{translation.language.cross_polarization_p1db}}</h1>

<cross-pol stand-alone-tool="stand_alone_tool"></cross-pol>
