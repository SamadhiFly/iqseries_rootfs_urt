<div>
	<div ng-repeat="item in rangeArrayMin track by $index">
		<label ng-attr-for="{{nmswebOptions.name}}_{{ nmswebOptions.checkboxLabel }}_{{ $index + 1 }}">
                	{{ nmswebOptions.checkboxLabel }} {{ $index + 1 }}<span class="checkbox-label" ng-class="{'checked': ngModel.charAt($index) === '1','view-mode-checkbox': additionalOptions.viewMode}"></span>
		</label>
		<input ng-attr-id="{{nmswebOptions.name}}_{{ nmswebOptions.checkboxLabel }}_{{ $index + 1 }}" type="checkbox" ng-click="updateModel($index)" ng-checked="ngModel.charAt($index) === '1'" ng-disabled="nmswebOptions.readonly || additionalOptions.viewMode" /> <button ng-show="$index + 1 > nmswebOptions.minlength" ng-click="removeCheckbox($index)">-</button>
	</div>
	<button ng-show="currentCheckboxNumber !== nmswebOptions.maxlength" ng-click="addCheckbox()">+</button>
</div>
