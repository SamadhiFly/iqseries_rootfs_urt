<h1 class="ng-binding ng-scope">{{translation.language.authentication}}</h1>

<one-time-token stand-alone-tool="stand_alone_tool"></one-time-token>
