<input kendo-date-picker='widget' nmsweb-spin="spin" k-options="nmswebOptions" ng-disabled={{additionalOptions.viewMode}}></input>
