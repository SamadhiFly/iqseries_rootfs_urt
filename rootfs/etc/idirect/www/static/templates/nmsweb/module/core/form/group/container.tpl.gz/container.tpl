<span class="container-label">{{schema.label}}</span>
<nmsweb-form-element ng-repeat="element in schema.contents" schema="element" form="form"></nmsweb-form-element>
