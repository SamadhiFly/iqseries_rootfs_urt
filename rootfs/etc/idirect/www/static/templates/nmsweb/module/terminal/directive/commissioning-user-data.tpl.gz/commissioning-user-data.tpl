<div class="center">
        <div ng-hide="!form.isRendered">
                <nmsweb-form schema="form" ng-attr-name="{{form.name}}"></nmsweb-form>
        </div>
</div>
