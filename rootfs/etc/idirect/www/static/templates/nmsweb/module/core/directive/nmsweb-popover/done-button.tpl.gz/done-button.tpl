<div class='n-configurator-apply-change-button-holder'>
	<button ng-click="hidePopover()" class="n-cnf-btn blue n-configurator-apply-change-button">Done</button>
</div>