<div ng-show='initializeDialog'>{{windowOptions.dialogContent}}<br /><br />
	<button class='yes-button'>{{windowOptions.yesText}}</button>
	<button class='no-button'>{{windowOptions.noText}}</button>
</div>