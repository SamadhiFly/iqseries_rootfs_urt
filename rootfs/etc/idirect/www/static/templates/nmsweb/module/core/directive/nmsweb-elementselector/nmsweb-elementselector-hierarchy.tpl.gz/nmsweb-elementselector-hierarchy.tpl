<nmsweb-groupactions-button nmsweb-options="groupactionsOptions" selected-data="selectedData"></nmsweb-groupactions-button>
