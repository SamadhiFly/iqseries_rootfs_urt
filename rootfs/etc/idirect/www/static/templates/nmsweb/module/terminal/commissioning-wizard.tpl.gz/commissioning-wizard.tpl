<h1>{{title}}</h1>
<div ng-if="wizardConfiguration && $root.commissioningAvailable && wizardConfigReady">
  <wizard id="{{wizardId}}" config="wizardConfiguration" initial-step="initialStep" clear-progress="clearProgress" force-process="forceProcess"></wizard>
</div>
<div class="commissioning-info" ng-if="!$root.commissioningAvailable && $root.commissioningAvailableChecked">
  <p>{{translation.language.commissioning_not_available}}</p>
</div>
