<h1>{{translation.language.external_equipment}} - {{translation.language.buc}}</h1>
<form class="new-fe">
    <div class="k-tabstrip-wrapper">
        <div class="n-tabstrip k-widget k-header k-tabstrip k-floatwrap k-tabstrip-top">

            <span ng-if="$root.system_type == 'VELOCITY'" class="mobile-tabs-holder">
				<select ng-model="activeTab" ng-init="activeTab = 0" ng-change="changeTab(activeTab)" class="ng-pristine ng-valid">
					<option ng-repeat="buc in bucs" value="0">BUC {{$index+1}}</option>
				</select>
			</span>
            <ul ng-if="$root.system_type == 'VELOCITY'" class=" k-tabstrip-items k-reset">
                <li ng-repeat="buc in bucs" ng-click="changeTab($index)" ng-class="{'k-state-active': activeTab == $index, 'k-first' : $first, 'k-last' : $last }" class="k-item k-state-default k-first k-tab-on-top" role="tab">
                    <span class="k-link">BUC {{$index+1}}</span>
                </li>
            </ul>
            <div  ng-hide="$root.noBuc && $root.system_type != 'VELOCITY'" ng-repeat="buc in bucs" ng-style="{ 'display': $index == activeTab ? 'block' : 'none' }">

                <buc-tab form-options="formOptions" buc="buc.id"></buc-tab>
            </div>
        </div>
        <div class="commissioning-info" ng-show="$root.noBuc && $root.system_type != 'VELOCITY'">
            <p>{{translation.language.no_buc_connected}}</p>
        </div>
</form>