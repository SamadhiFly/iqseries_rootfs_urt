<h1>{{translation.language.lan_interface}} - {{translation.language.ethernet_status}}</h1>
<div ng-if="ready">
    <nmsweb-form schema="form" ng-attr-name="{{form.name}}"></nmsweb-form>
</div>