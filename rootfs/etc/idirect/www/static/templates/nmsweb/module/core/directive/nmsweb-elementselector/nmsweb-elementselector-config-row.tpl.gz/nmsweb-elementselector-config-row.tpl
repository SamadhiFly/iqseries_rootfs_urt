<tr data-uid="#: uid #" elementname="#: obj_name #" elementid="#: obj_id #" elementtype="#: type #">
	<td class="n-element-selector-status-column">
		<nmsweb-icon po-state="#= obj_states.performance_operational_state #" cu_state="#= obj_states.config_update_state #" no-popover="true" obj_type="#= type #" obj_name="#= obj_name #" should-update="#= iconOptions.shouldUpdate #" no-popover="#= iconOptions.noPopover #" obj_id="#= obj_id #">
		</nmsweb-icon>#: obj_name #
	</td>
</tr>
