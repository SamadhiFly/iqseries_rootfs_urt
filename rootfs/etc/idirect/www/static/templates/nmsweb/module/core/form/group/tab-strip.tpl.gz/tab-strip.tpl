<p class="tabView" ng-if="schema.fieldDetails.viewToggle">
        <label for="viewType">{{viewType ? "Collapse tabs":"Expand tabs"}}</label>
        <input id="viewType" ng-model="viewType" ng-init="viewType = false" ng-change="toggleViewType(viewType)" type="checkbox" value="1" /> </p>
<span class="mobile-tabs-holder">
        <select ng-model="selectedTab" ng-init="selectedTab = 0" ng-change="changeTab(selectedTab)">
                <option value="{{$index}}" ng-repeat="tab in schema.contents">{{tab.label}}</option>
        </select>
</span>
<ul>
        <li ng-repeat="tab in schema.contents" ng-hide="tab.hide">{{tab.label}}</li>
</ul>
<div ng-repeat="tab in schema.contents">
        <!-- <h3 class="tabLabel" class="hide">{{tab.label}}</h3> -->
        <nmsweb-form-element schema="tab" form="form" class="nmsweb-tab"></nmsweb-form-element>
</div>