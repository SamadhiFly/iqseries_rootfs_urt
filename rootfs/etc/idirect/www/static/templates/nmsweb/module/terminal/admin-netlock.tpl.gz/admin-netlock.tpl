<h1>{{translation.language.admin_netlock}}</h1>
<div ng-if="model == 'iQDesktop'">
<div class="accordion status-accordion" ng-class="{'active': active['status']}" ng-click="toggle('status', $event)">{{translation.language.lock_status}}</div>
<div class="panel status" ng-style="{'maxHeight': panelScrollHeight['status']}">
	<nmsweb-form schema="status_form" ng-attr-name="{{status-form.name}}"></nmsweb-form>
</div>
<div class="accordion lock-accordion" ng-class="{'active': active['lock']}" ng-click="toggle('lock', $event)">{{sectionTitle}}</div>
<div class="panel lock" ng-style="{'maxHeight': panelScrollHeight['lock']}">
	<nmsweb-form schema="lock_form" ng-attr-name="{{status-form.name}}"></nmsweb-form>
	<div class="commissioning-info info" ng-if="currentStatus === lockedStatus.unlocked">{{translation.language.unlocked_info}}</div>
	<div class="commissioning-info info" ng-if="[lockedStatus.tempProgress, lockedStatus.softProgress, lockedStatus.hardProgress].indexOf(currentStatus) !== -1">
		{{translation.language.tempProgress_softProgress_info}}.<br/>
		{{translation.language.tempProgress_softProgress_info_2}}.
	</div>
	<div class="commissioning-info info" ng-if="[lockedStatus.tempLock, lockedStatus.softLock].indexOf(currentStatus) !== -1">{{translation.language.tempLock_softLock_info}}</div>
	<div class="commissioning-info warning" ng-if="currentStatus === lockedStatus.softProgress">
		{{translation.language.netlock_warning}}!<br/>
		{{translation.language.softLock_warning}}.<br/>
		{{translation.language.softLock_warning_2}}.<br/>
		{{translation.language.softLock_warning_3}}.
	</div>
	<div class="commissioning-info warning" ng-if="currentStatus === lockedStatus.hardProgress">
		{{translation.language.netlock_warning}}!<br/>
		{{translation.language.hardLock_warning}}.<br/>
		{{translation.language.hardLock_warning_2}}.<br/>
		{{translation.language.hardLock_warning_3}}.
	</div>
	<button class="terminal-btn" ng-disabled="checkFormInvalid(['lock-lock-type', 'lock-netkey'])" ng-class="{'disabled': checkFormInvalid(['lock-lock-type', 'lock-netkey'])}" ng-click="lock()" ng-if="currentStatus === lockedStatus.unlocked">{{translation.language.lock}}</button>
	<button class="terminal-btn" ng-disabled="checkFormInvalid(['lock-lock-type', 'lock-netkey', 'lock-netkey-fingerprint', 'lock-confirmation-word'])" ng-class="{'disabled': checkFormInvalid(['lock-lock-type', 'lock-netkey', 'lock-netkey-fingerprint', 'lock-confirmation-word'])}" ng-click="confirm()" ng-if="[lockedStatus.tempProgress, lockedStatus.softProgress, lockedStatus.hardProgress].indexOf(currentStatus) !== -1">{{translation.language.confirm}}</button>
	<!--<button class="terminal-btn" ng-click="cancel()" ng-if="[lockedStatus.tempProgress, lockedStatus.softProgress, lockedStatus.hardProgress].indexOf(currentStatus) !== -1">{{translation.language.cancel}}</button>-->
	<button class="terminal-btn" ng-disabled="checkFormInvalid(['lock-netkey-fingerprint', 'lock-confirmation-word'])" ng-class="{'disabled': checkFormInvalid(['lock-netkey-fingerprint', 'lock-confirmation-word'])}" ng-click="unlock()" ng-if="[lockedStatus.softLock, lockedStatus.tempLock].indexOf(currentStatus) !== -1">{{translation.language.unlock}}</button>
 </div>
 <!-- <div style="margin-top:100px;">
	<button class="terminal-btn" ng-click="setStatus('unlocked')">unlocked</button>
	<button class="terminal-btn" ng-click="setStatus('tempProgress')">tempProgress</button>
	<button class="terminal-btn" ng-click="setStatus('tempLock')">tempLock</button>
	<button class="terminal-btn" ng-click="setStatus('softProgress')">softProgress</button>
	<button class="terminal-btn" ng-click="setStatus('softLock')">softLock</button>
	<button class="terminal-btn" ng-click="setStatus('hardProgress')">hardProgress</button>
	<button class="terminal-btn" ng-click="setStatus('hardLock')">hardLock</button>
</div>   -->
</div>
<div class="commissioning-info" ng-if="model != 'iQDesktop'">
	<p>{{translation.language.no_netlock}}</p>
</div>