<p>{{translation.cpu_load}} {{TerminalStreamingValues['terminal/ip/vlan/sat/1'].data.id}}</p>
<p>First i18n Test. Key antenna_configuration is {{translation.language.start}}</p>
