<div>
    <div ng-if="model != '950mp'">
        <div class="span12">
            <fieldset class="table-fieldset">
                <legend>
                    {{translation.language.general}}
                </legend>
                <div class="directive-contents">
                    <div class="enable-filtering" id="manual-downstream-enable-filtering-container">
                        <label style="font-weight: bold;" ng-click="toggleEnableFiltering()">Enable Filtering
						<span ng-class="{'checked' : enableFilteringEnable, 'k-state-disabled' : disabledFilteringEnable}" style="float: right; position: inherit;" class="checkbox-label" class="view-mode-checkbox">

						</span>
					</label>
                    </div>
                </div>
            </fieldset>
        </div>
        <div class="span12">
            <fieldset class="table-fieldset">
                <legend>
                    {{translation.language.configuration}}
                </legend>
                <div class="directive-contents">
                    <div class="ng-scope interval" id="manual-downstream-interval-container">
                        <label style="font-weight: bold;" style="display: inline-block;">
						{{translation.language.interval}}
					</label>
                        <nmsweb-tooltip tooltip="tooltip_interval">
                        </nmsweb-tooltip>
                        <span style="margin-left: 20px;" class="k-widget k-numerictextbox">
							<span class="k-numeric-wrap k-state-default">
								<input type="text" ng-change="validate()" class="k-formatted-value k-input" tabindex="0" style="display: inline-block;" aria-disabled="false" aria-readonly="false" ng-model="multicast.model.interval">
							</span>
                        </span>
                        <h5 class="unit-ranges">
                            <span>sec</span>
                            <span>
								(1 - 30)
							</span>
                        </h5>
                    </div>
                    <div class="ng-scope activity_threshold" id="manual-downstream-activity_threshold-container">
                        <label style="font-weight: bold;" style="display: inline-block;">
							{{translation.language.activity_threshold}}
						</label>
                        <nmsweb-tooltip tooltip="tooltip_active_threshold">
                        </nmsweb-tooltip>
                        <span style="margin-left: 20px;" class="k-widget k-numerictextbox">
							<span class="k-numeric-wrap k-state-default">
								<input type="text" ng-change="validate()" class="k-formatted-value k-input" tabindex="0" style="display: inline-block;" aria-disabled="false" aria-readonly="false" ng-model="multicast.model.activity_threshold">
							</span>
                        </span>
                        <h5 class="unit-ranges">
                            <span>packets / interval</span>
                            <span>
								(1 - 100000)
							</span>
                        </h5>
                    </div>
                    <div class="ng-scope inactivity_threshold" id="manual-downstream-inactivity_threshold-container">
                        <label style="font-weight: bold;" style="display: inline-block;">
							{{translation.language.inactivity_threshold}}
					</label>
                        <nmsweb-tooltip tooltip="tooltip_inactive_threshold">
                        </nmsweb-tooltip>
                        <span style="margin-left: 20px;" class="k-widget k-numerictextbox">
						<span class="k-numeric-wrap k-state-default">
							<input type="text" ng-change="validate()" class="k-formatted-value k-input" tabindex="0" style="display: inline-block;" aria-disabled="false" aria-readonly="false" ng-model="multicast.model.inactivity_threshold">
						</span>
                        </span>
                        <h5 class="unit-ranges">
                            <span>packets / interval</span>
                            <span>
							(1 - {{upperthreshold}})
						</span>
                        </h5>
                    </div>
                </div>
            </fieldset>
        </div>
        <div class="span12">
            <button ng-click="saveMulticast()" style="margin-top:10px;float:right">
		{{translation.language.save}}
	</button>
        </div>
    </div>
    <div ng-if="model == '950mp'" class="commissioning-info">{{translation.language.not_supported_by_platform}}</div>
</div>