<div id={{nmswebOptions.id}} class="data-elementselectorgrid n-elementselectorgrid elementselector-angular-directive" nmsweb-elementselector-icon-popover="mainPopoverWidget">
	<form class='new-fe' ng-if="dataLoaded" ng-show="mainGridWidget.advSearchShown || mainGridWidget.advancedSearch && mainGridWidget.advancedSearch.alwaysOpened">
		<nmsweb-elementselector-adv-search datasource="datasource" initial-groups="advancedSearchGroups"></nmsweb-elementselector-adv-search>
	</form>
	<nmsweb-elementselector-grid ng-if="dataLoaded" ng-model="_isolate.ngModelMainGrid" nmsweb-options="_isolate.gridOptions" nmsweb-model="_isolate.selectedObjects" widget="_isolate.mainGridWidget"></nmsweb-elementselector-grid>
	<span ng-if="nmswebOptions.advancedSearch && !nmswebOptions.advancedSearch.alwaysOpened" class='advanced-search-toggle'>
		<a ng-click="showAdvancedSearch()" ng-hide="mainGridWidget.advSearchShown">Advanced Search</a>
		<a ng-click="hideAdvancedSearch()" ng-show="mainGridWidget.advSearchShown">Hide Advanced Search</a>
	</span>
	<span ng-if="nmswebOptions.useComposites" ng-show="nmswebOptions.compositesMapping && nmswebOptions.sameTypesSelected && mainGridWidget" class='composites-toggle'>
		<a ng-click="showComposites()" ng-hide="compositesShown">Show Composites Filter</a>
		<a ng-click="hideComposites()" ng-show="compositesShown">Hide Composites Filter</a>
	</span>
	<span ng-if="nmswebOptions.showRefineInAdvancedSearch" ng-hide="mainGridWidget.advSearchShown" class="refine-in-advanced-search">
		<a class="btn n-element-selector-btn" ng-click="(nmswebOptions.callbackRefineAdvancedSearch) ? nmswebOptions.callbackRefineAdvancedSearch() : datasource.refineInAdvancedSearch()">Refine in Advanced Search</a>
	</span>
	<div class="no-data-overlay hide">
		<span class="no-data-msg">
			<p class="title"></p>
			<p class="content"></p>
		</span>
	</div>
	<nmsweb-elementselector-grid ng-model="_isolate.ngModelComposites" ng-show="_isolate.compositesShown" nmsweb-options="_isolate.nmswebOptions.compositeGridOptions" nmsweb-model="_isolate.selectedComposites" widget="_isolate.compositesWidget" ng-if="dataLoaded"></nmsweb-elementselector-grid>
<div>
