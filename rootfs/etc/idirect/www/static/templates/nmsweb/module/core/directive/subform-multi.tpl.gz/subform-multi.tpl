<div class="n-subform">
	<nmsweb-window widget="schema.window.widget" nmsweb-options="schema.window">
		<nmsweb-form-element ng-repeat="element in schema.layout" schema="element" form="schema"></nmsweb-form-element>
		<div class="remaining-fields"></div>
		<button ng-click="schema.window.save()">Save</button>
	</nmsweb-window>
	<div ng-repeat="useSchema in schema.use">
		<nmsweb-window widget="useSchema.window.widget" nmsweb-options="useSchema.window">
			<div>
				<nmsweb-multiselect widget="useSchema.select.widget" nmsweb-options="useSchema.select"></nmsweb-multiselect>
			</div>
			<button ng-click="useSchema.window.save()">Save</button>
		</nmsweb-window>
	</div>
	<nmsweb-subform-grid widget="schema.grid.widget" nmsweb-options="schema.grid" form="schema"></nmsweb-subform-grid>
</div>
