<div class="value-wrapper">
  <input ng-show="!nmswebOptions.readonly" id="{{nmswebOptions.fieldDetails.id}}" ng-model="model" name={{nmswebOptions.name}} type={{nmswebOptions.nmswebType}} ng-minlength={{nmswebOptions.minlength}} ng-maxlength={{nmswebOptions.maxlength}} ng-pattern={{nmswebOptions.pattern}} ng-required={{nmswebOptions.required}} step={{nmswebOptions.step}} ng-disabled="{{additionalOptions.viewMode || nmswebOptions.readonly}}" ng-readonly="{{nmswebOptions.readonly}}" ng-class="{'password-view-mode': isPasswordFieldViewMode}" placeholder="{{nmswebOptions.placeholder}}" />
  <span ng-show="nmswebOptions.readonly" name="{{nmswebOptions.name}}">
    {{model}}
  </span>
</div>
