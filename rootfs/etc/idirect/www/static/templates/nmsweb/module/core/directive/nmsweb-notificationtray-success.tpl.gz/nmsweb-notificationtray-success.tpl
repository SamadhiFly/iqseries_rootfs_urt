<div class="notification-success">
    <b ng-if="successMsgs.length === 1">{{ successMsgs.length }} action was successfully completed </b> <br/>
    <b ng-if="successMsgs.length !== 1">{{ successMsgs.length }} actions were successfully completed </b> <br/>
    <ul>
        <li ng-repeat="notificationItem in successMsgs track by $index">{{notificationItem}}</li>
    </ul>
</div>