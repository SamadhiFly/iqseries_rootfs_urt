<h1>{{translation.language.administration}} - {{translation.language.external_equipment}}</h1>
<div ng-if="$root.system_type !== 'EVOLUTION'">
<fieldset class="ng-scope ng-isolate-scope buc">
  <legend class="ng-binding">{{translation.language.buc}}</legend>
  <div class="table_wrapper">
    <table style="width:500px">
      <tbody>
        <tr>
          <td>{{translation.language.block_up_converter_buc}}</td>
          <td>
            <div class="upload_wrapper">
              <input kendo-upload k-options="upload_buc" type="file" name="buc"/>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</fieldset>
<fieldset class="ng-scope ng-isolate-scope external-files">
  <legend class="ng-binding">{{translation.language.external_files}}</legend>
  <p>{{translation.language.upload_external_file}}:
    <div class="upload_wrapper">
      <input kendo-upload k-options="upload_external_file" type="file" name="upload_external_file"/>
    </div>
  </p>
  <div class="table_wrapper">
    <table style="width:1200px" class="terminal-table">
      <thead>
        <tr>
          <th>{{translation.language.description}}</th>
          <th>{{translation.language.filename}}</th>
          <th>{{translation.language.version}}</th>
          <th>{{translation.language.date}}</th>
          <th>{{translation.language.size}}</th>
          <th>{{translation.language.type}}</th>
        </tr>
      </thead>
      <tbody>
        <tr ng-repeat="i in externalFiles">
          <td>{{ i.description }}</td>
          <td>{{ i.filename }}</td>
          <td>{{ i.version }}</td>
          <td>{{ i.timestamp | date:'MM/dd/yyyy' }}</td>
          <td>{{ i.size }}</td>
          <td>{{ i.type }}</td>
        </tr>
      <tbody>
    </table>
  </div>
</fieldset>
</div>
<div ng-if="$root.system_type === 'EVOLUTION'" class="commissioning-info">{{translation.language.evolution_external_equipment_notice}}</div>
