<div ng-cloak>
	<label ng-attr-for="{{field.options.fieldDetails.id || field.id}}" ng-if="field.options.fieldDetails.chart_options.type !== 'fieldset'">
		{{field.options.label}}<span class="checkbox-label" ng-class="{'checked': model[field.name],'view-mode-checkbox': field.additionalOptions.viewMode}" ng-show="field.options.type == 'checkbox'"></span>
	</label>
	<nmsweb-field ng-if="field.options.fieldDetails.chart_options.type !== 'fieldset'" ng-attr-id="{{field.id}}" field="field" ng-model="model[field.name]" ng-change="checkDependencies(field.name)"></nmsweb-field>
	<div class="checkbox-placeholder" ng-if="field.options.fieldDetails.chart_options.type !== 'fieldset'" ng-show="field.options.type == 'checkbox'"></div>
	<h5 class="unit-ranges" ng-if="field.options.fieldDetails.chart_options.type !== 'fieldset'">
		<span class="ng-hide" ng-show="field.options.unit">{{field.options.unit}}</span>
		<span class="ng-hide" ng-show="field.options.range_start !== undefined && field.options.range_end !== undefined && field.options.range_start != '' && field.options.range_end != ''">
			({{field.options.range_start}} - {{field.options.range_end}})
		</span>
	</h5>
	<div class="wrapper-icon" ng-if="field.options.fieldDetails.chart_options.type !== 'fieldset'">
		<nmsweb-field-tooltip tooltips="field.options.tooltips"></nmsweb-field-tooltip>
		<chart ng-if="model[field.name] != '-'" resource="field.options.fieldDetails.chart_options.resource" respath="field.options.fieldDetails.chart_options.respath" resolutionlive="field.options.fieldDetails.chart_options.resolutionlive" resolutionbuffer="field.options.fieldDetails.chart_options.resolutionbuffer" streaminginterval="field.options.fieldDetails.chart_options.streaminginterval" buffer="field.options.fieldDetails.chart_options.buffer" field="field.options.fieldDetails.chart_options.field" unit="field.options.fieldDetails.chart_options.unit" type="field.options.fieldDetails.chart_options.type" tooltipoptions="field.options.fieldDetails.chart_options.tooltipoptions" min="field.options.fieldDetails.chart_options.min" max="field.options.fieldDetails.chart_options.max" maxpoints="field.options.fieldDetails.chart_options.maxpoints"></chart>
	</div>
	<chart ng-if="field.options.fieldDetails.chart_options.type === 'fieldset'" resource="field.options.fieldDetails.chart_options.resource" respath="field.options.fieldDetails.chart_options.respath" resolutionlive="field.options.fieldDetails.chart_options.resolutionlive" streaminginterval="field.options.fieldDetails.chart_options.streaminginterval" resolutionbuffer="field.options.fieldDetails.chart_options.resolutionbuffer" buffer="field.options.fieldDetails.chart_options.buffer" field="field.options.fieldDetails.chart_options.field" unit="field.options.fieldDetails.chart_options.unit" type="field.options.fieldDetails.chart_options.type" tooltipoptions="field.options.fieldDetails.chart_options.tooltipoptions" min="field.options.fieldDetails.chart_options.min" max="field.options.fieldDetails.chart_options.max" maxpoints="field.options.fieldDetails.chart_options.maxpoints"></chart>
</div>
