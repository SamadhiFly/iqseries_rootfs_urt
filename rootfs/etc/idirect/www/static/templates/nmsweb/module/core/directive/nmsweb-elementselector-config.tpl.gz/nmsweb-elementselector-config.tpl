<div>
	<div class="n-elementselector" nmsweb-spin="requestingData">
		<input ng-show="nmswebOptions.showFilterBox" ng-change="filter()" ng-model="filterBox" class="ng-valid ng-dirty input-large n-datasourcefilter" placeholder="Search..." />
		<div kendo-grid="widget" class="n-elementselectorgrid n-grid data-elementselectorgrid" k-options="nmswebOptions.grid"></div>
		<div ng-show="nmswebOptions.grid.selectable" class="k-pager-wrap k-grid-pager old-es">
			<span class="k-label n-selection-info"><span class="n-selection-counter">{{selectedData.length}}</span> of <span class="n-selection-total">{{nmswebOptions.grid.dataSource.total()}}</span> selected (<span class="n-selection-options"><a class="k-label n-select-all" href="#" ng-click="selectAll()">select all</a> | <a class="k-label n-deselect" href="#" ng-click="deselectAll()">deselect all</a></span>)
			</span>
		</div>
		<input type="button" class="btn btn-primary pull-right" ng-show="nmswebOptions.selectElement.showSelectButton" ng-click="nmswebOptions.selectElement.selectButtonCallback(selectedData)" value="Select Elements"></input>
	</div>
</div>