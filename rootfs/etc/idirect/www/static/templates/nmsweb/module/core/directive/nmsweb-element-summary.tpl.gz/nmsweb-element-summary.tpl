<h2>Element Summary</h2>

<nmsweb-keyvalue nmsweb-options="keyvalueOptions" additional-options="additionalOptions" ng-model="configData" widget="nmswebKeyvalue"></nmsweb-keyvalue>
