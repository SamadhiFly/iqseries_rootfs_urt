<h1>{{translation.language.administration}} - {{translation.language.transec}}</h1>

<div class="commissioning-info" ng-show="transecResponse && !transecDataLoaded">
    <p ng-if="transec_status == 'limited'"><a href="/#/software_and_configuration">{{transec_status_message}}</a></p>
    <p ng-if="transec_status != 'limited'">{{transec_status_message}}</p>
</div>

<div ng-if="transecResponse && transecDataLoaded">
    <form class="n-form new-fe n-form-horizontal-rendering">
        <fieldset>
            <legend>{{translation.language.general}}</legend>
            <div class="directive-contents">
                <label ng-for="did">{{translation.language.transec_did}}</label><span>{{transec_did}}</span>
            </div>
        </fieldset>
    </form>
</div>

<div ng-if="layout && transecDataLoaded" class="transec">
    <nmsweb-dashboard layout='layout' height="1000" width="500" layout-parameters="{}"></nmsweb-dashboard>
</div>
