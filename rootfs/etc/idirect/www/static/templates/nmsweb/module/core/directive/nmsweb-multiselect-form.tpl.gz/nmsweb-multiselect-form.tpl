<div class="multiselect">
        <select kendo-multi-select="widget" k-options="defaults" k-rebind="dataSource" k-data-source="dataSource" k-ng-model="model"></select>
</div>
