<svg version="1.1"
xmlns="http://www.w3.org/2000/svg"
xmlns:xlink="http://www.w3.org/1999/xlink"
	id="template_svg" height="300" style="display: none">

	<g id="detailNodeStyleTemplate">
		<rect fill="white" stroke="#3B93EA" width="350" height="100" />
		<line x1="10" y1="35" x2="340" y2="35" style="stroke:#545456;stroke-width:0.3;" />
		<rect x="2" y="43" fill="#F2F2F2" width="346" height="16" />
		<rect x="2" y="75" fill="#F2F2F2" width="346" height="16" />
		<image x="165" y="40" width="20" height="20" xlink:href="/static/images/spinner.svg"></image>
		<image class="icon" x="5" y="6" width="24" height="24" xlink:href="/static/images/spacer.svg" obj_id="{Binding obj_id}" obj_states="{Binding obj_states_json}" obj_type="{Binding obj_type}" />
		<image class="icon" x="13" y="12" width="22" height="22" xlink:href="/static/images/spacer.svg" obj_id="{Binding obj_id}" obj_states="{Binding obj_states_json}" obj_type="{Binding obj_type}" />

		<defs>
			<clipPath id="clip0">
				<rect width="245" height="35" />
			</clipPath>
		</defs>
		<g clip-path="url('#clip0')">
			<text  x="32" y="30"  style="font-size:13px; font-family:Arial; fill:#656567;" data-content="{Binding obj_name}"></text>
		</g>
		<defs>
			<clipPath id="clip1">
				<rect width="185" height="100"/>
			</clipPath>
		</defs>
		<g clip-path="url('#clip1')">
			<text  x="15" y="55" style="font-size:6px; font-family:Arial; fill:#656567;" data-content="{Binding field_1}"></text>
			<text  x="15" y="71" style="font-size:6px; font-family:Arial; fill:#656567;" data-content="{Binding field_3}"></text>
			<text x="15" y="87" style="font-size:6px; font-family:Arial; fill:#656567;" data-content="{Binding field_5}"></text>

			<text  x="75" y="55" style="font-size:6px; font-family:Arial; fill:#656567;" data-content="{Binding data_1}"></text>
			<text  x="75" y="71" style="font-size:6px; font-family:Arial; fill:#656567;" data-content="{Binding data_3}"></text>
			<text x="75" y="87" style="font-size:6px; font-family:Arial; fill:#656567;" data-content="{Binding data_5}"></text>
		</g>
		<defs>
			<clipPath id="clip2">
				<rect x="169" rx="8" ry="8" width="176" height="100"/>
			</clipPath>
		</defs>
		<g clip-path="url('#clip2')">
			<text x="180" y="55" style="font-size:6px; font-family:Arial; fill:#656567;" data-content="{Binding field_2}"></text>
			<text x="180" y="71" style="font-size:6px; font-family:Arial; fill:#656567;" data-content="{Binding field_4}"></text>
			<text x="180" y="87" style="font-size:6px; font-family:Arial; fill:#656567;" data-content="{Binding field_6}"></text>

			<text x="250" y="55" style="font-size:6px; font-family:Arial; fill:#656567;" data-content="{Binding data_2}"></text>
			<text x="250" y="71" style="font-size:6px; font-family:Arial; fill:#656567;" data-content="{Binding data_4}"></text>
			<text x="250" y="87" style="font-size:6px; font-family:Arial; fill:#656567;" data-content="{Binding data_6}"></text>
		</g>
		<rect onClick="$(this).parents('.orgchart').data('orgchart').toggle()" onMouseover="$(this).parents('.orgchart').data('orgchart').tileHover()" class="orgchart-tile" style="fill-opacity:0" width="350" height="100" />
		<g class="n-element-selector-actions orgchart-actions-hoverable">
			<rect x="315" y="15" fill="#3B93EA" width="25" height="16"  />

			<g transform="translate(2,-1)">
				<polygon points="321,22 325,26 329,22"  fill="white"/>
				<polygon points="321,20 325,24 329,20"  fill="#3B93EA"/>
			</g>
			<rect onClick="$(this).parents('.orgchart').data('orgchart').openOrgChartActions(this)" obj_id="{Binding obj_id}" obj_name="{Binding obj_name}" type="{Binding obj_type}" model="{Binding model}" x="315" y="15" style="fill-opacity:0"  width="90" height="16"  />
		</g>
	</g>

	<g id="intermediateNodeStyleTemplate">
		<rect fill="white" stroke="#3B93EA" width="350" height="100" />
		<line x1="10" y1="35" x2="340" y2="35" style="stroke:#545456;stroke-width:0.3;" />
		<image x="165" y="40" width="20" height="20" xlink:href="/static/images/spinner.svg"></image>
		<image class="icon" x="5" y="6" width="24" height="24" xlink:href="/static/images/spacer.svg" obj_id="{Binding obj_id}" obj_states="{Binding obj_states_json}" obj_type="{Binding obj_type}" />
		<image class="icon" x="13" y="12" width="22" height="22" xlink:href="/static/images/spacer.svg" obj_id="{Binding obj_id}" obj_states="{Binding obj_states_json}" obj_type="{Binding
		obj_type}" />
		<defs>
			<clipPath id="clip0">
				<rect width="245" height="50" />
			</clipPath>
		</defs>
		<g clip-path="url('#clip0')">
			<text  x="32" y="30"  style="font-size:13px; font-family:Arial; fill:#656567;" data-content="{Binding obj_name}"></text>
		</g>
		<defs>
			<clipPath id="clip1">
				<rect width="168" height="100"/>
			</clipPath>
		</defs>
		<g clip-path="url('#clip1')">
			<text  x="15" y="70" style="font-size:8px; font-family:Arial; fill:#656567;" data-content="{Binding field_1}"></text>
			<text  x="82" y="70" style="font-size:8px; font-family:Arial; fill:#656567;" data-content="{Binding data_1}"></text>
		</g>
		<defs>
			<clipPath id="clip2">
				<rect x="169" rx="8" ry="8" width="176" height="100"/>
			</clipPath>
		</defs>
		<g clip-path="url('#clip2')">
			<text x="180" y="70" style="font-size:8px; font-family:Arial; fill:#656567;" data-content="{Binding field_2}"></text>
			<text x="250" y="70" style="font-size:8px; font-family:Arial; fill:#656567;" data-content="{Binding data_2}"><text>
		</g>

		<rect onClick="$(this).parents('.orgchart').data('orgchart').toggle()" onMouseover="$(this).parents('.orgchart').data('orgchart').tileHover()" class="orgchart-tile" style="fill-opacity:0" width="350" height="100" />
		<g class="n-element-selector-actions orgchart-actions-hoverable">
			<rect x="315" y="15" fill="#3B93EA" width="25" height="16"  />

			<g transform="translate(2,-1)">
				<polygon points="321,22 325,26 329,22"  fill="white"/>
				<polygon points="321,20 325,24 329,20"  fill="#3B93EA"/>
			</g>
			<rect onClick="$(this).parents('.orgchart').data('orgchart').openOrgChartActions(this)" obj_id="{Binding obj_id}" obj_name="{Binding obj_name}" type="{Binding obj_type}" model="{Binding model}" x="315" y="15" style="fill-opacity:0" width="90" height="16"  />
		</g>
	</g>

	<g id="overviewNodeStyleTemplate">
		<rect class="orgchart-tile" onClick="$(this).parents('.orgchart').data('orgchart').toggle()" fill="white" stroke="#3B93EA" width="350" height="100" />
		<line  x1="10" y1="65" x2="340" y2="65" style="stroke:#565658;stroke-width:0.3;" />
		<image x="165" y="40" width="20" height="20" xlink:href="/static/images/spinner.svg"></image>
		<image class="icon orgchart-overview-icon" x="15" y="19" width="40" height="40" xlink:href="/static/images/spacer.svg" obj_id="{Binding obj_id}" obj_states="{Binding obj_states_json}" obj_type="{Binding obj_type}" />
		<image class="icon orgchart-overview-icon" x="24" y="27" width="34" height="34" xlink:href="/static/images/spacer.svg" obj_id="{Binding obj_id}" obj_states="{Binding obj_states_json}" obj_type="{Binding obj_type}" />
		<defs>
			<clipPath id="clip4">
				<rect width="320" height="100" />
			</clipPath>
		</defs>
		<g clip-path="url('#clip4')">
			<text  x="62" y="60"  style="font-size:20px; font-family:Arial; fill:#656567;" data-content="{Binding obj_name}"></text>
		</g>
	</g>
</svg>
