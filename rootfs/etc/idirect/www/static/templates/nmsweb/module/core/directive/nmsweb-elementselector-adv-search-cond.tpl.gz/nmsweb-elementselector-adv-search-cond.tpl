<div class="advanced-search-condition" nmsweb-spin="spin">
	<nmsweb-drop-down-list class="advanced-search-condition-field" widget='mainDropdown' nmsweb-options="mainDropdownOptions" ng-model="fieldValue"></nmsweb-drop-down-list>
	<!-- here options will change based whats selected in first dropdown list -->
	<nmsweb-drop-down-list class="advanced-search-condition-operator" widget='operatorDropdown' nmsweb-options="operatorOptions" ng-model='operatorValue'></nmsweb-drop-down-list>
	<nmsweb-multiselect class="advanced-search-condition-value" widget="advSearchMultiSelect" ng-show="conditionType==='dropdown' && (operatorValue ==='is' || operatorValue === 'isnot')" nmsweb-options='multiSelectOptions' ng-model='multiselectValue'></nmsweb-multiselect>
	<div class="advanced-search-condition-value" ng-show="conditionType==='text' || conditionType==='dropdown' && operatorValue !=='is' && operatorValue !== 'isnot'">
		<nmsweb-input class="advanced-search-condition-value" nmsweb-options="nmswebInputTextOptions" ng-model="inputValue1"></nmsweb-input>
	</div>
	<div class="advanced-search-condition-value" ng-class="{'advanced-search-condition-value-splitted':(operatorValue === 'isbetween' || operatorValue === 'isnotbetween')}" ng-show="conditionType==='number'">
		<nmsweb-numeric-text-box nmsweb-options='integerFieldOptions' widget='numericBox1' ng-model="inputValue1"></nmsweb-numeric-text-box>
		<span ng-show="operatorValue === 'isbetween' || operatorValue === 'isnotbetween'">
			<nmsweb-numeric-text-box nmsweb-options='integerFieldOptions' widget='numericBox2' ng-model="inputValue2"></nmsweb-numeric-text-box>
		</span>
	</div>
	<div class="advanced-search-condition-value" ng-class="{'advanced-search-condition-value-splitted':(operatorValue === 'isbetween' || operatorValue === 'isnotbetween')}" ng-show="conditionType==='ip'">
		<nmsweb-input nmsweb-options="nmswebInputIpOptions" ng-model="inputValue1"></nmsweb-input>
		<nmsweb-input ng-show="operatorValue === 'isbetween' || operatorValue === 'isnotbetween'" nmsweb-options="nmswebInputIpOptions" ng-model="inputValue2"></nmsweb-input>
	</div>
</div
