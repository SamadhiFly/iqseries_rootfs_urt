<div class="notification-error">
    <b ng-if="errorMsgs.length === 1">{{ errorMsgs.length }}  Error was found </b> <br/>
    <b ng-if="errorMsgs.length !== 1">{{ errorMsgs.length }} Errors were found </b> <br/>
    <ul>
        <li ng-repeat="notificationItem in errorMsgs track by $index">{{notificationItem}}</li>
    </ul>
</div>