<div widget="widget" class="ng-scope n-element-selector-status big-icon" ng-class="model.shape" ng-click="openPopover($event)">
	<div class="n-element-selector-status-configuration-icon" ng-class="model.config"></div>
</div>
