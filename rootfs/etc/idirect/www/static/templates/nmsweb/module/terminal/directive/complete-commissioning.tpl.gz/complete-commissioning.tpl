<div class="center">
        <!-- <div ng-if="!acquiringNetwork && foundNetwork">
                <h2 class="commissioningCompleted success">{{$root.translation.language.velo_commissioning_wizard_commissioning_completed}}</h2>
                <div class="commissioning-info success">
                        <p>{{$root.translation.language.network_has_been_acquired}}</p>
                </div>
                <div class="bigActiveHolder">
                        <button class="bigActive" ng-click="changePath('/')">{{$root.translation.language.return_to_dashboard}}</button>
                </div>
        </div>
        <div ng-if="!acquiringNetwork && !foundNetwork">
                <h2 class="commissioningFailed warning">{{$root.translation.language.velo_commissioning_wizard_commissioning_failed}}</h2>

                <div class="commissioning-info warning">
                        <p>{{$root.translation.language.no_network_has_been_acquired}}</p>
                </div>
                <div class="bigActiveHolder">
                        <button class="bigActive" ng-click="reloadPath()">{{$root.translation.language.restart_commissioning}}</button>
                </div>
        </div>

        <div ng-if="acquiringNetwork">
                <h2>{{$root.translation.language.velo_commissioning_wizard_exit_commissioning_mode}}</h2>

                <div class="commissioning-info">
                        <p>{{$root.translation.language.exiting_commissioning_mode_will_enable_the_terminal_to_acquire_network}}</p>
                </div>

                <p class="waitingForNetwork">{{$root.translation.language.please_wait_for_network}}</p>
                <p>{{remainingAqcuireTimeHuman}}</p>
        </div> -->
        <h2 class="commissioningCompleted success">{{$root.translation.language.commissioning_wizard_commissioning_completed}}</h2>
        <div class="commissioning-info success">
          <p>{{$root.translation.language.commissioning_complete_if_operational_network_is_active_modem_can_now_acquire_into_network}}<br/>
            {{$root.translation.language.please_check_leds_or_the_terminal_dashboard_for_acquisition_status}}</p>
        </div>
        <div class="bigActiveHolder">
                <button class="bigActive" ng-click="changePath('/')">{{$root.translation.language.return_to_dashboard}}</button>
        </div>
</div>
