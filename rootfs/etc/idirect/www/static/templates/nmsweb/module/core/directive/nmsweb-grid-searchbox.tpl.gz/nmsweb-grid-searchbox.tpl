<div>
    <input ng-model='gridSearchboxModel' placeholder='Search...' type='text' class='nmsweb-grid-searchbox'></input>
</div>
