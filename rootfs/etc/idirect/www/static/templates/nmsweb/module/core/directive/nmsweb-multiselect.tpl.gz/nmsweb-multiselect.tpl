<div class="k-content">
    <select kendo-multi-select="widget" k-options="defaults" k-ng-model="model"></select>
</div>
