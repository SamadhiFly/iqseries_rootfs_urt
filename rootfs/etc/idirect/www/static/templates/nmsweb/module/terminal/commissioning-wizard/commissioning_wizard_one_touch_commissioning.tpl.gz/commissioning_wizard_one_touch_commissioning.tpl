<h2>{{$root.translation.language.one_touch_commissioning}}</h2>

<one-touch-commissioning downstream-configuration="stepData['commissioning_wizard_configure_downstream']" valid="config.steps['commissioning_wizard_one_touch_commissioning'].buttons[0].enabled"></one-touch-commissioning>
