<div>
<h1 style="font-size:400%">403</h1>
<p style="font-size:large;padding-top:20px;">{{translation.language.you_are_not_authorized}}.</p>
</div>
