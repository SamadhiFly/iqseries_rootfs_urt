<nmsweb-composition nmsweb-options="compositionOptions" ng-model="form.data" name="my_composition"></nmsweb-composition>

<br /><br /><br />
<h4>Datasource</h4>
{{ compositionOptions.dataSource.data() }}

<h4>ngModel</h4>

{{ form.data }}


<h4>form.data[0].name</h4>
<input ng-model="form.data[0].name">
</input>

<h4>form.data[0].department</h4>
<input ng-model="form.data[0].department">
</input>

<h4>form.data[0].size.id</h4>
<input ng-model="form.data[0].size">
</input>

<h4>form.data[0].quantity</h4>
<input ng-model="form.data[0].quantity">
</input>